export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_settings: {
        Row: {
          daily_box_target: number
          daily_roll_target: number
          held_up_cost_rate: number
          id: string
          shift_end: string
          shift_start: string
          updated_at: string
        }
        Insert: {
          daily_box_target?: number
          daily_roll_target?: number
          held_up_cost_rate?: number
          id?: string
          shift_end?: string
          shift_start?: string
          updated_at?: string
        }
        Update: {
          daily_box_target?: number
          daily_roll_target?: number
          held_up_cost_rate?: number
          id?: string
          shift_end?: string
          shift_start?: string
          updated_at?: string
        }
        Relationships: []
      }
      api_audit_log: {
        Row: {
          client_id: string | null
          client_name: string | null
          created_at: string
          duration_ms: number | null
          id: number
          ip: string | null
          method: string
          query: string | null
          resource: string | null
          row_count: number | null
          status: number
        }
        Insert: {
          client_id?: string | null
          client_name?: string | null
          created_at?: string
          duration_ms?: number | null
          id?: never
          ip?: string | null
          method: string
          query?: string | null
          resource?: string | null
          row_count?: number | null
          status: number
        }
        Update: {
          client_id?: string | null
          client_name?: string | null
          created_at?: string
          duration_ms?: number | null
          id?: never
          ip?: string | null
          method?: string
          query?: string | null
          resource?: string | null
          row_count?: number | null
          status?: number
        }
        Relationships: []
      }
      api_clients: {
        Row: {
          allowed_tables: string[] | null
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          key_hash: string
          key_prefix: string
          last_used_at: string | null
          name: string
          rate_limit_per_minute: number
          revoked_at: string | null
          scopes: string[]
        }
        Insert: {
          allowed_tables?: string[] | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          key_hash: string
          key_prefix: string
          last_used_at?: string | null
          name: string
          rate_limit_per_minute?: number
          revoked_at?: string | null
          scopes?: string[]
        }
        Update: {
          allowed_tables?: string[] | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          key_hash?: string
          key_prefix?: string
          last_used_at?: string | null
          name?: string
          rate_limit_per_minute?: number
          revoked_at?: string | null
          scopes?: string[]
        }
        Relationships: []
      }
      api_rate_counters: {
        Row: {
          client_key: string
          count: number
          window_start: string
        }
        Insert: {
          client_key: string
          count?: number
          window_start: string
        }
        Update: {
          client_key?: string
          count?: number
          window_start?: string
        }
        Relationships: []
      }
      cc_daily_actuals: {
        Row: {
          counted_qty: number
          created_at: string
          entry_date: string
          id: string
          item_code: string
          updated_at: string
          warehouse: string
        }
        Insert: {
          counted_qty?: number
          created_at?: string
          entry_date: string
          id?: string
          item_code: string
          updated_at?: string
          warehouse: string
        }
        Update: {
          counted_qty?: number
          created_at?: string
          entry_date?: string
          id?: string
          item_code?: string
          updated_at?: string
          warehouse?: string
        }
        Relationships: []
      }
      cc_monthly_targets: {
        Row: {
          created_at: string
          id: string
          item_code: string
          month: string
          target_qty: number
          updated_at: string
          warehouse: string
        }
        Insert: {
          created_at?: string
          id?: string
          item_code: string
          month: string
          target_qty?: number
          updated_at?: string
          warehouse: string
        }
        Update: {
          created_at?: string
          id?: string
          item_code?: string
          month?: string
          target_qty?: number
          updated_at?: string
          warehouse?: string
        }
        Relationships: []
      }
      cycle_count_logs: {
        Row: {
          available_qty: number
          batch_id: string | null
          category: string
          count_by: string
          created_at: string
          grand_qty: number
          id: string
          material_code: string
          material_description: string
          updated_at: string
          upload_date: string
        }
        Insert: {
          available_qty?: number
          batch_id?: string | null
          category: string
          count_by: string
          created_at?: string
          grand_qty?: number
          id?: string
          material_code: string
          material_description?: string
          updated_at?: string
          upload_date?: string
        }
        Update: {
          available_qty?: number
          batch_id?: string | null
          category?: string
          count_by?: string
          created_at?: string
          grand_qty?: number
          id?: string
          material_code?: string
          material_description?: string
          updated_at?: string
          upload_date?: string
        }
        Relationships: []
      }
      fabric_downtime: {
        Row: {
          concern: string
          created_at: string
          entry_date: string
          id: string
          lost_hours: number
          notes: string | null
          updated_at: string
        }
        Insert: {
          concern: string
          created_at?: string
          entry_date: string
          id?: string
          lost_hours?: number
          notes?: string | null
          updated_at?: string
        }
        Update: {
          concern?: string
          created_at?: string
          entry_date?: string
          id?: string
          lost_hours?: number
          notes?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      fabric_picker_achievements: {
        Row: {
          created_at: string
          epf_number: string
          id: string
          picked_at: string
          picker_name: string | null
          plan_id: string | null
          po_number: string
        }
        Insert: {
          created_at?: string
          epf_number: string
          id?: string
          picked_at?: string
          picker_name?: string | null
          plan_id?: string | null
          po_number: string
        }
        Update: {
          created_at?: string
          epf_number?: string
          id?: string
          picked_at?: string
          picker_name?: string | null
          plan_id?: string | null
          po_number?: string
        }
        Relationships: []
      }
      fabric_picker_targets: {
        Row: {
          created_at: string
          epf_number: string
          gin_target_per_day: number
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          epf_number: string
          gin_target_per_day?: number
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          epf_number?: string
          gin_target_per_day?: number
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      fabric_plan: {
        Row: {
          created_at: string
          cut_date: string | null
          id: string
          order_description: string | null
          order_qty: number | null
          picker_date: string | null
          picker_epf: string | null
          picker_name: string | null
          production_order: string
          so_li: string | null
          so_no: string | null
          start_date: string | null
          updated_at: string
          uploaded_at: string
          work_center: string | null
        }
        Insert: {
          created_at?: string
          cut_date?: string | null
          id?: string
          order_description?: string | null
          order_qty?: number | null
          picker_date?: string | null
          picker_epf?: string | null
          picker_name?: string | null
          production_order: string
          so_li?: string | null
          so_no?: string | null
          start_date?: string | null
          updated_at?: string
          uploaded_at?: string
          work_center?: string | null
        }
        Update: {
          created_at?: string
          cut_date?: string | null
          id?: string
          order_description?: string | null
          order_qty?: number | null
          picker_date?: string | null
          picker_epf?: string | null
          picker_name?: string | null
          production_order?: string
          so_li?: string | null
          so_no?: string | null
          start_date?: string | null
          updated_at?: string
          uploaded_at?: string
          work_center?: string | null
        }
        Relationships: []
      }
      green_board_concerns: {
        Row: {
          board_key: string
          created_at: string
          id: string
          is_active: boolean
          label: string
          sort_order: number
        }
        Insert: {
          board_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          label: string
          sort_order?: number
        }
        Update: {
          board_key?: string
          created_at?: string
          id?: string
          is_active?: boolean
          label?: string
          sort_order?: number
        }
        Relationships: []
      }
      green_board_entries: {
        Row: {
          board_key: string
          concern_id: string
          created_at: string
          entry_date: string
          id: string
          note: string
          shift: string
          submission_count: number
          updated_at: string
        }
        Insert: {
          board_key?: string
          concern_id: string
          created_at?: string
          entry_date: string
          id?: string
          note?: string
          shift?: string
          submission_count?: number
          updated_at?: string
        }
        Update: {
          board_key?: string
          concern_id?: string
          created_at?: string
          entry_date?: string
          id?: string
          note?: string
          shift?: string
          submission_count?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "green_board_entries_concern_id_fkey"
            columns: ["concern_id"]
            isOneToOne: false
            referencedRelation: "green_board_concerns"
            referencedColumns: ["id"]
          },
        ]
      }
      grn_pending_reasons: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          label: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          label: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          label?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: []
      }
      held_up_rates: {
        Row: {
          rate_per_hour: number
          updated_at: string
          vehicle_size: string
        }
        Insert: {
          rate_per_hour?: number
          updated_at?: string
          vehicle_size: string
        }
        Update: {
          rate_per_hour?: number
          updated_at?: string
          vehicle_size?: string
        }
        Relationships: []
      }
      invoice_daily_log: {
        Row: {
          created_at: string
          fabric_completed: number
          fabric_received: number
          id: string
          log_date: string
          trims_completed: number
          trims_received: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          fabric_completed?: number
          fabric_received?: number
          id?: string
          log_date: string
          trims_completed?: number
          trims_received?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          fabric_completed?: number
          fabric_received?: number
          id?: string
          log_date?: string
          trims_completed?: number
          trims_received?: number
          updated_at?: string
        }
        Relationships: []
      }
      pending_invoices: {
        Row: {
          completed_at: string | null
          completed_by: string | null
          created_at: string
          id: string
          invoice_no: string
          merchant: string
          pcu_comment: string
          pcu_member: string
          po_number: string
          reason: string
          received_date: string
          status: string
          supplier: string
          updated_at: string
        }
        Insert: {
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          id?: string
          invoice_no?: string
          merchant?: string
          pcu_comment?: string
          pcu_member?: string
          po_number?: string
          reason?: string
          received_date?: string
          status?: string
          supplier?: string
          updated_at?: string
        }
        Update: {
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string
          id?: string
          invoice_no?: string
          merchant?: string
          pcu_comment?: string
          pcu_member?: string
          po_number?: string
          reason?: string
          received_date?: string
          status?: string
          supplier?: string
          updated_at?: string
        }
        Relationships: []
      }
      picker_achievements: {
        Row: {
          created_at: string
          epf_number: string
          id: string
          picked_at: string
          picker_name: string | null
          plan_id: string | null
          po_number: string
        }
        Insert: {
          created_at?: string
          epf_number: string
          id?: string
          picked_at?: string
          picker_name?: string | null
          plan_id?: string | null
          po_number: string
        }
        Update: {
          created_at?: string
          epf_number?: string
          id?: string
          picked_at?: string
          picker_name?: string | null
          plan_id?: string | null
          po_number?: string
        }
        Relationships: [
          {
            foreignKeyName: "picker_achievements_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "trims_plan"
            referencedColumns: ["id"]
          },
        ]
      }
      picker_targets: {
        Row: {
          created_at: string
          epf_number: string
          gin_target_per_day: number
          id: string
          is_active: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          epf_number: string
          gin_target_per_day?: number
          id?: string
          is_active?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          epf_number?: string
          gin_target_per_day?: number
          id?: string
          is_active?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      sample_handovers: {
        Row: {
          courier: string
          created_at: string
          entered_by: string
          entry_date: string
          gdn_number: string
          handed_over_at: string | null
          handed_over_to: string
          id: string
          item_description: string
          notes: string
          origin: string
          photo_url: string | null
          qty: number
          received_at: string
          recipient: string
          status: string
          updated_at: string
          vehicle_number: string
        }
        Insert: {
          courier?: string
          created_at?: string
          entered_by?: string
          entry_date?: string
          gdn_number?: string
          handed_over_at?: string | null
          handed_over_to?: string
          id?: string
          item_description?: string
          notes?: string
          origin?: string
          photo_url?: string | null
          qty?: number
          received_at?: string
          recipient?: string
          status?: string
          updated_at?: string
          vehicle_number?: string
        }
        Update: {
          courier?: string
          created_at?: string
          entered_by?: string
          entry_date?: string
          gdn_number?: string
          handed_over_at?: string | null
          handed_over_to?: string
          id?: string
          item_description?: string
          notes?: string
          origin?: string
          photo_url?: string | null
          qty?: number
          received_at?: string
          recipient?: string
          status?: string
          updated_at?: string
          vehicle_number?: string
        }
        Relationships: []
      }
      segregation_entries: {
        Row: {
          category: string
          created_at: string
          entry_date: string
          id: string
          note: string
          packaging: string
          packaging_concern: string
          supplier: string
          supplier_concern: string
        }
        Insert: {
          category?: string
          created_at?: string
          entry_date?: string
          id?: string
          note?: string
          packaging?: string
          packaging_concern?: string
          supplier?: string
          supplier_concern?: string
        }
        Update: {
          category?: string
          created_at?: string
          entry_date?: string
          id?: string
          note?: string
          packaging?: string
          packaging_concern?: string
          supplier?: string
          supplier_concern?: string
        }
        Relationships: []
      }
      segregation_options: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          kind: string
          label: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          kind: string
          label: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          kind?: string
          label?: string
        }
        Relationships: []
      }
      trims_downtime: {
        Row: {
          concern: string
          created_at: string
          entry_date: string
          id: string
          lost_hours: number
          notes: string | null
          updated_at: string
        }
        Insert: {
          concern: string
          created_at?: string
          entry_date?: string
          id?: string
          lost_hours?: number
          notes?: string | null
          updated_at?: string
        }
        Update: {
          concern?: string
          created_at?: string
          entry_date?: string
          id?: string
          lost_hours?: number
          notes?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      trims_plan: {
        Row: {
          created_at: string
          cut_date: string | null
          id: string
          order_description: string | null
          order_qty: number | null
          picker_date: string | null
          picker_epf: string | null
          picker_name: string | null
          production_order: string
          so_li: string | null
          so_no: string | null
          start_date: string | null
          updated_at: string
          uploaded_at: string
          work_center: string | null
        }
        Insert: {
          created_at?: string
          cut_date?: string | null
          id?: string
          order_description?: string | null
          order_qty?: number | null
          picker_date?: string | null
          picker_epf?: string | null
          picker_name?: string | null
          production_order: string
          so_li?: string | null
          so_no?: string | null
          start_date?: string | null
          updated_at?: string
          uploaded_at?: string
          work_center?: string | null
        }
        Update: {
          created_at?: string
          cut_date?: string | null
          id?: string
          order_description?: string | null
          order_qty?: number | null
          picker_date?: string | null
          picker_epf?: string | null
          picker_name?: string | null
          production_order?: string
          so_li?: string | null
          so_no?: string | null
          start_date?: string | null
          updated_at?: string
          uploaded_at?: string
          work_center?: string | null
        }
        Relationships: []
      }
      unload_entries: {
        Row: {
          created_at: string
          entered_by: string | null
          entry_date: string
          id: string
          material_type: string
          qty: number
          shift: string
          source: string
          token_no: string
          unit: string
          vehicle_number: string
        }
        Insert: {
          created_at?: string
          entered_by?: string | null
          entry_date?: string
          id?: string
          material_type?: string
          qty?: number
          shift?: string
          source?: string
          token_no: string
          unit?: string
          vehicle_number?: string
        }
        Update: {
          created_at?: string
          entered_by?: string | null
          entry_date?: string
          id?: string
          material_type?: string
          qty?: number
          shift?: string
          source?: string
          token_no?: string
          unit?: string
          vehicle_number?: string
        }
        Relationships: []
      }
      vehicle_logs: {
        Row: {
          arrival_status: string
          bay_assigned_at: string | null
          bay_id: string | null
          box_qty: number
          completed_by: string | null
          current_status: string
          driver_name: string
          driver_phone: string
          hold_notes: string | null
          hold_reason: string | null
          hold_started_at: string | null
          in_time: string
          invoice_no: string
          is_held_up: boolean
          manually_unloaded_qty: number | null
          material_type: string
          out_time: string | null
          quantity_brought: number
          queue_position: number | null
          relevant_pcu: string
          requested_start_time: string | null
          roll_qty: number
          schedule_id: string | null
          scheduled_end_time: string | null
          scheduled_start_time: string | null
          token_no: string
          unload_end_time: string | null
          unload_start_time: string | null
          vehicle_number: string
          vehicle_type: string
          vendor_name: string
        }
        Insert: {
          arrival_status?: string
          bay_assigned_at?: string | null
          bay_id?: string | null
          box_qty?: number
          completed_by?: string | null
          current_status?: string
          driver_name?: string
          driver_phone?: string
          hold_notes?: string | null
          hold_reason?: string | null
          hold_started_at?: string | null
          in_time?: string
          invoice_no?: string
          is_held_up?: boolean
          manually_unloaded_qty?: number | null
          material_type?: string
          out_time?: string | null
          quantity_brought?: number
          queue_position?: number | null
          relevant_pcu?: string
          requested_start_time?: string | null
          roll_qty?: number
          schedule_id?: string | null
          scheduled_end_time?: string | null
          scheduled_start_time?: string | null
          token_no: string
          unload_end_time?: string | null
          unload_start_time?: string | null
          vehicle_number?: string
          vehicle_type?: string
          vendor_name?: string
        }
        Update: {
          arrival_status?: string
          bay_assigned_at?: string | null
          bay_id?: string | null
          box_qty?: number
          completed_by?: string | null
          current_status?: string
          driver_name?: string
          driver_phone?: string
          hold_notes?: string | null
          hold_reason?: string | null
          hold_started_at?: string | null
          in_time?: string
          invoice_no?: string
          is_held_up?: boolean
          manually_unloaded_qty?: number | null
          material_type?: string
          out_time?: string | null
          quantity_brought?: number
          queue_position?: number | null
          relevant_pcu?: string
          requested_start_time?: string | null
          roll_qty?: number
          schedule_id?: string | null
          scheduled_end_time?: string | null
          scheduled_start_time?: string | null
          token_no?: string
          unload_end_time?: string | null
          unload_start_time?: string | null
          vehicle_number?: string
          vehicle_type?: string
          vendor_name?: string
        }
        Relationships: []
      }
      weekly_schedules: {
        Row: {
          claimed_date: string | null
          claimed_token: string | null
          created_at: string
          days_data: Json
          id: string
          ih_time: string | null
          material_type: string
          relevant_pcu: string
          remarks: string
          uom: string
          vehicle_type: string
          vendor_name: string
          week_start: string
        }
        Insert: {
          claimed_date?: string | null
          claimed_token?: string | null
          created_at?: string
          days_data?: Json
          id?: string
          ih_time?: string | null
          material_type?: string
          relevant_pcu?: string
          remarks?: string
          uom?: string
          vehicle_type?: string
          vendor_name?: string
          week_start?: string
        }
        Update: {
          claimed_date?: string | null
          claimed_token?: string | null
          created_at?: string
          days_data?: Json
          id?: string
          ih_time?: string | null
          material_type?: string
          relevant_pcu?: string
          remarks?: string
          uom?: string
          vehicle_type?: string
          vendor_name?: string
          week_start?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      api_rate_hit: { Args: { p_client_key: string }; Returns: number }
      bay_elapsed_minutes: {
        Args: { p_end: string; p_from: string; p_start: string; p_to: string }
        Returns: number
      }
      bay_work_end: {
        Args: {
          p_at: string
          p_end: string
          p_minutes: number
          p_start: string
        }
        Returns: string
      }
      bay_work_start: {
        Args: { p_at: string; p_end: string; p_start: string }
        Returns: string
      }
      recalculate_bay_schedules: { Args: never; Returns: undefined }
      reorder_bay_queue: { Args: { p_tokens: string[] }; Returns: undefined }
      submit_green_board_report: {
        Args: {
          p_board_key: string
          p_concern_id: string
          p_entry_date: string
          p_note: string
          p_shift: string
        }
        Returns: {
          board_key: string
          concern_id: string
          created_at: string
          entry_date: string
          id: string
          note: string
          shift: string
          submission_count: number
          updated_at: string
        }
        SetofOptions: {
          from: "*"
          to: "green_board_entries"
          isOneToOne: true
          isSetofReturn: false
        }
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
