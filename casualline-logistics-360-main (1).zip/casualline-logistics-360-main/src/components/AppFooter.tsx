export function AppFooter() {
  return (
    <footer className="flex flex-col md:flex-row items-center justify-between gap-3 bg-[#1a1a24] text-[#92929f] border-t border-[#2b2b40] px-6 py-3 text-[13px]">
      <div className="text-center md:text-left">
        <p>
          &copy; 2026 <span className="font-semibold text-white">MAS Casualline</span>. All Rights Reserved.
        </p>
      </div>

      <div className="flex flex-col items-center gap-1.5">
        <span className="uppercase tracking-wider text-[11px] font-semibold text-[#f64e60] bg-[#f64e60]/10 px-2 py-0.5 rounded">
          MAS Internal Use Only
        </span>
        <div className="flex items-center gap-2.5">
          <span className="uppercase text-[11px] text-[#626273] mr-0.5">Built with:</span>
          <i className="fab fa-react text-base cursor-pointer transition-transform duration-200 hover:scale-125 hover:brightness-125" style={{ color: "#61DAFB" }} title="React" />
          <i className="fab fa-python text-base cursor-pointer transition-transform duration-200 hover:scale-125 hover:brightness-125" style={{ color: "#3776AB" }} title="Python" />
          <i className="fas fa-database text-base cursor-pointer transition-transform duration-200 hover:scale-125 hover:brightness-125" style={{ color: "#00758F" }} title="MySQL" />
          <i className="fas fa-bolt text-base cursor-pointer transition-transform duration-200 hover:scale-125 hover:brightness-125" style={{ color: "#3ECF8E" }} title="Supabase" />
          <i className="fab fa-github text-base cursor-pointer transition-transform duration-200 hover:scale-125 hover:brightness-125" style={{ color: "#ffffff" }} title="GitHub" />
          <a href="https://lovable.dev" target="_blank" rel="noopener noreferrer" title="Built with Lovable" className="inline-flex items-center gap-1 ml-1 px-1.5 py-0.5 rounded bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-200 hover:scale-110">
            <span className="text-[13px]" style={{ color: "#ff4d8f" }}>❤</span>
            <span className="text-[11px] font-semibold bg-gradient-to-r from-pink-400 via-fuchsia-400 to-purple-400 bg-clip-text text-transparent">Lovable</span>
          </a>
        </div>
      </div>

      <div className="flex flex-col md:flex-row items-center gap-2 md:gap-3">
        <p>
          Developed by:{" "}
          <a
            href="mailto:vimukthisen@masholdings.com"
            className="text-[#3699ff] hover:text-[#187de4] hover:underline font-medium"
            title="Contact Vimukthi via Email"
          >
            Vimukthi Lakshan
          </a>
        </p>
        <span className="bg-[#2b2b40] text-[#a2a3b7] px-1.5 py-0.5 rounded text-[11px] font-medium">v1.0.0</span>
      </div>
    </footer>
  );
}
