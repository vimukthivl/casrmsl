import { ExternalLink, Boxes } from "lucide-react";

const WIP_URL = "https://cas-rm-sm-wip.lovable.app/";

export function WipSummaryEmbed() {
  return (
    <section className="rounded-2xl border-2 border-cyan-400/30 bg-gradient-to-br from-slate-900/60 via-cyan-950/30 to-slate-900/60 p-4 shadow-lg shadow-cyan-500/10">
      <div className="flex items-center justify-between gap-3 mb-3 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-cyan-500 to-teal-600 text-white grid place-items-center shadow shadow-cyan-500/40">
            <Boxes className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-sm md:text-base font-extrabold bg-gradient-to-r from-cyan-500 to-teal-500 bg-clip-text text-transparent">
              RM Supermarket WIP — Live Summary
            </h2>
            <p className="text-[11px] text-muted-foreground">Total WIP · Active · Open · Empty · Critical (&lt;2h)</p>
          </div>
        </div>
        <a
          href={WIP_URL}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-md border border-cyan-400/40 bg-cyan-500/10 px-3 py-1.5 text-xs font-semibold text-cyan-300 hover:bg-cyan-500/20 transition"
        >
          Open Full Board <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>
      {/*
        Cross-origin iframe: we cannot read the stat values in JS, but we can
        visually crop the embedded page to reveal only the top-right stat pills
        (Total WIP · Active · Open · Empty · Critical). We render a very wide
        iframe, scale it down, and clip the container to the stats strip.
      */}
      <div
        className="relative rounded-xl overflow-hidden border border-cyan-400/20 bg-slate-950"
        style={{ height: 78 }}
      >
        <iframe
          src={WIP_URL}
          title="RM Supermarket WIP Summary"
          loading="lazy"
          style={{
            border: 0,
            width: 1800,
            height: 900,
            transform: "scale(0.62) translate(-52%, -6px)",
            transformOrigin: "top left",
            pointerEvents: "none",
          }}
        />
        {/* Right-edge fade so the clipped "Reset" button blends out */}
        <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-slate-950 to-transparent" />
      </div>
      <p className="mt-2 text-[10px] text-muted-foreground">
        Live snapshot from{" "}
        <a href={WIP_URL} target="_blank" rel="noreferrer" className="underline">
          cas-rm-sm-wip.lovable.app
        </a>
        . Full board opens in a new tab.
      </p>
    </section>
  );
}
