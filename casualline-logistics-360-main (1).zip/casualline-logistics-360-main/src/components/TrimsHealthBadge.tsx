import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ShieldCheck, ShieldAlert, ShieldX } from "lucide-react";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

function fmt(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

interface Parts {
  cc: number; // 0..40
  gb: number; // 0..30
  dt: number; // 0..30
  ccPct: number;
  gbPct: number;
  dtHours: number;
}

export function TrimsHealthBadge() {
  const now = new Date();
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  const startMonth = fmt(new Date(now.getFullYear(), now.getMonth(), 1));
  const endMonth = fmt(new Date(now.getFullYear(), now.getMonth() + 1, 0));
  const daysElapsed = now.getDate();

  const [parts, setParts] = useState<Parts | null>(null);

  const load = useCallback(async () => {
    const [ccT, ccA, gbC, gbE, dT] = await Promise.all([
      sb.from("cc_monthly_targets").select("target_qty").eq("warehouse", "trims").eq("month", monthKey),
      sb.from("cc_daily_actuals").select("counted_qty").eq("warehouse", "trims").gte("entry_date", startMonth).lte("entry_date", endMonth),
      sb.from("green_board_concerns").select("id,is_active,board_key").in("board_key", ["kanban", "grn", "trims"]).eq("is_active", true),
      sb.from("green_board_entries").select("concern_id,entry_date").in("board_key", ["kanban", "grn", "trims"]).gte("entry_date", startMonth).lte("entry_date", endMonth),
      sb.from("trims_downtime").select("lost_hours").gte("entry_date", startMonth).lte("entry_date", endMonth),
    ]);

    const targetSum = ((ccT.data ?? []) as { target_qty: number }[]).reduce((s, r) => s + (Number(r.target_qty) || 0), 0);
    const actualSum = ((ccA.data ?? []) as { counted_qty: number }[]).reduce((s, r) => s + (Number(r.counted_qty) || 0), 0);
    const ccPct = targetSum > 0 ? Math.min(1, actualSum / targetSum) : (actualSum > 0 ? 1 : 0);

    const activeConcerns = ((gbC.data ?? []) as { id: string }[]).length;
    const totalCells = activeConcerns * daysElapsed;
    const redSet = new Set<string>();
    ((gbE.data ?? []) as { concern_id: string; entry_date: string }[]).forEach((e) => {
      redSet.add(`${e.concern_id}|${e.entry_date}`);
    });
    const gbPct = totalCells > 0 ? Math.max(0, 1 - redSet.size / totalCells) : 1;

    const dtHours = ((dT.data ?? []) as { lost_hours: number }[]).reduce((s, r) => s + (Number(r.lost_hours) || 0), 0);
    const dtScore = Math.max(0, 1 - dtHours / 40); // 40+ hrs = 0

    setParts({
      cc: ccPct * 40,
      gb: gbPct * 30,
      dt: dtScore * 30,
      ccPct,
      gbPct,
      dtHours,
    });
  }, [monthKey, startMonth, endMonth, daysElapsed]);

  useEffect(() => {
    load();
    const ch = sb
      .channel("trims-health-badge")
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_daily_actuals" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_monthly_targets" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_entries" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_concerns" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "trims_downtime" }, load)
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load]);

  const score = useMemo(() => {
    if (!parts) return 0;
    return Math.round(parts.cc + parts.gb + parts.dt);
  }, [parts]);

  const tier = score >= 80
    ? { label: "Well Protected", grad: "from-emerald-500 to-green-600", ring: "ring-emerald-400/50", icon: <ShieldCheck className="h-5 w-5" /> }
    : score >= 55
      ? { label: "Moderate", grad: "from-amber-500 to-orange-600", ring: "ring-amber-400/50", icon: <ShieldAlert className="h-5 w-5" /> }
      : { label: "At Risk", grad: "from-rose-500 to-red-600", ring: "ring-rose-400/50", icon: <ShieldX className="h-5 w-5" /> };

  return (
    <div
      className={`flex items-center gap-3 rounded-2xl bg-gradient-to-br ${tier.grad} px-4 py-2.5 text-white shadow-lg ring-2 ${tier.ring}`}
      title={parts ? `Cycle Count ${Math.round(parts.ccPct * 100)}% · Green Board ${Math.round(parts.gbPct * 100)}% · Downtime ${parts.dtHours.toFixed(1)}h` : "Loading…"}
    >
      {tier.icon}
      <div className="leading-tight">
        <div className="text-[10px] uppercase tracking-wide opacity-90">Protection</div>
        <div className="text-lg font-extrabold">{score}%</div>
      </div>
      <div className="hidden sm:block h-8 w-px bg-white/30" />
      <div className="hidden sm:block text-xs font-semibold">{tier.label}</div>
    </div>
  );
}
