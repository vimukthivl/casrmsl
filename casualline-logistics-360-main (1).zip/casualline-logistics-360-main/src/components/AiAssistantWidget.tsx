import { useState, useRef, useEffect } from "react";
import { useRouterState } from "@tanstack/react-router";
import { Bot, X, Send, LockKeyhole } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const EXCLUDED = new Set(["/tv", "/login", "/"]);

type Msg = { role: "ai" | "user"; text: string };

const QUICK_REPLIES = [
  "දැන් unload වෙන වාහනය?",
  "Held-up vehicles?",
  "Today's invoices",
  "Green board issues",
  "Yesterday trims downtime",
];

export function AiAssistantWidget() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [requiresPassword, setRequiresPassword] = useState(false);
  const [changePassword, setChangePassword] = useState("");
  const [pendingMessages, setPendingMessages] = useState<Msg[] | null>(null);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "ai",
      text: "Hello! How can I help with your warehouse today?",
    },
  ]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open, loading]);

  const isExcluded = EXCLUDED.has(pathname) || pathname.startsWith("/tv/");
  if (isExcluded) return null;

  const send = async (text: string, authorizedMessages?: Msg[], password?: string) => {
    const t = text.trim();
    if ((!t && !authorizedMessages) || loading) return;
    const nextMsgs: Msg[] = authorizedMessages ?? [...messages, { role: "user", text: t }];
    if (!authorizedMessages) setMessages(nextMsgs);
    setRequiresPassword(false);
    setInput("");
    setLoading(true);
    try {
      const res = await fetch("/api/ai-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: nextMsgs.map((m) => ({
            role: m.role === "ai" ? "assistant" : "user",
            content: m.text,
          })),
          page: pathname,
          ...(password ? { changePassword: password } : {}),
        }),
      });
      const data = (await res.json()) as { reply?: string; requiresPassword?: boolean };
      if (!res.ok && !data.requiresPassword) throw new Error("Request failed");
      setRequiresPassword(Boolean(data.requiresPassword));
      setPendingMessages(data.requiresPassword ? nextMsgs : null);
      setMessages((m) => [...m, { role: "ai", text: data.reply || "..." }]);
    } catch {
      setMessages((m) => [
        ...m,
        {
          role: "ai",
          text: "Sorry, I couldn't reach the AI service. / සමාවන්න, AI සේවාවට සම්බන්ධ විය නොහැක.",
        },
      ]);
    } finally {
      setChangePassword("");
      setLoading(false);
    }
  };

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Open AI Assistant"
          className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-slate-900 border border-cyan-400/40 shadow-[0_0_20px_rgba(34,211,238,0.45)] grid place-items-center text-cyan-300 hover:scale-105 transition-transform"
        >
          <Bot className="h-6 w-6" />
          <span className="absolute top-1 right-1 h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.9)]" />
        </button>
      )}

      {open && (
        <div className="fixed bottom-6 right-6 z-50 w-[min(20rem,calc(100vw-1.5rem))] h-[min(28rem,calc(100vh-6rem))] bg-slate-900 border border-slate-700/60 rounded-2xl shadow-2xl flex flex-col p-4 text-slate-100 overflow-hidden">
          <div className="flex items-center justify-between pb-2 border-b border-slate-700/60">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-slate-800 border border-cyan-400/40 grid place-items-center text-cyan-300">
                <Bot className="h-4 w-4" />
              </div>
              <div>
                <div className="text-sm font-semibold">RMWH Assistant</div>
                <div className="text-[10px] text-emerald-400 flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Live · Protected changes
                </div>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              aria-label="Close"
              className="text-slate-400 hover:text-white p-1"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto py-2 space-y-2 text-sm">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[80%] px-3 py-2 rounded-xl leading-snug ${
                    m.role === "user"
                      ? "bg-cyan-500/90 text-slate-900 rounded-br-sm"
                      : "bg-slate-800 text-slate-100 border border-slate-700/60 rounded-bl-sm"
                  }`}
                >
                  <div className="whitespace-pre-wrap">{m.text}</div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="bg-slate-800 border border-slate-700/60 rounded-xl rounded-bl-sm px-3 py-2 text-slate-400 text-xs flex gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse [animation-delay:150ms]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse [animation-delay:300ms]" />
                </div>
              </div>
            )}
          </div>

          {requiresPassword && <form className="space-y-2 border-t border-border py-3" onSubmit={(e) => { e.preventDefault(); if (pendingMessages && changePassword) void send("", pendingMessages, changePassword); }}>
            <label htmlFor="assistant-change-password" className="flex items-center gap-2 text-xs font-semibold"><LockKeyhole className="h-4 w-4" />Change password</label>
            <Input id="assistant-change-password" type="password" value={changePassword} onChange={(e) => setChangePassword(e.target.value)} autoComplete="off" maxLength={128} className="bg-background text-foreground" />
            <div className="flex gap-2"><Button type="submit" size="sm" disabled={loading || !changePassword}>Authorize request</Button><Button type="button" size="sm" variant="outline" onClick={() => { setRequiresPassword(false); setChangePassword(""); setPendingMessages(null); }}>Cancel</Button></div>
          </form>}
          <div className="flex gap-1.5 flex-wrap pb-2">
            {QUICK_REPLIES.map((q) => (
              <button
                key={q}
                onClick={() => send(q)}
                className="text-[10px] px-2 py-1 rounded-full bg-slate-800 border border-slate-700 text-cyan-300 hover:bg-slate-700 transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-center gap-2 border-t border-slate-700/60 pt-2"
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask or ask me to update... / අහන්න"
              className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-sm placeholder:text-slate-500 focus:outline-none focus:border-cyan-400/60"
            />
            <button
              type="submit"
              aria-label="Send"
              className="h-8 w-8 rounded-lg bg-cyan-500 text-slate-900 grid place-items-center hover:bg-cyan-400 transition-colors"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
