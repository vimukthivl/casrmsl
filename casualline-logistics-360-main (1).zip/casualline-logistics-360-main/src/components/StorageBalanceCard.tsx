import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Database, HardDrive, RefreshCw } from "lucide-react";

const ROW_LIMIT = 500_000; // free-tier proxy threshold

type Counts = { vehicles: number; concerns: number; entries: number; logs: number };

export function StorageBalanceCard() {
  const [counts, setCounts] = useState<Counts | null>(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setErr(null);
    try {
      const [v, c, e] = await Promise.all([
        supabase.from("vehicle_logs").select("*", { count: "exact", head: true }),
        supabase.from("green_board_concerns").select("*", { count: "exact", head: true }),
        supabase.from("green_board_entries").select("*", { count: "exact", head: true }),
      ]);
      setCounts({
        vehicles: v.count ?? 0,
        concerns: c.count ?? 0,
        entries: e.count ?? 0,
        logs: (v.count ?? 0) + (e.count ?? 0),
      });
    } catch (e: any) {
      setErr(e?.message ?? "Failed to read storage stats");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 60_000);
    return () => clearInterval(t);
  }, []);

  const total = counts ? counts.vehicles + counts.concerns + counts.entries : 0;
  const pct = Math.min(100, (total / ROW_LIMIT) * 100);
  const balance = Math.max(0, 100 - pct);

  const tone =
    pct >= 90
      ? { bar: "bg-red-500", chip: "bg-red-500/10 text-red-600 border-red-500/30", label: "CRITICAL" }
      : pct >= 70
      ? { bar: "bg-amber-500", chip: "bg-amber-500/10 text-amber-600 border-amber-500/30", label: "WARNING" }
      : { bar: "bg-emerald-500", chip: "bg-emerald-500/10 text-emerald-600 border-emerald-500/30", label: "HEALTHY" };

  const estMB = Math.max(0.1, total * 0.001).toFixed(2); // rough proxy: ~1KB/row

  return (
    <div className="rounded-xl border bg-gradient-to-br from-card to-muted/30 p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary grid place-items-center">
            <HardDrive className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold leading-tight">Cloud Storage & Database Balance</h3>
            <p className="text-xs text-muted-foreground">Estimated capacity vs. free-tier row threshold</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-[10px] font-bold px-2 py-1 rounded-full border ${tone.chip}`}>{tone.label}</span>
          <button
            onClick={load}
            disabled={loading}
            title="Refresh"
            className="h-8 w-8 grid place-items-center rounded-md hover:bg-muted text-muted-foreground"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        </div>
      </div>

      {err ? (
        <div className="text-xs text-destructive">{err}</div>
      ) : (
        <>
          <div className="flex items-baseline justify-between mb-1.5">
            <div className="text-sm text-muted-foreground">
              Database Rows:{" "}
              <span className="font-semibold text-foreground">{total.toLocaleString()}</span>
              <span className="text-muted-foreground"> / {ROW_LIMIT.toLocaleString()} Used</span>
            </div>
            <div className="text-sm font-bold">{pct.toFixed(2)}%</div>
          </div>
          <div className="h-3 w-full rounded-full bg-muted overflow-hidden">
            <div
              className={`h-full ${tone.bar} transition-all duration-700 ease-out`}
              style={{ width: `${Math.max(2, pct)}%` }}
            />
          </div>

          <div className="mt-3 flex items-center justify-between text-xs">
            <span className="text-muted-foreground">
              Estimated Balance Available: <span className="font-semibold text-foreground">{balance.toFixed(1)}%</span>
            </span>
            <span className="text-muted-foreground">≈ {estMB} MB stored</span>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2">
            <MiniStat label="Vehicle Logs" value={counts?.vehicles ?? 0} />
            <MiniStat label="Concerns" value={counts?.concerns ?? 0} />
            <MiniStat label="Board Entries" value={counts?.entries ?? 0} />
          </div>
        </>
      )}
    </div>
  );
}

function MiniStat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-md border bg-background/60 p-2.5">
      <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">
        <Database className="h-3 w-3" /> {label}
      </div>
      <div className="text-lg font-bold mt-0.5">{value.toLocaleString()}</div>
    </div>
  );
}
