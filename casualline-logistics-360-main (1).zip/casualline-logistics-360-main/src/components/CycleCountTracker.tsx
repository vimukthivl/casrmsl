import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Plus, Trash2, Target, CalendarDays, Loader2 } from "lucide-react";

type Warehouse = "fabric" | "trims";

interface TargetRow {
  id: string;
  warehouse: Warehouse;
  month: string;
  item_code: string;
  target_qty: number;
}
interface ActualRow {
  id: string;
  warehouse: Warehouse;
  entry_date: string;
  item_code: string;
  counted_qty: number;
}

function toMonth(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}
function daysInMonth(month: string) {
  const [y, m] = month.split("-").map(Number);
  const last = new Date(y, m, 0).getDate();
  const out: { iso: string; day: number; dow: number }[] = [];
  for (let d = 1; d <= last; d++) {
    const dt = new Date(y, m - 1, d);
    out.push({
      iso: `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`,
      day: d,
      dow: dt.getDay(),
    });
  }
  return out;
}

interface Props {
  warehouse: Warehouse;
  accent: "teal" | "fuchsia";
}

export function CycleCountTracker({ warehouse, accent }: Props) {
  const [month, setMonth] = useState(toMonth(new Date()));
  const [targets, setTargets] = useState<TargetRow[]>([]);
  const [actuals, setActuals] = useState<ActualRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [newCode, setNewCode] = useState("");
  const [newQty, setNewQty] = useState("");

  const days = useMemo(() => daysInMonth(month).filter((d) => d.dow !== 0), [month]);

  const load = async () => {
    setLoading(true);
    const [y, m] = month.split("-").map(Number);
    const lastDay = new Date(y, m, 0).getDate();
    const endDate = `${month}-${String(lastDay).padStart(2, "0")}`;
    const [t, a] = await Promise.all([
      supabase.from("cc_monthly_targets").select("*").eq("warehouse", warehouse).eq("month", month),
      supabase
        .from("cc_daily_actuals")
        .select("*")
        .eq("warehouse", warehouse)
        .gte("entry_date", `${month}-01`)
        .lte("entry_date", endDate),
    ]);
    setTargets((t.data ?? []) as TargetRow[]);
    setActuals((a.data ?? []) as ActualRow[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    const ch = supabase
      .channel(`cc-${warehouse}-${month}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_monthly_targets" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_daily_actuals" }, load)
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [warehouse, month]);

  const actualsByCodeDate = useMemo(() => {
    const m = new Map<string, number>();
    for (const a of actuals) m.set(`${a.item_code}|${a.entry_date}`, Number(a.counted_qty || 0));
    return m;
  }, [actuals]);

  const totalsByCode = useMemo(() => {
    const m = new Map<string, number>();
    for (const a of actuals) m.set(a.item_code, (m.get(a.item_code) ?? 0) + Number(a.counted_qty || 0));
    return m;
  }, [actuals]);

  const addTarget = async () => {
    const code = newCode.trim();
    const qty = Number(newQty);
    if (!code || !Number.isFinite(qty) || qty <= 0) return;
    await supabase
      .from("cc_monthly_targets")
      .upsert({ warehouse, month, item_code: code, target_qty: qty }, { onConflict: "warehouse,month,item_code" });
    setNewCode("");
    setNewQty("");
    load();
  };

  const updateTarget = async (id: string, qty: number) => {
    await supabase.from("cc_monthly_targets").update({ target_qty: qty }).eq("id", id);
  };
  const removeTarget = async (id: string) => {
    await supabase.from("cc_monthly_targets").delete().eq("id", id);
    load();
  };

  const setCell = async (item_code: string, entry_date: string, val: number) => {
    if (!val || val <= 0) {
      await supabase
        .from("cc_daily_actuals")
        .delete()
        .eq("warehouse", warehouse)
        .eq("item_code", item_code)
        .eq("entry_date", entry_date);
    } else {
      await supabase
        .from("cc_daily_actuals")
        .upsert(
          { warehouse, entry_date, item_code, counted_qty: val },
          { onConflict: "warehouse,entry_date,item_code" },
        );
    }
  };

  const accentClasses =
    accent === "teal"
      ? {
          border: "border-teal-400/30",
          bg: "from-teal-500/10 via-emerald-500/5 to-cyan-500/10",
          chip: "bg-teal-500 text-white",
          bar: "from-teal-500 to-emerald-500",
          ring: "focus:ring-teal-400",
        }
      : {
          border: "border-fuchsia-400/30",
          bg: "from-fuchsia-500/10 via-pink-500/5 to-rose-500/10",
          chip: "bg-fuchsia-500 text-white",
          bar: "from-fuchsia-500 to-pink-500",
          ring: "focus:ring-fuchsia-400",
        };

  return (
    <div className={`rounded-2xl border-2 ${accentClasses.border} bg-gradient-to-br ${accentClasses.bg} p-4 md:p-5 space-y-4`}>
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2">
          <div className={`h-9 w-9 rounded-xl ${accentClasses.chip} grid place-items-center shadow`}>
            <Target className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base md:text-lg font-bold">Cycle Counting — Monthly Target vs Daily Actual</h2>
            <p className="text-xs text-muted-foreground capitalize">{warehouse} warehouse · SAP material codes</p>
          </div>
        </div>
        <label className="flex items-center gap-2 text-xs">
          <CalendarDays className="h-4 w-4" />
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className={`rounded-lg border bg-background px-2 py-1 text-sm outline-none focus:ring-2 ${accentClasses.ring}`}
          />
        </label>
      </div>

      {/* Setup: add target */}
      <div className="rounded-xl border bg-background/60 p-3 space-y-3">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Monthly SAP Material Targets</div>
        <div className="flex flex-wrap gap-2">
          <input
            value={newCode}
            onChange={(e) => setNewCode(e.target.value)}
            placeholder="Item code (e.g. Elastic, MC, TRD)"
            className={`flex-1 min-w-[180px] rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 ${accentClasses.ring}`}
          />
          <input
            value={newQty}
            onChange={(e) => setNewQty(e.target.value)}
            type="number"
            min={0}
            placeholder="Target qty"
            className={`w-32 rounded-lg border bg-background px-3 py-2 text-sm outline-none focus:ring-2 ${accentClasses.ring}`}
          />
          <button
            onClick={addTarget}
            className={`inline-flex items-center gap-1 rounded-lg ${accentClasses.chip} px-3 py-2 text-sm font-medium shadow hover:opacity-90`}
          >
            <Plus className="h-4 w-4" /> Add / Update
          </button>
        </div>

        {loading ? (
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Loading…
          </div>
        ) : targets.length === 0 ? (
          <div className="text-xs text-muted-foreground">No targets set for {month}. Add one above.</div>
        ) : (
          <div className="space-y-2">
            {targets.map((t) => {
              const counted = totalsByCode.get(t.item_code) ?? 0;
              const pct = t.target_qty > 0 ? Math.min(100, (counted / t.target_qty) * 100) : 0;
              return (
                <div key={t.id} className="rounded-lg border bg-background p-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-sm">{t.item_code}</span>
                    <span className="text-xs text-muted-foreground">
                      {counted} / {t.target_qty} counted
                    </span>
                    <span className="ml-auto text-xs font-semibold">{pct.toFixed(1)}%</span>
                    <input
                      type="number"
                      defaultValue={t.target_qty}
                      onBlur={(e) => {
                        const v = Number(e.target.value);
                        if (Number.isFinite(v) && v !== t.target_qty) updateTarget(t.id, v);
                      }}
                      className="w-20 rounded-md border bg-background px-2 py-1 text-xs"
                    />
                    <button
                      onClick={() => removeTarget(t.id)}
                      className="rounded-md border p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30"
                      aria-label="Remove"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                  <div className="mt-2 h-2 w-full rounded-full bg-muted overflow-hidden">
                    <div
                      className={`h-full bg-gradient-to-r ${accentClasses.bar} transition-all`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Daily calendar matrix */}
      {targets.length > 0 && (
        <div className="rounded-xl border bg-background/60 p-3">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">
            Daily Actuals — {month} (Sundays excluded)
          </div>
          <div className="overflow-auto max-w-full">
            <table className="min-w-full border-collapse text-xs">
              <thead>
                <tr>
                  <th className="sticky left-0 z-10 bg-background border px-2 py-1 text-left">Item</th>
                  {days.map((d) => (
                    <th key={d.iso} className="border px-1 py-1 text-center whitespace-nowrap min-w-[46px]">
                      {d.day}
                    </th>
                  ))}
                  <th className="border px-2 py-1 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {targets.map((t) => {
                  const total = totalsByCode.get(t.item_code) ?? 0;
                  return (
                    <tr key={t.id}>
                      <td className="sticky left-0 z-10 bg-background border px-2 py-1 font-medium whitespace-nowrap">
                        {t.item_code}
                      </td>
                      {days.map((d) => {
                        const key = `${t.item_code}|${d.iso}`;
                        const v = actualsByCodeDate.get(key);
                        return (
                          <td key={d.iso} className="border p-0">
                            <input
                              type="number"
                              min={0}
                              defaultValue={v ?? ""}
                              onBlur={(e) => {
                                const nv = Number(e.target.value);
                                const current = v ?? 0;
                                if (nv !== current) setCell(t.item_code, d.iso, nv);
                              }}
                              className="w-14 bg-transparent px-1 py-1 text-center outline-none focus:bg-muted"
                            />
                          </td>
                        );
                      })}
                      <td className="border px-2 py-1 text-right font-semibold">{total}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
