import { Truck, MapPin, Package, Boxes, Clock } from "lucide-react";
import type { VehicleLog } from "@/lib/types";

/**
 * Compact animated arrival card for the TV bay timeline (bottom-left).
 * A lorry drives in from the left, brakes and parks — mimicking a truck
 * pulling into the yard the moment the guard checks it in.
 */
export function VehicleArrivalToast({ v }: { v: VehicleLog }) {
  const arrival = v.arrival_status || "Unscheduled";
  const tone =
    arrival === "Delayed"
      ? "border-rose-400/60 from-rose-950/95 via-slate-900/95 to-slate-950/95 text-rose-200"
      : arrival === "Early"
        ? "border-sky-400/60 from-sky-950/95 via-slate-900/95 to-slate-950/95 text-sky-200"
        : arrival === "On-Time"
          ? "border-emerald-400/60 from-emerald-950/95 via-slate-900/95 to-slate-950/95 text-emerald-200"
          : "border-amber-400/60 from-amber-950/95 via-slate-900/95 to-slate-950/95 text-amber-200";

  return (
    <div
      className={`animate-arrival-pop-in pointer-events-none relative overflow-hidden rounded-2xl border-2 bg-gradient-to-r ${tone} shadow-2xl backdrop-blur-sm`}
      style={{
        width: "min(30vw, 460px)",
        paddingTop: "0.9vh",
        paddingBottom: "0.9vh",
        paddingLeft: "0.9vw",
        paddingRight: "1vw",
      }}
    >
      {/* sweeping light + road line */}
      <span className="animate-arrival-sheen absolute inset-y-0 -left-1/3 w-1/3 bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-[3px] bg-slate-700/70" />

      <div className="flex items-center gap-[0.8vw]">
        {/* Driving lorry */}
        <div className="animate-truck-drive-in relative shrink-0">
          <div
            className="animate-truck-bounce relative grid place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-cyan-600 shadow-lg shadow-sky-500/40"
            style={{ height: "5vh", width: "5vh" }}
          >
            <Truck style={{ height: "2.8vh", width: "2.8vh" }} className="text-white" />
            <span className="animate-beacon-flash absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full bg-amber-300" />
          </div>
          <span className="animate-dust-puff absolute bottom-0 left-0 h-3 w-3 rounded-full bg-slate-400/40" />
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-[0.6vw]">
            <span
              className="animate-arrival-text-rise font-black tracking-tight text-white truncate"
              style={{ fontSize: "clamp(14px, 1.5vw, 26px)" }}
            >
              {v.vehicle_number || v.token_no}
            </span>
            <span
              className="animate-arrival-badge-pulse uppercase font-bold tracking-widest whitespace-nowrap"
              style={{ fontSize: "clamp(8px, 0.75vw, 12px)" }}
            >
              ARRIVED · {arrival}
            </span>
          </div>
          <div
            className="animate-arrival-text-rise flex items-center gap-[0.7vw] text-slate-300 font-mono truncate"
            style={{ fontSize: "clamp(9px, 0.8vw, 13px)", animationDelay: "0.12s" }}
          >
            <span className="truncate max-w-[9vw]">{v.vendor_name || "—"}</span>
            <span className="flex items-center gap-1"><MapPin style={{ height: "1.1vh", width: "1.1vh" }} />{v.relevant_pcu || "PCU —"}</span>
            <span className="flex items-center gap-1"><Package style={{ height: "1.1vh", width: "1.1vh" }} />{v.roll_qty}</span>
            <span className="flex items-center gap-1"><Boxes style={{ height: "1.1vh", width: "1.1vh" }} />{v.box_qty}</span>
            <span className="flex items-center gap-1">
              <Clock style={{ height: "1.1vh", width: "1.1vh" }} />
              {new Date(v.in_time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })}
            </span>
          </div>
        </div>

        {/* parking slot marker */}
        <div className="animate-arrival-slot-snap shrink-0 rounded-xl border-2 border-dashed border-slate-500/60 px-[0.6vw] py-[0.3vh] text-center">
          <div className="uppercase tracking-widest text-slate-400 font-bold" style={{ fontSize: "clamp(7px, 0.6vw, 10px)" }}>
            YARD
          </div>
          <div className="font-black text-white font-mono" style={{ fontSize: "clamp(10px, 1.1vw, 18px)" }}>
            {v.token_no}
          </div>
        </div>
      </div>
    </div>
  );
}
