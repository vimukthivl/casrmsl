import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ClipboardCheck, Leaf, Timer, FileText, HandMetal, DollarSign, Truck, PackageCheck, AlertTriangle, Activity } from "lucide-react";
import { useApp, heldUpCost, rateForVehicle } from "@/lib/store";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

type RangeKey = "day" | "week" | "month" | "year";

function fmt(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function rangeBounds(r: RangeKey, now = new Date()) {
  let start: Date; let end: Date; let label: string;
  if (r === "day") {
    start = new Date(now); start.setHours(0, 0, 0, 0);
    end = new Date(start);
    label = fmt(start);
  } else if (r === "week") {
    const d = new Date(now); d.setHours(0, 0, 0, 0);
    const diff = (d.getDay() + 6) % 7;
    start = new Date(d); start.setDate(d.getDate() - diff);
    end = new Date(start); end.setDate(start.getDate() + 6);
    label = `Week of ${fmt(start)}`;
  } else if (r === "month") {
    start = new Date(now.getFullYear(), now.getMonth(), 1);
    end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    label = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}`;
  } else {
    start = new Date(now.getFullYear(), 0, 1);
    end = new Date(now.getFullYear(), 11, 31);
    label = String(now.getFullYear());
  }
  const days = Math.floor((end.getTime() - start.getTime()) / 86400000) + 1;
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  return { start: fmt(start), end: fmt(end), label, days, monthKey };
}

function todayIsoStart() {
  const d = new Date(); d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

interface CCRow { warehouse: string; item_code: string; target_qty?: number; counted_qty?: number }
interface Concern { id: string; label: string; board_key: string; is_active: boolean }
interface Entry { concern_id: string; board_key: string; entry_date: string }
interface Dt { concern: string; lost_hours: number; entry_date: string }
interface PickerT { epf_number: string; name: string; gin_target_per_day: number }
interface PickerA { epf_number: string }
interface Inv { log_date: string; trims_received: number; trims_completed: number; fabric_received: number; fabric_completed: number }

const TRIMS_BOARDS = ["kanban", "grn", "trims"];

export function ManagementSummaryPanels() {
  const [range, setRange] = useState<RangeKey>("month");
  const [customDate, setCustomDate] = useState("");
  const { start, end, label: rangeLabel, days: daysInRange, monthKey } = useMemo(() => {
    if (customDate) {
      const d = new Date(customDate + "T00:00:00");
      const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      return { start: customDate, end: customDate, label: customDate, days: 1, monthKey };
    }
    return rangeBounds(range);
  }, [range, customDate]);

  const { state } = useApp();
  const demurrage = useMemo(() => {
    const rateFallback = state.settings.held_up_cost_rate;
    const held = state.vehicles.filter((v) => v.is_held_up);
    const perVehicle = (v: typeof held[number]) => heldUpCost(v, rateForVehicle(v, state.heldUpRates, rateFallback));
    const trims = held.filter((v) => v.material_type === "Trims");
    const fabric = held.filter((v) => v.material_type === "Fabric");
    const other = held.filter((v) => v.material_type !== "Trims" && v.material_type !== "Fabric");
    const sum = (arr: typeof held) => arr.reduce((s, v) => s + perVehicle(v), 0);
    return {
      trims: { count: trims.length, cost: sum(trims) },
      fabric: { count: fabric.length, cost: sum(fabric) },
      other: { count: other.length, cost: sum(other) },
      total: { count: held.length, cost: sum(held) },
    };
  }, [state.vehicles, state.heldUpRates, state.settings.held_up_cost_rate]);


  const [ccT, setCcT] = useState<CCRow[]>([]);
  const [ccA, setCcA] = useState<CCRow[]>([]);
  const [concerns, setConcerns] = useState<Concern[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [dtT, setDtT] = useState<Dt[]>([]);
  const [dtF, setDtF] = useState<Dt[]>([]);
  const [pT, setPT] = useState<PickerT[]>([]);
  const [pF, setPF] = useState<PickerT[]>([]);
  const [aT, setAT] = useState<PickerA[]>([]);
  const [aF, setAF] = useState<PickerA[]>([]);
  const [inv, setInv] = useState<Inv[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [ccTr, ccAr, gbC, gbE, dtTr, dtFr, ptT, ptF, paT, paF, iL] = await Promise.all([
      sb.from("cc_monthly_targets").select("warehouse,item_code,target_qty").in("warehouse", ["trims", "fabric"]).eq("month", monthKey),
      sb.from("cc_daily_actuals").select("warehouse,item_code,counted_qty").in("warehouse", ["trims", "fabric"]).gte("entry_date", start).lte("entry_date", end),
      sb.from("green_board_concerns").select("id,label,board_key,is_active").in("board_key", [...TRIMS_BOARDS, "fabric"]),
      sb.from("green_board_entries").select("concern_id,board_key,entry_date").in("board_key", [...TRIMS_BOARDS, "fabric"]).gte("entry_date", start).lte("entry_date", end),
      sb.from("trims_downtime").select("concern,lost_hours,entry_date").gte("entry_date", start).lte("entry_date", end),
      sb.from("fabric_downtime").select("concern,lost_hours,entry_date").gte("entry_date", start).lte("entry_date", end),
      sb.from("picker_targets").select("epf_number,name,gin_target_per_day").eq("is_active", true),
      sb.from("fabric_picker_targets").select("epf_number,name,gin_target_per_day").eq("is_active", true),
      sb.from("picker_achievements").select("epf_number").gte("picked_at", todayIsoStart()),
      sb.from("fabric_picker_achievements").select("epf_number").gte("picked_at", todayIsoStart()),
      sb.from("invoice_daily_log").select("log_date,trims_received,trims_completed,fabric_received,fabric_completed").gte("log_date", start).lte("log_date", end),
    ]);
    setCcT(ccTr.data ?? []); setCcA(ccAr.data ?? []);
    setConcerns(gbC.data ?? []); setEntries(gbE.data ?? []);
    setDtT(dtTr.data ?? []); setDtF(dtFr.data ?? []);
    setPT(ptT.data ?? []); setPF(ptF.data ?? []);
    setAT(paT.data ?? []); setAF(paF.data ?? []);
    setInv(iL.data ?? []);
    setLoading(false);
  }, [start, end, monthKey]);

  useEffect(() => {
    load();
    const ch = sb.channel("rt-mgmt-dash")
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_monthly_targets" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_daily_actuals" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_entries" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_concerns" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "trims_downtime" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_downtime" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "picker_targets" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_picker_targets" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "picker_achievements" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_picker_achievements" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "invoice_daily_log" }, () => load())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load]);

  // ===== CYCLE COUNTING =====
  const cc = useMemo(() => {
    const sumBy = (rows: CCRow[], field: "target_qty" | "counted_qty", wh: string) =>
      rows.filter((r) => r.warehouse === wh).reduce((s, r) => s + Number(r[field] ?? 0), 0);
    const tT = sumBy(ccT, "target_qty", "trims");
    const tF = sumBy(ccT, "target_qty", "fabric");
    const aT = sumBy(ccA, "counted_qty", "trims");
    const aF = sumBy(ccA, "counted_qty", "fabric");
    return {
      trims: { target: tT, actual: aT, pct: tT > 0 ? Math.min(100, Math.round((aT / tT) * 100)) : 0 },
      fabric: { target: tF, actual: aF, pct: tF > 0 ? Math.min(100, Math.round((aF / tF) * 100)) : 0 },
      total: { target: tT + tF, actual: aT + aF, pct: (tT + tF) > 0 ? Math.min(100, Math.round(((aT + aF) / (tT + tF)) * 100)) : 0 },
    };
  }, [ccT, ccA]);

  // ===== GREEN BOARD =====
  const gb = useMemo(() => {
    const calc = (keys: string[]) => {
      const areaC = concerns.filter((c) => keys.includes(c.board_key) && c.is_active);
      const ids = new Set(areaC.map((c) => c.id));
      const red = entries.filter((e) => keys.includes(e.board_key) && ids.has(e.concern_id)).length;
      const total = areaC.length * daysInRange;
      const clean = total > 0 ? Math.round(((total - red) / total) * 100) : 100;
      return { total, red, clean };
    };
    const t = calc(TRIMS_BOARDS);
    const f = calc(["fabric"]);
    const totCells = t.total + f.total;
    const totRed = t.red + f.red;
    return {
      trims: t, fabric: f,
      total: { total: totCells, red: totRed, clean: totCells > 0 ? Math.round(((totCells - totRed) / totCells) * 100) : 100 },
    };
  }, [concerns, entries, daysInRange]);

  // ===== DOWNTIME =====
  const dt = useMemo(() => {
    const sum = (rows: Dt[]) => Math.round(rows.reduce((s, r) => s + Number(r.lost_hours ?? 0), 0) * 100) / 100;
    const byItem = (rows: Dt[]) => {
      const m = new Map<string, number>();
      rows.forEach((r) => {
        const k = (r.concern || "Unspecified").trim() || "Unspecified";
        m.set(k, (m.get(k) ?? 0) + Number(r.lost_hours ?? 0));
      });
      return Array.from(m.entries()).map(([k, v]) => ({ concern: k, hours: Math.round(v * 100) / 100 })).sort((a, b) => b.hours - a.hours);
    };
    return {
      trims: { hours: sum(dtT), events: dtT.length, items: byItem(dtT) },
      fabric: { hours: sum(dtF), events: dtF.length, items: byItem(dtF) },
      totalHours: Math.round((sum(dtT) + sum(dtF)) * 100) / 100,
      totalEvents: dtT.length + dtF.length,
    };
  }, [dtT, dtF]);

  // ===== PICKER =====
  const picker = useMemo(() => {
    const calc = (targets: PickerT[], achs: PickerA[]) => {
      const counts: Record<string, number> = {};
      achs.forEach((r) => { counts[r.epf_number] = (counts[r.epf_number] ?? 0) + 1; });
      const tgt = targets.reduce((s, r) => s + Number(r.gin_target_per_day ?? 0), 0);
      const ach = targets.reduce((s, r) => s + (counts[r.epf_number] ?? 0), 0);
      return { target: tgt, achieved: ach, pct: tgt > 0 ? Math.min(100, Math.round((ach / tgt) * 100)) : 0, pickers: targets.length };
    };
    const t = calc(pT, aT);
    const f = calc(pF, aF);
    return {
      trims: t, fabric: f,
      total: {
        target: t.target + f.target, achieved: t.achieved + f.achieved,
        pct: (t.target + f.target) > 0 ? Math.min(100, Math.round(((t.achieved + f.achieved) / (t.target + f.target)) * 100)) : 0,
        pickers: t.pickers + f.pickers,
      },
    };
  }, [pT, pF, aT, aF]);

  // ===== INVOICE =====
  const invAgg = useMemo(() => {
    const tR = inv.reduce((s, r) => s + (Number(r.trims_received) || 0), 0);
    const tD = inv.reduce((s, r) => s + (Number(r.trims_completed) || 0), 0);
    const fR = inv.reduce((s, r) => s + (Number(r.fabric_received) || 0), 0);
    const fD = inv.reduce((s, r) => s + (Number(r.fabric_completed) || 0), 0);
    const mk = (rec: number, done: number) => ({ rec, done, pend: Math.max(0, rec - done), pct: rec > 0 ? Math.min(100, Math.round((done / rec) * 100)) : 0 });
    return { trims: mk(tR, tD), fabric: mk(fR, fD), total: mk(tR + fR, tD + fD) };
  }, [inv]);

  const RANGES: { key: RangeKey; label: string }[] = [
    { key: "day", label: "Day" }, { key: "week", label: "Week" }, { key: "month", label: "Month" }, { key: "year", label: "Year" },
  ];

  const SplitRow = ({ tLabel, tVal, fVal, tColor = "fuchsia", fColor = "sky" }: { tLabel?: string; tVal: string; fVal: string; tColor?: string; fColor?: string }) => (
    <div className="grid grid-cols-2 gap-2 mt-3">
      <div className={`rounded-lg border border-${tColor}-400/30 bg-${tColor}-500/10 p-2`}>
        <div className={`text-[10px] font-black uppercase text-${tColor}-700 dark:text-${tColor}-300`}>🧵 Trims{tLabel ? ` · ${tLabel}` : ""}</div>
        <div className="text-sm font-black tabular-nums">{tVal}</div>
      </div>
      <div className={`rounded-lg border border-${fColor}-400/30 bg-${fColor}-500/10 p-2`}>
        <div className={`text-[10px] font-black uppercase text-${fColor}-700 dark:text-${fColor}-300`}>🧶 Fabric{tLabel ? ` · ${tLabel}` : ""}</div>
        <div className="text-sm font-black tabular-nums">{fVal}</div>
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      {/* FILTER */}
      <div className="rounded-2xl border-2 border-primary/20 bg-gradient-to-r from-primary/5 via-background to-primary/5 p-3 flex items-center gap-3 flex-wrap sticky top-0 z-10 backdrop-blur">
        <div className="text-xs font-black uppercase text-muted-foreground">Filter</div>
        <div className="flex gap-1 rounded-xl border bg-background/70 p-1">
          {RANGES.map((r) => {
            const active = !customDate && range === r.key;
            return (
              <button key={r.key} type="button" onClick={() => { setCustomDate(""); setRange(r.key); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${active ? "bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow" : "text-muted-foreground hover:bg-muted"}`}>
                {r.label}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-bold uppercase text-muted-foreground">Pick date</label>
          <input type="date" value={customDate} onChange={(e) => setCustomDate(e.target.value)}
            className={`px-2 py-1.5 rounded-lg border text-xs font-semibold bg-background ${customDate ? "border-indigo-500 ring-1 ring-indigo-500/40" : "border-input"}`} />
          {customDate && <button type="button" onClick={() => setCustomDate("")} className="text-[11px] font-bold text-muted-foreground hover:text-foreground underline">Clear</button>}
        </div>
        <div className="text-[11px] text-muted-foreground ml-auto tabular-nums">{rangeLabel} · {daysInRange} day{daysInRange === 1 ? "" : "s"}</div>
      </div>

      {/* ======= WAREHOUSE-WIDE MAIN KPI HERO ======= */}
      <WarehouseKpiHero
        vehicles={state.vehicles}
        cc={cc}
        gb={gb}
        dt={dt}
        picker={picker}
        invAgg={invAgg}
        demurrage={demurrage}
      />



      <div className="grid gap-4 lg:grid-cols-2">
        {/* CYCLE COUNTING */}
        <div className="rounded-2xl border-2 border-teal-400/30 bg-gradient-to-br from-teal-500/10 via-background to-emerald-500/5 p-5 shadow-lg shadow-teal-500/10">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 grid place-items-center text-white shadow"><ClipboardCheck className="h-5 w-5" /></div>
            <div>
              <div className="text-sm font-black text-teal-700 dark:text-teal-300">Cycle Counting — Combined</div>
              <div className="text-[11px] text-muted-foreground">{monthKey} · Trims + Fabric</div>
            </div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">{cc.total.pct}%</div>
            <div className="text-xs text-muted-foreground pb-1">{cc.total.actual.toLocaleString()} / {cc.total.target.toLocaleString()}</div>
          </div>
          <div className="h-2 rounded-full bg-teal-500/10 overflow-hidden mt-2">
            <div className="h-full bg-gradient-to-r from-teal-500 to-emerald-500" style={{ width: `${cc.total.pct}%` }} />
          </div>
          <SplitRow tVal={`${cc.trims.actual}/${cc.trims.target} · ${cc.trims.pct}%`} fVal={`${cc.fabric.actual}/${cc.fabric.target} · ${cc.fabric.pct}%`} />
        </div>

        {/* GREEN BOARD */}
        <div className="rounded-2xl border-2 border-emerald-400/30 bg-gradient-to-br from-emerald-500/10 via-background to-lime-500/5 p-5 shadow-lg shadow-emerald-500/10">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-500 to-lime-600 grid place-items-center text-white shadow"><Leaf className="h-5 w-5" /></div>
            <div>
              <div className="text-sm font-black text-emerald-700 dark:text-emerald-300">Green Board — Combined Clean %</div>
              <div className="text-[11px] text-muted-foreground">{daysInRange} day{daysInRange === 1 ? "" : "s"} · red cells across all areas</div>
            </div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-emerald-600 to-lime-600 bg-clip-text text-transparent">{gb.total.clean}%</div>
            <div className="text-xs text-muted-foreground pb-1">{gb.total.red} red / {gb.total.total} cells</div>
          </div>
          <div className="h-2 rounded-full bg-emerald-500/10 overflow-hidden mt-2">
            <div className="h-full bg-gradient-to-r from-emerald-500 to-lime-500" style={{ width: `${gb.total.clean}%` }} />
          </div>
          <SplitRow tVal={`${gb.trims.clean}% clean · ${gb.trims.red} red`} fVal={`${gb.fabric.clean}% clean · ${gb.fabric.red} red`} />
        </div>

        {/* DOWNTIME */}
        <div className="rounded-2xl border-2 border-orange-400/30 bg-gradient-to-br from-orange-500/10 via-background to-red-500/5 p-5 shadow-lg shadow-orange-500/10">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-orange-500 to-red-600 grid place-items-center text-white shadow"><Timer className="h-5 w-5" /></div>
            <div>
              <div className="text-sm font-black text-orange-700 dark:text-orange-300">Downtime — Combined Lost Hours</div>
              <div className="text-[11px] text-muted-foreground">target = 0 h · {dt.totalEvents} events total</div>
            </div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">{dt.totalHours}</div>
            <div className="text-xs text-muted-foreground pb-1">lost hours</div>
          </div>
          <SplitRow tLabel="hrs" tVal={`${dt.trims.hours} · ${dt.trims.events} evt`} fVal={`${dt.fabric.hours} · ${dt.fabric.events} evt`} tColor="rose" fColor="amber" />
          {(dt.trims.items.length > 0 || dt.fabric.items.length > 0) && (
            <div className="grid gap-2 sm:grid-cols-2 mt-3">
              <div>
                <div className="text-[10px] font-black uppercase text-rose-700 dark:text-rose-300 mb-1">Top Trims</div>
                {dt.trims.items.slice(0, 3).map((r) => (
                  <div key={r.concern} className="text-[11px] flex justify-between border-b border-rose-400/10 py-0.5">
                    <span className="truncate pr-1">{r.concern}</span><span className="tabular-nums font-bold">{r.hours}h</span>
                  </div>
                ))}
                {dt.trims.items.length === 0 && <div className="text-[10px] text-muted-foreground">—</div>}
              </div>
              <div>
                <div className="text-[10px] font-black uppercase text-amber-700 dark:text-amber-300 mb-1">Top Fabric</div>
                {dt.fabric.items.slice(0, 3).map((r) => (
                  <div key={r.concern} className="text-[11px] flex justify-between border-b border-amber-400/10 py-0.5">
                    <span className="truncate pr-1">{r.concern}</span><span className="tabular-nums font-bold">{r.hours}h</span>
                  </div>
                ))}
                {dt.fabric.items.length === 0 && <div className="text-[10px] text-muted-foreground">—</div>}
              </div>
            </div>
          )}
        </div>

        {/* PICKER */}
        <div className="rounded-2xl border-2 border-fuchsia-400/30 bg-gradient-to-br from-fuchsia-500/10 via-background to-purple-500/5 p-5 shadow-lg shadow-fuchsia-500/10">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-fuchsia-500 to-purple-600 grid place-items-center text-white shadow"><HandMetal className="h-5 w-5" /></div>
            <div>
              <div className="text-sm font-black text-fuchsia-700 dark:text-fuchsia-300">Picker Performance — Today</div>
              <div className="text-[11px] text-muted-foreground">{picker.total.pickers} pickers · GIN vs daily target</div>
            </div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-fuchsia-600 to-purple-600 bg-clip-text text-transparent">{picker.total.pct}%</div>
            <div className="text-xs text-muted-foreground pb-1">{picker.total.achieved} / {picker.total.target}</div>
          </div>
          <div className="h-2 rounded-full bg-fuchsia-500/10 overflow-hidden mt-2">
            <div className="h-full bg-gradient-to-r from-fuchsia-500 to-purple-500" style={{ width: `${picker.total.pct}%` }} />
          </div>
          <SplitRow tVal={`${picker.trims.achieved}/${picker.trims.target} · ${picker.trims.pct}%`} fVal={`${picker.fabric.achieved}/${picker.fabric.target} · ${picker.fabric.pct}%`} />
        </div>

        {/* INVOICE */}
        <div className="rounded-2xl border-2 border-sky-400/30 bg-gradient-to-br from-sky-500/10 via-background to-cyan-500/5 p-5 shadow-lg shadow-sky-500/10 lg:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-sky-500 to-cyan-600 grid place-items-center text-white shadow"><FileText className="h-5 w-5" /></div>
            <div>
              <div className="text-sm font-black text-sky-700 dark:text-sky-300">Daily Invoice GRN Completion — Combined</div>
              <div className="text-[11px] text-muted-foreground">received vs completed · Trims + Fabric</div>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-sky-400/20 bg-background/60 p-3">
              <div className="text-[10px] font-black uppercase text-muted-foreground">Combined</div>
              <div className="text-2xl font-black tabular-nums bg-gradient-to-r from-sky-600 to-cyan-600 bg-clip-text text-transparent">{invAgg.total.pct}%</div>
              <div className="text-[11px] text-muted-foreground">{invAgg.total.done}/{invAgg.total.rec} · pending {invAgg.total.pend}</div>
              <div className="h-1.5 rounded-full bg-sky-500/10 overflow-hidden mt-1"><div className="h-full bg-sky-500" style={{ width: `${invAgg.total.pct}%` }} /></div>
            </div>
            <div className="rounded-xl border border-rose-400/20 bg-rose-500/5 p-3">
              <div className="text-[10px] font-black uppercase text-rose-700 dark:text-rose-300">🧵 Trims WH</div>
              <div className="text-2xl font-black tabular-nums text-rose-600 dark:text-rose-300">{invAgg.trims.pct}%</div>
              <div className="text-[11px] text-muted-foreground">{invAgg.trims.done}/{invAgg.trims.rec} · pending {invAgg.trims.pend}</div>
              <div className="h-1.5 rounded-full bg-rose-500/10 overflow-hidden mt-1"><div className="h-full bg-rose-500" style={{ width: `${invAgg.trims.pct}%` }} /></div>
            </div>
            <div className="rounded-xl border border-amber-400/20 bg-amber-500/5 p-3">
              <div className="text-[10px] font-black uppercase text-amber-700 dark:text-amber-300">🧶 Fabric WH</div>
              <div className="text-2xl font-black tabular-nums text-amber-600 dark:text-amber-300">{invAgg.fabric.pct}%</div>
              <div className="text-[11px] text-muted-foreground">{invAgg.fabric.done}/{invAgg.fabric.rec} · pending {invAgg.fabric.pend}</div>
              <div className="h-1.5 rounded-full bg-amber-500/10 overflow-hidden mt-1"><div className="h-full bg-amber-500" style={{ width: `${invAgg.fabric.pct}%` }} /></div>
            </div>
          </div>
        </div>

        {/* DEMURRAGE / HELD-UP COST */}
        <div className="rounded-2xl border-2 border-red-400/30 bg-gradient-to-br from-red-500/10 via-background to-rose-500/5 p-5 shadow-lg shadow-red-500/10 lg:col-span-2">
          <div className="flex items-center gap-2 mb-3">
            <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-red-500 to-rose-600 grid place-items-center text-white shadow"><DollarSign className="h-5 w-5" /></div>
            <div>
              <div className="text-sm font-black text-red-700 dark:text-red-300">Held-Up / Demurrage — Live Cost</div>
              <div className="text-[11px] text-muted-foreground">accruing on {demurrage.total.count} vehicle(s) beyond 24h SLA · admin panel rates</div>
            </div>
          </div>
          <div className="flex items-end gap-2 mb-3">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">Rs. {Math.round(demurrage.total.cost).toLocaleString()}</div>
            <div className="text-xs text-muted-foreground pb-1">total live accrual</div>
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-xl border border-rose-400/20 bg-rose-500/5 p-3">
              <div className="text-[10px] font-black uppercase text-rose-700 dark:text-rose-300">🧵 Trims</div>
              <div className="text-lg font-black tabular-nums text-rose-600 dark:text-rose-300">Rs. {Math.round(demurrage.trims.cost).toLocaleString()}</div>
              <div className="text-[11px] text-muted-foreground">{demurrage.trims.count} vehicle(s)</div>
            </div>
            <div className="rounded-xl border border-amber-400/20 bg-amber-500/5 p-3">
              <div className="text-[10px] font-black uppercase text-amber-700 dark:text-amber-300">🧶 Fabric</div>
              <div className="text-lg font-black tabular-nums text-amber-600 dark:text-amber-300">Rs. {Math.round(demurrage.fabric.cost).toLocaleString()}</div>
              <div className="text-[11px] text-muted-foreground">{demurrage.fabric.count} vehicle(s)</div>
            </div>
            <div className="rounded-xl border border-slate-400/20 bg-slate-500/5 p-3">
              <div className="text-[10px] font-black uppercase text-slate-700 dark:text-slate-300">📦 Other</div>
              <div className="text-lg font-black tabular-nums text-slate-700 dark:text-slate-300">Rs. {Math.round(demurrage.other.cost).toLocaleString()}</div>
              <div className="text-[11px] text-muted-foreground">{demurrage.other.count} vehicle(s)</div>
            </div>
          </div>
        </div>
      </div>


      {loading && <div className="text-xs text-muted-foreground text-center">Loading…</div>}
    </div>
  );
}

// ============ WAREHOUSE-WIDE MAIN KPI HERO ============
interface HeroProps {
  vehicles: ReturnType<typeof useApp>["state"]["vehicles"];
  cc: { total: { pct: number; actual: number; target: number } };
  gb: { total: { clean: number; red: number; total: number } };
  dt: { totalHours: number; totalEvents: number };
  picker: { total: { pct: number; achieved: number; target: number } };
  invAgg: { total: { pct: number; done: number; rec: number; pend: number } };
  demurrage: { total: { count: number; cost: number } };
}

function WarehouseKpiHero({ vehicles, cc, gb, dt, picker, invAgg, demurrage }: HeroProps) {
  const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
  const active = vehicles.filter((v) => ["Waiting", "Assigned", "Unloading", "Hold"].includes(v.current_status));
  const unloading = vehicles.filter((v) => v.current_status === "Unloading").length;
  const waiting = vehicles.filter((v) => v.current_status === "Waiting" || v.current_status === "Assigned").length;
  const onHold = vehicles.filter((v) => v.current_status === "Hold").length;
  const completedToday = vehicles.filter((v) => {
    if (v.current_status !== "Completed" && v.current_status !== "Departed") return false;
    const t = v.unload_end_time || v.out_time;
    return t ? new Date(t) >= todayStart : false;
  }).length;

  const tiles: Array<{
    icon: React.ReactNode; label: string; value: string; sub: string;
    from: string; to: string; text: string; border: string;
  }> = [
    {
      icon: <Truck className="h-5 w-5" />, label: "Live Vehicles",
      value: String(active.length), sub: `${unloading} unloading · ${waiting} waiting · ${onHold} hold`,
      from: "from-indigo-500", to: "to-violet-600", text: "text-indigo-700 dark:text-indigo-300", border: "border-indigo-400/30",
    },
    {
      icon: <PackageCheck className="h-5 w-5" />, label: "Completed Today",
      value: String(completedToday), sub: "vehicles departed / done",
      from: "from-emerald-500", to: "to-teal-600", text: "text-emerald-700 dark:text-emerald-300", border: "border-emerald-400/30",
    },
    {
      icon: <DollarSign className="h-5 w-5" />, label: "Live Demurrage",
      value: `Rs. ${Math.round(demurrage.total.cost).toLocaleString()}`, sub: `${demurrage.total.count} held-up vehicle(s)`,
      from: "from-red-500", to: "to-rose-600", text: "text-red-700 dark:text-red-300", border: "border-red-400/30",
    },
    {
      icon: <FileText className="h-5 w-5" />, label: "Invoice GRN",
      value: `${invAgg.total.pct}%`, sub: `${invAgg.total.done}/${invAgg.total.rec} · pending ${invAgg.total.pend}`,
      from: "from-sky-500", to: "to-cyan-600", text: "text-sky-700 dark:text-sky-300", border: "border-sky-400/30",
    },
    {
      icon: <ClipboardCheck className="h-5 w-5" />, label: "Cycle Count",
      value: `${cc.total.pct}%`, sub: `${cc.total.actual.toLocaleString()} / ${cc.total.target.toLocaleString()}`,
      from: "from-teal-500", to: "to-emerald-600", text: "text-teal-700 dark:text-teal-300", border: "border-teal-400/30",
    },
    {
      icon: <Leaf className="h-5 w-5" />, label: "Green Board Clean",
      value: `${gb.total.clean}%`, sub: `${gb.total.red} red / ${gb.total.total} cells`,
      from: "from-lime-500", to: "to-green-600", text: "text-lime-700 dark:text-lime-300", border: "border-lime-400/30",
    },
    {
      icon: <HandMetal className="h-5 w-5" />, label: "Picker Perf.",
      value: `${picker.total.pct}%`, sub: `${picker.total.achieved}/${picker.total.target} GIN today`,
      from: "from-fuchsia-500", to: "to-purple-600", text: "text-fuchsia-700 dark:text-fuchsia-300", border: "border-fuchsia-400/30",
    },
    {
      icon: <Timer className="h-5 w-5" />, label: "Downtime",
      value: `${dt.totalHours}h`, sub: `${dt.totalEvents} event(s) · target 0h`,
      from: "from-orange-500", to: "to-red-600", text: "text-orange-700 dark:text-orange-300", border: "border-orange-400/30",
    },
  ];

  const alerts: string[] = [];
  if (demurrage.total.count > 0) alerts.push(`${demurrage.total.count} vehicle(s) accruing demurrage`);
  if (onHold > 0) alerts.push(`${onHold} vehicle(s) on hold`);
  if (invAgg.total.pend > 0) alerts.push(`${invAgg.total.pend} invoice(s) pending`);
  if (dt.totalHours > 0) alerts.push(`${dt.totalHours}h downtime logged`);

  return (
    <div className="rounded-2xl border-2 border-indigo-400/30 bg-gradient-to-br from-indigo-500/10 via-background to-violet-500/5 p-4 shadow-lg shadow-indigo-500/10">
      <div className="flex items-center gap-2 mb-3">
        <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 grid place-items-center text-white shadow">
          <Activity className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="text-sm font-black text-indigo-700 dark:text-indigo-300">Warehouse Main KPIs — Live</div>
          <div className="text-[11px] text-muted-foreground">Consolidated snapshot across Trims &amp; Fabric warehouses</div>
        </div>
      </div>
      <div className="grid gap-3 grid-cols-2 md:grid-cols-4">
        {tiles.map((t) => (
          <div key={t.label} className={`rounded-xl border ${t.border} bg-background/70 p-3 shadow-sm`}>
            <div className="flex items-center gap-2 mb-1">
              <div className={`h-7 w-7 rounded-lg bg-gradient-to-br ${t.from} ${t.to} grid place-items-center text-white shadow-sm`}>
                {t.icon}
              </div>
              <div className={`text-[10px] font-black uppercase tracking-wide ${t.text}`}>{t.label}</div>
            </div>
            <div className={`text-2xl font-black tabular-nums bg-gradient-to-r ${t.from} ${t.to} bg-clip-text text-transparent`}>
              {t.value}
            </div>
            <div className="text-[11px] text-muted-foreground truncate">{t.sub}</div>
          </div>
        ))}
      </div>
      {alerts.length > 0 && (
        <div className="mt-3 flex items-start gap-2 rounded-xl border border-amber-400/30 bg-amber-500/10 p-2.5">
          <AlertTriangle className="h-4 w-4 text-amber-600 dark:text-amber-300 mt-0.5 shrink-0" />
          <div className="text-[11px] font-semibold text-amber-800 dark:text-amber-200 flex flex-wrap gap-x-3 gap-y-0.5">
            {alerts.map((a) => <span key={a}>• {a}</span>)}
          </div>
        </div>
      )}
    </div>
  );
}
