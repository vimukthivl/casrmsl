import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { supplierSummary, validateSupplierReport } from "@/lib/segregation-summary";
import { toast } from "sonner";
import { Plus, Send, Trash2, Building2 } from "lucide-react";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;
type Kind = "supplier" | "supplier_concern" | "category";
interface Option { id: string; kind: Kind; label: string }
export interface SegEntry {
  id: string; entry_date: string; supplier: string; supplier_concern: string;
  category: string; note: string;
  created_at: string;
}
const pad = (n: number) => String(n).padStart(2, "0");
const today = () => { const d = new Date(); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const selectClass = "w-full min-w-0 px-3 py-2 border border-input rounded-md text-sm bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring";

function useOptions() {
  const [opts, setOpts] = useState<Option[]>([]);
  const load = useCallback(async () => {
    const { data, error } = await sb.from("segregation_options").select("id,kind,label").eq("is_active", true).in("kind", ["supplier", "supplier_concern", "category"]).order("label");
    if (error) { toast.error(error.message); return; }
    setOpts((data ?? []) as Option[]);
  }, []);
  useEffect(() => { void load(); }, [load]);
  return { opts, reload: load };
}

function OptionSelect({ kind, label, value, onChange, opts, reload }: {
  kind: Kind; label: string; value: string; onChange: (v: string) => void; opts: Option[]; reload: () => Promise<void>;
}) {
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const list = opts.filter((o) => o.kind === kind);
  const add = async () => {
    if (busy) return;
    const v = text.trim();
    if (!v) return toast.error(`Type the new ${label} first.`);
    if (list.some((o) => o.label.toLowerCase() === v.toLowerCase())) return toast.error(`${label} already exists.`);
    setBusy(true);
    try {
      const { error } = await sb.from("segregation_options").insert({ kind, label: v });
      if (error) throw error;
      await reload(); onChange(v); setText(""); setAdding(false);
      toast.success(`${label} added`);
    } catch (error) { toast.error((error as { message?: string }).message ?? "Could not add option."); }
    finally { setBusy(false); }
  };
  return <div>
    <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
      <label htmlFor={`seg-${kind}`} className="text-xs font-semibold uppercase text-muted-foreground">{label}</label>
      <Button type="button" variant="ghost" size="sm" onClick={() => setAdding((a) => !a)} className="text-board-clean-foreground"><Plus />{adding ? "Cancel" : "Add new"}</Button>
    </div>
    <select id={`seg-${kind}`} required value={value} onChange={(e) => onChange(e.target.value)} className={selectClass}>
      <option value="">{list.length ? `Select ${label.toLowerCase()}…` : `No ${label.toLowerCase()} yet — add new`}</option>
      {list.map((o) => <option key={o.id} value={o.label}>{o.label}</option>)}
    </select>
    {adding && <div className="mt-2 flex gap-2">
      <input aria-label={`New ${label}`} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); void add(); } }} placeholder={`New ${label.toLowerCase()}`} className={`${selectClass} flex-1`} />
      <Button type="button" onClick={() => void add()} disabled={busy}>{busy ? "Adding…" : "Add"}</Button>
    </div>}
  </div>;
}

export function SegregationReportForm() {
  const { opts, reload } = useOptions();
  const [supplier, setSupplier] = useState("");
  const [supplierConcern, setSupplierConcern] = useState("");
  const [category, setCategory] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [recent, setRecent] = useState<SegEntry[]>([]);
  const loadRecent = useCallback(async () => {
    const { data, error } = await sb.from("segregation_entries").select("id,entry_date,supplier,supplier_concern,category,note,created_at").neq("supplier", "").neq("supplier_concern", "").order("created_at", { ascending: false }).limit(10);
    if (error) { toast.error(error.message); return; }
    setRecent((data ?? []) as SegEntry[]);
  }, []);
  useEffect(() => { void loadRecent(); }, [loadRecent]);
  const submit = async () => {
    if (saving) return;
    const validation = validateSupplierReport(supplier, supplierConcern, category);
    if (validation) return toast.error(validation);
    setSaving(true);
    try {
      const { error } = await sb.from("segregation_entries").insert({ entry_date: today(), supplier: supplier.trim(), supplier_concern: supplierConcern.trim(), category: category.trim(), note: note.trim() });
      if (error) throw error;
      toast.success("Submitted — Segregation Area updated");
      setSupplier(""); setSupplierConcern(""); setCategory(""); setNote("");
      await loadRecent();
    } catch (error) { toast.error((error as { message?: string }).message ?? "Submission failed. Please try again."); }
    finally { setSaving(false); }
  };
  return <>
    <section className="border-y border-border bg-card">
      <h2 className="px-5 py-3 bg-primary text-primary-foreground text-sm font-bold uppercase">Segregation Area — Issue Form</h2>
      <form onSubmit={(e) => { e.preventDefault(); void submit(); }} className="p-5 space-y-4">
        <OptionSelect kind="supplier" label="Supplier" value={supplier} onChange={setSupplier} opts={opts} reload={reload} />
        <OptionSelect kind="supplier_concern" label="Supplier Concern / Issue" value={supplierConcern} onChange={setSupplierConcern} opts={opts} reload={reload} />
        <OptionSelect kind="category" label="Category" value={category} onChange={setCategory} opts={opts} reload={reload} />
        <div>
          <label htmlFor="seg-note" className="block text-xs font-semibold uppercase text-muted-foreground mb-1.5">Note <span className="normal-case font-normal">(optional)</span></label>
          <textarea id="seg-note" value={note} onChange={(e) => setNote(e.target.value)} rows={3} maxLength={500} placeholder="Extra details about this issue…" className={`${selectClass} resize-y`} />
        </div>
        <Button type="submit" disabled={saving} className="w-full h-11 bg-board-clean text-board-clean-foreground hover:bg-board-clean/90"><Send />{saving ? "Submitting…" : "Submit to Green Board"}</Button>
      </form>
    </section>
    <SegregationTable rows={recent} title="Latest Segregation Area reports" />
  </>;
}

export function SegregationTable({ rows, title, onDelete }: { rows: SegEntry[]; title: string; onDelete?: (id: string) => void }) {
  return <section className="mt-5 border-y border-border bg-card">
    <h2 className="px-4 py-3 text-xs font-bold uppercase text-board-clean-foreground bg-board-clean/15">{title}</h2>
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="bg-muted text-xs uppercase text-muted-foreground"><tr>
          {["Date", "Supplier", "Supplier Concern / Issue", "Category", "Note"].map((h) => <th key={h} className="px-3 py-3 text-left font-semibold">{h}</th>)}
          {onDelete && <th><span className="sr-only">Actions</span></th>}
        </tr></thead>
        <tbody className="divide-y divide-border">
          {rows.length === 0 && <tr><td colSpan={onDelete ? 6 : 5} className="px-3 py-6 text-center text-muted-foreground">No supplier reports yet</td></tr>}
          {rows.map((r) => <tr key={r.id}>
            <td className="px-3 py-3 whitespace-nowrap tabular-nums">{r.entry_date}</td>
            <td className="px-3 py-3 break-words font-medium">{r.supplier || "—"}</td>
            <td className="px-3 py-3 break-words text-destructive">{r.supplier_concern || "—"}</td>
            <td className="px-3 py-3 break-words">{r.category || "—"}</td>
            <td className="px-3 py-3 break-words text-muted-foreground">{r.note || "—"}</td>
            {onDelete && <td className="px-2"><Button variant="ghost" size="icon" onClick={() => onDelete(r.id)} className="text-destructive" aria-label="Delete report" title="Delete report"><Trash2 /></Button></td>}
          </tr>)}
        </tbody>
      </table>
    </div>
  </section>;
}

export function SegregationBoard({ year, month0, isAdmin }: { year: number; month0: number; isAdmin: boolean }) {
  const [rows, setRows] = useState<SegEntry[]>([]);
  const days = new Date(year, month0 + 1, 0).getDate();
  const start = `${year}-${pad(month0 + 1)}-01`;
  const end = `${year}-${pad(month0 + 1)}-${pad(days)}`;
  const load = useCallback(async () => {
    const { data, error } = await sb.from("segregation_entries").select("id,entry_date,supplier,supplier_concern,category,note,created_at").gte("entry_date", start).lte("entry_date", end).order("entry_date", { ascending: false });
    if (error) { toast.error(error.message); return; }
    setRows((data ?? []) as SegEntry[]);
  }, [start, end]);
  useEffect(() => {
    void load();
    const refresh = () => { if (document.visibilityState === "visible") void load(); };
    const t = window.setInterval(refresh, 10000);
    window.addEventListener("focus", refresh);
    return () => { window.clearInterval(t); window.removeEventListener("focus", refresh); };
  }, [load]);
  const summaries = useMemo(() => supplierSummary(rows), [rows]);
  const supplierRows = useMemo(() => rows.filter((r) => r.supplier.trim() && r.supplier_concern.trim()), [rows]);
  const dayList = useMemo(() => Array.from({ length: days }, (_, i) => i + 1).filter((d) => new Date(year, month0, d).getDay() !== 0), [days, year, month0]);
  const counts = useMemo(() => { const m: Record<string, number> = {}; supplierRows.forEach((r) => { m[r.entry_date] = (m[r.entry_date] ?? 0) + 1; }); return m; }, [supplierRows]);
  const todayS = today();
  const elapsed = dayList.filter((d) => `${year}-${pad(month0 + 1)}-${pad(d)}` <= todayS);
  const red = elapsed.filter((d) => counts[`${year}-${pad(month0 + 1)}-${pad(d)}`]).length;
  const clean = elapsed.length ? Math.round(((elapsed.length - red) / elapsed.length) * 100) : 100;
  const del = async (id: string) => {
    if (!confirm("Delete this report?")) return;
    const { error } = await sb.from("segregation_entries").delete().eq("id", id);
    if (error) return toast.error(error.message);
    void load();
  };
  return <>
    <div className="mb-5 grid grid-cols-2 md:grid-cols-4 gap-3">
      {[["Reports this month", supplierRows.length], ["Suppliers with issues", summaries.length], ["Red days", red], ["Clean % (to date)", `${clean}%`]].map(([l, v]) => <div key={l} className="rounded-lg border border-border bg-card p-4">
        <div className="text-xs uppercase text-muted-foreground font-semibold">{l}</div><div className="text-3xl font-bold text-foreground tabular-nums">{v}</div>
      </div>)}
    </div>
    <section className="py-4 border-y border-border">
      <h2 className="text-xs font-bold uppercase text-muted-foreground mb-3">Segregation Area · Daily</h2>
      <div className="flex flex-wrap gap-1.5">{dayList.map((d) => {
        const key = `${year}-${pad(month0 + 1)}-${pad(d)}`;
        const c = counts[key] ?? 0;
        const future = key > todayS;
        return <div key={d} title={c ? `${c} submissions` : "Clean"} className={`w-11 h-11 rounded-md grid place-items-center text-xs font-bold ${future ? "bg-muted text-muted-foreground" : c ? "bg-destructive text-destructive-foreground" : "bg-board-clean text-board-clean-foreground"} ${key === todayS ? "ring-2 ring-ring" : ""}`}>
          <div className="leading-none text-center">{d}{c ? <div className="text-[10px] mt-1">×{c}</div> : null}</div>
        </div>;
      })}</div>
    </section>
    <section className="mt-5 border-y border-border bg-card">
      <h2 className="px-4 py-3 flex items-center gap-2 text-sm font-bold text-board-clean-foreground bg-board-clean/15"><Building2 className="h-4 w-4" />Supplier-wise summary · {new Date(year, month0, 1).toLocaleString("en", { month: "long", year: "numeric" })}</h2>
      <div className="overflow-x-auto"><table className="w-full text-sm">
        <thead className="bg-muted text-muted-foreground text-xs uppercase"><tr>{["Supplier", "Submissions", "Concern / Issue breakdown", "Last reported"].map((h) => <th key={h} className="px-4 py-3 text-left font-semibold">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-border">
          {!summaries.length && <tr><td colSpan={4} className="p-6 text-center text-muted-foreground">No supplier reports this month</td></tr>}
          {summaries.map((s, i) => <tr key={s.supplier} className={i === 0 ? "bg-destructive/5" : ""}>
            <td className="px-4 py-3 font-semibold break-words">{s.supplier}</td>
            <td className="px-4 py-3 text-xl font-bold tabular-nums text-destructive">{s.count}</td>
            <td className="px-4 py-3 min-w-48"><ul className="space-y-1">{s.concerns.map((c) => <li key={c.label} className="flex items-start justify-between gap-4"><span className="break-words">{c.label}</span><span className="tabular-nums font-semibold shrink-0">×{c.count}</span></li>)}</ul></td>
            <td className="px-4 py-3 whitespace-nowrap tabular-nums text-muted-foreground">{s.lastDate}</td>
          </tr>)}
        </tbody>
      </table></div>
    </section>
    <SegregationTable rows={supplierRows} title="Segregation Area reports this month" onDelete={isAdmin ? del : undefined} />
  </>;
}
