import { ArrowDownLeft, ArrowUpRight, CalendarClock, Clock, FileText, Package, Truck, UserRound } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { VehicleLog } from "@/lib/types";
import { hasDeparted, vehicleDuration } from "@/lib/vehicle-update";

function timestamp(value?: string | null): string {
  return value ? new Date(value).toLocaleString("en-GB", { timeZone: "Asia/Colombo", day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";
}

function Detail({ label, value }: { label: string; value?: string | number | null }) {
  return <div className="min-w-0"><dt className="text-xs leading-5 text-muted-foreground">{label}</dt><dd className="mt-1 break-words text-sm font-semibold leading-6 [overflow-wrap:anywhere]">{value === undefined || value === null || value === "" ? "—" : value}</dd></div>;
}

function Group({ title, icon: Icon, children }: { title: string; icon: LucideIcon; children: React.ReactNode }) {
  return <section className="min-w-0"><h3 className="mb-3 flex items-center gap-2 text-sm font-semibold"><Icon className="h-4 w-4 shrink-0 text-muted-foreground" />{title}</h3><dl className="grid grid-cols-2 gap-x-5 gap-y-3">{children}</dl></section>;
}

export function VehicleUpdateCard({ vehicle: v, now }: { vehicle: VehicleLog; now: number }) {
  const departed = hasDeparted(v);
  const status = departed ? "Departed" : v.current_status === "Hold" ? "On hold" : v.current_status;
  const tone = departed || status === "Completed" ? "border-chart-2/40 bg-chart-2/10" : status === "On hold" ? "border-chart-5/40 bg-chart-5/10" : status === "Unloading" ? "border-chart-4/40 bg-chart-4/10" : "border-chart-3/30 bg-chart-3/10";
  const edge = departed || status === "Completed" ? "border-l-chart-2" : status === "On hold" ? "border-l-chart-5" : status === "Unloading" ? "border-l-chart-4" : "border-l-chart-3";
  return <article aria-label={`Vehicle ${v.vehicle_number || v.token_no}`} className={`min-w-0 overflow-hidden rounded-lg border border-l-4 bg-card ${edge}`}>
    <header className="flex flex-wrap items-start justify-between gap-4 border-b bg-muted/30 px-4 py-4 sm:px-6">
      <div className="flex min-w-0 flex-1 items-start gap-3">
        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border ${tone}`}><Truck className="h-6 w-6" /></div>
        <div className="min-w-0"><h2 className="break-words text-xl font-bold [overflow-wrap:anywhere]">{v.vehicle_number || "Vehicle not entered"}</h2><p className="mt-1 break-words text-sm text-muted-foreground">Token {v.token_no} · {v.vehicle_type} · {v.material_type}</p><p className="mt-2 break-words text-sm font-semibold [overflow-wrap:anywhere]">{v.vendor_name || "Supplier not entered"}</p></div>
      </div>
      <div className="flex flex-wrap items-center gap-2"><span className={`inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-xs font-semibold ${tone}`}>{departed ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownLeft className="h-3.5 w-3.5" />}{status}</span>{v.is_held_up && <span className="rounded-md border border-destructive/30 bg-destructive/10 px-3 py-1.5 text-xs font-semibold text-destructive">Held up</span>}</div>
    </header>
    <div className="grid gap-6 px-4 py-5 sm:px-6 md:grid-cols-2 xl:grid-cols-3">
      <Group title="Delivery & driver" icon={UserRound}><Detail label="Invoice no." value={v.invoice_no} /><Detail label="Relevant PCU" value={v.relevant_pcu} /><Detail label="Driver name" value={v.driver_name} /><Detail label="Driver phone" value={v.driver_phone} /><Detail label="Arrival status" value={v.arrival_status} /><Detail label="Current status" value={status} /></Group>
      <Group title="Load & unloading" icon={Package}><Detail label="Quantity brought" value={v.quantity_brought} /><Detail label="Partially unloaded qty" value={v.manually_unloaded_qty} /><Detail label="Roll quantity" value={v.roll_qty} /><Detail label="Box quantity" value={v.box_qty} /><Detail label="Bay" value={v.bay_id} /><Detail label="Queue position" value={v.queue_position} /></Group>
      <Group title="Bay reservation" icon={CalendarClock}><Detail label="Bay assigned" value={timestamp(v.bay_assigned_at)} /><Detail label="Requested start" value={timestamp(v.requested_start_time)} /><Detail label="Scheduled start" value={timestamp(v.scheduled_start_time)} /><Detail label="Scheduled end" value={timestamp(v.scheduled_end_time)} /><Detail label="Completed by" value={v.completed_by} /><Detail label="Schedule reference" value={v.schedule_id} /></Group>
    </div>
    <section className="border-t px-4 py-4 sm:px-6"><h3 className="mb-3 flex items-center gap-2 text-sm font-semibold"><Clock className="h-4 w-4 text-muted-foreground" />Movement history <span className="ml-auto text-xs font-normal text-muted-foreground">Colombo time</span></h3><dl className="grid grid-cols-2 gap-x-5 gap-y-4 lg:grid-cols-5"><Detail label="Gate check-in" value={timestamp(v.in_time)} /><Detail label="Unloading started" value={timestamp(v.unload_start_time)} /><Detail label="Unloading completed" value={timestamp(v.unload_end_time)} /><Detail label="Gate check-out" value={timestamp(v.out_time)} /><Detail label="Total time on site" value={now ? vehicleDuration(v, now) : "—"} /></dl></section>
    <section className={`border-t px-4 py-4 sm:px-6 ${v.is_held_up || v.hold_reason || v.hold_notes ? "bg-destructive/5" : "bg-muted/20"}`}><h3 className="mb-3 flex items-center gap-2 text-sm font-semibold"><FileText className="h-4 w-4 text-muted-foreground" />Hold details</h3><dl className="grid gap-3 sm:grid-cols-[100px_1fr_2fr]"><Detail label="Held up" value={v.is_held_up ? "Yes" : "No"} /><Detail label="Hold reason" value={v.hold_reason} /><Detail label="Hold notes" value={v.hold_notes} /></dl></section>
  </article>;
}