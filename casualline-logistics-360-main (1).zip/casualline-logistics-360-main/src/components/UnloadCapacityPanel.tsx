import { useMemo } from "react";
import { useApp, isoMondayOf } from "@/lib/store";
import { DAYS, type DayKey } from "@/lib/types";
import { Gauge, CheckCircle2, AlertTriangle, CalendarRange, Truck, Timer, Clock, MoonStar } from "lucide-react";

function parseHM(hm: string): number {
  if (!hm) return 0;
  const [h, m] = hm.split(":").map((n) => parseInt(n, 10) || 0);
  return h + m / 60;
}

function fmtMin(min: number): string {
  if (min <= 0) return "0m";
  const h = Math.floor(min / 60);
  const m = Math.round(min % 60);
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
}

export function UnloadCapacityPanel({ compact = false }: { compact?: boolean }) {
  const { state } = useApp();
  const currentMon = useMemo(() => isoMondayOf(), []);

  const { rows, weekly, shiftHours, shiftMinutes, unitsPerHour, shiftStart, shiftEnd } = useMemo(() => {
    const s = state.settings;
    const startH = parseHM(s.shift_start);
    const endH = parseHM(s.shift_end);
    const shiftH = Math.max(1, endH - startH);
    const shiftM = shiftH * 60;
    const uph = Math.max(1, ((Number(s.daily_roll_target) || 0) + (Number(s.daily_box_target) || 0)) / shiftH);

    const weekRows = state.schedules.filter((sc) => sc.week_start === currentMon);

    const rows = DAYS.map((d: DayKey) => {
      let vehicles = 0;
      let units = 0;
      let minutes = 0;
      let overtimeMin = 0;
      let lateArrivals = 0; // ih_time >= shift_end: won't unload same day
      let tightVehicles = 0; // arrival + unload > shift_end
      let latestFinishH = startH;

      for (const sc of weekRows) {
        const q = Number(sc.days_data?.[d]) || 0;
        if (q <= 0) continue;
        vehicles += 1;
        units += q;
        const need = (q / uph) * 60;
        minutes += need;

        const ihH = sc.ih_time ? parseHM(sc.ih_time) : startH;
        const startAt = Math.max(ihH, startH);
        if (ihH >= endH) {
          lateArrivals += 1;
          overtimeMin += need; // whole job pushed past shift
          latestFinishH = Math.max(latestFinishH, ihH + need / 60);
          continue;
        }
        const available = (endH - startAt) * 60;
        if (need > available) {
          tightVehicles += 1;
          overtimeMin += need - available;
        }
        latestFinishH = Math.max(latestFinishH, startAt + need / 60);
      }

      const utilPct = Math.min(999, Math.round((minutes / shiftM) * 100));
      const feasible = overtimeMin <= 0 && lateArrivals === 0;
      return { day: d, vehicles, units, minutes, utilPct, feasible, overtimeMin, lateArrivals, tightVehicles, latestFinishH };
    });

    const totalVehicles = rows.reduce((a, r) => a + r.vehicles, 0);
    const totalUnits = rows.reduce((a, r) => a + r.units, 0);
    const totalMin = rows.reduce((a, r) => a + r.minutes, 0);
    const totalOvertime = rows.reduce((a, r) => a + r.overtimeMin, 0);
    const totalLate = rows.reduce((a, r) => a + r.lateArrivals, 0);
    const daysNeeded = totalMin / shiftM;
    const capacityMin = shiftM * DAYS.length;
    const weekUtil = Math.round((totalMin / capacityMin) * 100);

    return {
      rows,
      weekly: { totalVehicles, totalUnits, totalMin, daysNeeded, weekUtil, capacityMin, totalOvertime, totalLate },
      shiftHours: shiftH,
      shiftMinutes: shiftM,
      unitsPerHour: uph,
      shiftStart: s.shift_start,
      shiftEnd: s.shift_end,
    };
  }, [state.schedules, state.settings, currentMon]);

  const anyOver = rows.some((r) => !r.feasible);

  function fmtHour(h: number): string {
    const hh = Math.floor(h);
    const mm = Math.round((h - hh) * 60);
    return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
  }

  return (
    <section className={`rounded-2xl border-2 ${anyOver ? "border-rose-400/50" : "border-emerald-400/50"} bg-gradient-to-br from-sky-500/5 via-card to-card shadow-sm`}>
      <header className="flex items-center justify-between gap-3 flex-wrap p-4 border-b">
        <div className="flex items-center gap-3">
          <div className={`h-10 w-10 rounded-lg grid place-items-center border ${anyOver ? "bg-rose-500/15 text-rose-700 border-rose-500/30" : "bg-emerald-500/15 text-emerald-700 border-emerald-500/30"}`}>
            <Gauge className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-base font-semibold">Unload Capacity vs PCU Schedule</h3>
            <p className="text-xs text-muted-foreground">
              Shift {shiftStart}–{shiftEnd} · {shiftHours.toFixed(1)}h/day · Throughput ≈ {Math.round(unitsPerHour)} units/hr · Uses IH Time per vehicle
            </p>
          </div>
        </div>
        <div className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold border ${anyOver ? "bg-rose-500/10 text-rose-700 border-rose-500/30" : "bg-emerald-500/10 text-emerald-700 border-emerald-500/30"}`}>
          {anyOver ? <AlertTriangle className="h-3.5 w-3.5" /> : <CheckCircle2 className="h-3.5 w-3.5" />}
          {anyOver ? "Overtime / Late arrivals" : "All days feasible"}
        </div>
      </header>

      <div className="p-4 grid grid-cols-2 md:grid-cols-5 gap-3">
        <MiniStat icon={Truck} label="Total Vehicles (Week)" value={String(weekly.totalVehicles)} tone="sky" />
        <MiniStat icon={Timer} label="Total Unload Time" value={fmtMin(weekly.totalMin)} tone="indigo" />
        <MiniStat icon={CalendarRange} label="Days Needed" value={`${weekly.daysNeeded.toFixed(2)} / ${DAYS.length}`} tone={weekly.daysNeeded > DAYS.length ? "rose" : "emerald"} />
        <MiniStat icon={Clock} label="Weekly Overtime" value={fmtMin(weekly.totalOvertime)} tone={weekly.totalOvertime > 0 ? "rose" : "emerald"} />
        <MiniStat icon={MoonStar} label={`Late Arrivals (after ${shiftEnd})`} value={String(weekly.totalLate)} tone={weekly.totalLate > 0 ? "rose" : "emerald"} />
      </div>

      {!compact && (
        <div className="overflow-x-auto px-4 pb-4">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase text-muted-foreground bg-muted/50">
              <tr>
                <th className="text-left p-2">Day</th>
                <th className="text-right p-2">Vehicles</th>
                <th className="text-right p-2">Units</th>
                <th className="text-right p-2">Est. Unload Time</th>
                <th className="text-right p-2">Last Finish</th>
                <th className="text-right p-2">Overtime</th>
                <th className="text-left p-2">Shift Load</th>
                <th className="text-right p-2">Status</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.day} className="border-t">
                  <td className="p-2 font-medium">{r.day}</td>
                  <td className="p-2 text-right tabular-nums">{r.vehicles}</td>
                  <td className="p-2 text-right tabular-nums">{r.units.toLocaleString()}</td>
                  <td className="p-2 text-right tabular-nums">{fmtMin(r.minutes)}</td>
                  <td className="p-2 text-right tabular-nums">
                    {r.vehicles === 0 ? (
                      <span className="text-muted-foreground">—</span>
                    ) : (
                      <span className={r.latestFinishH > parseHM(shiftEnd) ? "text-rose-700 font-semibold" : ""}>
                        {fmtHour(r.latestFinishH)}
                      </span>
                    )}
                  </td>
                  <td className="p-2 text-right tabular-nums">
                    {r.overtimeMin > 0 ? (
                      <span className="text-rose-700 font-semibold">+{fmtMin(r.overtimeMin)}</span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </td>
                  <td className="p-2">
                    <div className="h-2 rounded-full bg-muted overflow-hidden w-40">
                      <div
                        className={`h-full ${r.utilPct > 100 ? "bg-rose-500" : r.utilPct > 85 ? "bg-amber-500" : "bg-emerald-500"}`}
                        style={{ width: `${Math.min(100, r.utilPct)}%` }}
                      />
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">{r.utilPct}% of {shiftMinutes}m</div>
                  </td>
                  <td className="p-2 text-right">
                    {r.vehicles === 0 ? (
                      <span className="text-xs text-muted-foreground">—</span>
                    ) : r.lateArrivals > 0 ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700"><MoonStar className="h-3 w-3" /> {r.lateArrivals} after {shiftEnd}</span>
                    ) : r.overtimeMin > 0 ? (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-700"><AlertTriangle className="h-3 w-3" /> OT {fmtMin(r.overtimeMin)}</span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700"><CheckCircle2 className="h-3 w-3" /> Fits</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="text-[11px] text-muted-foreground mt-2">
            Per-vehicle check: available time = shift end ({shiftEnd}) − IH Time. If a vehicle's estimated unload exceeds available time, the excess counts as <b>Overtime</b>. Vehicles with IH Time on/after {shiftEnd} are flagged as <b>Late Arrivals</b> (cannot unload same day).
          </p>
        </div>
      )}
    </section>
  );
}

function MiniStat({ icon: Icon, label, value, tone }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string; tone: "sky" | "indigo" | "emerald" | "amber" | "rose" }) {
  const map: Record<string, string> = {
    sky: "from-sky-500/15 to-sky-500/5 text-sky-700 border-sky-500/30",
    indigo: "from-indigo-500/15 to-indigo-500/5 text-indigo-700 border-indigo-500/30",
    emerald: "from-emerald-500/15 to-emerald-500/5 text-emerald-700 border-emerald-500/30",
    amber: "from-amber-500/15 to-amber-500/5 text-amber-800 border-amber-500/30",
    rose: "from-rose-500/15 to-rose-500/5 text-rose-700 border-rose-500/30",
  };
  return (
    <div className={`rounded-xl border bg-gradient-to-br p-3 ${map[tone]}`}>
      <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider opacity-80">
        <Icon className="h-3.5 w-3.5" /> {label}
      </div>
      <div className="text-2xl font-black mt-1 tabular-nums">{value}</div>
    </div>
  );
}
