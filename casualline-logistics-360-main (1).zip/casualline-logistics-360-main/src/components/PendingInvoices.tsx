import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CheckCircle2, Plus, MessageSquare, Clock, AlertTriangle, Trash2, Search, Building2, X, Printer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { hasDuplicateInvoiceNumber } from "@/lib/pending-invoice";

export type PendingInvoice = {
  id: string;
  received_date: string;
  supplier: string;
  po_number: string;
  invoice_no: string;
  reason: string;
  pcu_member: string;
  merchant: string;
  pcu_comment: string;
  status: string;
  completed_at: string | null;
  completed_by: string | null;
};

const today = () => new Date().toISOString().slice(0, 10);

function pendingDays(received: string, completedAt: string | null) {
  const start = new Date(`${received}T00:00:00`);
  const end = completedAt ? new Date(completedAt) : new Date();
  const d = Math.floor((end.getTime() - start.getTime()) / 86400000);
  return d < 0 ? 0 : d;
}

function ageTone(days: number) {
  if (days >= 7) return "text-rose-500 bg-rose-500/10 border-rose-500/30";
  if (days >= 3) return "text-amber-500 bg-amber-500/10 border-amber-500/30";
  return "text-emerald-500 bg-emerald-500/10 border-emerald-500/30";
}

const emptyDraft = {
  received_date: today(),
  supplier: "",
  po_number: "",
  invoice_no: "",
  reason: "",
  pcu_member: "",
  merchant: "",
};

export function PendingInvoices({
  canComplete,
  userName,
  showAddForm = true,
  showSearch = false,
}: {
  canComplete: boolean;
  userName?: string;
  showAddForm?: boolean;
  showSearch?: boolean;
}) {
  const [rows, setRows] = useState<PendingInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [draft, setDraft] = useState({ ...emptyDraft });
  const [view, setView] = useState<"Pending" | "Completed">("Pending");
  const [pcuTab, setPcuTab] = useState<string>("ALL");
  const [commentDraft, setCommentDraft] = useState<Record<string, string>>({});
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState(false);
  const [invoiceError, setInvoiceError] = useState("");
  const [reasonOptions, setReasonOptions] = useState<string[]>([]);

  const load = async () => {
    const { data, error } = await supabase
      .from("pending_invoices")
      .select("*")
      .order("received_date", { ascending: true });
    if (error) {
      toast.error("Could not load pending invoices");
    } else {
      setRows((data ?? []) as PendingInvoice[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    load();
    supabase
      .from("grn_pending_reasons")
      .select("label")
      .eq("is_active", true)
      .order("sort_order")
      .then(({ data }) => {
        if (data) setReasonOptions(data.map((r) => r.label).filter(Boolean));
      });
    const ch = supabase
      .channel("pending_invoices_rt")
      .on("postgres_changes", { event: "*", schema: "public", table: "pending_invoices" }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  const pcuMembers = useMemo(
    () => Array.from(new Set(rows.map((r) => r.pcu_member.trim()).filter(Boolean))).sort(),
    [rows],
  );

  const supplierSuggestions = useMemo(
    () => Array.from(new Set(rows.map((r) => r.supplier.trim()).filter(Boolean))).sort(),
    [rows],
  );
  const reasonSuggestions = useMemo(
    () =>
      Array.from(
        new Set([...reasonOptions, ...rows.map((r) => r.reason.trim())].filter(Boolean)),
      ).sort(),
    [reasonOptions, rows],
  );

  const visible = useMemo(() => {
    let list = rows.filter((r) => (view === "Pending" ? r.status !== "Completed" : r.status === "Completed"));
    if (pcuTab !== "ALL") list = list.filter((r) => (r.pcu_member.trim() || "—") === pcuTab);
    const query = search.trim().toLocaleLowerCase();
    if (query) {
      list = list.filter((r) =>
        [r.supplier, r.po_number, r.invoice_no, r.reason, r.pcu_member, r.merchant, r.pcu_comment]
          .some((value) => value.toLocaleLowerCase().includes(query)),
      );
    }
    return list.sort((a, b) => a.received_date.localeCompare(b.received_date));
  }, [rows, view, pcuTab, search]);

  const printList = () => {
    if (visible.length === 0) {
      toast.error("Nothing to print");
      return;
    }
    const esc = (s: string) =>
      s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    const printedAt = new Date().toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" });
    const filterLabel = `${view}${pcuTab !== "ALL" ? ` · PCU: ${pcuTab}` : ""}${search.trim() ? ` · Search: "${search.trim()}"` : ""}`;
    const body = visible
      .map((r, i) => {
        const days = pendingDays(r.received_date, r.completed_at);
        return `<tr>
          <td>${i + 1}</td>
          <td>${esc(r.received_date)}</td>
          <td>${esc(r.supplier)}</td>
          <td>${esc(r.po_number)}</td>
          <td>${esc(r.invoice_no)}</td>
          <td>${esc(r.reason)}</td>
          <td>${esc(r.pcu_member)}</td>
          <td>${esc(r.merchant)}</td>
          <td class="num">${days}</td>
          <td>${esc(r.pcu_comment || "")}</td>
        </tr>`;
      })
      .join("");
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Pending Invoices — ${esc(view)}</title>
      <style>
        * { box-sizing: border-box; }
        body { font-family: Arial, Helvetica, sans-serif; color: #111; margin: 24px; font-size: 12px; }
        h1 { font-size: 18px; margin: 0 0 2px; }
        .meta { color: #555; margin-bottom: 14px; font-size: 11px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #999; padding: 5px 7px; text-align: left; vertical-align: top; }
        th { background: #eee; font-size: 10px; text-transform: uppercase; letter-spacing: .04em; }
        td.num { text-align: center; font-weight: 700; }
        tr:nth-child(even) td { background: #f7f7f7; }
        .footer { margin-top: 12px; color: #555; font-size: 10px; }
        @media print { body { margin: 10mm; } }
      </style></head><body>
      <h1>Pending Invoices — ${esc(view)}</h1>
      <div class="meta">Casualline Logistics 360 · RM GRN Team · ${esc(filterLabel)} · ${visible.length} record${visible.length === 1 ? "" : "s"} · Printed ${esc(printedAt)}</div>
      <table><thead><tr>
        <th>#</th><th>Received</th><th>Supplier</th><th>P/O</th><th>Invoice No</th><th>Reason</th><th>PCU Member</th><th>Merchant</th><th>Pending Days</th><th>PCU Comment</th>
      </tr></thead><tbody>${body}</tbody></table>
      <div class="footer">Generated from the GRN Pending Invoices module.</div>
      <script>window.onload = function () { window.print(); };</script>
      </body></html>`;
    const win = window.open("", "_blank", "width=1100,height=800");
    if (!win) {
      toast.error("Pop-up blocked — allow pop-ups to print");
      return;
    }
    win.document.write(html);
    win.document.close();
  };

  const pending = rows.filter((r) => r.status !== "Completed");
  const summary = useMemo(() => {
    const days = pending.map((r) => pendingDays(r.received_date, null));
    return {
      total: pending.length,
      over7: days.filter((d) => d >= 7).length,
      over3: days.filter((d) => d >= 3 && d < 7).length,
      oldest: days.length ? Math.max(...days) : 0,
      avg: days.length ? Math.round((days.reduce((a, b) => a + b, 0) / days.length) * 10) / 10 : 0,
      completedToday: rows.filter((r) => r.status === "Completed" && (r.completed_at ?? "").slice(0, 10) === today())
        .length,
    };
  }, [rows, pending]);

  const bySupplier = useMemo(() => {
    const m = new Map<string, number>();
    pending.forEach((r) => {
      const k = r.supplier.trim() || "Supplier not entered";
      m.set(k, (m.get(k) ?? 0) + 1);
    });
    return Array.from(m.entries()).sort((a, b) => b[1] - a[1]);
  }, [pending]);

  const add = async () => {
    if (saving) return;
    if (!draft.invoice_no.trim() && !draft.po_number.trim()) {
      toast.error("Invoice No or P/O required");
      return;
    }
    if (hasDuplicateInvoiceNumber(rows, draft.invoice_no)) {
      const message = "This Invoice No already exists. Duplicate invoices cannot be added.";
      setInvoiceError(message);
      toast.error(message);
      return;
    }
    setInvoiceError("");
    setSaving(true);
    try {
    const { error } = await supabase.from("pending_invoices").insert({
      ...draft,
      supplier: draft.supplier.trim(),
      po_number: draft.po_number.trim(),
      invoice_no: draft.invoice_no.trim(),
      reason: draft.reason.trim(),
      pcu_member: draft.pcu_member.trim(),
      merchant: draft.merchant.trim(),
    });
    if (error) {
      const message = error.code === "23505" ? "This Invoice No already exists. Duplicate invoices cannot be added." : "Could not add invoice. Please try again.";
      setInvoiceError(message);
      toast.error(message);
      return;
    }
    toast.success("Pending invoice added");
    setDraft({ ...emptyDraft, received_date: draft.received_date });
    await load();
    } catch {
      toast.error("Could not add invoice. Please try again.");
    } finally {
      setSaving(false);
    }
  };

  const saveComment = async (id: string) => {
    const text = commentDraft[id] ?? "";
    const { error } = await supabase.from("pending_invoices").update({ pcu_comment: text }).eq("id", id);
    if (error) {
      toast.error("Comment not saved");
      return;
    }
    toast.success("PCU comment saved");
    setCommentDraft((c) => {
      const n = { ...c };
      delete n[id];
      return n;
    });
    load();
  };

  const complete = async (r: PendingInvoice) => {
    const { error } = await supabase
      .from("pending_invoices")
      .update({ status: "Completed", completed_at: new Date().toISOString(), completed_by: userName ?? "GRN Team" })
      .eq("id", r.id);
    if (error) {
      toast.error("Could not complete");
      return;
    }
    toast.success(`Invoice ${r.invoice_no || r.po_number} marked completed`);
    load();
  };

  const reopen = async (r: PendingInvoice) => {
    await supabase
      .from("pending_invoices")
      .update({ status: "Pending", completed_at: null, completed_by: null })
      .eq("id", r.id);
    load();
  };

  const remove = async (r: PendingInvoice) => {
    if (!canComplete) return;
    await supabase.from("pending_invoices").delete().eq("id", r.id);
    load();
  };

  return (
    <div className="space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Tile label="Pending Invoices" value={summary.total} tone="amber" icon={Clock} />
        <Tile label="Aged > 7 days" value={summary.over7} tone="rose" icon={AlertTriangle} hint="Escalate" />
        <Tile label="3–6 days" value={summary.over3} tone="orange" />
        <Tile label="Oldest (days)" value={summary.oldest} tone="sky" />
        <Tile label="Completed Today" value={summary.completedToday} tone="emerald" icon={CheckCircle2} />
      </div>

      {bySupplier.length > 0 && (
        <div className="rounded-lg border bg-card p-4">
          <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground">
            <Building2 className="h-4 w-4 text-primary" /> Pending by Supplier
          </div>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
            {bySupplier.map(([supplier, count], index) => (
              <div
                key={supplier}
                className={`flex min-w-0 items-center justify-between gap-3 rounded-lg border px-3 py-2 ${
                  index === 0 ? "border-destructive/50 bg-destructive/10 text-destructive" : "bg-muted/40"
                }`}
              >
                <span className="truncate text-xs font-semibold" title={supplier}>{supplier}</span>
                <span className={`grid h-7 min-w-7 place-items-center rounded-full px-2 text-xs font-bold ${index === 0 ? "bg-destructive text-destructive-foreground" : "bg-background"}`}>
                  {count}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add form */}
      {showAddForm && <section className="rounded-2xl border-2 border-sky-400/40 bg-gradient-to-br from-sky-500/5 via-card to-card p-4">
        <h3 className="font-semibold mb-3 flex items-center gap-2">
          <Plus className="h-4 w-4 text-sky-500" /> Add Pending Invoice
        </h3>
        <div className="grid gap-3 md:grid-cols-4">
          <Field label="Received Date">
            <input
              type="date"
              value={draft.received_date}
              onChange={(e) => setDraft({ ...draft, received_date: e.target.value })}
              className="input-base"
            />
          </Field>
          <Field label="Supplier">
            <input
              value={draft.supplier}
              onChange={(e) => setDraft({ ...draft, supplier: e.target.value })}
              className="input-base"
              list="pi-supplier-suggestions"
              autoComplete="off"
            />
            <datalist id="pi-supplier-suggestions">
              {supplierSuggestions.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </Field>
          <Field label="P/O">
            <input value={draft.po_number} onChange={(e) => setDraft({ ...draft, po_number: e.target.value })} className="input-base" />
          </Field>
          <Field label="Invoice No">
            <input value={draft.invoice_no} onChange={(e) => { setDraft({ ...draft, invoice_no: e.target.value }); setInvoiceError(""); }} className="input-base" aria-invalid={Boolean(invoiceError)} aria-describedby={invoiceError ? "pending-invoice-error" : undefined} />
          </Field>
          <Field label="Reason">
            <input
              value={draft.reason}
              onChange={(e) => setDraft({ ...draft, reason: e.target.value })}
              className="input-base"
              list="pi-reason-suggestions"
              autoComplete="off"
            />
            <datalist id="pi-reason-suggestions">
              {reasonSuggestions.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </Field>
          <Field label="PCU Member">
            <input
              value={draft.pcu_member}
              onChange={(e) => setDraft({ ...draft, pcu_member: e.target.value })}
              className="input-base"
              list="pi-pcu-suggestions"
              autoComplete="off"
            />
            <datalist id="pi-pcu-suggestions">
              {pcuMembers.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </Field>
          <Field label="Merchant">
            <input value={draft.merchant} onChange={(e) => setDraft({ ...draft, merchant: e.target.value })} className="input-base" />
          </Field>
          <div className="flex items-end">
            <Button onClick={add} disabled={saving || loading} className="w-full">
              {saving ? "Adding…" : "Add"}
            </Button>
          </div>
        </div>
        {invoiceError && <p id="pending-invoice-error" role="alert" className="mt-3 flex items-start gap-2 text-sm font-medium text-destructive"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />{invoiceError}</p>}
      </section>}

      {/* Filters */}
      <div className="rounded-lg border bg-card p-3 space-y-3">
        {showSearch && (
          <label className="relative block max-w-xl">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-base h-10 pl-10 pr-10"
              placeholder="Search supplier, P/O, invoice, PCU member or comment…"
              aria-label="Search pending invoices"
            />
            {search && (
              <Button type="button" variant="ghost" size="icon" onClick={() => setSearch("")} className="absolute right-1 top-1/2 h-8 w-8 -translate-y-1/2" aria-label="Clear search">
                <X className="h-4 w-4" />
              </Button>
            )}
          </label>
        )}
        <div className="flex flex-wrap items-center gap-2">
          {(["Pending", "Completed"] as const).map((v) => (
            <Button key={v} onClick={() => setView(v)} variant={view === v ? "default" : "outline"} size="sm">
              {v}
            </Button>
          ))}
          <span className="mx-1 h-5 w-px bg-border" />
          {["ALL", ...pcuMembers, ...(rows.some((r) => !r.pcu_member.trim()) ? ["—"] : [])].map((m) => (
            <Button key={m} onClick={() => setPcuTab(m)} variant={pcuTab === m ? "secondary" : "ghost"} size="sm">
              {m === "ALL" ? "All PCU" : m}
            </Button>
          ))}
          <span className="ml-auto text-xs text-muted-foreground">{visible.length} result{visible.length === 1 ? "" : "s"}</span>
          <Button type="button" variant="outline" size="sm" onClick={printList} disabled={visible.length === 0} aria-label="Print pending invoices list">
            <Printer className="h-4 w-4" /> Print
          </Button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-2xl border bg-card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left p-3">Received</th>
              <th className="text-left p-3">Supplier</th>
              <th className="text-left p-3">P/O</th>
              <th className="text-left p-3">Invoice No</th>
              <th className="text-left p-3">Reason</th>
              <th className="text-left p-3">PCU Member</th>
              <th className="text-left p-3">Merchant</th>
              <th className="text-left p-3">Pending Days</th>
              <th className="text-left p-3">PCU Comment</th>
              <th className="text-left p-3">Action</th>
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={10} className="p-6 text-center text-muted-foreground">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && visible.length === 0 && (
              <tr>
                <td colSpan={10} className="p-6 text-center text-muted-foreground">
                  {search ? "No invoices match your search" : `No ${view.toLowerCase()} invoices`}
                </td>
              </tr>
            )}
            {visible.map((r) => {
              const days = pendingDays(r.received_date, r.completed_at);
              const editing = commentDraft[r.id] !== undefined;
              return (
                <tr key={r.id} className="border-t align-top">
                  <td className="p-3 whitespace-nowrap font-medium">{r.received_date}</td>
                  <td className="p-3">{r.supplier || "—"}</td>
                  <td className="p-3">{r.po_number || "—"}</td>
                  <td className="p-3 font-semibold">{r.invoice_no || "—"}</td>
                  <td className="p-3 max-w-[14rem]">{r.reason || "—"}</td>
                  <td className="p-3">{r.pcu_member || "—"}</td>
                  <td className="p-3">{r.merchant || "—"}</td>
                  <td className="p-3">
                    <span className={`inline-block rounded-full border px-2 py-0.5 text-xs font-bold ${ageTone(days)}`}>
                      {days}d
                    </span>
                  </td>
                  <td className="p-3 min-w-[16rem]">
                    {editing ? (
                      <div className="flex gap-1">
                        <input
                          value={commentDraft[r.id]}
                          onChange={(e) => setCommentDraft({ ...commentDraft, [r.id]: e.target.value })}
                          className="input-base flex-1"
                          placeholder="PCU comment"
                        />
                        <button
                          onClick={() => saveComment(r.id)}
                          className="text-xs px-2 rounded-md bg-emerald-500 text-white font-semibold"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setCommentDraft({ ...commentDraft, [r.id]: r.pcu_comment })}
                        className="text-left text-xs text-muted-foreground hover:text-foreground flex items-start gap-1"
                      >
                        <MessageSquare className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                        <span>{r.pcu_comment || "Add comment"}</span>
                      </button>
                    )}
                  </td>
                  <td className="p-3 whitespace-nowrap">
                    {r.status === "Completed" ? (
                      <div className="space-y-1">
                        <span className="inline-flex items-center gap-1 text-xs text-emerald-500 font-semibold">
                          <CheckCircle2 className="h-3.5 w-3.5" /> Completed
                        </span>
                        {canComplete && (
                          <button onClick={() => reopen(r)} className="block text-[10px] underline text-muted-foreground">
                            Reopen
                          </button>
                        )}
                      </div>
                    ) : canComplete ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => complete(r)}
                          className="inline-flex items-center gap-1 text-xs font-semibold rounded-lg bg-emerald-500 text-white px-2.5 py-1.5 hover:bg-emerald-600"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" /> Complete
                        </button>
                        <button
                          onClick={() => remove(r)}
                          aria-label="Delete"
                          className="p-1.5 rounded-md text-muted-foreground hover:text-rose-500"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    ) : (
                      <span className="text-[10px] text-muted-foreground">GRN team only</span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[11px] font-semibold uppercase text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

const TONES: Record<string, string> = {
  amber: "border-amber-400/40 from-amber-500/10 text-amber-500",
  rose: "border-rose-400/40 from-rose-500/10 text-rose-500",
  orange: "border-orange-400/40 from-orange-500/10 text-orange-500",
  sky: "border-sky-400/40 from-sky-500/10 text-sky-500",
  emerald: "border-emerald-400/40 from-emerald-500/10 text-emerald-500",
};

function Tile({
  label,
  value,
  tone,
  hint,
  icon: Icon,
}: {
  label: string;
  value: number;
  tone: keyof typeof TONES;
  hint?: string;
  icon?: React.ComponentType<{ className?: string }>;
}) {
  return (
    <div className={`rounded-2xl border-2 bg-gradient-to-br to-card p-4 ${TONES[tone]}`}>
      <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide">
        {Icon && <Icon className="h-3.5 w-3.5" />} {label}
      </div>
      <div className="text-3xl font-bold text-foreground mt-1">{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
    </div>
  );
}
