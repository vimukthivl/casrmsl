import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ClipboardCheck, Leaf, HandMetal, TrendingUp, AlertTriangle, Target, Flame, Package, Truck, Boxes, Timer, Zap, FileText } from "lucide-react";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

type RangeKey = "day" | "week" | "month" | "year";

function fmt(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function rangeBounds(r: RangeKey, now = new Date()) {
  let start: Date;
  let end: Date;
  let label: string;
  if (r === "day") {
    start = new Date(now); start.setHours(0, 0, 0, 0);
    end = new Date(start);
    label = fmt(start);
  } else if (r === "week") {
    const d = new Date(now); d.setHours(0, 0, 0, 0);
    const diff = (d.getDay() + 6) % 7; // Monday start
    start = new Date(d); start.setDate(d.getDate() - diff);
    end = new Date(start); end.setDate(start.getDate() + 6);
    label = `Week of ${fmt(start)}`;
  } else if (r === "month") {
    start = new Date(now.getFullYear(), now.getMonth(), 1);
    end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    label = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}`;
  } else {
    start = new Date(now.getFullYear(), 0, 1);
    end = new Date(now.getFullYear(), 11, 31);
    label = String(now.getFullYear());
  }
  const days = Math.floor((end.getTime() - start.getTime()) / 86400000) + 1;
  const monthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
  return { start: fmt(start), end: fmt(end), label, days, monthKey };
}

function todayIsoStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}


interface CCData {
  targets: { item_code: string; target_qty: number }[];
  actuals: { item_code: string; counted_qty: number }[];
}

interface Concern { id: string; label: string; board_key: string; is_active: boolean; }
interface Entry { concern_id: string; board_key: string; entry_date: string; note: string | null; }

interface PickerRow {
  epf_number: string;
  name: string;
  target: number;
  achieved: number;
}

const GB_AREAS: { key: string; title: string; icon: React.ReactNode; accent: string; }[] = [
  { key: "kanban", title: "RM Kanban Area", icon: <Boxes className="h-4 w-4" />, accent: "from-sky-500 to-cyan-600" },
  { key: "grn", title: "RM GRN", icon: <Truck className="h-4 w-4" />, accent: "from-emerald-500 to-lime-600" },
  { key: "trims", title: "RM Trims Picking", icon: <Package className="h-4 w-4" />, accent: "from-fuchsia-500 to-rose-600" },
];

export function TrimsSummaryPanels() {
  const [range, setRange] = useState<RangeKey>("month");
  const [customDate, setCustomDate] = useState<string>("");
  const { start, end, label: rangeLabel, days: daysInRange, monthKey } = useMemo(() => {
    if (customDate) {
      const d = new Date(customDate + "T00:00:00");
      const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      return { start: customDate, end: customDate, label: customDate, days: 1, monthKey };
    }
    return rangeBounds(range);
  }, [range, customDate]);


  const [cc, setCc] = useState<CCData>({ targets: [], actuals: [] });
  const [concerns, setConcerns] = useState<Concern[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [pickers, setPickers] = useState<PickerRow[]>([]);
  const [downtime, setDowntime] = useState<{ concern: string; lost_hours: number; entry_date: string }[]>([]);
  const [invoices, setInvoices] = useState<{ log_date: string; trims_received: number; trims_completed: number }[]>([]);
  const [loading, setLoading] = useState(true);


  const load = useCallback(async () => {
    setLoading(true);
    const [ccT, ccA, gbC, gbE, pT, pA, dT, iL] = await Promise.all([
      sb.from("cc_monthly_targets").select("item_code,target_qty").eq("warehouse", "trims").eq("month", monthKey),
      sb.from("cc_daily_actuals").select("item_code,counted_qty").eq("warehouse", "trims").gte("entry_date", start).lte("entry_date", end),
      sb.from("green_board_concerns").select("id,label,board_key,is_active").in("board_key", ["kanban", "grn", "trims"]),
      sb.from("green_board_entries").select("concern_id,board_key,entry_date,note").in("board_key", ["kanban", "grn", "trims"]).gte("entry_date", start).lte("entry_date", end),
      sb.from("picker_targets").select("epf_number,name,gin_target_per_day").eq("is_active", true),
      sb.from("picker_achievements").select("epf_number").gte("picked_at", todayIsoStart()),
      sb.from("trims_downtime").select("concern,lost_hours,entry_date").gte("entry_date", start).lte("entry_date", end),
      sb.from("invoice_daily_log").select("log_date,trims_received,trims_completed").gte("log_date", start).lte("log_date", end).order("log_date", { ascending: false }),
    ]);
    setInvoices((iL.data ?? []) as { log_date: string; trims_received: number; trims_completed: number }[]);
    setDowntime((dT.data ?? []) as { concern: string; lost_hours: number; entry_date: string }[]);

    setCc({ targets: (ccT.data ?? []), actuals: (ccA.data ?? []) });
    setConcerns((gbC.data ?? []) as Concern[]);
    setEntries((gbE.data ?? []) as Entry[]);
    const counts: Record<string, number> = {};
    ((pA.data ?? []) as { epf_number: string }[]).forEach((r) => {
      counts[r.epf_number] = (counts[r.epf_number] ?? 0) + 1;
    });
    const rows: PickerRow[] = ((pT.data ?? []) as { epf_number: string; name: string; gin_target_per_day: number }[])
      .map((t) => ({
        epf_number: t.epf_number,
        name: t.name,
        target: t.gin_target_per_day,
        achieved: counts[t.epf_number] ?? 0,
      }))
      .sort((a, b) => b.achieved - a.achieved);
    setPickers(rows);
    setLoading(false);
  }, [start, end, monthKey]);

  useEffect(() => {
    load();
    const ch = sb.channel("rt-trims-dash-summary")
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_monthly_targets" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "cc_daily_actuals" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_entries" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_concerns" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "picker_achievements" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "picker_targets" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "trims_downtime" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "invoice_daily_log" }, () => load())
      .subscribe();

    return () => { sb.removeChannel(ch); };
  }, [load]);

  // CC aggregates
  const ccTotalTarget = cc.targets.reduce((s, t) => s + (t.target_qty ?? 0), 0);
  const ccTotalActual = cc.actuals.reduce((s, a) => s + (a.counted_qty ?? 0), 0);
  const ccPct = ccTotalTarget > 0 ? Math.min(100, Math.round((ccTotalActual / ccTotalTarget) * 100)) : 0;
  const ccPerCode = useMemo(() => {
    const t = new Map<string, number>();
    cc.targets.forEach((r) => t.set(r.item_code, (t.get(r.item_code) ?? 0) + r.target_qty));
    const a = new Map<string, number>();
    cc.actuals.forEach((r) => a.set(r.item_code, (a.get(r.item_code) ?? 0) + r.counted_qty));
    return Array.from(t.entries()).map(([code, tgt]) => ({
      code,
      target: tgt,
      actual: a.get(code) ?? 0,
      pct: tgt > 0 ? Math.min(100, Math.round(((a.get(code) ?? 0) / tgt) * 100)) : 0,
    })).sort((x, y) => y.pct - x.pct);
  }, [cc]);

  // Green Board per-area breakdowns
  const gbAreas = useMemo(() => {
    return GB_AREAS.map((area) => {
      const areaConcerns = concerns.filter((c) => c.board_key === area.key && c.is_active);
      const activeIds = new Set(areaConcerns.map((c) => c.id));
      const areaEntries = entries.filter((e) => e.board_key === area.key && activeIds.has(e.concern_id));
      const totalCells = areaConcerns.length * daysInRange;
      const redCells = areaEntries.length;
      const cleanPct = totalCells > 0 ? Math.round(((totalCells - redCells) / totalCells) * 100) : 100;

      // Top red reasons: count entries per concern
      const perConcern = new Map<string, number>();
      areaEntries.forEach((e) => { perConcern.set(e.concern_id, (perConcern.get(e.concern_id) ?? 0) + 1); });
      const topReasons = areaConcerns
        .map((c) => ({ label: c.label, count: perConcern.get(c.id) ?? 0 }))
        .filter((r) => r.count > 0)
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

      return { ...area, totalCells, redCells, cleanPct, concernsCount: areaConcerns.length, topReasons };
    });
  }, [concerns, entries, daysInRange]);

  const gbOverallClean = useMemo(() => {
    const t = gbAreas.reduce((s, a) => s + a.totalCells, 0);
    const r = gbAreas.reduce((s, a) => s + a.redCells, 0);
    return t > 0 ? Math.round(((t - r) / t) * 100) : 100;
  }, [gbAreas]);

  // Picker aggregates
  const totalAchievedToday = pickers.reduce((s, p) => s + p.achieved, 0);
  const totalTargetToday = pickers.reduce((s, p) => s + p.target, 0);
  const pickerPct = totalTargetToday > 0 ? Math.min(100, Math.round((totalAchievedToday / totalTargetToday) * 100)) : 0;

  // Downtime aggregates (target = 0 hours → any entry is highlighted)
  const dtByItem = useMemo(() => {
    const m = new Map<string, { hours: number; events: number; days: Set<string> }>();
    downtime.forEach((d) => {
      const key = (d.concern || "Unspecified").trim() || "Unspecified";
      const cur = m.get(key) ?? { hours: 0, events: 0, days: new Set<string>() };
      cur.hours += Number(d.lost_hours ?? 0);
      cur.events += 1;
      cur.days.add(d.entry_date);
      m.set(key, cur);
    });
    return Array.from(m.entries())
      .map(([concern, v]) => ({ concern, hours: Math.round(v.hours * 100) / 100, events: v.events, days: v.days.size }))
      .sort((a, b) => b.hours - a.hours);
  }, [downtime]);
  const dtTotalHours = Math.round(dtByItem.reduce((s, r) => s + r.hours, 0) * 100) / 100;
  const dtTotalEvents = dtByItem.reduce((s, r) => s + r.events, 0);
  const dtMaxHours = dtByItem[0]?.hours ?? 0;

  // Invoice GRN aggregates — Trims WH
  const invAgg = useMemo(() => {
    const totRec = invoices.reduce((s, r) => s + (Number(r.trims_received) || 0), 0);
    const totDone = invoices.reduce((s, r) => s + (Number(r.trims_completed) || 0), 0);
    const totPend = Math.max(0, totRec - totDone);
    const pct = totRec > 0 ? Math.min(100, Math.round((totDone / totRec) * 100)) : 0;
    const rows = invoices
      .map((r) => {
        const rec = Number(r.trims_received) || 0;
        const done = Number(r.trims_completed) || 0;
        const pend = Math.max(0, rec - done);
        const p = rec > 0 ? Math.min(100, Math.round((done / rec) * 100)) : 0;
        return { date: r.log_date, received: rec, completed: done, pending: pend, pct: p };
      })
      .filter((r) => r.received > 0 || r.completed > 0);
    const daysActive = rows.length;
    const worstPending = rows.slice().sort((a, b) => b.pending - a.pending)[0];
    return { totRec, totDone, totPend, pct, rows, daysActive, worstPending };
  }, [invoices]);


  const RANGES: { key: RangeKey; label: string }[] = [
    { key: "day", label: "Day" },
    { key: "week", label: "Week" },
    { key: "month", label: "Month" },
    { key: "year", label: "Year" },
  ];

  return (
    <div className="space-y-4">
      {/* RANGE FILTER */}
      <div className="rounded-2xl border-2 border-primary/20 bg-gradient-to-r from-primary/5 via-background to-primary/5 p-3 flex items-center gap-3 flex-wrap sticky top-0 z-10 backdrop-blur">
        <div className="text-xs font-black uppercase text-muted-foreground">Filter</div>
        <div className="flex gap-1 rounded-xl border bg-background/70 p-1">
          {RANGES.map((r) => {
            const active = !customDate && range === r.key;
            return (
              <button
                key={r.key}
                type="button"
                onClick={() => { setCustomDate(""); setRange(r.key); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  active
                    ? "bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow"
                    : "text-muted-foreground hover:bg-muted"
                }`}
              >
                {r.label}
              </button>
            );
          })}
        </div>
        <div className="flex items-center gap-2">
          <label className="text-[11px] font-bold uppercase text-muted-foreground">Pick date</label>
          <input
            type="date"
            value={customDate}
            onChange={(e) => setCustomDate(e.target.value)}
            className={`px-2 py-1.5 rounded-lg border text-xs font-semibold bg-background ${customDate ? "border-teal-500 ring-1 ring-teal-500/40" : "border-input"}`}
          />
          {customDate && (
            <button
              type="button"
              onClick={() => setCustomDate("")}
              className="text-[11px] font-bold text-muted-foreground hover:text-foreground underline"
            >
              Clear
            </button>
          )}
        </div>
        <div className="text-[11px] text-muted-foreground ml-auto tabular-nums">
          {rangeLabel} · {daysInRange} day{daysInRange === 1 ? "" : "s"}
        </div>
      </div>



      {/* CYCLE COUNTING */}
      <div className="rounded-2xl border-2 border-teal-400/30 bg-gradient-to-br from-teal-500/10 via-background to-emerald-500/5 p-5 shadow-lg shadow-teal-500/10">

        <div className="flex items-center gap-2 mb-3">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-teal-500 to-emerald-600 grid place-items-center text-white shadow">
            <ClipboardCheck className="h-5 w-5" />
          </div>
          <div>
            <div className="text-sm font-black text-teal-700 dark:text-teal-300">Cycle Counting — Monthly Target vs Daily Actual</div>
            <div className="text-[11px] text-muted-foreground">{monthKey} · Trims WH · view only</div>
          </div>
        </div>
        <div className="flex items-end gap-2 mb-2">
          <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-teal-600 to-emerald-600 bg-clip-text text-transparent">{ccPct}%</div>
          <div className="text-xs text-muted-foreground pb-1">{ccTotalActual.toLocaleString()} / {ccTotalTarget.toLocaleString()}</div>
        </div>
        <div className="h-2 rounded-full bg-teal-500/10 overflow-hidden mb-3">
          <div className="h-full bg-gradient-to-r from-teal-500 to-emerald-500 transition-all" style={{ width: `${ccPct}%` }} />
        </div>
        {loading ? (
          <div className="text-xs text-muted-foreground">Loading…</div>
        ) : ccPerCode.length === 0 ? (
          <div className="text-xs text-muted-foreground">No monthly targets set for {monthKey}.</div>
        ) : (
          <div className="grid gap-1.5 sm:grid-cols-2 lg:grid-cols-3 max-h-56 overflow-auto pr-1">
            {ccPerCode.map((r) => (
              <div key={r.code} className="text-xs rounded-lg border border-teal-400/20 bg-background/60 p-2">
                <div className="flex justify-between gap-2">
                  <span className="font-semibold font-mono truncate">{r.code}</span>
                  <span className="tabular-nums text-muted-foreground">{r.actual}/{r.target} · {r.pct}%</span>
                </div>
                <div className="h-1 rounded-full bg-teal-500/10 overflow-hidden mt-1">
                  <div className="h-full bg-teal-500" style={{ width: `${r.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* GREEN BOARD — 3 areas */}
      <div className="rounded-2xl border-2 border-emerald-400/30 bg-gradient-to-br from-emerald-500/10 via-background to-lime-500/5 p-5 shadow-lg shadow-emerald-500/10">
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-emerald-500 to-lime-600 grid place-items-center text-white shadow">
            <Leaf className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-black text-emerald-700 dark:text-emerald-300">Green Board — RM Kanban · RM GRN · RM Trims Picking</div>
            <div className="text-[11px] text-muted-foreground">{monthKey} · {daysInRange} days · red cells & top reasons</div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-emerald-600 to-lime-600 bg-clip-text text-transparent">{gbOverallClean}%</div>
            <div className="text-xs text-muted-foreground pb-1">overall clean</div>
          </div>
        </div>

        <div className="grid gap-3 lg:grid-cols-3">
          {gbAreas.map((a) => {
            const barCls = a.cleanPct >= 90 ? "bg-emerald-500" : a.cleanPct >= 70 ? "bg-amber-500" : "bg-red-500";
            return (
              <div key={a.key} className="rounded-xl border border-emerald-400/20 bg-background/70 p-3">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`h-7 w-7 rounded-lg bg-gradient-to-br ${a.accent} grid place-items-center text-white shadow-sm`}>
                    {a.icon}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-black truncate">{a.title}</div>
                    <div className="text-[10px] text-muted-foreground">{a.concernsCount} concerns</div>
                  </div>
                  <div className="text-lg font-black tabular-nums">{a.cleanPct}%</div>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden mb-2">
                  <div className={`h-full ${barCls} transition-all`} style={{ width: `${a.cleanPct}%` }} />
                </div>
                <div className="grid grid-cols-3 gap-1 text-center mb-2">
                  <MiniStat icon={<Target className="h-3 w-3" />} label="Concerns" value={a.concernsCount} tone="emerald" />
                  <MiniStat icon={<AlertTriangle className="h-3 w-3" />} label="Red" value={a.redCells} tone="red" />
                  <MiniStat icon={<TrendingUp className="h-3 w-3" />} label="Cells" value={a.totalCells} tone="slate" />
                </div>
                <div className="text-[10px] font-bold uppercase text-muted-foreground mb-1 flex items-center gap-1">
                  <Flame className="h-3 w-3 text-red-500" /> Top red reasons
                </div>
                {a.topReasons.length === 0 ? (
                  <div className="text-[11px] text-emerald-600 dark:text-emerald-400 italic">No red cells 🎉</div>
                ) : (
                  <div className="space-y-1">
                    {a.topReasons.map((r) => {
                      const pct = a.redCells > 0 ? Math.round((r.count / a.redCells) * 100) : 0;
                      return (
                        <div key={r.label} className="text-[11px]">
                          <div className="flex justify-between gap-2">
                            <span className="truncate font-semibold">{r.label}</span>
                            <span className="tabular-nums text-red-600 dark:text-red-400 font-bold">{r.count} · {pct}%</span>
                          </div>
                          <div className="h-1 rounded-full bg-red-500/10 overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-red-500 to-rose-500" style={{ width: `${pct}%` }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* TRIMS DOWNTIME — item-wise, target = 0 hrs */}
      <div className={`rounded-2xl border-2 p-5 shadow-lg ${dtTotalHours > 0 ? "border-red-400/40 bg-gradient-to-br from-red-500/10 via-background to-orange-500/5 shadow-red-500/10" : "border-emerald-400/30 bg-gradient-to-br from-emerald-500/10 via-background to-teal-500/5 shadow-emerald-500/10"}`}>
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <div className={`h-9 w-9 rounded-xl grid place-items-center text-white shadow ${dtTotalHours > 0 ? "bg-gradient-to-br from-red-500 to-orange-600" : "bg-gradient-to-br from-emerald-500 to-teal-600"}`}>
            <Timer className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className={`text-sm font-black ${dtTotalHours > 0 ? "text-red-700 dark:text-red-300" : "text-emerald-700 dark:text-emerald-300"}`}>Trims Downtime — Item-wise Lost Hours</div>
            <div className="text-[11px] text-muted-foreground">{monthKey} · target = 0 hrs · any entry is highlighted</div>
          </div>
          <div className="flex items-end gap-2">
            <div className={`text-3xl font-black tabular-nums bg-clip-text text-transparent ${dtTotalHours > 0 ? "bg-gradient-to-r from-red-600 to-orange-600" : "bg-gradient-to-r from-emerald-600 to-teal-600"}`}>{dtTotalHours}h</div>
            <div className="text-xs text-muted-foreground pb-1">{dtTotalEvents} event{dtTotalEvents === 1 ? "" : "s"}</div>
          </div>
        </div>
        {loading ? (
          <div className="text-xs text-muted-foreground">Loading…</div>
        ) : dtByItem.length === 0 ? (
          <div className="rounded-xl border border-emerald-400/30 bg-emerald-500/5 p-4 text-center text-sm font-semibold text-emerald-700 dark:text-emerald-300">
            🎉 No downtime recorded this month — target met.
          </div>
        ) : (
          <>
            <div className="mb-3 rounded-xl border-2 border-red-400/40 bg-red-500/10 p-3 flex items-center gap-2">
              <Zap className="h-4 w-4 text-red-600 shrink-0" />
              <div className="text-xs">
                <span className="font-black text-red-700 dark:text-red-300">Target breach:</span>{" "}
                <span className="text-muted-foreground">{dtByItem.length} item{dtByItem.length === 1 ? "" : "s"} with downtime · worst: </span>
                <span className="font-bold text-red-700 dark:text-red-300">{dtByItem[0].concern} ({dtByItem[0].hours}h)</span>
              </div>
            </div>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {dtByItem.map((r, idx) => {
                const pct = dtMaxHours > 0 ? Math.round((r.hours / dtMaxHours) * 100) : 0;
                const isTop = idx < 3;
                return (
                  <div key={r.concern} className={`rounded-xl border p-3 ${isTop ? "border-red-400/50 bg-red-500/5" : "border-orange-400/30 bg-background/60"}`}>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="min-w-0 flex items-center gap-1.5">
                        {isTop && <Flame className="h-3.5 w-3.5 text-red-600 shrink-0" />}
                        <div className="text-sm font-bold truncate">{r.concern}</div>
                      </div>
                      <div className="text-lg font-black tabular-nums text-red-600 dark:text-red-400">{r.hours}h</div>
                    </div>
                    <div className="flex justify-between text-[11px] text-muted-foreground tabular-nums mb-1">
                      <span>{r.events} event{r.events === 1 ? "" : "s"}</span>
                      <span>{r.days} day{r.days === 1 ? "" : "s"}</span>
                    </div>
                    <div className="h-1.5 rounded-full bg-red-500/10 overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-red-500 to-orange-500" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* DAILY INVOICE GRN — Trims WH */}
      <div className={`rounded-2xl border-2 p-5 shadow-lg ${invAgg.totPend > 0 ? "border-amber-400/40 bg-gradient-to-br from-amber-500/10 via-background to-orange-500/5 shadow-amber-500/10" : "border-sky-400/30 bg-gradient-to-br from-sky-500/10 via-background to-indigo-500/5 shadow-sky-500/10"}`}>
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <div className={`h-9 w-9 rounded-xl grid place-items-center text-white shadow ${invAgg.totPend > 0 ? "bg-gradient-to-br from-amber-500 to-orange-600" : "bg-gradient-to-br from-sky-500 to-indigo-600"}`}>
            <FileText className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className={`text-sm font-black ${invAgg.totPend > 0 ? "text-amber-700 dark:text-amber-300" : "text-sky-700 dark:text-sky-300"}`}>Daily Invoice GRN Completion — Trims WH</div>
            <div className="text-[11px] text-muted-foreground">{rangeLabel} · received vs completed · pending highlighted</div>
          </div>
          <div className="flex items-end gap-2">
            <div className={`text-3xl font-black tabular-nums bg-clip-text text-transparent ${invAgg.totPend > 0 ? "bg-gradient-to-r from-amber-600 to-orange-600" : "bg-gradient-to-r from-sky-600 to-indigo-600"}`}>{invAgg.pct}%</div>
            <div className="text-xs text-muted-foreground pb-1">{invAgg.totDone} / {invAgg.totRec}</div>
          </div>
        </div>
        <div className={`h-2 rounded-full overflow-hidden mb-3 ${invAgg.totPend > 0 ? "bg-amber-500/10" : "bg-sky-500/10"}`}>
          <div className={`h-full transition-all ${invAgg.totPend > 0 ? "bg-gradient-to-r from-amber-500 to-orange-500" : "bg-gradient-to-r from-sky-500 to-indigo-500"}`} style={{ width: `${invAgg.pct}%` }} />
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <MiniStat icon={<Truck className="h-3 w-3" />} label="Received" value={invAgg.totRec} tone="slate" />
          <MiniStat icon={<ClipboardCheck className="h-3 w-3" />} label="Completed" value={invAgg.totDone} tone="emerald" />
          <MiniStat icon={<AlertTriangle className="h-3 w-3" />} label="Pending" value={invAgg.totPend} tone="red" />
          <MiniStat icon={<TrendingUp className="h-3 w-3" />} label="Days" value={invAgg.daysActive} tone="slate" />
        </div>
        {loading ? (
          <div className="text-xs text-muted-foreground">Loading…</div>
        ) : invAgg.rows.length === 0 ? (
          <div className="text-xs text-muted-foreground">No invoice activity for this range.</div>
        ) : (
          <>
            {invAgg.worstPending && invAgg.worstPending.pending > 0 && (
              <div className="mb-3 rounded-xl border-2 border-amber-400/40 bg-amber-500/10 p-3 flex items-center gap-2">
                <Zap className="h-4 w-4 text-amber-600 shrink-0" />
                <div className="text-xs">
                  <span className="font-black text-amber-700 dark:text-amber-300">Highest pending:</span>{" "}
                  <span className="text-muted-foreground">{invAgg.worstPending.date} · </span>
                  <span className="font-bold text-amber-700 dark:text-amber-300">{invAgg.worstPending.pending} invoices</span>
                </div>
              </div>
            )}
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3 max-h-64 overflow-auto pr-1">
              {invAgg.rows.map((r) => {
                const hasPend = r.pending > 0;
                return (
                  <div key={r.date} className={`rounded-xl border p-3 ${hasPend ? "border-amber-400/50 bg-amber-500/5" : "border-sky-400/20 bg-background/60"}`}>
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="text-sm font-bold font-mono">{r.date}</div>
                      <div className={`text-lg font-black tabular-nums ${hasPend ? "text-amber-600 dark:text-amber-400" : "text-sky-600 dark:text-sky-400"}`}>{r.pct}%</div>
                    </div>
                    <div className="flex justify-between text-[11px] text-muted-foreground tabular-nums mb-1">
                      <span>Rec: <b className="text-foreground">{r.received}</b></span>
                      <span>Done: <b className="text-foreground">{r.completed}</b></span>
                      <span className={hasPend ? "text-amber-700 dark:text-amber-300 font-bold" : ""}>Pend: <b>{r.pending}</b></span>
                    </div>
                    <div className={`h-1.5 rounded-full overflow-hidden ${hasPend ? "bg-amber-500/10" : "bg-sky-500/10"}`}>
                      <div className={`h-full ${hasPend ? "bg-gradient-to-r from-amber-500 to-orange-500" : "bg-gradient-to-r from-sky-500 to-indigo-500"}`} style={{ width: `${r.pct}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>

      {/* TRIMS PICKING PERFORMANCE — full width, all pickers */}

      <div className="rounded-2xl border-2 border-fuchsia-400/30 bg-gradient-to-br from-fuchsia-500/10 via-background to-rose-500/5 p-5 shadow-lg shadow-fuchsia-500/10">
        <div className="flex items-center gap-2 mb-4 flex-wrap">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-fuchsia-500 to-rose-600 grid place-items-center text-white shadow">
            <HandMetal className="h-5 w-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-black text-fuchsia-700 dark:text-fuchsia-300">Picker Performance — All Trims Pickers</div>
            <div className="text-[11px] text-muted-foreground">Today's GIN count vs daily target</div>
          </div>
          <div className="flex items-end gap-2">
            <div className="text-3xl font-black tabular-nums bg-gradient-to-r from-fuchsia-600 to-rose-600 bg-clip-text text-transparent">{pickerPct}%</div>
            <div className="text-xs text-muted-foreground pb-1">{totalAchievedToday} / {totalTargetToday}</div>
          </div>
        </div>
        <div className="h-2 rounded-full bg-fuchsia-500/10 overflow-hidden mb-4">
          <div className="h-full bg-gradient-to-r from-fuchsia-500 to-rose-500 transition-all" style={{ width: `${pickerPct}%` }} />
        </div>
        {loading ? (
          <div className="text-xs text-muted-foreground">Loading…</div>
        ) : pickers.length === 0 ? (
          <div className="text-xs text-muted-foreground">No active trims pickers.</div>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {pickers.map((p) => {
              const pct = p.target > 0 ? Math.min(100, Math.round((p.achieved / p.target) * 100)) : 0;
              const barCls = pct >= 100 ? "bg-emerald-500" : pct >= 50 ? "bg-fuchsia-500" : "bg-amber-500";
              return (
                <div key={p.epf_number} className="rounded-xl border border-fuchsia-400/20 bg-background/60 p-3">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="min-w-0">
                      <div className="text-sm font-bold truncate">{p.name}</div>
                      <div className="text-[10px] font-mono text-muted-foreground">EPF {p.epf_number}</div>
                    </div>
                    <div className="text-lg font-black tabular-nums text-fuchsia-600 dark:text-fuchsia-400">{pct}%</div>
                  </div>
                  <div className="flex justify-between text-[11px] text-muted-foreground tabular-nums mb-1">
                    <span>Achieved: <b className="text-foreground">{p.achieved}</b></span>
                    <span>Target: <b className="text-foreground">{p.target}</b></span>
                  </div>
                  <div className="h-1.5 rounded-full bg-fuchsia-500/10 overflow-hidden">
                    <div className={`h-full ${barCls} transition-all`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function MiniStat({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: "emerald" | "red" | "slate" }) {
  const toneCls = tone === "emerald" ? "text-emerald-600 bg-emerald-500/10" : tone === "red" ? "text-red-600 bg-red-500/10" : "text-slate-600 bg-slate-500/10";
  return (
    <div className={`rounded-lg px-1.5 py-1 ${toneCls}`}>
      <div className="flex items-center justify-center gap-0.5 text-[9px] font-bold uppercase opacity-80">{icon}{label}</div>
      <div className="text-sm font-black tabular-nums">{value}</div>
    </div>
  );
}
