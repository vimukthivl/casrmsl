import { useEffect, type ReactNode } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import { useApp, canAccess, ROLE_HOMES } from "@/lib/store";
import { AppShell } from "./AppShell";

export function RequireAccess({ path, children }: { path: string; children: ReactNode }) {
  const { user, authReady } = useApp();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authReady) return;
    if (!user) {
      navigate({ to: "/login", replace: true });
    } else if (!canAccess(user.role, path)) {
      toast.error("Permission Denied", {
        description: `Your role (${user.role.toUpperCase()}) is not authorised to access ${path}.`,
      });
      navigate({ to: ROLE_HOMES[user.role], replace: true });
    }
  }, [user, authReady, path, navigate]);

  if (!authReady || !user || !canAccess(user.role, path)) {
    return <div className="min-h-screen grid place-items-center text-muted-foreground">Redirecting…</div>;
  }
  return <AppShell>{children}</AppShell>;
}

