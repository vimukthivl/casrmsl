import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { useApp, ROLE_ACCESS } from "@/lib/store";
import { LayoutDashboard, FileSpreadsheet, ShieldCheck, PackageCheck, LogOut, Truck, Warehouse, Settings, Tv, Leaf, ClipboardList, HandMetal, ClipboardCheck, Scissors, Shirt, Briefcase, type LucideIcon } from "lucide-react";
import { useState, type ReactNode } from "react";
import { AiAssistantWidget } from "@/components/AiAssistantWidget";



const NAV: { path: string; label: string; icon: LucideIcon; color: string; bg: string }[] = [
  { path: "/dashboard",   label: "Logistics Dashboard", icon: LayoutDashboard,  color: "text-sky-600",     bg: "bg-sky-100 dark:bg-sky-500/15" },
  { path: "/trims-dashboard",      label: "Trims Dashboard",      icon: Scissors,   color: "text-teal-600",    bg: "bg-teal-100 dark:bg-teal-500/15" },
  { path: "/fabric-dashboard",     label: "Fabric Dashboard",     icon: Shirt,      color: "text-fuchsia-600", bg: "bg-fuchsia-100 dark:bg-fuchsia-500/15" },
  { path: "/management-dashboard", label: "Management Dashboard", icon: Briefcase,  color: "text-indigo-600",  bg: "bg-indigo-100 dark:bg-indigo-500/15" },
  { path: "/pcu",         label: "PCU Schedule",    icon: FileSpreadsheet,  color: "text-violet-600",  bg: "bg-violet-100 dark:bg-violet-500/15" },
  { path: "/guard",       label: "Guard Room",      icon: ShieldCheck,      color: "text-amber-600",   bg: "bg-amber-100 dark:bg-amber-500/15" },
  
  { path: "/grn",         label: "RM GRN Team",     icon: PackageCheck,     color: "text-emerald-600", bg: "bg-emerald-100 dark:bg-emerald-500/15" },
  { path: "/vehicle-update", label: "Vehicle Update", icon: Truck, color: "text-primary", bg: "bg-accent" },
  { path: "/green-board", label: "Green Board",     icon: Leaf,             color: "text-green-600",   bg: "bg-green-100 dark:bg-green-500/15" },
  { path: "/trims-plan",  label: "Trims Plan",      icon: ClipboardList,    color: "text-teal-600",    bg: "bg-teal-100 dark:bg-teal-500/15" },
  { path: "/fabric-plan", label: "Fabric Plan",     icon: ClipboardList,    color: "text-fuchsia-600", bg: "bg-fuchsia-100 dark:bg-fuchsia-500/15" },
  { path: "/picker",      label: "Picker",          icon: HandMetal,        color: "text-pink-600",    bg: "bg-pink-100 dark:bg-pink-500/15" },
  { path: "/tv",          label: "Unloading Plan",  icon: Tv,               color: "text-indigo-600",  bg: "bg-indigo-100 dark:bg-indigo-500/15" },
  { path: "/cycle-counting", label: "Cycle Counting", icon: ClipboardCheck,  color: "text-cyan-600",    bg: "bg-cyan-100 dark:bg-cyan-500/15" },
  { path: "/settings",    label: "Admin Settings",  icon: Settings,         color: "text-rose-600",    bg: "bg-rose-100 dark:bg-rose-500/15" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { user, logout } = useApp();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [hovered, setHovered] = useState(false);


  if (!user) return null;

  // TV kiosk: no chrome — full-screen read-only view
  if (user.role === "tv") {
    return <main className="min-h-screen bg-background">{children}</main>;
  }

  const allowed = ROLE_ACCESS[user.role];
  const expanded = hovered;

  return (
    <div className="min-h-screen flex w-full bg-background">
      <aside
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        className={`${expanded ? "w-64" : "w-16"} border-r flex flex-col transition-[width] duration-300 ease-out overflow-hidden shrink-0 bg-gradient-to-b from-slate-50 via-white to-slate-100 dark:from-slate-900 dark:via-slate-950 dark:to-slate-900`}
      >
        <div className="p-3 border-b flex items-center gap-2 h-16 bg-gradient-to-r from-sky-500 via-indigo-500 to-violet-600 text-white shadow-sm">
          <div className="h-9 w-9 shrink-0 rounded-lg bg-white/20 backdrop-blur grid place-items-center ring-1 ring-white/30">
            <Truck className="h-5 w-5" />
          </div>
          <div className={`min-w-0 transition-opacity duration-200 ${expanded ? "opacity-100" : "opacity-0 pointer-events-none"}`}>
            <div className="font-bold text-sm leading-tight truncate">MAS Casualline</div>
            <div className="text-[11px] text-white/80 truncate">RMWH Command Center</div>
          </div>
        </div>
        <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
          {NAV.filter((n) => allowed.includes(n.path)).map((n) => {
            const active = pathname === n.path || pathname.startsWith(n.path + "/");
            const Icon = n.icon;
            return (
              <Link
                key={n.path}
                to={n.path}
                title={!expanded ? n.label : undefined}
                className={`group flex items-center gap-3 px-2 py-2 rounded-lg text-sm transition-all duration-200 relative ${
                  active
                    ? "bg-gradient-to-r from-sky-500 via-indigo-500 to-violet-600 text-white font-semibold shadow-md shadow-indigo-500/20"
                    : "hover:bg-white hover:shadow-sm dark:hover:bg-slate-800/60 text-foreground"
                }`}
              >
                <span
                  className={`h-8 w-8 shrink-0 rounded-md grid place-items-center transition-colors ${
                    active ? "bg-white/20 text-white" : `${n.bg} ${n.color} group-hover:scale-105`
                  }`}
                >
                  <Icon className="h-4 w-4" />
                </span>
                <span className={`truncate transition-opacity duration-200 ${expanded ? "opacity-100" : "opacity-0"}`}>
                  {n.label}
                </span>
                {active && expanded && (
                  <span className="ml-auto h-2 w-2 rounded-full bg-white/90 shadow-[0_0_8px_rgba(255,255,255,0.9)]" />
                )}
              </Link>
            );
          })}
        </nav>
        <div className="p-2 border-t bg-white/60 dark:bg-slate-900/60 backdrop-blur">
          <div className={`px-2 py-2 mb-1 flex items-center gap-2 transition-opacity duration-200 ${expanded ? "opacity-100" : "opacity-0 pointer-events-none h-0 overflow-hidden"}`}>
            <div className="h-8 w-8 rounded-full bg-gradient-to-br from-indigo-500 to-pink-500 text-white grid place-items-center text-xs font-bold shadow">
              {user.display_name.slice(0, 1).toUpperCase()}
            </div>
            <div className="min-w-0">
              <div className="text-sm font-medium truncate leading-tight">{user.display_name}</div>
              <div className="text-[10px] text-muted-foreground uppercase tracking-wider">{user.role}</div>
            </div>
          </div>
          <button
            onClick={() => {
              logout();
              navigate({ to: "/login" });
            }}
            title={!expanded ? "Sign out" : undefined}
            className="w-full flex items-center gap-3 px-2 py-2 rounded-lg text-sm text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10 transition-colors font-medium"
          >
            <span className="h-8 w-8 shrink-0 rounded-md grid place-items-center bg-rose-100 dark:bg-rose-500/15">
              <LogOut className="h-4 w-4" />
            </span>
            <span className={`truncate transition-opacity duration-200 ${expanded ? "opacity-100" : "opacity-0"}`}>
              Sign out
            </span>
          </button>
          <div
            className={`px-3 pt-2 mt-1 border-t border-border/40 text-[10px] leading-tight text-muted-foreground/60 tracking-wide transition-opacity duration-200 ${
              expanded ? "opacity-100" : "opacity-0 pointer-events-none h-0 overflow-hidden"
            }`}
          >
            Developer @ Vimukthi Lakshan
            <div className="text-muted-foreground/40">Casualline RM</div>
          </div>
        </div>
      </aside>
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-12 border-b bg-card/80 backdrop-blur px-4 flex items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-muted-foreground truncate">
            Signed in as <span className="font-medium text-foreground">{user.display_name}</span>
          </div>
          <div className="text-[11px] uppercase tracking-wider text-muted-foreground font-medium">
            {user.role.replace("_", " ")}
          </div>
        </header>
        {user.role === "viewer" && (
          <div className="px-4 py-1.5 text-[11px] font-semibold text-amber-700 dark:text-amber-300 bg-amber-100/70 dark:bg-amber-500/10 border-b border-amber-300/50">
            READ-ONLY VISITOR VIEW · Data entry and changes are disabled
          </div>
        )}
        <main className={`flex-1 overflow-auto animate-fade-in min-w-0 ${user.role === "viewer" ? "readonly-lock" : ""}`}>
          {children}
        </main>
      </div>
      <AiAssistantWidget />
    </div>
  );
}
