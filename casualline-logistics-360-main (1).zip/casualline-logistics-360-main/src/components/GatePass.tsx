import { useEffect } from "react";
import { X, Printer } from "lucide-react";
import type { VehicleLog } from "@/lib/types";
import { heldUpHours, heldUpCost } from "@/lib/store";

interface Props {
  vehicle: VehicleLog;
  costRate: number;
  onClose: () => void;
}

export function GatePass({ vehicle: v, costRate, onClose }: Props) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const handlePrint = () => window.print();

  return (
    <>
      <style>{`
        @page {
          size: A4 portrait;
          margin: 1in;
        }
        @media print {
          html, body { margin: 0 !important; padding: 0 !important; background: #fff !important; }
          body * { visibility: hidden !important; }
          #gate-pass-print, #gate-pass-print * { visibility: visible !important; }
          #gate-pass-print {
            position: absolute;
            left: 0; top: 0;
            width: 100%;
            box-shadow: none !important;
            border: none !important;
            background: #fff !important;
          }
          .no-print { display: none !important; }
          .gp-copy { page-break-inside: avoid; break-inside: avoid; }
          .gp-perforation { border-top: 2px dashed #ccc; margin: 12px 0; position: relative; }
          .gp-perforation::after {
            content: "✂  tear here";
            position: absolute;
            top: -9px;
            left: 50%;
            transform: translateX(-50%);
            background: #fff;
            padding: 0 8px;
            font-size: 9px;
            color: #999;
            letter-spacing: 2px;
          }
        }
        .gp-perforation { border-top: 2px dashed #ccc; margin: 12px 0; position: relative; }
        .gp-perforation::after {
          content: "✂  tear here";
          position: absolute;
          top: -9px;
          left: 50%;
          transform: translateX(-50%);
          background: #fff;
          padding: 0 8px;
          font-size: 9px;
          color: #999;
          letter-spacing: 2px;
        }
      `}</style>
      <div className="fixed inset-0 bg-black/60 grid place-items-center z-50 p-4 overflow-auto">
        <div className="w-full max-w-[720px] bg-white text-slate-900 rounded-lg shadow-2xl">
          <div className="flex items-center justify-between p-3 border-b no-print">
            <h3 className="font-semibold text-slate-900">Gate Pass Ready — 2 Copies / A4</h3>
            <div className="flex gap-2">
              <button onClick={handlePrint}
                className="h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-medium flex items-center gap-1">
                <Printer className="h-4 w-4" /> Print
              </button>
              <button onClick={onClose} className="p-1.5 hover:bg-muted rounded"><X className="h-4 w-4" /></button>
            </div>
          </div>

          <div id="gate-pass-print" className="p-4 bg-white">
            <Copy vehicle={v} costRate={costRate} label="VEHICLE COPY" />
            <div className="gp-perforation" />
            <Copy vehicle={v} costRate={costRate} label="RM COPY" />
          </div>
        </div>
      </div>
    </>
  );
}

function Copy({ vehicle: v, costRate, label }: { vehicle: VehicleLog; costRate: number; label: string }) {
  const inTime = new Date(v.in_time);
  const outTime = v.unload_end_time ? new Date(v.unload_end_time) : new Date();
  const hu = heldUpHours(v);
  const cost = heldUpCost(v, costRate);
  const isHeld = hu > 0;

  return (
    <div className="gp-copy" style={{ boxSizing: "border-box" }}>
      <div className="border-b-2 border-slate-900 pb-2 mb-3 flex justify-between items-start gap-4">
        <div>
          <div className="text-[10px] uppercase tracking-widest text-slate-500">Official Gate Pass</div>
          <div className="text-base font-bold text-slate-900 leading-tight">UNICHELA PRIVATE LIMITED – CASUALLINE DIVISION</div>
          <div className="text-[11px] text-slate-500 italic">E.P.Z. Mawathagama, Sri Lanka</div>
        </div>
        <div className="text-right shrink-0">
          <div className="inline-block border-2 border-slate-900 px-2 py-0.5 text-xs font-bold tracking-wider">{label}</div>
          <div className="text-[10px] text-slate-500 mt-1">Token</div>
          <div className="font-mono font-bold text-base leading-none">{v.token_no}</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-[12px]">
        <Row k="Vehicle Number" val={v.vehicle_number} />
        <Row k="Vehicle Type" val={v.vehicle_type} />
        <Row k="Vendor" val={v.vendor_name} />
        <Row k="Material" val={v.material_type} />
        <Row k="PCU / Dept" val={v.relevant_pcu || "—"} />
        <Row k="Invoice No" val={v.invoice_no || "—"} />
        <Row k="Roll Qty" val={String(v.roll_qty)} />
        <Row k="Box Qty" val={String(v.box_qty)} />
        <Row k="Driver" val={v.driver_name || "—"} />
        <Row k="Driver Phone" val={v.driver_phone || "—"} />
        <Row k="Checked In" val={inTime.toLocaleString()} />
        <Row k="Completed / Out" val={outTime.toLocaleString()} />
        <Row k="Completed By" val={v.completed_by || "—"} />
        <Row k="Arrival Status" val={v.arrival_status} />
      </div>

      {isHeld && (
        <div className="mt-2 border-2 border-red-500 rounded p-1.5 bg-red-50">
          <div className="flex justify-between text-[11px]">
            <span className="font-semibold text-red-800">Held-up Hours (over 24h)</span>
            <span className="font-bold text-red-900">{hu.toFixed(2)} h</span>
          </div>
          <div className="flex justify-between text-[11px] mt-0.5">
            <span className="font-semibold text-red-800">Total Held-up Cost</span>
            <span className="font-bold text-red-900">Rs. {cost.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-3 gap-4 mt-4 pt-2 border-t text-[10px] text-slate-600">
        <Signature label="GRN Officer" name={v.completed_by || ""} />
        <Signature label="Gate Guard" />
        <Signature label="Driver" name={v.driver_name} />
      </div>
    </div>
  );
}

function Row({ k, val }: { k: string; val: string }) {
  return (
    <div className="flex justify-between border-b border-dashed border-slate-200 py-0.5">
      <span className="text-slate-500">{k}</span>
      <span className="font-medium text-slate-900">{val}</span>
    </div>
  );
}

function Signature({ label, name }: { label: string; name?: string }) {
  return (
    <div>
      <div className="border-b border-slate-500 h-7 flex items-end justify-center pb-0.5 text-[10px] text-slate-600">{name || ""}</div>
      <div className="text-center text-[10px] mt-1">{label}</div>
    </div>
  );
}
