import { test } from 'node:test';
import { strict as assert } from 'node:assert';

// Opt-in integration regression: uses temporary tagged vehicles and deletes them in finally.
test('database schedules adjacent reservations, edits, moves, reloads and concurrent assignments', { skip: !process.env.RUN_BAY_DATABASE_TESTS, timeout: 60000 }, async () => {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error('Public database configuration missing');
  const prefix = `SCHED-REG-${Date.now()}`;
  const request = async (path: string, method = 'GET', body?: unknown) => {
    const response = await fetch(`${url}/rest/v1/${path}`, { method, headers: { apikey: key, ...(key.startsWith('sb_') ? {} : { Authorization: `Bearer ${key}` }), 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await response.text();
    if (!response.ok) throw new Error(`${response.status}: ${text}`);
    return text ? JSON.parse(text) : null;
  };
  const at = (time: string) => `2026-11-02T${time}:00+05:30`;
  const token = (id: string) => `${prefix}-${id}`;
  const rows = async () => await request(`vehicle_logs?token_no=like.${prefix}*&order=token_no`) as Record<string, unknown>[];
  const get = async (id: string) => { const row = (await rows()).find(v => v.token_no === token(id)); if (!row) throw new Error('Test vehicle missing'); return row; };
  const patch = (id: string, body: unknown) => request(`vehicle_logs?token_no=eq.${token(id)}`, 'PATCH', body);
  const create = (id: string, bay: string, time: string, qty: number) => request('vehicle_logs', 'POST', { token_no: token(id), vehicle_number: token(id), bay_id: bay, requested_start_time: at(time), roll_qty: qty, in_time: '2026-11-01T15:00:00+05:30' });
  const equalTime = (actual: unknown, expected: string) => assert.equal(Date.parse(String(actual)),Date.parse(expected));
  try {
    const settings = await request('admin_settings?id=eq.singleton');
    const cfg = settings[0];
    const minutes = (s: string) => Number(s.split(':')[0])*60+Number(s.split(':')[1]);
    const rate = (Number(cfg.daily_roll_target)+Number(cfg.daily_box_target))/((minutes(cfg.shift_end)-minutes(cfg.shift_start))/60);
    await create('A','BAY-01','08:00',rate);
    await create('B','BAY-01','08:00',rate*1.5);
    await create('C','BAY-01','08:00',rate);
    equalTime((await get('A')).scheduled_end_time,at('09:00'));
    equalTime((await get('B')).scheduled_start_time,at('09:00'));
    equalTime((await get('C')).scheduled_start_time,at('10:30'));
    await create('D','BAY-02','08:00',rate);
    equalTime((await get('D')).scheduled_start_time,at('08:00'));
    await create('E','BAY-03','10:00',rate*2.5);
    const e = await get('E');
    equalTime(e.in_time,'2026-11-01T15:00:00+05:30');
    equalTime(e.scheduled_start_time,at('10:00'));
    assert.ok(e.bay_assigned_at);
    await create('F','BAY-03','10:00',rate);
    equalTime((await get('F')).scheduled_start_time,at('12:30'));
    await patch('A',{roll_qty:rate*2});
    equalTime((await get('B')).scheduled_start_time,at('10:00'));
    equalTime((await get('C')).scheduled_start_time,at('11:30'));
    await patch('B',{bay_id:'BAY-02'});
    equalTime((await get('C')).scheduled_start_time,at('10:00'));
    equalTime((await get('B')).scheduled_start_time,at('09:00'));
    const before = await rows();
    await request('rpc/recalculate_bay_schedules','POST',{});
    assert.deepEqual(await rows(),before);
    await Promise.all([create('G','BAY-01','08:00',rate),create('H','BAY-01','08:00',rate)]);
    const saved = await rows();
    for (const bay of ['BAY-01','BAY-02','BAY-03']) {
      const list = saved.filter(v=>v.bay_id===bay).sort((a,b)=>Date.parse(String(a.scheduled_start_time))-Date.parse(String(b.scheduled_start_time)));
      for(let i=1;i<list.length;i++) assert.ok(Date.parse(String(list[i].scheduled_start_time))>=Date.parse(String(list[i-1].scheduled_end_time)));
    }
    await request(`vehicle_logs?token_no=eq.${token('A')}`,'DELETE');
    equalTime((await get('C')).scheduled_start_time,at('08:00'));
    await request('vehicle_logs','POST',{ token_no:token('NOW'), vehicle_number:token('NOW'), in_time:'2026-10-29T15:00:00+05:30' });
    await patch('NOW',{bay_id:'BAY-01'});
    const immediate=await get('NOW');
    assert.ok(Date.parse(String(immediate.scheduled_start_time))>=Date.parse(String(immediate.bay_assigned_at)));
    equalTime(immediate.in_time,'2026-10-29T15:00:00+05:30');
    await assert.rejects(patch('G',{current_status:'Unloading'}),/occupied|first vehicle|23505/);
    console.log('Executed: exact 09:00/10:30 adjacency, parallel bays, old gate arrival, occupied-until-12:30, workload edit, bay move, persisted reads, idempotence, concurrency, deletion; all passed.');
  } finally {
    await request(`vehicle_logs?token_no=like.${prefix}*`,'DELETE');
  }
});