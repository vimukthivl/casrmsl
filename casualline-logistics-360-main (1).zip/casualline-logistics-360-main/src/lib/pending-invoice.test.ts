import { describe, test } from "node:test";
import { strict as assert } from "node:assert";
import { hasDuplicateInvoiceNumber } from "./pending-invoice";

describe("Pending invoice duplicate prevention", () => {
  test("rejects the same Invoice No", () => {
    assert.equal(hasDuplicateInvoiceNumber([{ invoice_no: "INV-001" }], "INV-001"), true);
    assert.equal(hasDuplicateInvoiceNumber([{ invoice_no: "INV-001" }], "INV-002"), false);
  });
  test("spaces and letter case cannot bypass duplicate detection", () => {
    assert.equal(hasDuplicateInvoiceNumber([{ invoice_no: " INV-001 " }], " inv-001 "), true);
  });
  test("completed invoices also reserve their Invoice No", () => {
    const rows = [{ invoice_no: "INV-001", status: "Completed" }];
    assert.equal(hasDuplicateInvoiceNumber(rows, "INV-001"), true);
  });
  test("empty Invoice No does not prevent existing P/O-only entry", () => {
    assert.equal(hasDuplicateInvoiceNumber([{ invoice_no: "" }], " "), false);
  });
});