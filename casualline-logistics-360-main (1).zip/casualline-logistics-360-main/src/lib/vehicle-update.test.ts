import { describe, test } from "node:test";
import { strict as assert } from "node:assert";
import { canViewVehicleUpdate } from "./vehicle-update";
import type { Role } from "./types";

describe("Vehicle Update team visibility", () => {
  test("PCU team can view Vehicle Update", () => assert.equal(canViewVehicleUpdate("pcu"), true));
  test("GRN team can view Vehicle Update", () => assert.equal(canViewVehicleUpdate("grn"), true));
  test("Admin can view Vehicle Update", () => assert.equal(canViewVehicleUpdate("admin"), true));
  test("all other teams cannot view Vehicle Update", () => {
    const otherRoles: Role[] = ["guard", "tv", "rm_gl", "picker", "trims", "bay", "menu", "cycle", "viewer"];
    for (const role of otherRoles) assert.equal(canViewVehicleUpdate(role), false);
  });
});