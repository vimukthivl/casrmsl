import { test } from 'node:test';
import { strict as assert } from 'node:assert';

test('bay assignment saves reservations and validates active transfers', { skip: !process.env.RUN_BAY_DATABASE_TESTS, timeout: 60000 }, async () => {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error('Database configuration missing');
  const prefix = `ASSIGN-REG-${Date.now()}`;
  const req = async (path: string, method = 'GET', body?: unknown) => {
    const r = await fetch(`${url}/rest/v1/${path}`, { method, headers: { apikey: key, ...(key.startsWith('sb_') ? {} : { Authorization: `Bearer ${key}` }), 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await r.text();
    if (!r.ok) throw new Error(text);
    return text ? JSON.parse(text) : null;
  };
  const patch = (id: string, body: unknown) => req(`vehicle_logs?token_no=eq.${prefix}-${id}`, 'PATCH', body);
  const get = async (id: string) => (await req(`vehicle_logs?token_no=eq.${prefix}-${id}`))[0];
  try {
    for (const id of ['A', 'B']) await req('vehicle_logs', 'POST', { token_no: `${prefix}-${id}`, vehicle_number: `${prefix}-${id}`, roll_qty: 100 });
    await patch('A', { bay_id: 'BAY-01' });
    await patch('B', { bay_id: 'BAY-03' });
    const assigned = await get('A');
    assert.ok(assigned.bay_assigned_at && assigned.scheduled_start_time && assigned.scheduled_end_time);
    assert.ok(Date.parse(assigned.scheduled_start_time) >= Date.parse(assigned.bay_assigned_at));
    await patch('A', { current_status: 'Unloading' });
    await patch('B', { current_status: 'Unloading' });
    await assert.rejects(patch('A', { bay_id: 'BAY-03' }), /Place it on Hold before starting/);
    assert.equal((await get('A')).bay_id, 'BAY-01');
    await patch('B', { current_status: 'Hold', hold_reason: 'Transfer test' });
    const held = await get('B');
    assert.ok(Date.parse(held.scheduled_start_time) >= Date.parse(held.hold_started_at));
    await patch('A', { bay_id: 'BAY-03' });
    const moved = await get('A');
    assert.equal(moved.bay_id, 'BAY-03');
    assert.equal(moved.scheduled_start_time, moved.unload_start_time);
    assert.ok(Date.parse((await get('B')).scheduled_start_time) >= Date.parse(moved.scheduled_end_time));
    const before = await req(`vehicle_logs?token_no=like.${prefix}*&order=token_no`);
    await req('rpc/recalculate_bay_schedules', 'POST', {});
    assert.deepEqual(await req(`vehicle_logs?token_no=like.${prefix}*&order=token_no`), before);
  } finally { await req(`vehicle_logs?token_no=like.${prefix}*`, 'DELETE'); }
});