import { test } from "node:test";
import { strict as assert } from "node:assert";

test("Green Board counts each report by concern, date and shift without counting edits", { skip: !process.env.RUN_GREEN_BOARD_DATABASE_TESTS, timeout: 60000 }, async () => {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Database configuration missing");
  const req = async (path: string, method = "GET", body?: unknown) => {
    const response = await fetch(`${url}/rest/v1/${path}`, {
      method,
      headers: { apikey: key, ...(key.startsWith("sb_") ? {} : { Authorization: `Bearer ${key}` }), "Content-Type": "application/json", Prefer: "return=representation" },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (!response.ok) throw new Error(await response.text());
    const text = await response.text();
    return text ? JSON.parse(text) : null;
  };
  const [concern] = await req("green_board_concerns", "POST", { label: `COUNT-REG-${Date.now()}`, board_key: "kanban" });
  const report = (note: string, shift = "A", date = "2026-11-04") => req("rpc/submit_green_board_report", "POST", { p_concern_id: concern.id, p_board_key: "kanban", p_entry_date: date, p_shift: shift, p_note: note });
  const readA = async () => (await req(`green_board_entries?concern_id=eq.${concern.id}&shift=eq.A&entry_date=eq.2026-11-04`))[0];
  try {
    await report("On-time Kanban not ready — first report");
    assert.equal((await readA()).submission_count, 1);
    await report("Second report");
    assert.equal((await readA()).submission_count, 2);
    await Promise.all([report("Concurrent one"), report("Concurrent two"), report("Concurrent three")]);
    const a = await readA();
    assert.equal(a.submission_count, 5);
    for (const note of ["first report", "Second report", "Concurrent one", "Concurrent two", "Concurrent three"]) assert.ok(a.note.includes(note));
    await report("Shift B report", "B");
    const [b] = await req(`green_board_entries?concern_id=eq.${concern.id}&shift=eq.B`);
    assert.equal(b.submission_count, 1);
    await report("Another date", "A", "2026-11-05");
    const [nextDate] = await req(`green_board_entries?concern_id=eq.${concern.id}&entry_date=eq.2026-11-05`);
    assert.equal(nextDate.submission_count, 1);
    await req(`green_board_entries?id=eq.${a.id}`, "PATCH", { note: "Corrected note" });
    assert.equal((await readA()).submission_count, 5);
  } finally {
    await req(`green_board_concerns?id=eq.${concern.id}`, "DELETE");
  }
});