import { test } from 'node:test';
import { strict as assert } from 'node:assert';

test('one unloader starts now while held vehicles move after it', { skip: !process.env.RUN_BAY_DATABASE_TESTS, timeout: 60000 }, async () => {
  const url = process.env.VITE_SUPABASE_URL;
  const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error('Database configuration missing');
  const prefix = `HOLD-REG-${Date.now()}`;
  const req = async (path: string, method = 'GET', body?: unknown) => {
    const r = await fetch(`${url}/rest/v1/${path}`, { method, headers: { apikey: key, ...(key.startsWith('sb_') ? {} : { Authorization: `Bearer ${key}` }), 'Content-Type': 'application/json', Prefer: 'return=representation' }, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await r.text();
    if (!r.ok) throw new Error(text);
    return text ? JSON.parse(text) : null;
  };
  const patch = (id: string, body: unknown) => req(`vehicle_logs?token_no=eq.${prefix}-${id}`, 'PATCH', body);
  const get = async (id: string) => (await req(`vehicle_logs?token_no=eq.${prefix}-${id}`))[0];
  try {
    for (const id of ['A', 'B', 'C']) await req('vehicle_logs', 'POST', { token_no: `${prefix}-${id}`, vehicle_number: `${prefix}-${id}`, bay_id: 'BAY-03', roll_qty: 100 });
    await patch('A', { current_status: 'Unloading' });
    await patch('A', { current_status: 'Hold', hold_reason: 'Test hold' });
    const before = Date.now();
    await patch('B', { current_status: 'Unloading' });
    const b = await get('B'); const a = await get('A');
    assert.ok(Date.parse(b.unload_start_time) >= before - 1000);
    assert.equal(Date.parse(b.scheduled_start_time), Date.parse(b.unload_start_time));
    assert.ok(Date.parse(a.scheduled_start_time) >= Date.parse(b.scheduled_end_time));
    assert.equal(a.current_status, 'Hold');
    assert.equal(a.hold_reason, 'Test hold');
    await assert.rejects(patch('A', { current_status: 'Unloading' }), /Hold before starting/);
    await patch('B', { current_status: 'Hold', hold_reason: 'Second hold' });
    await patch('C', { current_status: 'Unloading' });
    assert.equal((await get('C')).current_status, 'Unloading');
    assert.equal((await get('A')).current_status, 'Hold');
    assert.equal((await get('B')).current_status, 'Hold');
    await patch('C', { current_status: 'Completed', unload_end_time: new Date().toISOString() });
    await patch('A', { current_status: 'Unloading' });
    assert.equal((await get('A')).current_status, 'Unloading');
    const saved = await req(`vehicle_logs?token_no=like.${prefix}*&order=token_no`);
    await req('rpc/recalculate_bay_schedules', 'POST', {});
    assert.deepEqual(await req(`vehicle_logs?token_no=like.${prefix}*&order=token_no`), saved);
  } finally { await req(`vehicle_logs?token_no=like.${prefix}*`, 'DELETE'); }
});