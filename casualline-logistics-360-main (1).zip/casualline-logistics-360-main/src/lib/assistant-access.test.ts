import { describe, test } from "node:test";
import { strict as assert } from "node:assert";
import { ASSISTANT_WRITE_TOOLS, needsAssistantPassword, assistantPasswordMatches } from "./assistant-access";

describe("Assistant password protection", () => {
  test("every supported write requires password verification", () => {
    for (const tool of ASSISTANT_WRITE_TOOLS) {
      assert.equal(needsAssistantPassword(tool, false), true);
      assert.equal(needsAssistantPassword(tool, true), false);
    }
  });
  test("ordinary reads do not require the change password", () => {
    assert.equal(needsAssistantPassword("read_table", false), false);
  });
  test("password comparison accepts exact matches only", async () => {
    assert.equal(await assistantPasswordMatches("test-only-value", "test-only-value"), true);
    assert.equal(await assistantPasswordMatches("wrong", "test-only-value"), false);
    assert.equal(await assistantPasswordMatches(" test-only-value", "test-only-value"), false);
  });
});