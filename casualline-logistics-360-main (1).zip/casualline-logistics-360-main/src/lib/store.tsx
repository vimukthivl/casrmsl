import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from "react";
import type { User, Role, WeeklySchedule, VehicleLog, DayKey, MaterialType, VehicleType, ArrivalStatus, CurrentStatus, HoldReason, BayId, AdminSettings, HeldUpRate, GrnReason } from "./types";
import { DAYS, DEFAULT_SETTINGS } from "./types";
import { supabase } from "@/integrations/supabase/client";
import { fetchUnloadEntries, addUnloadEntry } from "./unload-entries";
import { canViewVehicleUpdate } from "./vehicle-update";


const AUTH_KEY = "casualline_auth_v1";

const MOCK_USERS: Record<string, { password: string; user: User }> = {
  admin: { password: "admin123", user: { username: "admin", role: "admin", display_name: "System Admin" } },
  menu: { password: "menu123", user: { username: "menu", role: "menu", display_name: "Full Menu Access" } },
  pcu: { password: "pcu123", user: { username: "pcu", role: "pcu", display_name: "PCU Officer" } },
  guard: { password: "guard123", user: { username: "guard", role: "guard", display_name: "Guard Room" } },
  grn: { password: "grn123", user: { username: "grn", role: "grn", display_name: "RM GRN Team" } },
  tv: { password: "tv123", user: { username: "tv", role: "tv", display_name: "TV Kiosk" } },
  rm_gl: { password: "gl123", user: { username: "rm_gl", role: "rm_gl", display_name: "RM Group Leader" } },
  trims: { password: "trims123", user: { username: "trims", role: "trims", display_name: "Trims Team" } },
  pick: { password: "pick123", user: { username: "pick", role: "picker", display_name: "Floor Picker" } },
  picker: { password: "picker123", user: { username: "picker", role: "picker", display_name: "Floor Picker" } },
  bay: { password: "bay123", user: { username: "bay", role: "bay", display_name: "Bay Display" } },
  viewer: { password: "view123", user: { username: "viewer", role: "viewer", display_name: "Guest Viewer" } },
  cycle: { password: "cycle123", user: { username: "cycle", role: "cycle", display_name: "Cycle Counting Team" } },
};

interface State {
  schedules: WeeklySchedule[];
  vehicles: VehicleLog[];
  settings: AdminSettings;
  heldUpRates: HeldUpRate[];
  grnReasons: GrnReason[];
  loading: boolean;
}

type ScheduleRow = {
  id: string;
  vendor_name: string;
  material_type: string;
  relevant_pcu: string;
  vehicle_type: string;
  uom: string;
  remarks: string;
  ih_time?: string | null;
  days_data: unknown;
  claimed_date?: string | null;
  claimed_token?: string | null;
  week_start?: string | null;
};

// ---- ISO week helpers (Monday-start) ----
export function isoMondayOf(d: Date = new Date()): string {
  const day = d.getDay(); // 0=Sun..6=Sat
  const diff = day === 0 ? -6 : 1 - day;
  const m = new Date(d);
  m.setDate(d.getDate() + diff);
  m.setHours(0, 0, 0, 0);
  return m.toISOString().slice(0, 10);
}
export function isoNextMondayOf(d: Date = new Date()): string {
  const m = new Date(isoMondayOf(d));
  m.setDate(m.getDate() + 7);
  return m.toISOString().slice(0, 10);
}

type VehicleRow = {
  token_no: string;
  vehicle_number: string;
  vehicle_type: string;
  driver_name: string;
  driver_phone: string;
  invoice_no: string;
  quantity_brought: number | string;
  roll_qty: number | string | null;
  box_qty: number | string | null;
  manually_unloaded_qty?: number | string | null;
  vendor_name: string;
  material_type: string;
  relevant_pcu: string;
  arrival_status: string;
  current_status: string;
  hold_reason: string | null;
  hold_notes: string | null;
  in_time: string;
  bay_assigned_at?: string | null;
  requested_start_time?: string | null;
  scheduled_start_time?: string | null;
  scheduled_end_time?: string | null;
  unload_start_time: string | null;
  unload_end_time: string | null;
  out_time: string | null;
  is_held_up: boolean;
  bay_id: string | null;
  queue_position: number | null;
  completed_by?: string | null;
  schedule_id?: string | null;
};

type SettingsRow = {
  held_up_cost_rate: number | string;
  daily_roll_target: number | string;
  daily_box_target: number | string;
  shift_start: string;
  shift_end: string;
};

const EMPTY_DAYS: Record<DayKey, number> = { Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0 };

function mapSchedule(r: ScheduleRow): WeeklySchedule {
  const d = (r.days_data && typeof r.days_data === "object" ? r.days_data : {}) as Record<string, unknown>;
  const days: Record<DayKey, number> = { ...EMPTY_DAYS };
  DAYS.forEach((k) => { days[k] = Number(d[k]) || 0; });
  return {
    id: r.id,
    vendor_name: r.vendor_name ?? "",
    material_type: (r.material_type || "Fabric") as MaterialType,
    relevant_pcu: r.relevant_pcu ?? "",
    vehicle_type: (r.vehicle_type || "20 FT") as VehicleType,
    uom: r.uom ?? "",
    remarks: r.remarks ?? "",
    ih_time: r.ih_time ?? "",
    days_data: days,
    claimed_date: r.claimed_date ?? null,
    claimed_token: r.claimed_token ?? null,
    week_start: (r.week_start ?? isoMondayOf()) as string,
  };
}

function mapVehicle(r: VehicleRow): VehicleLog {
  return {
    token_no: r.token_no,
    vehicle_number: r.vehicle_number ?? "",
    vehicle_type: (r.vehicle_type || "20 FT") as VehicleType,
    driver_name: r.driver_name ?? "",
    driver_phone: r.driver_phone ?? "",
    invoice_no: r.invoice_no ?? "",
    quantity_brought: Number(r.quantity_brought) || 0,
    roll_qty: Number(r.roll_qty) || 0,
    box_qty: Number(r.box_qty) || 0,
    manually_unloaded_qty: r.manually_unloaded_qty == null || r.manually_unloaded_qty === "" ? null : Number(r.manually_unloaded_qty),
    vendor_name: r.vendor_name ?? "",
    material_type: (r.material_type || "Fabric") as MaterialType,
    relevant_pcu: r.relevant_pcu ?? "",
    arrival_status: (r.arrival_status || "Unscheduled") as ArrivalStatus,
    current_status: (r.current_status || "Waiting") as CurrentStatus,
    hold_reason: (r.hold_reason || undefined) as HoldReason | undefined,
    hold_notes: r.hold_notes || undefined,
    in_time: r.in_time,
    bay_assigned_at: r.bay_assigned_at,
    requested_start_time: r.requested_start_time,
    scheduled_start_time: r.scheduled_start_time,
    scheduled_end_time: r.scheduled_end_time,
    unload_start_time: r.unload_start_time || undefined,
    unload_end_time: r.unload_end_time || undefined,
    out_time: r.out_time || undefined,
    is_held_up: !!r.is_held_up,
    bay_id: (r.bay_id as BayId | null) ?? null,
    queue_position: r.queue_position ?? null,
    completed_by: r.completed_by ?? null,
    schedule_id: r.schedule_id ?? null,
  };
}

function mapSettings(r: SettingsRow | null | undefined): AdminSettings {
  if (!r) return { ...DEFAULT_SETTINGS };
  return {
    held_up_cost_rate: Number(r.held_up_cost_rate) || 0,
    daily_roll_target: Number(r.daily_roll_target) || 0,
    daily_box_target: Number(r.daily_box_target) || 0,
    shift_start: r.shift_start || DEFAULT_SETTINGS.shift_start,
    shift_end: r.shift_end || DEFAULT_SETTINGS.shift_end,
  };
}

interface AppCtx {
  user: User | null;
  authReady: boolean;
  login: (u: string, p: string) => { ok: boolean; error?: string };
  logout: () => void;
  state: State;
  addBlankSchedule: (weekStart?: string) => Promise<void>;
  addSchedules: (rows: Omit<WeeklySchedule, "id">[]) => Promise<void>;
  updateSchedule: (id: string, patch: Partial<WeeklySchedule>) => Promise<void>;
  updateScheduleDay: (id: string, day: DayKey, val: number) => Promise<void>;
  clearScheduleWeek: (weekStart: string) => Promise<void>;
  removeSchedule: (id: string) => Promise<void>;
  generateToken: () => string;
  computeArrival: (vendor: string, material: string) => VehicleLog["arrival_status"];
  addVehicle: (
    v: Omit<VehicleLog, "token_no" | "in_time" | "arrival_status" | "current_status" | "is_held_up" | "bay_id" | "queue_position">
  ) => Promise<VehicleLog | null>;
  updateVehicle: (token: string, patch: Partial<VehicleLog>) => Promise<void>;
  revertGateIn: (token: string, reason: string) => Promise<void>;
  // Bay ops
  assignToBay: (token: string, bay: BayId) => Promise<void>;
  unassignFromBay: (token: string) => Promise<void>;
  moveInQueue: (token: string, dir: "up" | "down") => Promise<void>;
  changeBay: (token: string, bay: BayId) => Promise<void>;
  startUnloading: (token: string) => Promise<void>;
  completeUnloading: (token: string, completedBy?: string) => Promise<VehicleLog | null>;
  // Settings
  updateSettings: (patch: Partial<AdminSettings>) => Promise<void>;
  // Held-up rates
  upsertHeldUpRate: (size: VehicleType, rate: number) => Promise<void>;
  // GRN reasons
  addGrnReason: (label: string) => Promise<void>;
  updateGrnReason: (id: string, patch: Partial<Pick<GrnReason, "label" | "is_active" | "sort_order">>) => Promise<void>;
  removeGrnReason: (id: string) => Promise<void>;
}

const Ctx = createContext<AppCtx | null>(null);

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [state, setState] = useState<State>({ schedules: [], vehicles: [], settings: { ...DEFAULT_SETTINGS }, heldUpRates: [], grnReasons: [], loading: true });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTH_KEY);
      if (raw) setUser(JSON.parse(raw));
    } catch { /* ignore */ }
    setAuthReady(true);
  }, []);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      const currentMon = isoMondayOf();
      const [sRes, vRes, setRes, rRes, gRes] = await Promise.all([
        sb.from("weekly_schedules").select("*").gte("week_start", currentMon).order("created_at", { ascending: true }),
        sb.from("vehicle_logs").select("*").order("in_time", { ascending: true }),
        sb.from("admin_settings").select("*").eq("id", "singleton").maybeSingle(),
        sb.from("held_up_rates").select("*"),
        sb.from("grn_pending_reasons").select("*").order("sort_order", { ascending: true }),
      ]);
      if (cancelled) return;
      setState({
        schedules: (sRes.data ?? []).map((r: ScheduleRow) => mapSchedule(r)),
        vehicles: (vRes.data ?? []).map((r: VehicleRow) => mapVehicle(r)),
        settings: mapSettings(setRes.data as SettingsRow | null),
        heldUpRates: (rRes.data ?? []) as HeldUpRate[],
        grnReasons: (gRes.data ?? []) as GrnReason[],
        loading: false,
      });
    };
    load();

    // Auto-reload once per hour so the week promotion happens automatically at
    // Monday 00:00 (archived rows drop out; staged next-week rows become current).
    const weekWatcher = setInterval(load, 60 * 60 * 1000);
    // Read the complete saved schedule after reconnects and as a realtime fallback.
    // Gate-in-only polling misses updates to vehicles already inside a bay.
    const reloadVehicles = async () => {
      const { data, error } = await sb.from("vehicle_logs").select("*").order("in_time", { ascending: true });
      if (!cancelled && !error && data) setState(prev => ({ ...prev, vehicles: data.map(mapVehicle) }));
    };
    const vehicleWatcher = setInterval(reloadVehicles, 10000);

    const schedCh = sb
      .channel("rt-weekly_schedules")
      .on("postgres_changes", { event: "*", schema: "public", table: "weekly_schedules" }, (payload: { eventType: string; new: ScheduleRow; old: { id: string } }) => {
        setState((prev) => {
          let schedules = prev.schedules;
          const currentMon = isoMondayOf();
          if (payload.eventType === "INSERT") {
            const row = mapSchedule(payload.new);
            if (row.week_start >= currentMon && !schedules.find((s) => s.id === row.id)) {
              schedules = [...schedules, row];
            }
          } else if (payload.eventType === "UPDATE") {
            const row = mapSchedule(payload.new);
            if (row.week_start < currentMon) {
              schedules = schedules.filter((s) => s.id !== row.id);
            } else {
              const exists = schedules.find((s) => s.id === row.id);
              schedules = exists ? schedules.map((s) => (s.id === row.id ? row : s)) : [...schedules, row];
            }
          } else if (payload.eventType === "DELETE") {
            schedules = schedules.filter((s) => s.id !== payload.old.id);
          }
          return { ...prev, schedules };
        });
      })
      .subscribe();

    const vehCh = sb
      .channel("rt-vehicle_logs")
      .on("postgres_changes", { event: "*", schema: "public", table: "vehicle_logs" }, (payload: { eventType: string; new: VehicleRow; old: { token_no: string } }) => {
        setState((prev) => {
          let vehicles = prev.vehicles;
          if (payload.eventType === "INSERT") {
            const row = mapVehicle(payload.new);
            if (!vehicles.find((v) => v.token_no === row.token_no)) vehicles = [...vehicles, row];
          } else if (payload.eventType === "UPDATE") {
            const row = mapVehicle(payload.new);
            vehicles = vehicles.map((v) => (v.token_no === row.token_no ? row : v));
          } else if (payload.eventType === "DELETE") {
            vehicles = vehicles.filter((v) => v.token_no !== payload.old.token_no);
          }
          return { ...prev, vehicles };
        });
      })
      .subscribe((status: string) => { if (status === "SUBSCRIBED") void reloadVehicles(); });

    const setCh = sb
      .channel("rt-admin_settings")
      .on("postgres_changes", { event: "*", schema: "public", table: "admin_settings" }, (payload: { new: SettingsRow }) => {
        setState((prev) => ({ ...prev, settings: mapSettings(payload.new) }));
      })
      .subscribe();

    const rateCh = sb
      .channel("rt-held_up_rates")
      .on("postgres_changes", { event: "*", schema: "public", table: "held_up_rates" }, async () => {
        const { data } = await sb.from("held_up_rates").select("*");
        setState((prev) => ({ ...prev, heldUpRates: (data ?? []) as HeldUpRate[] }));
      })
      .subscribe();

    const reasonCh = sb
      .channel("rt-grn_pending_reasons")
      .on("postgres_changes", { event: "*", schema: "public", table: "grn_pending_reasons" }, async () => {
        const { data } = await sb.from("grn_pending_reasons").select("*").order("sort_order", { ascending: true });
        setState((prev) => ({ ...prev, grnReasons: (data ?? []) as GrnReason[] }));
      })
      .subscribe();

    return () => {
      cancelled = true;
      clearInterval(weekWatcher);
      clearInterval(vehicleWatcher);
      sb.removeChannel(schedCh);
      sb.removeChannel(vehCh);
      sb.removeChannel(setCh);
      sb.removeChannel(rateCh);
      sb.removeChannel(reasonCh);
    };
  }, []);

  useEffect(() => {
    const check = async () => {
      const now = Date.now();
      const flips = state.vehicles.filter((v) => {
        const active = v.current_status !== "Completed" && v.current_status !== "Departed";
        const overdue = active && now - new Date(v.in_time).getTime() > 24 * 60 * 60 * 1000;
        return overdue !== v.is_held_up;
      });
      for (const v of flips) {
        const overdue = v.current_status !== "Completed" && v.current_status !== "Departed"
          && now - new Date(v.in_time).getTime() > 24 * 60 * 60 * 1000;
        await sb.from("vehicle_logs").update({ is_held_up: overdue }).eq("token_no", v.token_no);
      }
    };
    const interval = setInterval(check, 30000);
    return () => clearInterval(interval);
  }, [state.vehicles]);

  const login: AppCtx["login"] = (username, password) => {
    const rec = MOCK_USERS[username.toLowerCase()];
    if (!rec || rec.password !== password) return { ok: false, error: "Invalid credentials" };
    setUser(rec.user);
    localStorage.setItem(AUTH_KEY, JSON.stringify(rec.user));
    return { ok: true };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(AUTH_KEY);
  };

  const generateToken = useCallback(() => {
    const d = new Date();
    const yyyymmdd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
    const prefix = `TKN-${yyyymmdd}`;
    const count = state.vehicles.filter((v) => v.token_no.startsWith(prefix)).length + 1;
    return `${prefix}-${String(count).padStart(4, "0")}`;
  }, [state.vehicles]);

  const computeArrival: AppCtx["computeArrival"] = (vendor, material) => {
    const currentMon = isoMondayOf();
    const match = state.schedules.find(
      (s) => s.week_start === currentMon && s.vendor_name.toLowerCase() === vendor.toLowerCase() && s.material_type === material
    );
    if (!match) return "Unscheduled";
    const now = new Date();
    const day = now.getDay();
    if (day === 0) return "Unscheduled";
    const todayIdx = day - 1;
    const todayKey = DAYS[todayIdx];
    if (match.days_data[todayKey] > 0) {
      // If scheduled today, compare actual time vs planned IH time (HH:MM)
      const ih = (match.ih_time || "").trim();
      const m = ih.match(/^(\d{1,2}):(\d{2})/);
      if (m) {
        const planned = new Date(now);
        planned.setHours(Number(m[1]), Number(m[2]), 0, 0);
        const diffMin = (now.getTime() - planned.getTime()) / 60000;
        if (diffMin < -15) return "Early";
        if (diffMin > 15) return "Delayed";
        return "On-Time";
      }
      return "On-Time";
    }
    for (let i = todayIdx + 1; i < DAYS.length; i++) {
      if (match.days_data[DAYS[i] as DayKey] > 0) return "Early";
    }
    for (let i = 0; i < todayIdx; i++) {
      if (match.days_data[DAYS[i] as DayKey] > 0) return "Delayed";
    }
    return "Unscheduled";
  };

  const addBlankSchedule: AppCtx["addBlankSchedule"] = async (weekStart) => {
    const insertBody: Record<string, unknown> = {};
    if (weekStart) insertBody.week_start = weekStart;
    const { data, error } = await sb.from("weekly_schedules").insert(insertBody).select().single();
    if (error) throw error;
    if (data) {
      const row = mapSchedule(data as ScheduleRow);
      setState((prev) => (prev.schedules.find((s) => s.id === row.id) ? prev : { ...prev, schedules: [...prev.schedules, row] }));
    }
  };

  const addSchedules: AppCtx["addSchedules"] = async (rows) => {
    if (!rows.length) return;
    const payload = rows.map((r) => ({
      vendor_name: r.vendor_name,
      material_type: r.material_type,
      relevant_pcu: r.relevant_pcu,
      vehicle_type: r.vehicle_type,
      uom: r.uom,
      remarks: r.remarks,
      ih_time: r.ih_time ?? "",
      days_data: r.days_data,
      week_start: r.week_start,
    }));
    const { data, error } = await sb.from("weekly_schedules").insert(payload).select();
    if (error) throw error;
    if (data) {
      const mapped = (data as ScheduleRow[]).map(mapSchedule);
      setState((prev) => {
        const existing = new Set(prev.schedules.map((s) => s.id));
        const next = [...prev.schedules, ...mapped.filter((m) => !existing.has(m.id))];
        return { ...prev, schedules: next };
      });
    }
  };

  const clearScheduleWeek: AppCtx["clearScheduleWeek"] = async (weekStart) => {
    setState((prev) => ({ ...prev, schedules: prev.schedules.filter((s) => s.week_start !== weekStart) }));
    await sb.from("weekly_schedules").delete().eq("week_start", weekStart);
  };

  const updateSchedule: AppCtx["updateSchedule"] = async (id, patch) => {
    setState((prev) => ({ ...prev, schedules: prev.schedules.map((s) => (s.id === id ? { ...s, ...patch } : s)) }));
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { id: _ignored, ...body } = { id, ...patch } as Partial<WeeklySchedule> & { id: string };
    await sb.from("weekly_schedules").update(body).eq("id", id);
  };

  const updateScheduleDay: AppCtx["updateScheduleDay"] = async (id, day, val) => {
    const cur = state.schedules.find((s) => s.id === id);
    if (!cur) return;
    const days_data = { ...cur.days_data, [day]: val };
    setState((prev) => ({ ...prev, schedules: prev.schedules.map((s) => (s.id === id ? { ...s, days_data } : s)) }));
    await sb.from("weekly_schedules").update({ days_data }).eq("id", id);
  };

  const removeSchedule: AppCtx["removeSchedule"] = async (id) => {
    setState((prev) => ({ ...prev, schedules: prev.schedules.filter((s) => s.id !== id) }));
    await sb.from("weekly_schedules").delete().eq("id", id);
  };

  const addVehicle: AppCtx["addVehicle"] = async (v) => {
    const arrival = computeArrival(v.vendor_name, v.material_type);
    const in_time = new Date().toISOString();
    let token = generateToken();
    // Retry with the next token number if another session already claimed this one
    // (local state can be stale when two devices check in at the same time).
    let data: unknown = null;
    for (let attempt = 0; attempt < 6; attempt++) {
      const insertRow = {
        token_no: token,
        vehicle_number: v.vehicle_number,
        vehicle_type: v.vehicle_type,
        driver_name: v.driver_name,
        driver_phone: v.driver_phone,
        invoice_no: v.invoice_no,
        quantity_brought: v.quantity_brought,
        roll_qty: v.roll_qty,
        box_qty: v.box_qty,
        vendor_name: v.vendor_name,
        material_type: v.material_type,
        relevant_pcu: v.relevant_pcu,
        arrival_status: arrival,
        current_status: "Waiting",
        in_time,
        is_held_up: false,
        schedule_id: v.schedule_id ?? null,
      };
      const res = await sb.from("vehicle_logs").insert(insertRow).select().single();
      if (!res.error) { data = res.data; break; }
      if (res.error.code === "23505") {
        const m = token.match(/^(.*-)(\d+)$/);
        if (!m) throw res.error;
        token = `${m[1]}${String(Number(m[2]) + 1).padStart(4, "0")}`;
        continue;
      }
      throw res.error;
    }
    if (!data) throw new Error("Could not allocate a token number — please try again");
    const row = mapVehicle(data as VehicleRow);
    setState((prev) => (prev.vehicles.find((x) => x.token_no === row.token_no) ? prev : { ...prev, vehicles: [...prev.vehicles, row] }));
    // Mark schedule as claimed for today
    if (v.schedule_id) {
      const today = new Date().toISOString().slice(0, 10);
      await sb.from("weekly_schedules").update({ claimed_date: today, claimed_token: token }).eq("id", v.schedule_id);
    }
    return row;
  };

  const updateVehicle: AppCtx["updateVehicle"] = async (token, patch) => {
    const body: Record<string, unknown> = {};
    if ("requested_start_time" in patch) body.requested_start_time = patch.requested_start_time ?? null;
    if ("scheduled_start_time" in patch) body.scheduled_start_time = patch.scheduled_start_time ?? null;
    if ("current_status" in patch) body.current_status = patch.current_status;
    if ("hold_reason" in patch) body.hold_reason = patch.hold_reason ?? null;
    if ("hold_notes" in patch) body.hold_notes = patch.hold_notes ?? null;
    if ("unload_start_time" in patch) body.unload_start_time = patch.unload_start_time ?? null;
    if ("unload_end_time" in patch) body.unload_end_time = patch.unload_end_time ?? null;
    if ("out_time" in patch) body.out_time = patch.out_time ?? null;
    if ("is_held_up" in patch) body.is_held_up = patch.is_held_up;
    if ("bay_id" in patch) body.bay_id = patch.bay_id ?? null;
    if ("queue_position" in patch) body.queue_position = patch.queue_position ?? null;
    if ("roll_qty" in patch) body.roll_qty = patch.roll_qty;
    if ("box_qty" in patch) body.box_qty = patch.box_qty;
    if ("manually_unloaded_qty" in patch) body.manually_unloaded_qty = patch.manually_unloaded_qty ?? null;
    if ("vehicle_number" in patch) body.vehicle_number = patch.vehicle_number;
    if ("completed_by" in patch) body.completed_by = patch.completed_by ?? null;
    if (Object.keys(body).length) {
      const { error } = await sb.from("vehicle_logs").update(body).eq("token_no", token);
      if (error) throw error;
      await refreshVehicles();
    }
  };

  const revertGateIn: AppCtx["revertGateIn"] = async (token, reason) => {
    const v = state.vehicles.find((x) => x.token_no === token);
    setState((prev) => ({ ...prev, vehicles: prev.vehicles.filter((x) => x.token_no !== token) }));
    try {
      const { error } = await sb.from("vehicle_logs").delete().eq("token_no", token);
      if (error) throw error;
      await refreshVehicles();
      if (v?.schedule_id) {
        await sb.from("weekly_schedules").update({ claimed_date: null, claimed_token: null }).eq("id", v.schedule_id);
      }
      console.info("[revertGateIn]", { token, vehicle: v?.vehicle_number, reason });
    } catch (e) {
      console.error("revertGateIn failed", e);
      throw e;
    }
  };

  // ---- BAY OPS ----
  const bayQueue = (vehicles: VehicleLog[], bay: BayId) =>
    vehicles
      .filter((v) => v.bay_id === bay && v.current_status !== "Completed" && v.current_status !== "Departed")
      .sort((a, b) => (a.queue_position ?? 9999) - (b.queue_position ?? 9999));

  const refreshVehicles = async () => {
    const { data, error } = await sb.from("vehicle_logs").select("*");
    if (error) throw error;
    setState(prev => ({ ...prev, vehicles: (data ?? []).map(mapVehicle) }));
  };

  const assignToBay: AppCtx["assignToBay"] = async (token, bay) => {
    const { error } = await sb.from("vehicle_logs").update({ bay_id: bay }).eq("token_no", token);
    if (error) throw error;
    await refreshVehicles();
  };

  const unassignFromBay: AppCtx["unassignFromBay"] = async (token) => {
    await updateVehicle(token, { bay_id: null, queue_position: null, current_status: "Waiting", requested_start_time: null });
  };

  const changeBay: AppCtx["changeBay"] = async (token, bay) => {
    // One write: the database updates both affected bays in the same transaction.
    await assignToBay(token, bay);
  };

  const moveInQueue: AppCtx["moveInQueue"] = async (token, dir) => {
    const v = state.vehicles.find((x) => x.token_no === token);
    if (!v || !v.bay_id) return;
    const queue = bayQueue(state.vehicles, v.bay_id);
    const idx = queue.findIndex((x) => x.token_no === token);
    const swapIdx = dir === "up" ? idx - 1 : idx + 1;
    if (swapIdx < 0 || swapIdx >= queue.length) return;
    const next = [...queue];
    [next[idx], next[swapIdx]] = [next[swapIdx], next[idx]];
    const { error } = await sb.rpc("reorder_bay_queue", { p_tokens: next.map(v => v.token_no) });
    if (error) throw error;
    await refreshVehicles();
  };

  const startUnloading: AppCtx["startUnloading"] = async (token) => {
    await updateVehicle(token, { current_status: "Unloading" });
  };

  const completeUnloading: AppCtx["completeUnloading"] = async (token, completedBy) => {
    const v = state.vehicles.find((x) => x.token_no === token);
    if (!v) return null;
    const end = new Date().toISOString();
    const isFabric = v.material_type === "Fabric";
    const totalManifest = isFabric ? (v.roll_qty || 0) : (v.box_qty || 0);
    const unit = isFabric ? "Rolls" : "Boxes";
    // Partial unloads are logged as shift-stamped entries. On completion, whatever
    // balance is left over is logged as a final entry in the current shift so the
    // cumulative unloaded qty always equals the full manifest.
    let unloadedSoFar = 0;
    try {
      const entries = await fetchUnloadEntries([token]);
      unloadedSoFar = entries.reduce((s, e) => s + e.qty, 0);
      const balance = Math.max(0, totalManifest - unloadedSoFar);
      if (balance > 0) {
        await addUnloadEntry({
          token_no: token,
          vehicle_number: v.vehicle_number,
          material_type: v.material_type,
          unit,
          qty: balance,
          entered_by: completedBy ?? null,
          source: "completion",
        });
        unloadedSoFar += balance;
      }
    } catch (e) {
      console.error("unload entry balance failed", e);
      unloadedSoFar = v.manually_unloaded_qty ?? totalManifest;
    }
    const manualQty = unloadedSoFar;
    // Preserve bay_id so historical bay-wise totals stay computable on the TV display
    await updateVehicle(token, {
      current_status: "Completed",
      unload_end_time: end,
      completed_by: completedBy ?? null,
      manually_unloaded_qty: manualQty,
    });

    return { ...v, current_status: "Completed", unload_end_time: end, completed_by: completedBy ?? null, manually_unloaded_qty: manualQty };
  };

  const updateSettings: AppCtx["updateSettings"] = async (patch) => {
    setState((prev) => ({ ...prev, settings: { ...prev.settings, ...patch } }));
    const { error } = await sb.from("admin_settings").update({ ...patch, updated_at: new Date().toISOString() }).eq("id", "singleton");
    if (error) throw error;
    await refreshVehicles();
  };

  const upsertHeldUpRate: AppCtx["upsertHeldUpRate"] = async (size, rate) => {
    await sb.from("held_up_rates").upsert({ vehicle_size: size, rate_per_hour: rate, updated_at: new Date().toISOString() });
  };

  const addGrnReason: AppCtx["addGrnReason"] = async (label) => {
    const sort_order = (state.grnReasons.at(-1)?.sort_order ?? 0) + 1;
    await sb.from("grn_pending_reasons").insert({ label, sort_order });
  };

  const updateGrnReason: AppCtx["updateGrnReason"] = async (id, patch) => {
    await sb.from("grn_pending_reasons").update({ ...patch, updated_at: new Date().toISOString() }).eq("id", id);
  };

  const removeGrnReason: AppCtx["removeGrnReason"] = async (id) => {
    await sb.from("grn_pending_reasons").delete().eq("id", id);
  };

  return (
    <Ctx.Provider value={{
      user, authReady, login, logout, state,
      addBlankSchedule, addSchedules, updateSchedule, updateScheduleDay, clearScheduleWeek, removeSchedule,
      generateToken, computeArrival, addVehicle, updateVehicle, revertGateIn,
      assignToBay, unassignFromBay, moveInQueue, changeBay, startUnloading, completeUnloading,
      updateSettings, upsertHeldUpRate, addGrnReason, updateGrnReason, removeGrnReason,
    }}>
      {children}
    </Ctx.Provider>
  );
}

export function useApp() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useApp must be within AppProvider");
  return c;
}

export const ROLE_HOMES: Record<Role, string> = {
  admin: "/dashboard",
  menu: "/dashboard",
  pcu: "/pcu",
  guard: "/guard",
  grn: "/bays",
  tv: "/tv",
  rm_gl: "/green-board",
  trims: "/trims-plan",
  picker: "/picker",
  bay: "/tv",
  cycle: "/cycle-counting",
  viewer: "/dashboard",
};

export const ROLE_ACCESS: Record<Role, string[]> = {
  admin: ["/dashboard", "/trims-dashboard", "/fabric-dashboard", "/management-dashboard", "/pcu", "/guard", "/grn", "/bays", "/tv", "/green-board", "/trims-plan", "/fabric-plan", "/picker", "/cycle-counting", "/invoice-log", "/vehicle-update", "/settings"],
  menu: ["/dashboard", "/trims-dashboard", "/fabric-dashboard", "/management-dashboard", "/pcu", "/guard", "/grn", "/bays", "/tv", "/green-board", "/trims-plan", "/fabric-plan", "/picker", "/cycle-counting", "/invoice-log"],
  pcu: ["/pcu", "/tv", "/vehicle-update"],
  guard: ["/guard"],
  grn: ["/bays", "/grn", "/green-board", "/tv", "/invoice-log", "/vehicle-update"],
  trims: ["/green-board", "/trims-plan", "/fabric-plan", "/picker"],
  picker: ["/picker"],
  bay: ["/tv"],
  tv: ["/tv"],
  rm_gl: ["/green-board", "/tv"],
  cycle: ["/cycle-counting"],
  viewer: ["/dashboard", "/trims-dashboard", "/fabric-dashboard", "/management-dashboard", "/pcu", "/guard", "/grn", "/bays", "/tv", "/green-board", "/trims-plan", "/fabric-plan", "/picker", "/cycle-counting", "/invoice-log"],
};

export function canAccess(role: Role, path: string) {
  if (path === "/vehicle-update" || path.startsWith("/vehicle-update/")) return canViewVehicleUpdate(role);
  return ROLE_ACCESS[role].some((p) => path === p || path.startsWith(p + "/"));
}

// ---- Cost calculation helpers ----
export function heldUpHours(v: VehicleLog): number {
  const end = v.unload_end_time ? new Date(v.unload_end_time).getTime() : Date.now();
  const start = new Date(v.in_time).getTime();
  const hours = (end - start) / (1000 * 60 * 60);
  return Math.max(0, hours - 24);
}

export function rateForVehicle(v: VehicleLog, rates: HeldUpRate[], _fallback: number): number {
  // Use ONLY the admin-panel configured rate per vehicle size.
  // If no rate is set in the admin panel for this vehicle size, cost is 0.
  const match = rates.find((r) => r.vehicle_size === v.vehicle_type);
  return match ? Number(match.rate_per_hour) || 0 : 0;
}


export function heldUpCost(v: VehicleLog, rate: number): number {
  return heldUpHours(v) * rate;
}
