import { describe, test } from "node:test";
import { strict as assert } from "node:assert";
import { supplierSummary, validateSupplierReport } from "./segregation-summary";

describe("supplier-only Segregation reports", () => {
  test("requires Supplier", () => assert.equal(validateSupplierReport(" ", "Damaged delivery"), "Select a Supplier."));
  test("requires Supplier Concern / Issue", () => assert.equal(validateSupplierReport("ABC", " "), "Select the Supplier Concern / Issue."));
  test("accepts just supplier and concern without packaging or shift", () => assert.equal(validateSupplierReport("ABC", "Damaged delivery"), null));
  test("requires Category when one is expected", () => assert.equal(validateSupplierReport("ABC", "Damaged delivery", " "), "Select a Category."));
  test("accepts supplier, concern and category", () => assert.equal(validateSupplierReport("ABC", "Damaged delivery", "Packaging"), null));
  test("counts each submission by supplier, ranks highest first and breaks down concerns", () => {
    const result = supplierSummary([
      { supplier: "ABC", supplier_concern: "Damaged", entry_date: "2026-11-01" },
      { supplier: " abc ", supplier_concern: "Damaged", entry_date: "2026-11-02" },
      { supplier: "ABC", supplier_concern: "Late", entry_date: "2026-11-03" },
      { supplier: "XYZ", supplier_concern: "Late", entry_date: "2026-11-02" },
      { supplier: "", supplier_concern: "", entry_date: "2026-11-04" },
    ]);
    assert.equal(result.length, 2);
    assert.equal(result[0]?.supplier, "ABC");
    assert.equal(result[0]?.count, 3);
    assert.equal(result[0]?.lastDate, "2026-11-03");
    assert.deepEqual(result[0]?.concerns, [{ label: "Damaged", count: 2 }, { label: "Late", count: 1 }]);
    assert.equal(result[1]?.count, 1);
  });
});