import type { Role, VehicleLog } from "./types";

export function canViewVehicleUpdate(role: Role): boolean {
  return role === "pcu" || role === "grn" || role === "admin";
}

export function hasDeparted(vehicle: VehicleLog): boolean {
  return vehicle.current_status === "Departed" || Boolean(vehicle.out_time);
}

export function matchesVehicleSearch(vehicle: VehicleLog, search: string): boolean {
  const query = search.trim().toLowerCase();
  return !query || Object.values(vehicle).some((value) => String(value ?? "").toLowerCase().includes(query));
}

export function vehicleDuration(vehicle: VehicleLog, now: number): string {
  const end = vehicle.out_time ? Date.parse(vehicle.out_time) : now;
  const minutes = Math.max(0, Math.floor((end - Date.parse(vehicle.in_time)) / 60000));
  return Number.isFinite(minutes) ? `${Math.floor(minutes / 60)}h ${minutes % 60}m` : "—";
}