import { supabase } from "@/integrations/supabase/client";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

export type ShiftKey = "A" | "B" | "OFF";

export const SHIFT_LABELS: Record<ShiftKey, string> = {
  A: "Shift A · 06:00–14:00",
  B: "Shift B · 14:00–22:00",
  OFF: "Off-shift",
};

/** 06:00–13:59 → A, 14:00–21:59 → B, otherwise OFF */
export function shiftOf(d: Date = new Date()): ShiftKey {
  const h = d.getHours();
  if (h >= 6 && h < 14) return "A";
  if (h >= 14 && h < 22) return "B";
  return "OFF";
}

export interface UnloadEntry {
  id: string;
  token_no: string;
  vehicle_number: string;
  material_type: string;
  unit: string;
  qty: number;
  shift: ShiftKey;
  entry_date: string;
  entered_by: string | null;
  source: string;
  created_at: string;
}

function mapEntry(r: Record<string, unknown>): UnloadEntry {
  return {
    id: String(r.id),
    token_no: String(r.token_no ?? ""),
    vehicle_number: String(r.vehicle_number ?? ""),
    material_type: String(r.material_type ?? ""),
    unit: String(r.unit ?? "Rolls"),
    qty: Number(r.qty) || 0,
    shift: (String(r.shift || "A") as ShiftKey),
    entry_date: String(r.entry_date ?? ""),
    entered_by: (r.entered_by as string | null) ?? null,
    source: String(r.source ?? "manual"),
    created_at: String(r.created_at ?? ""),
  };
}

export async function fetchUnloadEntries(tokens?: string[]): Promise<UnloadEntry[]> {
  let q = sb.from("unload_entries").select("*").order("created_at", { ascending: true });
  if (tokens && tokens.length) q = q.in("token_no", tokens);
  const { data, error } = await q;
  if (error) throw error;
  return (data ?? []).map(mapEntry);
}

export interface NewUnloadEntry {
  token_no: string;
  vehicle_number: string;
  material_type: string;
  unit: string;
  qty: number;
  entered_by?: string | null;
  source?: string;
}

export async function addUnloadEntry(e: NewUnloadEntry): Promise<UnloadEntry> {
  const now = new Date();
  const row = {
    token_no: e.token_no,
    vehicle_number: e.vehicle_number,
    material_type: e.material_type,
    unit: e.unit,
    qty: e.qty,
    shift: shiftOf(now),
    entry_date: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`,
    entered_by: e.entered_by ?? null,
    source: e.source ?? "manual",
  };
  const { data, error } = await sb.from("unload_entries").insert(row).select().single();
  if (error) throw error;
  return mapEntry(data);
}

export async function deleteUnloadEntry(id: string): Promise<void> {
  const { error } = await sb.from("unload_entries").delete().eq("id", id);
  if (error) throw error;
}

export function sumByShift(entries: UnloadEntry[]) {
  const out: Record<ShiftKey, number> = { A: 0, B: 0, OFF: 0 };
  entries.forEach((e) => { out[e.shift] = (out[e.shift] || 0) + e.qty; });
  return out;
}

export function subscribeUnloadEntries(onChange: () => void) {
  const ch = sb
    .channel("rt-unload_entries")
    .on("postgres_changes", { event: "*", schema: "public", table: "unload_entries" }, () => onChange())
    .subscribe();
  return () => { sb.removeChannel(ch); };
}
