import { describe, it } from "node:test";
import { strict as assert } from "node:assert";
import { API_TABLES, ApiError, hasScope, parseFilters, parseLimit, scopeFor, tableAllowed, validateBody } from "./integration-api";

describe("integration API rules", () => {
  it("covers all 22 business tables", () => {
    assert.equal(Object.keys(API_TABLES).length, 22);
    assert.ok(API_TABLES.pending_invoices);
  });
  it("read-only key cannot write or delete", () => {
    assert.equal(hasScope(["read"], scopeFor("POST")), false);
    assert.equal(hasScope(["read"], scopeFor("DELETE")), false);
    assert.equal(hasScope(["read"], scopeFor("GET")), true);
  });
  it("rejects unknown columns", () => {
    assert.throws(() => parseFilters("vehicle_logs", new URLSearchParams("password=x")), ApiError);
    assert.throws(() => validateBody("pending_invoices", { hacker: 1 }, true), ApiError);
  });
  it("caps limit at 5000", () => {
    assert.equal(parseLimit("99999"), 5000);
  });
  it("restricts keys to allowed tables", () => {
    assert.equal(tableAllowed(["fabric_plan"], "vehicle_logs"), false);
    assert.equal(tableAllowed(null, "vehicle_logs"), true);
  });
  it("rejects more than 1000 rows per insert", () => {
    assert.throws(() => validateBody("fabric_downtime", Array(1001).fill({ concern: "x" }), true), ApiError);
  });
});
