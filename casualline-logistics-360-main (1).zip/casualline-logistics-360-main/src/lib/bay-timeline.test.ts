import { describe, test } from 'node:test';
import { strict as assert } from 'node:assert';
import { timelineCards, operatingDate, operatingDayStart } from './bay-timeline';
import type { VehicleLog } from './types';

const at = (time: string) => Date.parse(`2026-10-30T${time}:00+05:30`);
const vehicle = (token: string, start: string, end: string, bay = 'BAY-01') => ({ token_no: token, bay_id: bay, scheduled_start_time: new Date(at(start)).toISOString(), scheduled_end_time: new Date(at(end)).toISOString() } as VehicleLog);
describe('Saved bay timeline intervals', () => {
  test('08:00–09:00 followed by 09:00–10:30 and 10:30 has exact adjacent positions', () => {
    const cards = timelineCards([vehicle('A','08:00','09:00'), vehicle('B','09:00','10:30'), vehicle('C','10:30','11:30')], at('06:00'), at('22:00'));
    assert.equal(cards[1].start, at('09:00'));
    assert.equal(cards[2].start, at('10:30'));
    assert.equal(cards[0].leftPct + cards[0].widthPct, cards[1].leftPct);
    assert.equal(cards[1].leftPct + cards[1].widthPct, cards[2].leftPct);
  });
  test('different bays can begin at 08:00', () => {
    const a = timelineCards([vehicle('A','08:00','09:00')],at('06:00'),at('22:00'));
    const b = timelineCards([vehicle('B','08:00','09:00','BAY-02')],at('06:00'),at('22:00'));
    assert.equal(a[0].leftPct,b[0].leftPct);
  });
  test('yesterday gate-in never replaces a saved 10:00 start with 06:00', () => {
    const v = { ...vehicle('A','10:00','11:00'), in_time:'2026-10-29T15:00:00+05:30', bay_assigned_at:'2026-10-30T10:00:00+05:30' };
    assert.equal(timelineCards([v],at('06:00'),at('22:00'))[0].leftPct,25);
    assert.equal(v.in_time,'2026-10-29T15:00:00+05:30');
  });
  test('short intervals retain exact duration without visual minimum width', () => {
    const cards = timelineCards([vehicle('A','08:00','08:15'),vehicle('B','08:15','08:30')],at('06:00'),at('22:00'));
    assert.equal(cards[0].widthPct,15/960*100);
    assert.equal(cards[0].leftPct+cards[0].widthPct,cards[1].leftPct);
  });
  test('off-date vehicles are excluded, never clamped back to 06:00', () => assert.equal(timelineCards([vehicle('A','23:00','23:30')],at('06:00'),at('22:00')).length,0));
  test('midnight crossing clips full dates correctly', () => {
    const v = { token_no:'A', scheduled_start_time:'2026-10-29T21:00:00+05:30', scheduled_end_time:'2026-10-30T07:00:00+05:30' } as VehicleLog;
    const c = timelineCards([v],at('06:00'),at('22:00'))[0];
    assert.equal(c.leftPct,0); assert.equal(c.widthPct,60/960*100);
  });
  test('reload and repeated rendering preserve exact saved positions', () => {
    const v = vehicle('A','10:00','11:00');
    assert.deepEqual(timelineCards([v],at('06:00'),at('22:00')),timelineCards(JSON.parse(JSON.stringify([v])),at('06:00'),at('22:00')));
  });
  test('operating day follows Colombo even before UTC midnight', () => {
    assert.equal(operatingDate(Date.parse('2026-10-29T23:12:00Z')),'2026-10-30');
    assert.equal(operatingDayStart('2026-10-30'),Date.parse('2026-10-29T18:30:00Z'));
  });
});