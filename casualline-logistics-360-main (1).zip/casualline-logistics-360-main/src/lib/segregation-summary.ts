export interface SupplierReport {
  supplier: string;
  supplier_concern: string;
  entry_date: string;
}

export function validateSupplierReport(supplier: string, concern: string, category = "ok") {
  if (!supplier.trim()) return "Select a Supplier.";
  if (!concern.trim()) return "Select the Supplier Concern / Issue.";
  if (!category.trim()) return "Select a Category.";
  return null;
}

export function supplierSummary(rows: SupplierReport[]) {
  const suppliers = new Map<string, { supplier: string; count: number; lastDate: string; concerns: Map<string, { label: string; count: number }> }>();
  for (const row of rows) {
    const name = row.supplier.trim();
    const concern = row.supplier_concern.trim();
    if (!name || !concern) continue;
    const key = name.toLowerCase();
    const current = suppliers.get(key) ?? { supplier: name, count: 0, lastDate: row.entry_date, concerns: new Map() };
    current.count += 1;
    if (row.entry_date > current.lastDate) current.lastDate = row.entry_date;
    const concernKey = concern.toLowerCase();
    const issue = current.concerns.get(concernKey) ?? { label: concern, count: 0 };
    issue.count += 1;
    current.concerns.set(concernKey, issue);
    suppliers.set(key, current);
  }
  return [...suppliers.values()].map((s) => ({ ...s, concerns: [...s.concerns.values()].sort((a, b) => b.count - a.count || a.label.localeCompare(b.label)) }))
    .sort((a, b) => b.count - a.count || a.supplier.localeCompare(b.supplier));
}