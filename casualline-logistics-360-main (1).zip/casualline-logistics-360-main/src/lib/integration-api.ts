// Pure helpers for the external integration API (v1). No server-only imports.

export const API_TABLES: Record<string, { pk: string; columns: string[] }> = {
  admin_settings: { pk: "id", columns: ["daily_box_target", "daily_roll_target", "held_up_cost_rate", "id", "shift_end", "shift_start", "updated_at"] },
  cc_daily_actuals: { pk: "id", columns: ["counted_qty", "created_at", "entry_date", "id", "item_code", "updated_at", "warehouse"] },
  cc_monthly_targets: { pk: "id", columns: ["created_at", "id", "item_code", "month", "target_qty", "updated_at", "warehouse"] },
  cycle_count_logs: { pk: "id", columns: ["available_qty", "batch_id", "category", "count_by", "created_at", "grand_qty", "id", "material_code", "material_description", "updated_at", "upload_date"] },
  fabric_downtime: { pk: "id", columns: ["concern", "created_at", "entry_date", "id", "lost_hours", "notes", "updated_at"] },
  fabric_picker_achievements: { pk: "id", columns: ["created_at", "epf_number", "id", "picked_at", "picker_name", "plan_id", "po_number"] },
  fabric_picker_targets: { pk: "id", columns: ["created_at", "epf_number", "gin_target_per_day", "id", "is_active", "name", "updated_at"] },
  fabric_plan: { pk: "id", columns: ["created_at", "cut_date", "id", "order_description", "order_qty", "picker_date", "picker_epf", "picker_name", "production_order", "so_li", "so_no", "start_date", "updated_at", "uploaded_at", "work_center"] },
  green_board_concerns: { pk: "id", columns: ["board_key", "created_at", "id", "is_active", "label", "sort_order"] },
  green_board_entries: { pk: "id", columns: ["board_key", "concern_id", "created_at", "entry_date", "id", "note", "shift", "submission_count", "updated_at"] },
  grn_pending_reasons: { pk: "id", columns: ["created_at", "id", "is_active", "label", "sort_order", "updated_at"] },
  held_up_rates: { pk: "vehicle_size", columns: ["rate_per_hour", "updated_at", "vehicle_size"] },
  invoice_daily_log: { pk: "id", columns: ["created_at", "fabric_completed", "fabric_received", "id", "log_date", "trims_completed", "trims_received", "updated_at"] },
  pending_invoices: { pk: "id", columns: ["completed_at", "completed_by", "created_at", "id", "invoice_no", "merchant", "pcu_comment", "pcu_member", "po_number", "reason", "received_date", "status", "supplier", "updated_at"] },
  picker_achievements: { pk: "id", columns: ["created_at", "epf_number", "id", "picked_at", "picker_name", "plan_id", "po_number"] },
  picker_targets: { pk: "id", columns: ["created_at", "epf_number", "gin_target_per_day", "id", "is_active", "name", "updated_at"] },
  sample_handovers: { pk: "id", columns: ["courier", "created_at", "entered_by", "entry_date", "gdn_number", "handed_over_at", "handed_over_to", "id", "item_description", "notes", "origin", "photo_url", "qty", "received_at", "recipient", "status", "updated_at", "vehicle_number"] },
  trims_downtime: { pk: "id", columns: ["concern", "created_at", "entry_date", "id", "lost_hours", "notes", "updated_at"] },
  trims_plan: { pk: "id", columns: ["created_at", "cut_date", "id", "order_description", "order_qty", "picker_date", "picker_epf", "picker_name", "production_order", "so_li", "so_no", "start_date", "updated_at", "uploaded_at", "work_center"] },
  unload_entries: { pk: "id", columns: ["created_at", "entered_by", "entry_date", "id", "material_type", "qty", "shift", "source", "token_no", "unit", "vehicle_number"] },
  vehicle_logs: { pk: "token_no", columns: ["arrival_status", "bay_assigned_at", "bay_id", "box_qty", "completed_by", "current_status", "driver_name", "driver_phone", "hold_notes", "hold_reason", "hold_started_at", "in_time", "invoice_no", "is_held_up", "manually_unloaded_qty", "material_type", "out_time", "quantity_brought", "queue_position", "relevant_pcu", "requested_start_time", "roll_qty", "schedule_id", "scheduled_end_time", "scheduled_start_time", "token_no", "unload_end_time", "unload_start_time", "vehicle_number", "vehicle_type", "vendor_name"] },
  weekly_schedules: { pk: "id", columns: ["claimed_date", "claimed_token", "created_at", "days_data", "id", "ih_time", "material_type", "relevant_pcu", "remarks", "uom", "vehicle_type", "vendor_name", "week_start"] },
};

export type Scope = "read" | "write" | "delete";
export const SCOPES: Scope[] = ["read", "write", "delete"];
export const MAX_LIMIT = 5000;
export const MAX_BODY_BYTES = 1_000_000;
export const MAX_INSERT_ROWS = 1000;
export const RESERVED_PARAMS = new Set(["select", "limit", "offset", "order"]);
const OPS = new Set(["eq", "neq", "gt", "gte", "lt", "lte", "like", "ilike", "is", "in"]);

export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

export function scopeFor(method: string): Scope {
  if (method === "GET") return "read";
  if (method === "DELETE") return "delete";
  return "write";
}

export function hasScope(scopes: string[], needed: Scope) {
  return scopes.includes(needed);
}

export function tableAllowed(allowed: string[] | null | undefined, table: string) {
  return !allowed || allowed.length === 0 || allowed.includes(table);
}

export function assertTable(table: string) {
  const t = API_TABLES[table];
  if (!t) throw new ApiError(400, "unknown_table", `Unknown table "${table}"`);
  return t;
}

export function assertColumns(table: string, cols: string[]) {
  const t = assertTable(table);
  for (const c of cols) if (!t.columns.includes(c)) throw new ApiError(400, "unknown_column", `Unknown column "${c}" on ${table}`);
}

export function parseSelect(table: string, select: string | null) {
  if (!select || select === "*") return "*";
  const cols = select.split(",").map((s) => s.trim()).filter(Boolean);
  assertColumns(table, cols);
  return cols.join(",");
}

export type Filter = { col: string; op: string; value: string | string[] | null | boolean };

export function parseFilters(table: string, params: URLSearchParams): Filter[] {
  const out: Filter[] = [];
  for (const [col, raw] of params.entries()) {
    if (RESERVED_PARAMS.has(col)) continue;
    assertColumns(table, [col]);
    const m = /^([a-z]+)\.(.*)$/s.exec(raw);
    let op = "eq"; let val = raw;
    if (m && OPS.has(m[1])) { op = m[1]; val = m[2]; }
    if (op === "in") out.push({ col, op, value: val.replace(/^\(|\)$/g, "").split(",").map((s) => s.trim()) });
    else if (op === "is") {
      if (!["null", "true", "false"].includes(val)) throw new ApiError(400, "bad_filter", "is. accepts null, true or false");
      out.push({ col, op, value: val === "null" ? null : val === "true" });
    } else out.push({ col, op, value: val });
  }
  return out;
}

export function parseLimit(raw: string | null) {
  const n = raw == null ? 500 : Number(raw);
  if (!Number.isInteger(n) || n < 1) throw new ApiError(400, "bad_limit", "limit must be a positive integer");
  return Math.min(n, MAX_LIMIT);
}

export function parseOffset(raw: string | null) {
  const n = raw == null ? 0 : Number(raw);
  if (!Number.isInteger(n) || n < 0) throw new ApiError(400, "bad_offset", "offset must be 0 or more");
  return n;
}

export function parseOrder(table: string, raw: string | null) {
  if (!raw) return null;
  const [col, dir = "asc"] = raw.split(".");
  assertColumns(table, [col]);
  if (dir !== "asc" && dir !== "desc") throw new ApiError(400, "bad_order", "order direction must be asc or desc");
  return { col, ascending: dir === "asc" };
}

export function validateBody(table: string, body: unknown, allowArray: boolean) {
  const rows = Array.isArray(body) ? body : [body];
  if (Array.isArray(body) && !allowArray) throw new ApiError(400, "bad_body", "Body must be a single object");
  if (rows.length === 0) throw new ApiError(400, "bad_body", "Body is empty");
  if (rows.length > MAX_INSERT_ROWS) throw new ApiError(400, "too_many_rows", `At most ${MAX_INSERT_ROWS} rows per request`);
  for (const r of rows) {
    if (!r || typeof r !== "object" || Array.isArray(r)) throw new ApiError(400, "bad_body", "Each row must be a JSON object");
    assertColumns(table, Object.keys(r));
  }
  return rows as Record<string, unknown>[];
}

export async function sha256Hex(s: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function generateApiKey() {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  return "cl360_" + [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function timingSafeEqualStr(a: string, b: string) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}
