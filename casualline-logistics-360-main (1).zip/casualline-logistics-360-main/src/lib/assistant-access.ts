export const ASSISTANT_WRITE_TOOLS = new Set([
  "update_invoice_log", "add_green_board_entry", "log_downtime", "set_vehicle_hold",
  "update_admin_settings", "update_held_up_rate",
]);

export function needsAssistantPassword(tool: string, passwordVerified: boolean): boolean {
  return ASSISTANT_WRITE_TOOLS.has(tool) && !passwordVerified;
}

export async function assistantPasswordMatches(input: string, expected: string): Promise<boolean> {
  const encode = new TextEncoder();
  const [a, b] = await Promise.all([
    crypto.subtle.digest("SHA-256", encode.encode(input)),
    crypto.subtle.digest("SHA-256", encode.encode(expected)),
  ]);
  const left = new Uint8Array(a);
  const right = new Uint8Array(b);
  let difference = 0;
  for (let i = 0; i < left.length; i++) difference |= left[i] ^ right[i];
  return difference === 0;
}