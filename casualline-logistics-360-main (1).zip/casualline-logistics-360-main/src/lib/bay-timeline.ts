import type { VehicleLog } from './types';

export const APP_TIMEZONE = 'Asia/Colombo';
export function operatingDate(at: number): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: APP_TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit' }).format(at);
}
export function operatingDayStart(day: string): number {
  return Date.parse(`${day}T00:00:00+05:30`);
}
export function timelineCards(list: VehicleLog[], rangeStart: number, rangeEnd: number) {
  const length = rangeEnd - rangeStart;
  if (length <= 0) return [];
  return list.flatMap(v => {
    const start = Date.parse(v.scheduled_start_time || v.unload_start_time || '');
    const end = Date.parse(v.scheduled_end_time || v.unload_end_time || '');
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start || end <= rangeStart || start >= rangeEnd) return [];
    const clippedStart = Math.max(start, rangeStart);
    const clippedEnd = Math.min(end, rangeEnd);
    return [{ v, start, end, targetMin: (end - start) / 60_000,
      leftPct: (clippedStart - rangeStart) / length * 100,
      widthPct: (clippedEnd - clippedStart) / length * 100, lane: 0, laneCount: 1 }];
  }).sort((a, b) => a.start - b.start || a.v.token_no.localeCompare(b.v.token_no));
}