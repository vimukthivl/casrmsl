export function hasDuplicateInvoiceNumber(rows: ReadonlyArray<{ invoice_no: string }>, invoiceNo: string): boolean {
  const key = invoiceNo.trim().toLowerCase();
  return key !== "" && rows.some((row) => row.invoice_no.trim().toLowerCase() === key);
}