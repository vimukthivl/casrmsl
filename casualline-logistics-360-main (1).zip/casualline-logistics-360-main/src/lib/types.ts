export type Role = "admin" | "pcu" | "guard" | "grn" | "tv" | "rm_gl" | "picker" | "trims" | "bay" | "menu" | "cycle" | "viewer";

export type MaterialType = "Fabric" | "Trims" | "Packaging";
export type PCU = string;
export type VehicleType = "40 Ft" | "20 Ft" | "16.5 Ft" | "14.5 Ft" | "12.5 Ft" | "10.5 Ft" | "10 Ft";
export const VEHICLE_TYPES: VehicleType[] = ["40 Ft", "20 Ft", "16.5 Ft", "14.5 Ft", "12.5 Ft", "10.5 Ft", "10 Ft"];

export type ArrivalStatus = "On-Time" | "Early" | "Delayed" | "Unscheduled";
export type CurrentStatus =
  | "Waiting"
  | "Assigned"
  | "Unloading"
  | "Hold"
  | "Completed"
  | "Departed";
export type HoldReason = string;

export type DayKey = "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat";
export const DAYS: DayKey[] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export type BayId = "BAY-01" | "BAY-02" | "BAY-03";
export const BAYS: { id: BayId; label: string }[] = [
  { id: "BAY-01", label: "Bay 01" },
  { id: "BAY-02", label: "Bay 02" },
  { id: "BAY-03", label: "Bay 03" },
];

export interface WeeklySchedule {
  id: string;
  vendor_name: string;
  material_type: MaterialType;
  relevant_pcu: PCU;
  vehicle_type: VehicleType;
  uom: string;
  remarks: string;
  ih_time: string;
  days_data: Record<DayKey, number>;
  claimed_date?: string | null;
  claimed_token?: string | null;
  week_start: string; // YYYY-MM-DD (Monday of the ISO week the row belongs to)
}

export interface VehicleLog {
  token_no: string;
  vehicle_number: string;
  vehicle_type: VehicleType;
  driver_name: string;
  driver_phone: string;
  invoice_no: string;
  quantity_brought: number;
  roll_qty: number;
  box_qty: number;
  manually_unloaded_qty?: number | null;
  vendor_name: string;
  material_type: MaterialType;
  relevant_pcu: PCU;
  arrival_status: ArrivalStatus;
  current_status: CurrentStatus;
  hold_reason?: HoldReason;
  hold_notes?: string;
  in_time: string;
  bay_assigned_at?: string | null;
  requested_start_time?: string | null;
  scheduled_start_time?: string | null;
  scheduled_end_time?: string | null;
  unload_start_time?: string;
  unload_end_time?: string;
  out_time?: string;
  is_held_up: boolean;
  bay_id?: BayId | null;
  queue_position?: number | null;
  completed_by?: string | null;
  schedule_id?: string | null;
}

export interface AdminSettings {
  held_up_cost_rate: number;
  daily_roll_target: number;
  daily_box_target: number;
  shift_start: string;
  shift_end: string;
}

export interface HeldUpRate {
  vehicle_size: VehicleType;
  rate_per_hour: number;
}

export interface GrnReason {
  id: string;
  label: string;
  is_active: boolean;
  sort_order: number;
}

export const DEFAULT_SETTINGS: AdminSettings = {
  held_up_cost_rate: 500,
  daily_roll_target: 1000,
  daily_box_target: 500,
  shift_start: "06:00",
  shift_end: "22:00",
};

export interface User {
  username: string;
  role: Role;
  display_name: string;
}
