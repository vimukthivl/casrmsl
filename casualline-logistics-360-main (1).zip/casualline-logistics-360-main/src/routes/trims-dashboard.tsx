import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { AppFooter } from "@/components/AppFooter";
import { TrimsSummaryPanels } from "@/components/TrimsSummaryPanels";
import { TrimsHealthBadge } from "@/components/TrimsHealthBadge";
import { WipSummaryEmbed } from "@/components/WipSummaryEmbed";
import { Scissors } from "lucide-react";


export const Route = createFileRoute("/trims-dashboard")({
  head: () => ({
    meta: [
      { title: "Trims Dashboard — Casualline Logistics 360" },
      { name: "description", content: "Trims planning and downtime KPI overview." },
      { property: "og:title", content: "Trims Dashboard — Casualline Logistics 360" },
      { property: "og:description", content: "Trims planning and downtime KPI overview." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/trims-dashboard">
      <TrimsDashboardPage />
      <AppFooter />
    </RequireAccess>
  ),
});

function TrimsDashboardPage() {
  return (
    <div className="p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto">
      <header className="relative overflow-hidden rounded-2xl border-2 border-teal-400/30 bg-gradient-to-br from-teal-500/15 via-emerald-500/10 to-cyan-500/10 p-5 shadow-lg shadow-teal-500/10">
        <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-teal-400/20 blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-3 flex-wrap">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shadow-md shadow-teal-500/40">
            <Scissors className="h-6 w-6" />
          </div>
          <TrimsHealthBadge />
          <div className="min-w-0">
            <h1 className="text-xl md:text-2xl font-extrabold truncate bg-gradient-to-r from-teal-600 via-emerald-600 to-cyan-600 bg-clip-text text-transparent">
              Trims Dashboard ✂️
            </h1>
            <p className="text-xs text-muted-foreground">Read-only overview · Cycle Counting, Green Board & Picker Performance.</p>
          </div>
        </div>
      </header>


      <WipSummaryEmbed />
      <TrimsSummaryPanels />
    </div>
  );
}
