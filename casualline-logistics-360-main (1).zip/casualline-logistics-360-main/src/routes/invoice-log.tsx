import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { useApp } from "@/lib/store";
import { supabase } from "@/integrations/supabase/client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { FileSpreadsheet, Save } from "lucide-react";

export const Route = createFileRoute("/invoice-log")({
  head: () => ({
    meta: [
      { title: "Daily Invoice GRN Completion Log · Casualline Logistics 360" },
      { name: "description", content: "Daily fabric & trims invoice GRN completion tracker with manager view." },
      { property: "og:title", content: "Daily Invoice GRN Completion Log · Casualline Logistics 360" },
      { property: "og:description", content: "Daily fabric & trims invoice GRN completion tracker with manager view." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/invoice-log">
      <InvoiceLog />
    </RequireAccess>
  ),
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

interface LogRow {
  id?: string;
  log_date: string;
  fabric_received: number;
  fabric_completed: number;
  trims_received: number;
  trims_completed: number;
}

const MONTH_NAMES = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December",
];

function daysInMonth(y: number, m0: number) { return new Date(y, m0 + 1, 0).getDate(); }
function fmt(y: number, m0: number, d: number) {
  return `${y}-${String(m0 + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}
function isSunday(y: number, m0: number, d: number) { return new Date(y, m0, d).getDay() === 0; }
function pct(c: number, r: number) { return r > 0 ? Math.round((c / r) * 1000) / 10 : 0; }

type TabKey = "fabric" | "trims";

export function InvoiceLog() {
  const { user } = useApp();
  const canEdit = user?.role === "admin" || user?.role === "menu" || user?.role === "grn";

  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month0, setMonth0] = useState(now.getMonth());
  const [tab, setTab] = useState<TabKey>("fabric");
  const [rows, setRows] = useState<Record<string, LogRow>>({});
  const [drafts, setDrafts] = useState<Record<string, Partial<LogRow>>>({});
  const [loading, setLoading] = useState(true);

  const numDays = daysInMonth(year, month0);
  const monthStart = fmt(year, month0, 1);
  const monthEnd = fmt(year, month0, numDays);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb
      .from("invoice_daily_log")
      .select("*")
      .gte("log_date", monthStart)
      .lte("log_date", monthEnd)
      .order("log_date");
    if (error) toast.error(error.message);
    const map: Record<string, LogRow> = {};
    for (const r of (data ?? []) as LogRow[]) map[r.log_date] = r;
    setRows(map);
    setDrafts({});
    setLoading(false);
  }, [monthStart, monthEnd]);

  useEffect(() => {
    load();
    const ch = sb.channel("rt-invoice-log")
      .on("postgres_changes", { event: "*", schema: "public", table: "invoice_daily_log" }, () => load())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load]);

  const days = useMemo(() => Array.from({ length: numDays }, (_, i) => i + 1), [numDays]);

  const getVal = (date: string, field: keyof LogRow): number => {
    const d = drafts[date];
    if (d && field in d) return Number(d[field] ?? 0);
    const r = rows[date];
    return Number((r?.[field] as number | undefined) ?? 0);
  };

  const setDraft = (date: string, field: keyof LogRow, value: number) => {
    setDrafts((prev) => ({ ...prev, [date]: { ...(prev[date] ?? {}), [field]: value } }));
  };

  const isDirty = (date: string) => !!drafts[date] && Object.keys(drafts[date]).length > 0;

  const saveRow = async (date: string) => {
    if (!canEdit) return;
    const existing = rows[date];
    const payload = {
      log_date: date,
      fabric_received: getVal(date, "fabric_received"),
      fabric_completed: getVal(date, "fabric_completed"),
      trims_received: getVal(date, "trims_received"),
      trims_completed: getVal(date, "trims_completed"),
    };
    const { error } = existing
      ? await sb.from("invoice_daily_log").update(payload).eq("log_date", date)
      : await sb.from("invoice_daily_log").insert(payload);
    if (error) { toast.error(error.message); return; }
    toast.success(`Saved ${date}`);
    setDrafts((p) => { const n = { ...p }; delete n[date]; return n; });
    load();
  };

  const changeMonth = (delta: number) => {
    const d = new Date(year, month0 + delta, 1);
    setYear(d.getFullYear()); setMonth0(d.getMonth());
  };

  // Totals for header
  const totals = useMemo(() => {
    let fr=0,fc=0,tr=0,tc=0;
    for (const d of days) {
      if (isSunday(year, month0, d)) continue;
      const date = fmt(year, month0, d);
      fr += getVal(date, "fabric_received");
      fc += getVal(date, "fabric_completed");
      tr += getVal(date, "trims_received");
      tc += getVal(date, "trims_completed");
    }
    return { fr, fc, tr, tc };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rows, drafts, days, year, month0]);


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-sky-50/40 p-6">
      {/* Header */}
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-sky-600 text-white grid place-items-center shadow-lg">
            <FileSpreadsheet className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-3xl md:text-4xl font-black tracking-tight text-slate-900 uppercase leading-none">
              Daily Invoice GRN Completion Log
            </h1>
            <p className="text-sm text-slate-500 mt-1">Fabric &amp; Trims daily invoice tracker (Sundays excluded)</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={() => changeMonth(-1)} className="px-3 py-2 rounded-md border bg-white hover:bg-slate-50 text-sm font-medium">◀ Prev</button>
          <div className="px-4 py-2 rounded-md bg-white border shadow-sm min-w-[180px] text-center">
            <div className="text-xs uppercase tracking-wider text-slate-400">Viewing</div>
            <div className="text-lg font-bold text-slate-900">{MONTH_NAMES[month0]} {year}</div>
          </div>
          <button onClick={() => changeMonth(1)} className="px-3 py-2 rounded-md border bg-white hover:bg-slate-50 text-sm font-medium">Next ▶</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-4 flex flex-wrap gap-2 rounded-xl border bg-white p-2 shadow-sm">
        {([
          { k: "fabric", label: "Fabric WH" },
          { k: "trims",  label: "Trims WH" },
        ] as { k: TabKey; label: string }[]).map((t) => {
          const active = tab === t.k;
          return (
            <button key={t.k} onClick={() => setTab(t.k)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                active ? "bg-sky-600 text-white shadow" : "text-slate-600 hover:bg-slate-100"
              }`}>
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === "fabric" && (
        <DailyGrid
          storeLabel="Fabric"
          receivedField="fabric_received"
          completedField="fabric_completed"
          totalReceived={totals.fr}
          totalCompleted={totals.fc}
          accent="from-indigo-500 to-sky-500"
          days={days} year={year} month0={month0}
          getVal={getVal} setDraft={setDraft} isDirty={isDirty} saveRow={saveRow}
          canEdit={canEdit} loading={loading}
        />
      )}

      {tab === "trims" && (
        <DailyGrid
          storeLabel="Trims"
          receivedField="trims_received"
          completedField="trims_completed"
          totalReceived={totals.tr}
          totalCompleted={totals.tc}
          accent="from-emerald-500 to-teal-500"
          days={days} year={year} month0={month0}
          getVal={getVal} setDraft={setDraft} isDirty={isDirty} saveRow={saveRow}
          canEdit={canEdit} loading={loading}
        />
      )}

    </div>
  );
}

interface DailyGridProps {
  storeLabel: string;
  receivedField: keyof LogRow;
  completedField: keyof LogRow;
  totalReceived: number;
  totalCompleted: number;
  accent: string;
  days: number[];
  year: number;
  month0: number;
  getVal: (date: string, field: keyof LogRow) => number;
  setDraft: (date: string, field: keyof LogRow, value: number) => void;
  isDirty: (date: string) => boolean;
  saveRow: (date: string) => void;
  canEdit: boolean;
  loading: boolean;
}

function DailyGrid(p: DailyGridProps) {
  const overall = pct(p.totalCompleted, p.totalReceived);
  return (
    <div className="space-y-4">
      <div className={`rounded-xl bg-gradient-to-r ${p.accent} text-white p-4 shadow-sm grid grid-cols-2 md:grid-cols-4 gap-4`}>
        <Stat label={`${p.storeLabel} Invoices Received`} value={p.totalReceived} />
        <Stat label={`${p.storeLabel} GRNs Completed`} value={p.totalCompleted} />
        <Stat label="Pending" value={Math.max(0, p.totalReceived - p.totalCompleted)} />
        <Stat label="Completion %" value={`${overall}%`} />
      </div>

      <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-900 text-white">
              <tr>
                <th className="text-left px-3 py-2 font-semibold">Date</th>
                <th className="text-left px-3 py-2 font-semibold">Day</th>
                <th className="text-right px-3 py-2 font-semibold">Invoices Received<br/><span className="text-[10px] font-normal opacity-70">06 AM – 10 PM</span></th>
                <th className="text-right px-3 py-2 font-semibold">GRNs Completed</th>
                <th className="text-right px-3 py-2 font-semibold">Pending</th>
                <th className="text-right px-3 py-2 font-semibold">Completion %</th>
                <th className="text-right px-3 py-2 font-semibold">Save</th>
              </tr>
            </thead>
            <tbody>
              {p.loading && (
                <tr><td colSpan={7} className="p-8 text-center text-slate-400">Loading…</td></tr>
              )}
              {!p.loading && (() => {
                const today = new Date();
                const isCurrentMonth = today.getFullYear() === p.year && today.getMonth() === p.month0;
                const todayDay = today.getDate();
                const ordered = isCurrentMonth
                  ? [todayDay, ...p.days.filter((d) => d !== todayDay)].filter((d) => d >= 1 && d <= p.days.length)
                  : p.days;
                return ordered.map((d) => {
                const date = fmt(p.year, p.month0, d);
                const sun = isSunday(p.year, p.month0, d);
                const isToday = isCurrentMonth && d === todayDay;
                if (sun) {
                  return (
                    <tr key={d} className={`bg-slate-100 text-slate-400 ${isToday ? "ring-2 ring-sky-400" : ""}`}>
                      <td className="px-3 py-2">{date}{isToday && <span className="ml-2 text-[10px] font-bold text-sky-600">TODAY</span>}</td>
                      <td className="px-3 py-2 italic">Sunday</td>
                      <td colSpan={5} className="px-3 py-2 text-center italic">— Excluded —</td>
                    </tr>
                  );
                }
                const r = p.getVal(date, p.receivedField);
                const c = p.getVal(date, p.completedField);
                const pending = Math.max(0, r - c);
                const cp = pct(c, r);
                const dirty = p.isDirty(date);
                const dayName = new Date(p.year, p.month0, d).toLocaleDateString(undefined, { weekday: "short" });
                return (
                  <tr key={d} className={`border-b last:border-0 hover:bg-slate-50 ${isToday ? "bg-sky-50 ring-2 ring-sky-400" : ""}`}>
                    <td className="px-3 py-2 font-mono text-xs text-slate-600">{date}{isToday && <span className="ml-2 text-[10px] font-bold text-sky-600">TODAY</span>}</td>
                    <td className="px-3 py-2">{dayName}</td>
                    <td className="px-3 py-2 text-right">
                      <input type="number" min={0} value={r} disabled={!p.canEdit}
                        onChange={(e) => p.setDraft(date, p.receivedField, Math.max(0, Number(e.target.value)))}
                        className="w-24 h-8 px-2 rounded border bg-background text-right disabled:opacity-60" />
                    </td>
                    <td className="px-3 py-2 text-right">
                      <input type="number" min={0} value={c} disabled={!p.canEdit}
                        onChange={(e) => p.setDraft(date, p.completedField, Math.max(0, Number(e.target.value)))}
                        className="w-24 h-8 px-2 rounded border bg-background text-right disabled:opacity-60" />
                    </td>
                    <td className="px-3 py-2 text-right font-semibold text-amber-700">{pending}</td>
                    <td className={`px-3 py-2 text-right font-bold ${cp >= 95 ? "text-emerald-600" : cp >= 80 ? "text-amber-600" : "text-rose-600"}`}>
                      {cp}%
                    </td>
                    <td className="px-3 py-2 text-right">
                      <button disabled={!p.canEdit || !dirty} onClick={() => p.saveRow(date)}
                        className="h-8 px-2 rounded bg-sky-600 text-white text-xs font-medium disabled:opacity-30 inline-flex items-center gap-1">
                        <Save className="h-3 w-3" /> Save
                      </button>
                    </td>
                  </tr>
                );
              });
              })()}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}


function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div>
      <div className="text-[11px] uppercase tracking-wider opacity-80">{label}</div>
      <div className="text-2xl font-black leading-tight">{value}</div>
    </div>
  );
}
