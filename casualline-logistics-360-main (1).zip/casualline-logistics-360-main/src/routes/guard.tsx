import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import type { MaterialType, VehicleType, WeeklySchedule, DayKey } from "@/lib/types";
import { DAYS, VEHICLE_TYPES } from "@/lib/types";
import { ArrivalBadge, StatusBadge } from "./dashboard";
import { AlertCircle, ClipboardList, Plus, ShieldCheck, Truck, LogOut, Activity, Undo2, X } from "lucide-react";

export const Route = createFileRoute("/guard")({
  head: () => ({ meta: [{ title: "Guard Room — Casualline Logistics 360" }, { name: "description", content: "Casualline gate arrivals, vehicle check-in and departure records." },
      { property: "og:title", content: "Guard Room — Casualline Logistics 360" },
      { property: "og:description", content: "Casualline gate arrivals, vehicle check-in and departure records." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: () => (
    <RequireAccess path="/guard">
      <Guard />
    </RequireAccess>
  ),
});

type FormState = {
  schedule_id: string | null;
  vendor_name: string;
  material_type: MaterialType;
  relevant_pcu: string;
  vehicle_type: VehicleType;
  vehicle_number: string;
  driver_name: string;
  driver_phone: string;
  invoice_no: string;
  quantity_brought: number;
  roll_qty: number;
  box_qty: number;
};

const EMPTY_FORM: FormState = {
  schedule_id: null,
  vendor_name: "",
  material_type: "Fabric",
  relevant_pcu: "",
  vehicle_type: "20 Ft",
  vehicle_number: "",
  driver_name: "",
  driver_phone: "",
  invoice_no: "",
  quantity_brought: 0,
  roll_qty: 0,
  box_qty: 0,
};

function todayKey(): DayKey | null {
  const d = new Date().getDay();
  if (d === 0) return null;
  return DAYS[d - 1];
}

// Monday-anchored dates for the current week (Mon..Sat)
function weekDates(): Record<DayKey, Date> {
  const now = new Date();
  const dow = now.getDay(); // 0=Sun..6=Sat
  const mondayOffset = dow === 0 ? -6 : 1 - dow;
  const mon = new Date(now);
  mon.setDate(now.getDate() + mondayOffset);
  mon.setHours(0, 0, 0, 0);
  const out = {} as Record<DayKey, Date>;
  DAYS.forEach((d, i) => {
    const dt = new Date(mon);
    dt.setDate(mon.getDate() + i);
    out[d] = dt;
  });
  return out;
}

type PlanOption = {
  key: string;
  schedule: WeeklySchedule;
  day: DayKey;
  date: Date;
  qty: number;
  relation: "today" | "past" | "future";
};

function Guard() {
  const { state, addVehicle, updateVehicle, revertGateIn } = useApp();
  const [mode, setMode] = useState<"scheduled" | "unscheduled">("scheduled");
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [selectedKey, setSelectedKey] = useState<string>("");
  const [revertTarget, setRevertTarget] = useState<{ token: string; vehicle: string } | null>(null);
  const [revertReason, setRevertReason] = useState("");
  const [reverting, setReverting] = useState(false);

  const today = todayKey();

  // Build full weekly plan options (Mon-Sat). Each (schedule × day-with-qty) becomes an option,
  // filtered out once a vehicle_log exists for that schedule + planned date.
  const planOptions = useMemo<PlanOption[]>(() => {
    const wk = weekDates();
    const midnight = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
    const todayTs = midnight(new Date());
    const opts: PlanOption[] = [];
    for (const s of state.schedules) {
      if (!s.vendor_name.trim()) continue;
      for (const d of DAYS) {
        const qty = s.days_data[d] || 0;
        if (qty <= 0) continue;
        const date = wk[d];
        // Claimed if a vehicle exists for this schedule on this planned date
        const claimed = state.vehicles.some(
          (v) => v.schedule_id === s.id && midnight(new Date(v.in_time)) === midnight(date)
        );
        if (claimed) continue;
        const ts = midnight(date);
        const relation: PlanOption["relation"] = ts === todayTs ? "today" : ts < todayTs ? "past" : "future";
        opts.push({ key: `${s.id}__${d}`, schedule: s, day: d, date, qty, relation });
      }
    }
    // Sort: today first, then future ascending, then past descending (most recent overdue first)
    return opts.sort((a, b) => {
      const rank = { today: 0, future: 1, past: 2 } as const;
      if (rank[a.relation] !== rank[b.relation]) return rank[a.relation] - rank[b.relation];
      return a.relation === "past"
        ? b.date.getTime() - a.date.getTime()
        : a.date.getTime() - b.date.getTime();
    });
  }, [state.schedules, state.vehicles]);

  const pickOption = (opt: PlanOption) => {
    setSelectedKey(opt.key);
    setForm((f) => ({
      ...f,
      schedule_id: opt.schedule.id,
      vendor_name: opt.schedule.vendor_name,
      material_type: opt.schedule.material_type,
      relevant_pcu: opt.schedule.relevant_pcu,
      vehicle_type: opt.schedule.vehicle_type,
      quantity_brought: opt.qty,
      roll_qty: opt.qty,
      box_qty: 0,
    }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.vehicle_number.trim()) { toast.error("Vehicle number is required"); return; }
    if (!form.vendor_name.trim()) { toast.error("Vendor is required"); return; }
    try {
      const v = await addVehicle(form);
      if (v) {
        toast.success(`Token issued: ${v.token_no} · ${v.arrival_status}`);
        setForm(EMPTY_FORM);
        setSelectedKey("");
      }
    } catch (err) {
      console.error(err);
      const msg = err instanceof Error ? err.message : "Unknown error";
      toast.error("Failed to check in vehicle", { description: msg });
    }
  };

  const active = state.vehicles
    .filter((v) => v.current_status !== "Departed")
    .sort((a, b) => new Date(b.in_time).getTime() - new Date(a.in_time).getTime());

  const completedReadyOut = state.vehicles.filter((v) => v.current_status === "Completed");

  const confirmDeparture = async (token: string) => {
    try {
      await updateVehicle(token, { current_status: "Departed", out_time: new Date().toISOString() });
      toast.success("Vehicle departure confirmed");
    } catch { toast.error("Failed to confirm departure"); }
  };

  const startUnscheduled = () => {
    setMode("unscheduled");
    setSelectedKey("");
    setForm({ ...EMPTY_FORM, schedule_id: null });
  };

  const backToScheduled = () => {
    setMode("scheduled");
    setForm(EMPTY_FORM);
    setSelectedKey("");
  };

  const fmtDate = (d: Date) => `${d.getDate()}/${d.getMonth() + 1}`;
  const relationBadge = (r: PlanOption["relation"]) =>
    r === "today" ? "TODAY" : r === "past" ? "PENDING" : "UPCOMING";

  return (
    <div className="p-6 space-y-6 min-h-screen bg-gradient-to-br from-sky-50 via-background to-violet-50 dark:from-sky-950/30 dark:via-background dark:to-violet-950/30">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl border border-sky-500/30 bg-gradient-to-r from-sky-500/15 via-cyan-500/10 to-violet-500/15 p-5 shadow-lg animate-fade-in">
        <div className="absolute -top-16 -right-10 h-52 w-52 rounded-full bg-cyan-400/25 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-10 h-52 w-52 rounded-full bg-violet-400/25 blur-3xl pointer-events-none" />
        <div className="relative flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-sky-500 to-violet-500 text-white grid place-items-center shadow-md shadow-sky-500/40">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-sky-600 via-cyan-600 to-violet-600 dark:from-sky-300 dark:via-cyan-300 dark:to-violet-300 bg-clip-text text-transparent">
                Guard Room — Gate Operations
              </h1>
              <p className="text-sm text-muted-foreground">Pick from the weekly plan or log an unscheduled entry</p>
            </div>
          </div>
          {mode === "scheduled" ? (
            <button onClick={startUnscheduled}
              className="h-10 px-4 rounded-lg bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white text-sm font-semibold flex items-center gap-2 shadow-md shadow-amber-500/40 transition-all hover:scale-[1.02]">
              <AlertCircle className="h-4 w-4" /> Unscheduled Entry
            </button>
          ) : (
            <button onClick={backToScheduled}
              className="h-10 px-4 rounded-lg bg-gradient-to-r from-sky-500 to-violet-500 hover:from-sky-600 hover:to-violet-600 text-white text-sm font-semibold flex items-center gap-2 shadow-md shadow-sky-500/40 transition-all hover:scale-[1.02]">
              <ClipboardList className="h-4 w-4" /> Back to Scheduled
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Check-in form */}
        <form onSubmit={submit}
          className="lg:col-span-1 rounded-2xl border-2 border-sky-500/25 bg-gradient-to-br from-card via-card to-sky-500/5 p-5 space-y-3 shadow-lg">
          <h3 className="font-semibold flex items-center gap-2 pb-2 border-b border-sky-500/20">
            <div className="h-7 w-7 rounded-md bg-gradient-to-br from-sky-500 to-cyan-500 grid place-items-center text-white shadow">
              <Truck className="h-4 w-4" />
            </div>
            <span className="bg-gradient-to-r from-sky-600 to-cyan-600 dark:from-sky-300 dark:to-cyan-300 bg-clip-text text-transparent">Vehicle IN</span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${mode === "unscheduled" ? "bg-gradient-to-r from-amber-500 to-orange-500 text-white" : "bg-gradient-to-r from-sky-500 to-violet-500 text-white"}`}>
              {mode === "unscheduled" ? "Unscheduled" : "From Plan"}
            </span>
          </h3>

          {mode === "scheduled" ? (
            <Field label={`Weekly Plan (Today: ${today ?? "Sunday — no plan"})`}>
              <select value={selectedKey}
                onChange={(e) => {
                  const opt = planOptions.find((x) => x.key === e.target.value);
                  if (opt) pickOption(opt);
                  else { setSelectedKey(""); setForm({ ...EMPTY_FORM }); }
                }}
                className="w-full h-10 px-2 rounded-lg border-2 border-sky-500/30 bg-background font-medium focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all">
                <option value="">— Select vendor from weekly plan —</option>
                {planOptions.filter((o) => o.relation === "today").length > 0 && (
                  <optgroup label="★ Today">
                    {planOptions.filter((o) => o.relation === "today").map((o) => (
                      <option key={o.key} value={o.key} style={{ fontWeight: 700 }}>
                        ● {o.schedule.vendor_name} — {o.schedule.material_type} ({o.day} {fmtDate(o.date)}) · qty {o.qty}
                      </option>
                    ))}
                  </optgroup>
                )}
                {planOptions.filter((o) => o.relation === "past").length > 0 && (
                  <optgroup label="⚠ Past Pending (this week)">
                    {planOptions.filter((o) => o.relation === "past").map((o) => (
                      <option key={o.key} value={o.key}>
                        {o.schedule.vendor_name} — {o.schedule.material_type} ({o.day} {fmtDate(o.date)}) · qty {o.qty}
                      </option>
                    ))}
                  </optgroup>
                )}
                {planOptions.filter((o) => o.relation === "future").length > 0 && (
                  <optgroup label="→ Upcoming (this week)">
                    {planOptions.filter((o) => o.relation === "future").map((o) => (
                      <option key={o.key} value={o.key}>
                        {o.schedule.vendor_name} — {o.schedule.material_type} ({o.day} {fmtDate(o.date)}) · qty {o.qty}
                      </option>
                    ))}
                  </optgroup>
                )}
              </select>
              {selectedKey && (() => {
                const opt = planOptions.find((x) => x.key === selectedKey);
                if (!opt) return null;
                const tone = opt.relation === "today"
                  ? "from-emerald-500/15 to-green-500/5 border-emerald-500/40 text-emerald-700 dark:text-emerald-300"
                  : opt.relation === "past"
                  ? "from-rose-500/15 to-red-500/5 border-rose-500/40 text-rose-700 dark:text-rose-300"
                  : "from-sky-500/15 to-cyan-500/5 border-sky-500/40 text-sky-700 dark:text-sky-300";
                return (
                  <div className={`mt-2 text-xs px-3 py-2 rounded-lg bg-gradient-to-r ${tone} border-2 font-medium`}>
                    <b>{relationBadge(opt.relation)}</b> · Planned for <b>{opt.day} {fmtDate(opt.date)}</b>
                  </div>
                );
              })()}
              {planOptions.length === 0 && (
                <div className="text-xs text-muted-foreground mt-1">
                  No unclaimed schedules this week. Use <b>Unscheduled Entry</b> for walk-in vehicles.
                </div>
              )}
            </Field>
          ) : (
            <Field label="Vendor Name">
              <input required value={form.vendor_name} placeholder="Type vendor name"
                onChange={(e) => setForm({ ...form, vendor_name: e.target.value })}
                className="w-full h-10 px-2 rounded-lg border-2 border-amber-500/30 bg-background focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-none transition-all" />
            </Field>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Field label="Material">
              <select value={form.material_type} disabled={mode === "scheduled" && !!form.schedule_id}
                onChange={(e) => setForm({ ...form, material_type: e.target.value as MaterialType })}
                className="w-full h-10 px-2 rounded-lg border-2 border-border bg-background disabled:bg-muted/40 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all">
                <option>Fabric</option><option>Trims</option><option>Packaging</option>
              </select>
            </Field>
            <Field label="Relevant PCU / Dept">
              <input value={form.relevant_pcu}
                onChange={(e) => setForm({ ...form, relevant_pcu: e.target.value })}
                placeholder="Type PCU or department"
                className="w-full h-10 px-2 rounded-lg border-2 border-border bg-background focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all" />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Vehicle Type">
              <select value={form.vehicle_type} disabled={mode === "scheduled" && !!form.schedule_id}
                onChange={(e) => setForm({ ...form, vehicle_type: e.target.value as VehicleType })}
                className="w-full h-10 px-2 rounded-lg border-2 border-border bg-background disabled:bg-muted/40 focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all">
                {VEHICLE_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Vehicle Number *">
              <input required value={form.vehicle_number} placeholder="e.g. NC-4587"
                onChange={(e) => setForm({ ...form, vehicle_number: e.target.value.toUpperCase() })}
                className="w-full h-10 px-2 rounded-lg border-2 border-violet-500/30 bg-background font-mono font-semibold focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all" />
            </Field>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Driver Name *">
              <input value={form.driver_name} onChange={(e) => setForm({ ...form, driver_name: e.target.value })}
                className="w-full h-10 px-2 rounded-lg border-2 border-border bg-background focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all" />
            </Field>
            <Field label="Driver Phone *">
              <input value={form.driver_phone} onChange={(e) => setForm({ ...form, driver_phone: e.target.value })}
                className="w-full h-10 px-2 rounded-lg border-2 border-border bg-background focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all" />
            </Field>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Field label="Roll Qty">
              <input type="number" min={0} value={form.roll_qty}
                onChange={(e) => {
                  const r = Number(e.target.value) || 0;
                  setForm({ ...form, roll_qty: r, quantity_brought: r + (form.box_qty || 0) });
                }}
                className="w-full h-10 px-2 rounded-lg border-2 border-cyan-500/30 bg-background text-center font-semibold focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20 outline-none transition-all" />
            </Field>
            <Field label="Box Qty">
              <input type="number" min={0} value={form.box_qty}
                onChange={(e) => {
                  const b = Number(e.target.value) || 0;
                  setForm({ ...form, box_qty: b, quantity_brought: (form.roll_qty || 0) + b });
                }}
                className="w-full h-10 px-2 rounded-lg border-2 border-fuchsia-500/30 bg-background text-center font-semibold focus:border-fuchsia-500 focus:ring-2 focus:ring-fuchsia-500/20 outline-none transition-all" />
            </Field>
            <Field label="Total (auto)">
              <input type="number" value={(form.roll_qty || 0) + (form.box_qty || 0)} readOnly
                className="w-full h-10 px-2 rounded-lg border-2 border-emerald-500/40 bg-gradient-to-br from-emerald-500/10 to-green-500/5 text-center font-bold text-emerald-700 dark:text-emerald-300 cursor-not-allowed" />
            </Field>
          </div>

          <Field label="Invoice No">
            <input value={form.invoice_no} onChange={(e) => setForm({ ...form, invoice_no: e.target.value })}
              className="w-full h-10 px-2 rounded-lg border-2 border-border bg-background focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all" />
          </Field>

          <button className="w-full h-12 rounded-xl bg-gradient-to-r from-sky-500 via-cyan-500 to-violet-500 hover:from-sky-600 hover:via-cyan-600 hover:to-violet-600 text-white font-bold flex items-center justify-center gap-2 shadow-lg shadow-sky-500/40 transition-all hover:scale-[1.02] hover:shadow-xl">
            <Plus className="h-5 w-5" /> Issue Token & Check IN
          </button>
        </form>

        <div className="lg:col-span-2 space-y-6">
          {/* Ready for departure */}
          <div className="relative overflow-hidden rounded-2xl border-2 border-emerald-500/30 bg-gradient-to-br from-emerald-500/10 via-card to-green-500/5 p-5 shadow-lg">
            <div className="absolute -top-12 -right-12 h-40 w-40 rounded-full bg-emerald-400/20 blur-3xl pointer-events-none" />
            <h3 className="relative font-semibold mb-3 flex items-center gap-2">
              <div className="h-7 w-7 rounded-md bg-gradient-to-br from-emerald-500 to-green-500 grid place-items-center text-white shadow">
                <LogOut className="h-4 w-4" />
              </div>
              <span className="bg-gradient-to-r from-emerald-600 to-green-600 dark:from-emerald-300 dark:to-green-300 bg-clip-text text-transparent">
                Ready for Departure
              </span>
              <span className="ml-1 px-2 py-0.5 text-xs font-bold rounded-full bg-emerald-500 text-white tabular-nums">
                {completedReadyOut.length}
              </span>
            </h3>
            {completedReadyOut.length === 0 ? (
              <p className="relative text-sm text-muted-foreground italic">No vehicles awaiting release.</p>
            ) : (
              <ul className="relative space-y-2">
                {completedReadyOut.map((v) => (
                  <li key={v.token_no} className="flex items-center justify-between p-3 rounded-xl border-2 border-emerald-500/20 bg-background/60 backdrop-blur hover:border-emerald-500/50 hover:shadow-md transition-all">
                    <div>
                      <div className="font-semibold">
                        {v.vehicle_number}
                        <span className="text-xs font-mono text-muted-foreground ml-2 px-2 py-0.5 rounded bg-muted">{v.token_no}</span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">{v.vendor_name} · {v.material_type} · {v.relevant_pcu}</div>
                    </div>
                    <button onClick={() => confirmDeparture(v.token_no)}
                      className="h-9 px-4 rounded-lg bg-gradient-to-r from-emerald-500 to-green-500 hover:from-emerald-600 hover:to-green-600 text-white text-sm font-semibold shadow-md shadow-emerald-500/40 transition-all hover:scale-[1.03] flex items-center gap-1.5">
                      <LogOut className="h-3.5 w-3.5" /> Confirm Departure
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Active yard */}
          <div className="relative overflow-hidden rounded-2xl border-2 border-violet-500/30 bg-gradient-to-br from-violet-500/10 via-card to-fuchsia-500/5 p-5 shadow-lg">
            <div className="absolute -bottom-12 -left-12 h-40 w-40 rounded-full bg-violet-400/20 blur-3xl pointer-events-none" />
            <h3 className="relative font-semibold mb-3 flex items-center gap-2">
              <div className="h-7 w-7 rounded-md bg-gradient-to-br from-violet-500 to-fuchsia-500 grid place-items-center text-white shadow">
                <Activity className="h-4 w-4" />
              </div>
              <span className="bg-gradient-to-r from-violet-600 to-fuchsia-600 dark:from-violet-300 dark:to-fuchsia-300 bg-clip-text text-transparent">
                Active Yard
              </span>
              <span className="ml-1 px-2 py-0.5 text-xs font-bold rounded-full bg-violet-500 text-white tabular-nums">
                {active.length}
              </span>
            </h3>
            <div className="relative overflow-x-auto rounded-xl border border-violet-500/20 bg-background/60 backdrop-blur">
              <table className="w-full text-sm">
                <thead className="text-xs uppercase text-white bg-gradient-to-r from-violet-500 to-fuchsia-500">
                  <tr>
                    <th className="text-left py-2 px-3">Token</th>
                    <th className="text-left py-2 px-3">Vehicle</th>
                    <th className="text-left py-2 px-3">Vendor</th>
                    <th className="text-left py-2 px-3">Arrival</th>
                    <th className="text-left py-2 px-3">Status</th>
                    <th className="text-left py-2 px-3">In</th>
                    <th className="text-right py-2 px-3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {active.length === 0 ? (
                    <tr><td colSpan={7} className="py-6 text-center text-sm text-muted-foreground italic">Yard is clear.</td></tr>
                  ) : active.map((v, i) => {
                    const canRevert = v.current_status === "Waiting" || v.current_status === "Assigned";
                    return (
                    <tr key={v.token_no} className={`border-b border-violet-500/10 last:border-0 transition-colors hover:bg-violet-500/5 ${v.is_held_up ? "bg-rose-500/10" : i % 2 === 0 ? "" : "bg-violet-500/[0.03]"}`}>
                      <td className="py-2 px-3 font-mono text-xs font-semibold text-violet-600 dark:text-violet-300">{v.token_no}</td>
                      <td className="py-2 px-3 font-semibold">{v.vehicle_number}</td>
                      <td className="py-2 px-3">{v.vendor_name}</td>
                      <td className="py-2 px-3"><ArrivalBadge status={v.arrival_status} /></td>
                      <td className="py-2 px-3"><StatusBadge status={v.current_status} /></td>
                      <td className="py-2 px-3 text-xs text-muted-foreground">{new Date(v.in_time).toLocaleString()}</td>
                      <td className="py-2 px-3 text-right">
                        {canRevert ? (
                          <button
                            onClick={() => { setRevertReason(""); setRevertTarget({ token: v.token_no, vehicle: v.vehicle_number }); }}
                            title="Revert Gate In (wrong entry)"
                            className="h-8 px-2.5 rounded-lg bg-gradient-to-r from-rose-500 to-red-500 hover:from-rose-600 hover:to-red-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 shadow-md shadow-rose-500/30 transition-all hover:scale-[1.04]">
                            <Undo2 className="h-3.5 w-3.5" /> Revert
                          </button>
                        ) : (
                          <span className="text-[10px] text-muted-foreground italic">locked</span>
                        )}
                      </td>
                    </tr>
                  );})}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {revertTarget && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-2xl border-2 border-rose-500/40 bg-card shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
            <div className="relative bg-gradient-to-r from-rose-500 via-red-500 to-orange-500 p-4 text-white">
              <div className="absolute -top-8 -right-8 h-24 w-24 rounded-full bg-white/20 blur-2xl" />
              <div className="relative flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-white/20 grid place-items-center backdrop-blur">
                  <Undo2 className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg leading-tight">Revert Gate In?</h3>
                  <p className="text-xs text-white/90">Use only if this vehicle was gated in by mistake.</p>
                </div>
                <button onClick={() => setRevertTarget(null)} className="p-1 rounded hover:bg-white/20">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="p-5 space-y-4">
              <div className="rounded-xl border-2 border-rose-500/20 bg-rose-500/5 p-3 text-sm">
                Are you sure to send vehicle <b className="text-rose-600 dark:text-rose-300">{revertTarget.vehicle}</b> back?
                <div className="text-xs text-muted-foreground mt-1 font-mono">Token · {revertTarget.token}</div>
              </div>
              <div>
                <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Reason for revert <span className="text-rose-500">*</span>
                </label>
                <textarea
                  value={revertReason}
                  onChange={(e) => setRevertReason(e.target.value)}
                  rows={3}
                  autoFocus
                  placeholder="Type the reason for reverting this gate-in…"
                  className="mt-1 w-full p-2.5 rounded-lg border-2 border-rose-500/30 bg-background focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none transition-all text-sm"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  onClick={() => setRevertTarget(null)}
                  disabled={reverting}
                  className="h-10 px-4 rounded-lg border-2 border-border hover:bg-muted text-sm font-medium transition-colors disabled:opacity-50">
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    if (!revertReason.trim()) { toast.error("Please enter a reason"); return; }
                    if (!revertTarget) return;
                    setReverting(true);
                    try {
                      await revertGateIn(revertTarget.token, revertReason.trim());
                      toast.success(`Vehicle ${revertTarget.vehicle} reverted`);
                      setRevertTarget(null);
                      setRevertReason("");
                    } catch { toast.error("Revert failed"); }
                    finally { setReverting(false); }
                  }}
                  disabled={reverting || !revertReason.trim()}
                  className="h-10 px-4 rounded-lg bg-gradient-to-r from-rose-500 to-red-500 hover:from-rose-600 hover:to-red-600 text-white text-sm font-bold shadow-md shadow-rose-500/40 transition-all hover:scale-[1.02] disabled:opacity-50 disabled:hover:scale-100 inline-flex items-center gap-1.5">
                  <Undo2 className="h-4 w-4" /> {reverting ? "Reverting…" : "Yes, revert"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
