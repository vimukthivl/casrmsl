import { createFileRoute } from "@tanstack/react-router";
import { useApp, heldUpCost, heldUpHours, rateForVehicle } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { AppFooter } from "@/components/AppFooter";
import { UnloadCapacityPanel } from "@/components/UnloadCapacityPanel";
import { AnimatedNumber } from "@/components/AnimatedNumber";
import { DAYS } from "@/lib/types";
import {
  AlertTriangle,
  TrendingUp,
  Truck,
  CheckCircle2,
  Clock,
  DollarSign,
  Leaf,
  Activity,
  Radio,
  Gauge,
  ClipboardList,
  TrendingDown,
  ShieldCheck,
  Building2,
} from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Legend,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts";
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Logistics Dashboard — Casualline Logistics 360" }, { name: "description", content: "Casualline logistics performance, vehicle movements and held-up costs." },
      { property: "og:title", content: "Logistics Dashboard — Casualline Logistics 360" },
      { property: "og:description", content: "Casualline logistics performance, vehicle movements and held-up costs." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: () => (
    <RequireAccess path="/dashboard">
      <Dashboard />
      <AppFooter />
    </RequireAccess>
  ),
});

const ARRIVAL_COLORS: Record<string, string> = {
  "On-Time": "#16a34a",
  Early: "#0ea5e9",
  Delayed: "#f59e0b",
  Unscheduled: "#ef4444",
};

const BAY_ORDER = ["BAY-01", "BAY-02", "BAY-03"] as const;
// Distinct premium bay themes: Electric Cyan / Neon Mint / Deep Violet
const BAY_ACCENT: Record<string, string> = {
  "BAY-01": "#06b6d4", // electric cyan
  "BAY-02": "#22c55e", // neon mint / jade
  "BAY-03": "#8b5cf6", // deep violet
};

const TREND_DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function buildEfficiencyTrend(
  vehicles: { in_time: string; current_status: string }[],
  _schedules: unknown[],
): { day: string; efficiency: number }[] {
  const today = new Date();
  const out: { day: string; efficiency: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    d.setHours(0, 0, 0, 0);
    const next = new Date(d);
    next.setDate(d.getDate() + 1);
    const dayVehicles = vehicles.filter((v) => {
      const t = new Date(v.in_time).getTime();
      return t >= d.getTime() && t < next.getTime();
    });
    const done = dayVehicles.filter(
      (v) => v.current_status === "Completed" || v.current_status === "Departed",
    ).length;
    const total = dayVehicles.length;
    const eff = total > 0 ? Math.round((done / total) * 100) : 0;
    out.push({ day: TREND_DAY_LABELS[d.getDay()], efficiency: eff });
  }
  return out;
}

const CATEGORY_GROUPS: { key: "Fabric" | "Trims"; label: string; material: string; grad: string; ring: string; badge: string }[] = [
  { key: "Fabric", label: "Fabric", material: "Fabric", grad: "from-amber-500 to-orange-600", ring: "border-amber-400/60", badge: "from-amber-500 to-orange-600" },
  { key: "Trims", label: "Trims", material: "Trims", grad: "from-fuchsia-500 to-purple-700", ring: "border-fuchsia-400/60", badge: "from-fuchsia-500 to-purple-700" },
];

function Dashboard() {
  const { state } = useApp();
  const today = new Date();
  const isToday = (iso: string) => new Date(iso).toDateString() === today.toDateString();

  // All-vehicles view drives the rest of the dashboard; per-category slices are computed below.
  const catVehicles = state.vehicles;
  const catSchedules = state.schedules;


  // 10-second pulse loop: bump this key to smoothly re-animate charts & rings.
  const [pulseKey, setPulseKey] = useState(0);
  const [pendingSuppliers, setPendingSuppliers] = useState<{ supplier: string; count: number }[]>([]);
  useEffect(() => {
    const t = setInterval(() => setPulseKey((k) => k + 1), 10000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    let cancelled = false;
    const loadPendingSuppliers = async () => {
      const { data } = await supabase
        .from("pending_invoices")
        .select("supplier")
        .neq("status", "Completed");
      if (cancelled) return;
      const totals = new Map<string, number>();
      (data ?? []).forEach((row) => {
        const supplier = row.supplier.trim() || "Supplier not entered";
        totals.set(supplier, (totals.get(supplier) ?? 0) + 1);
      });
      setPendingSuppliers(
        Array.from(totals, ([supplier, count]) => ({ supplier, count })).sort((a, b) => b.count - a.count),
      );
    };
    loadPendingSuppliers();
    const channel = supabase
      .channel("dashboard_pending_invoices_rt")
      .on("postgres_changes", { event: "*", schema: "public", table: "pending_invoices" }, loadPendingSuppliers)
      .subscribe();
    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, []);

  // TV auto-scroll: while the user is idle (no input for 10s), smoothly cycle
  // through 3 sections of the page (top → middle → bottom → top) so every
  // section is visible on a large TV without manual interaction.
  useEffect(() => {
    if (typeof window === "undefined") return;
    let idleTimer: ReturnType<typeof setTimeout> | null = null;
    let loopTimer: ReturnType<typeof setInterval> | null = null;
    let step = 0; // 0=top, 1=middle, 2=bottom
    let active = false;

    const stopLoop = () => {
      if (loopTimer) { clearInterval(loopTimer); loopTimer = null; }
      active = false;
    };
    const startLoop = () => {
      if (active) return;
      active = true;
      const tick = () => {
        const maxY = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
        if (maxY < 20) return;
        const targetY = step === 0 ? 0 : step === 1 ? Math.round(maxY / 2) : maxY;
        window.scrollTo({ top: targetY, behavior: "smooth" });
        step = (step + 1) % 3;
      };
      tick();
      loopTimer = setInterval(tick, 10000);
    };
    const scheduleIdle = () => {
      if (idleTimer) clearTimeout(idleTimer);
      idleTimer = setTimeout(startLoop, 10000);
    };
    const onUserActivity = (e: Event) => {
      if (e.type === "scroll" && active) return;
      stopLoop();
      scheduleIdle();
    };

    const events = ["mousemove", "mousedown", "keydown", "touchstart", "wheel", "scroll"];
    events.forEach((ev) => window.addEventListener(ev, onUserActivity, { passive: true }));
    scheduleIdle();

    return () => {
      if (idleTimer) clearTimeout(idleTimer);
      stopLoop();
      events.forEach((ev) => window.removeEventListener(ev, onUserActivity));
    };
  }, []);

  // Shift-wise picker metrics (Shift A: 06-14, Shift B: 14-22).
  // "Yesterday" skips Sunday: if today is Monday, compare against Saturday.
  const [shiftMetrics, setShiftMetrics] = useState<{
    a: { today: number; yesterday: number };
    b: { today: number; yesterday: number };
    yesterdayTotal: number;
    pastWeekTotal: number;
  }>({ a: { today: 0, yesterday: 0 }, b: { today: 0, yesterday: 0 }, yesterdayTotal: 0, pastWeekTotal: 0 });
  useEffect(() => {
    let cancel = false;
    (async () => {
      const now = new Date();
      const startOfDay = (d: Date, h = 0) => {
        const x = new Date(d); x.setHours(h, 0, 0, 0); return x;
      };
      const todayStart = startOfDay(now);
      // Yesterday: skip Sunday. Monday (getDay()===1) → -2 days (Saturday); otherwise -1.
      const yesterday = new Date(todayStart);
      yesterday.setDate(todayStart.getDate() - (todayStart.getDay() === 1 ? 2 : 1));
      const yesterdayEnd = new Date(yesterday); yesterdayEnd.setDate(yesterday.getDate() + 1);
      // Past week: previous ISO week Monday 00:00 → Sunday 24:00
      const dow = todayStart.getDay(); // 0=Sun..6=Sat
      const daysSinceMon = dow === 0 ? 6 : dow - 1;
      const thisWeekMon = new Date(todayStart); thisWeekMon.setDate(todayStart.getDate() - daysSinceMon);
      const pastWeekStart = new Date(thisWeekMon); pastWeekStart.setDate(thisWeekMon.getDate() - 7);
      const pastWeekEnd = new Date(thisWeekMon);
      const win = (base: Date, from: number, to: number) => ({
        from: startOfDay(base, from).toISOString(),
        to: startOfDay(base, to).toISOString(),
      });
      const wins = {
        aToday: win(todayStart, 6, 14),
        bToday: win(todayStart, 14, 22),
        aYest: win(yesterday, 6, 14),
        bYest: win(yesterday, 14, 22),
      };
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const sb = supabase as any;
      const count = async (from: string, to: string) => {
        const r = await sb.from("picker_achievements").select("id", { count: "exact", head: true }).gte("picked_at", from).lt("picked_at", to);
        return r.count ?? 0;
      };
      const [aT, bT, aY, bY, yTot, wTot] = await Promise.all([
        count(wins.aToday.from, wins.aToday.to),
        count(wins.bToday.from, wins.bToday.to),
        count(wins.aYest.from, wins.aYest.to),
        count(wins.bYest.from, wins.bYest.to),
        count(yesterday.toISOString(), yesterdayEnd.toISOString()),
        count(pastWeekStart.toISOString(), pastWeekEnd.toISOString()),
      ]);
      if (cancel) return;
      setShiftMetrics({ a: { today: aT, yesterday: aY }, b: { today: bT, yesterday: bY }, yesterdayTotal: yTot, pastWeekTotal: wTot });
    })();
    return () => { cancel = true; };
  }, [pulseKey]);

  // TV auto-scroll: smooth glide down, pause, snap back up, repeat.
  useEffect(() => {
    const el = document.getElementById("tv-scroll");
    if (!el) return;
    let phase: "down" | "up" = "down";
    const tick = () => {
      const max = el.scrollHeight - el.clientHeight;
      if (max <= 4) return;
      if (phase === "down") {
        el.scrollTo({ top: max, behavior: "smooth" });
        phase = "up";
      } else {
        el.scrollTo({ top: 0, behavior: "smooth" });
        phase = "down";
      }
    };
    const iv = setInterval(tick, 8000);
    return () => clearInterval(iv);
  }, []);




  const day = today.getDay();
  const todayKey = day >= 1 && day <= 6 ? DAYS[day - 1] : null;
  const totalScheduledToday = todayKey
    ? catSchedules.reduce((sum, s) => sum + (s.days_data[todayKey] || 0), 0)
    : 0;

  const checkedInToday = catVehicles.filter((v) => isToday(v.in_time));
  const completedToday = catVehicles.filter(
    (v) => (v.current_status === "Completed" || v.current_status === "Departed") && isToday(v.in_time)
  );
  const heldUp = catVehicles.filter((v) => v.is_held_up);
  const rate = state.settings.held_up_cost_rate;
  const heldUpCostLive = heldUp.reduce((s, v) => s + heldUpCost(v, rateForVehicle(v, state.heldUpRates, rate)), 0);

  // Today's roll/box throughput (from completed vehicles today)
  const todayRolls = completedToday.reduce((s, v) => s + (Number(v.roll_qty) || 0), 0);
  const todayBoxes = completedToday.reduce((s, v) => s + (Number(v.box_qty) || 0), 0);

  // Weekly (Mon–Sat) roll/box breakdown from checked-in vehicles
  const weekStart = (() => {
    const d = new Date(today);
    d.setHours(0, 0, 0, 0);
    const dow = d.getDay(); // 0=Sun..6=Sat
    const diff = dow === 0 ? -6 : 1 - dow; // back to Monday
    d.setDate(d.getDate() + diff);
    return d;
  })();
  const weekEnd = new Date(weekStart);
  weekEnd.setDate(weekStart.getDate() + 6);
  weekEnd.setHours(23, 59, 59, 999);
  const inThisWeek = (iso: string) => {
    const t = new Date(iso).getTime();
    return t >= weekStart.getTime() && t <= weekEnd.getTime();
  };
  const weekVehicles = catVehicles.filter((v) => inThisWeek(v.in_time));
  const weekRolls = weekVehicles.reduce((s, v) => s + (Number(v.roll_qty) || 0), 0);
  const weekBoxes = weekVehicles.reduce((s, v) => s + (Number(v.box_qty) || 0), 0);

  // Unloading production analytics — sums Roll/Box qty by unload_end_time window.
  const unloadingBreakdown = useMemo(() => {
    const now = new Date();
    const dayStart = new Date(now); dayStart.setHours(0, 0, 0, 0);
    const at = (base: Date, h: number) => { const x = new Date(base); x.setHours(h, 0, 0, 0); return x; };
    const s1From = at(dayStart, 6).getTime(), s1To = at(dayStart, 14).getTime();
    const s2From = at(dayStart, 14).getTime(), s2To = at(dayStart, 22).getTime();
    // Yesterday: if Monday, go back to Saturday (skip Sunday)
    const yStart = new Date(dayStart);
    yStart.setDate(dayStart.getDate() - (dayStart.getDay() === 1 ? 2 : 1));
    const yEnd = new Date(yStart); yEnd.setDate(yStart.getDate() + 1);
    const yFrom = yStart.getTime(), yTo = yEnd.getTime();
    const acc = {
      s1: { box: 0, roll: 0 },
      s2: { box: 0, roll: 0 },
      yest: { box: 0, roll: 0 },
    };
    for (const v of state.vehicles) {
      if (!v.unload_end_time) continue;
      const t = new Date(v.unload_end_time).getTime();
      const box = Number(v.box_qty) || 0;
      const roll = Number(v.roll_qty) || 0;
      if (t >= s1From && t < s1To) { acc.s1.box += box; acc.s1.roll += roll; }
      if (t >= s2From && t < s2To) { acc.s2.box += box; acc.s2.roll += roll; }
      if (t >= yFrom && t < yTo) { acc.yest.box += box; acc.yest.roll += roll; }
    }
    return acc;
  }, [state.vehicles, pulseKey]);

  // PCU: pending vs completed schedules for today
  const pcuPct = totalScheduledToday
    ? Math.min(100, Math.round((completedToday.length / totalScheduledToday) * 100))
    : 0;

  // Bay distribution — includes critical flag (held-up >24h OR Hold status in bay)
  const bayCounts = BAY_ORDER.map((b) => {
    const vs = state.vehicles.filter(
      (v) => v.bay_id === b && (v.current_status === "Assigned" || v.current_status === "Unloading" || v.current_status === "Hold")
    );
    const critical = vs.some((v) => v.is_held_up || v.current_status === "Hold");
    return {
      bay: b,
      count: vs.length,
      active: vs.some((v) => v.current_status === "Unloading"),
      critical,
    };
  });


  // Green board summary (this month)
  const [gb, setGb] = useState<{ redCells: number; totalCells: number }>({ redCells: 0, totalCells: 0 });
  useEffect(() => {
    let cancel = false;
    (async () => {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth();
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const first = `${year}-${String(month + 1).padStart(2, "0")}-01`;
      const last = `${year}-${String(month + 1).padStart(2, "0")}-${String(daysInMonth).padStart(2, "0")}`;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const sb = supabase as any;
      const [concerns, entries] = await Promise.all([
        sb.from("green_board_concerns").select("id", { count: "exact", head: true }),
        sb.from("green_board_entries").select("id", { count: "exact", head: true }).gte("entry_date", first).lte("entry_date", last),
      ]);
      if (cancel) return;
      const concernCount = concerns.count ?? 0;
      setGb({ redCells: entries.count ?? 0, totalCells: concernCount * daysInMonth });
    })();
    return () => {
      cancel = true;
    };
  }, [state.vehicles.length]);

  // Green board 7-day trend by area
  type GbTrendPoint = { day: string; grn: number; kanban: number; picking: number; fabric: number; trims: number };
  const [gbTrend, setGbTrend] = useState<GbTrendPoint[]>([]);
  const [gbTick, setGbTick] = useState(0);
  useEffect(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sb = supabase as any;
    const ch = sb
      .channel("rt-dash-gb")
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_entries" }, () => setGbTick((t) => t + 1))
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_concerns" }, () => setGbTick((t) => t + 1))
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, []);
  useEffect(() => {
    let cancel = false;
    (async () => {
      const days: { key: string; label: string }[] = [];
      const today = new Date();
      for (let i = 6; i >= 0; i--) {
        const d = new Date(today);
        d.setDate(today.getDate() - i);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
        days.push({ key, label: TREND_DAY_LABELS[d.getDay()] });
      }
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const sb2 = supabase as any;
      // Always load concern -> board_key map so legacy rows (no board_key on entry) still count.
      const [entriesRes, concernsRes] = await Promise.all([
        sb2
          .from("green_board_entries")
          .select("concern_id, entry_date, board_key")
          .gte("entry_date", days[0].key)
          .lte("entry_date", days[6].key),
        sb2.from("green_board_concerns").select("id, board_key"),
      ]);
      const boardByConcern = new Map<string, string>();
      (concernsRes.data ?? []).forEach((c: { id: string; board_key: string }) => boardByConcern.set(c.id, c.board_key));
      if (cancel) return;
      const buckets: Record<string, GbTrendPoint> = {};
      days.forEach((d) => { buckets[d.key] = { day: d.label, grn: 0, kanban: 0, picking: 0, fabric: 0, trims: 0 }; });
      // Count distinct concern×date cells per board (a red cell), not raw note count.
      const seen = new Set<string>();
      (entriesRes.data ?? []).forEach((e: { concern_id: string; entry_date: string; board_key?: string | null }) => {
        const bucket = buckets[e.entry_date];
        const board = e.board_key || boardByConcern.get(e.concern_id);
        if (!bucket || !board) return;
        const k = `${e.entry_date}|${board}|${e.concern_id}`;
        if (seen.has(k)) return;
        seen.add(k);
        if (board in bucket) (bucket as unknown as Record<string, number>)[board] += 1;
      });
      setGbTrend(days.map((d) => buckets[d.key]));

    })();
    return () => { cancel = true; };
  }, [pulseKey, gbTick]);

  // Cycle Counting live metrics
  const [cycleMetrics, setCycleMetrics] = useState<{
    varianceCount: number;
    highestCat: string;
    highestQty: number;
    bestCat: string;
    bestMatches: number;
  }>({ varianceCount: 0, highestCat: "None", highestQty: 0, bestCat: "None", bestMatches: 0 });
  useEffect(() => {
    let cancel = false;
    (async () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const sb = supabase as any;
      const { data } = await sb
        .from("cycle_count_logs")
        .select("material_code, category, grand_qty, available_qty");
      if (cancel || !data) return;
      const varianceMaterials = new Set<string>();
      const varianceByCat = new Map<string, number>();
      const matchByCat = new Map<string, number>();
      for (const r of data as { material_code: string; category: string; grand_qty: number; available_qty: number }[]) {
        const diff = (Number(r.grand_qty) || 0) - (Number(r.available_qty) || 0);
        if (diff !== 0) {
          varianceMaterials.add(r.material_code);
          varianceByCat.set(r.category, (varianceByCat.get(r.category) || 0) + Math.abs(diff));
        } else {
          matchByCat.set(r.category, (matchByCat.get(r.category) || 0) + 1);
        }
      }
      let hCat = "None", hQty = 0;
      varianceByCat.forEach((v, k) => { if (v > hQty) { hQty = v; hCat = k; } });
      let bCat = "None", bMatches = 0;
      matchByCat.forEach((v, k) => { if (v > bMatches) { bMatches = v; bCat = k; } });
      setCycleMetrics({
        varianceCount: varianceMaterials.size,
        highestCat: hCat,
        highestQty: hQty,
        bestCat: bCat,
        bestMatches: bMatches,
      });
    })();
    return () => { cancel = true; };
  }, [pulseKey]);

  const greenPct = gb.totalCells > 0 ? Math.round(((gb.totalCells - gb.redCells) / gb.totalCells) * 100) : 100;


  const arrivalCounts = checkedInToday.reduce<Record<string, number>>((acc, v) => {
    acc[v.arrival_status] = (acc[v.arrival_status] || 0) + 1;
    return acc;
  }, {});
  const arrivalData = ["On-Time", "Early", "Delayed", "Unscheduled"].map((k) => ({
    name: k,
    value: arrivalCounts[k] || 0,
  }));

  const active = state.vehicles
    .filter((v) => v.current_status === "Waiting" || v.current_status === "Unloading")
    .sort((a, b) => new Date(a.in_time).getTime() - new Date(b.in_time).getTime());

  const holdVehicles = state.vehicles.filter((v) => v.current_status === "Hold");
  const portalPending = holdVehicles.filter((v) => v.hold_reason === "Portal Pending");
  const otherHolds = holdVehicles.filter((v) => v.hold_reason === "Other");

  const vendorRows = (() => {
    const map = new Map<string, { Waiting: number; Unloading: number; Hold: number; qty: number }>();
    state.vehicles
      .filter((v) => v.current_status === "Waiting" || v.current_status === "Unloading" || v.current_status === "Hold")
      .forEach((v) => {
        const key = v.vendor_name || "Unknown";
        const rec = map.get(key) || { Waiting: 0, Unloading: 0, Hold: 0, qty: 0 };
        rec[v.current_status as "Waiting" | "Unloading" | "Hold"] += 1;
        rec.qty += Number(v.quantity_brought) || 0;
        map.set(key, rec);
      });
    return Array.from(map.entries())
      .map(([vendor, r]) => ({ vendor, ...r, total: r.Waiting + r.Unloading + r.Hold }))
      .sort((a, b) => b.total - a.total);
  })();

  return (
    <div className="h-full flex flex-col overflow-hidden bg-gradient-to-br from-slate-300 via-slate-400 to-slate-700 animate-fade-in">

      {/* ============ LOCKED TOP HORIZON ============ */}
      <div className="shrink-0 px-6 pt-4 pb-3 space-y-3 border-b border-slate-500/30 bg-slate-300/60 backdrop-blur">
        <div className="flex items-end justify-between flex-wrap gap-3">
          <div>
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-muted-foreground">
              <Activity className="h-3 w-3 text-emerald-500 animate-pulse" />
              Real-time control room · pulse every 10s
            </div>
            <h1 className="text-2xl md:text-3xl font-semibold mt-0.5 tracking-tight headline-shadow bg-gradient-to-r from-sky-500 via-indigo-500 to-violet-500 bg-clip-text text-transparent">
              MAS Casualline Logistics 360
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <LiveClock />
          </div>
        </div>

        {/* Category-grouped core metrics — each category wraps its own set of cards */}
        <div key={`core-${pulseKey}`} className="space-y-3">
          {CATEGORY_GROUPS.map((g) => {
            const gv = state.vehicles.filter((v) => v.material_type === g.material);
            const gs = state.schedules.filter((s) => s.material_type === g.material);
            const gScheduled = todayKey ? gs.reduce((sum, s) => sum + (s.days_data[todayKey] || 0), 0) : 0;
            const gChecked = gv.filter((v) => isToday(v.in_time)).length;
            const gCompleted = gv.filter((v) => (v.current_status === "Completed" || v.current_status === "Departed") && isToday(v.in_time)).length;
            const gHeld = gv.filter((v) => v.is_held_up).length;
            return (
              <div key={g.key} className={`relative rounded-2xl border-2 ${g.ring} bg-white/70 dark:bg-slate-900/40 backdrop-blur px-3 pt-5 pb-3 shadow-sm`}>
                <div className={`absolute -top-3 left-4 px-3 py-0.5 rounded-full bg-gradient-to-r ${g.badge} text-white text-[11px] font-black uppercase tracking-widest shadow-md`}>
                  {g.label}
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <CoreMetric label="Scheduled Today" value={gScheduled} icon={TrendingUp} tone="neonBlue" />
                  <CoreMetric label="Checked-In Today" value={gChecked} icon={Truck} tone="neonAmber" />
                  <CoreMetric label="Completed Today" value={gCompleted} icon={CheckCircle2} tone="emerald" />
                  <CoreMetric label="Held Up (>24h)" value={gHeld} icon={AlertTriangle} tone="crimson" pulsing={gHeld > 0} />
                </div>
              </div>
            );
          })}
        </div>


        {/* Row 2 — Held-up delay cost */}
        <div key={`chrono-${pulseKey}`} className="grid grid-cols-1 gap-3">
          <HeldUpCostBigCard cost={heldUpCostLive} count={heldUp.length} rate={rate} />
        </div>


        {/* Row 3 — Unloading production analytics (Box / Roll qty) */}
        <div key={`unload-${pulseKey}`} className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <TodayUnloadingSplitCard s1={unloadingBreakdown.s1} s2={unloadingBreakdown.s2} />
          </div>
          <YesterdayUnloadingCard box={unloadingBreakdown.yest.box} roll={unloadingBreakdown.yest.roll} />
        </div>

        {/* Cycle Counting cards removed per request */}
      </div>

      {/* ============ AUTO-SCROLLING MATRIX ============ */}
      <div
        id="tv-scroll"
        className="auto-scrolling-container flex-1 overflow-hidden px-6 py-4 space-y-5"
        style={{ scrollbarWidth: "none" }}
      >
        {heldUp.length > 0 && (
          <div className="rounded-xl border border-destructive/40 bg-gradient-to-r from-destructive/15 via-destructive/5 to-transparent p-3 flex items-start gap-3 animate-fade-in">
            <div className="relative">
              <AlertTriangle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <span className="absolute inset-0 rounded-full bg-destructive/40 animate-ping" />
            </div>
            <div>
              <div className="font-semibold text-destructive text-sm">
                Critical: {heldUp.length} vehicle(s) held up over 24 hours
              </div>
              <div className="text-xs mt-1">
                {heldUp.map((v) => `${v.token_no} (${v.vehicle_number})`).join(", ")}
              </div>
            </div>
          </div>
        )}

        {/* Hero widgets — Held-up + Bay overview */}
        <div key={`hero-${pulseKey}`} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <HeldupCard count={heldUp.length} cost={heldUpCostLive} rate={rate} />
          <BayOverviewCard bays={bayCounts} />
        </div>

        <SupplierPendingCard suppliers={pendingSuppliers} />











      <CostAnalytics />

      <UnloadCapacityPanel />

      </div>
    </div>
  );

}

function SupplierPendingCard({ suppliers }: { suppliers: { supplier: string; count: number }[] }) {
  const total = suppliers.reduce((sum, item) => sum + item.count, 0);
  return (
    <section className="rounded-xl border bg-card p-5 shadow-sm">
      <div className="flex items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase text-primary">
            <Building2 className="h-4 w-4" /> Pending Invoices by Supplier
          </div>
          <p className="mt-1 text-sm text-muted-foreground">Live supplier backlog</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold tabular-nums"><AnimatedNumber value={total} /></div>
          <div className="text-xs text-muted-foreground">total pending</div>
        </div>
      </div>
      {suppliers.length > 0 ? (
        <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {suppliers.slice(0, 8).map((item, index) => (
            <div key={item.supplier} className={`flex min-w-0 items-center justify-between gap-3 rounded-lg border p-3 ${index === 0 ? "border-destructive/60 bg-destructive/10 text-destructive shadow-sm" : "bg-muted/40"}`}>
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold" title={item.supplier}>{item.supplier}</div>
                <div className="text-[10px] text-muted-foreground">{index === 0 ? "Highest pending supplier" : "Pending invoices"}</div>
              </div>
              <span className={`grid h-9 min-w-9 place-items-center rounded-full px-2 text-sm font-bold ${index === 0 ? "bg-destructive text-destructive-foreground" : "bg-background"}`}>
                {item.count}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-4 rounded-lg border border-dashed p-5 text-center text-sm text-muted-foreground">No pending supplier invoices</div>
      )}
    </section>
  );
}


function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="rounded-lg border bg-card/70 backdrop-blur px-4 py-2 text-right shadow-sm">
      <div className="text-2xl font-mono font-semibold tracking-tight tabular-nums">
        {now.toLocaleTimeString(undefined, { hour12: false })}
      </div>
      <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Live</div>
    </div>
  );
}

/* ------------ Hero widgets ------------ */

function ProgressRing({ pct, color, size = 96, stroke = 10, children }: { pct: number; color: string; size?: number; stroke?: number; children?: React.ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (Math.max(0, Math.min(100, pct)) / 100) * c;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="currentColor" strokeOpacity={0.12} strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={color}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={off}
          style={{ transition: "stroke-dashoffset 900ms cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

function PcuHubCard({
  total,
  completed,
  pct,
  todayRolls,
  todayBoxes,
  weekRolls,
  weekBoxes,
}: {
  total: number;
  completed: number;
  pct: number;
  todayRolls: number;
  todayBoxes: number;
  weekRolls: number;
  weekBoxes: number;
}) {
  const pending = Math.max(0, total - completed);
  return (
    <div className="relative overflow-hidden rounded-xl border border-emerald-500/30 bg-gradient-to-br from-emerald-500/15 via-card to-amber-500/10 p-5 shadow-sm hover:shadow-xl transition-all animate-fade-in">
      <div className="absolute -top-8 -right-8 h-28 w-28 rounded-full bg-emerald-500/25 blur-3xl" />
      <div className="absolute -bottom-8 -left-8 h-24 w-24 rounded-full bg-amber-500/20 blur-3xl" />
      <div className="flex items-start justify-between relative">
        <div>
          <div className="text-[11px] uppercase tracking-widest font-semibold bg-gradient-to-r from-emerald-500 via-sky-500 to-violet-500 bg-clip-text text-transparent">
            PCU Data Hub
          </div>
          <div className="text-sm text-muted-foreground mt-1">Today's throughput</div>
          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-4xl font-bold tabular-nums text-emerald-600 dark:text-emerald-400 drop-shadow-[0_0_10px_rgba(16,185,129,0.35)]">
              <AnimatedNumber value={completed} />
            </span>
            <span className="text-lg text-muted-foreground font-medium">/ {total}</span>
          </div>
          <div className="mt-2 flex items-center gap-2 text-xs flex-wrap">
            <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 font-semibold">
              ✓ Completed <AnimatedNumber value={completed} />
            </span>
            <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-700 dark:text-amber-300 font-semibold shadow-[0_0_10px_rgba(245,158,11,0.35)]">
              ⏳ Pending <AnimatedNumber value={pending} />
            </span>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
            <div className="rounded-lg border border-sky-500/25 bg-sky-500/10 px-2 py-1.5">
              <div className="text-[9px] uppercase tracking-wider text-sky-600 dark:text-sky-300 font-semibold">Today</div>
              <div className="mt-0.5 flex items-baseline gap-2 tabular-nums">
                <span className="font-bold text-sky-700 dark:text-sky-200"><AnimatedNumber value={todayRolls} /></span>
                <span className="text-[10px] text-muted-foreground">rolls</span>
                <span className="font-bold text-sky-700 dark:text-sky-200"><AnimatedNumber value={todayBoxes} /></span>
                <span className="text-[10px] text-muted-foreground">boxes</span>
              </div>
            </div>
            <div className="rounded-lg border border-violet-500/25 bg-violet-500/10 px-2 py-1.5">
              <div className="text-[9px] uppercase tracking-wider text-violet-600 dark:text-violet-300 font-semibold">This Week</div>
              <div className="mt-0.5 flex items-baseline gap-2 tabular-nums">
                <span className="font-bold text-violet-700 dark:text-violet-200"><AnimatedNumber value={weekRolls} /></span>
                <span className="text-[10px] text-muted-foreground">rolls</span>
                <span className="font-bold text-violet-700 dark:text-violet-200"><AnimatedNumber value={weekBoxes} /></span>
                <span className="text-[10px] text-muted-foreground">boxes</span>
              </div>
            </div>
          </div>
        </div>
        <div className="relative">
          <div className="absolute inset-0 rounded-full blur-xl bg-gradient-to-br from-emerald-500/40 via-sky-500/30 to-violet-500/40" />
          <ProgressRing pct={pct} color="url(#pcuHubGrad)" size={104} stroke={11}>
            <div className="text-center">
              <div className="text-lg font-bold tabular-nums bg-gradient-to-r from-emerald-500 via-sky-500 to-violet-500 bg-clip-text text-transparent">
                <AnimatedNumber value={pct} />%
              </div>
              <div className="text-[9px] uppercase text-muted-foreground">efficiency</div>
            </div>
          </ProgressRing>
          <svg width="0" height="0" style={{ position: "absolute" }}>
            <defs>
              <linearGradient id="pcuHubGrad" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="55%" stopColor="#0ea5e9" />
                <stop offset="100%" stopColor="#8b5cf6" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
    </div>
  );
}


function GreenBoardCard({ greenPct, redCells, totalCells }: { greenPct: number; redCells: number; totalCells: number }) {
  const color = greenPct >= 90 ? "#16a34a" : greenPct >= 70 ? "#f59e0b" : "#ef4444";
  return (
    <div className="relative overflow-hidden rounded-xl border bg-gradient-to-br from-emerald-500/10 via-card to-card p-5 shadow-sm hover:shadow-lg transition-all animate-fade-in">
      <div className="absolute -top-6 -right-6 h-24 w-24 rounded-full bg-emerald-500/20 blur-2xl" />
      <div className="flex items-start justify-between">
        <div>
          <div className="text-[11px] uppercase tracking-widest text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
            <Leaf className="h-3 w-3" /> Green Board
          </div>
          <div className="text-sm text-muted-foreground mt-1">This month health</div>
          <div className="mt-4 text-4xl font-bold tabular-nums text-emerald-600 dark:text-emerald-400">
            <AnimatedNumber value={greenPct} />%
          </div>
          <div className="text-xs text-muted-foreground mt-1">
            <AnimatedNumber value={redCells} /> red alerts · {totalCells} cells
          </div>
        </div>
        <ProgressRing pct={greenPct} color={color}>
          <Leaf className="h-6 w-6 text-emerald-500" />
        </ProgressRing>
      </div>
    </div>
  );
}

function HeldupCard({ count, cost, rate }: { count: number; cost: number; rate: number }) {
  const critical = count > 0;
  return (
    <div className={`relative overflow-hidden rounded-xl border p-5 shadow-sm hover:shadow-xl transition-all animate-fade-in ${
      critical
        ? "border-rose-500/60 bg-gradient-to-br from-rose-600/20 via-rose-500/5 to-card"
        : "bg-gradient-to-br from-muted/40 via-card to-card"
    }`}>
      {critical && (
        <>
          <div className="absolute -top-8 -right-8 h-32 w-32 rounded-full bg-rose-500/40 blur-3xl animate-pulse" />
          <div className="absolute inset-0 pointer-events-none rounded-xl ring-1 ring-rose-500/40 shadow-[inset_0_0_30px_rgba(244,63,94,0.25)]" />
        </>
      )}
      <div className="flex items-start justify-between relative">
        <div>
          <div className={`text-[11px] uppercase tracking-widest font-semibold flex items-center gap-1 ${critical ? "text-rose-500 drop-shadow-[0_0_6px_rgba(244,63,94,0.7)]" : "text-muted-foreground"}`}>
            <AlertTriangle className="h-3 w-3" /> Held-up Control
          </div>
          <div className="text-sm text-muted-foreground mt-1">Critical accrual</div>
          <div className={`mt-4 text-5xl font-bold tabular-nums ${critical ? "text-rose-500 drop-shadow-[0_0_14px_rgba(244,63,94,0.65)]" : ""}`}>
            <AnimatedNumber value={count} />
          </div>
          <div className="text-xs text-muted-foreground mt-1">vehicles beyond 24h SLA</div>
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">Accrued cost</div>
          {critical ? (
            <div className="mt-1 inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-gradient-to-r from-rose-600 to-red-500 text-white font-bold tabular-nums shadow-[0_0_14px_rgba(244,63,94,0.7)] animate-neon-pulse">
              Rs. <AnimatedNumber value={cost} />
            </div>
          ) : (
            <div className="text-xl font-bold tabular-nums mt-1">
              Rs. <AnimatedNumber value={cost} />
            </div>
          )}
          <div className="text-[10px] text-muted-foreground mt-0.5">per-vehicle-size rate</div>
        </div>
      </div>
    </div>
  );
}


function BayOverviewCard({ bays }: { bays: { bay: string; count: number; active: boolean; critical: boolean }[] }) {
  const total = bays.reduce((s, b) => s + b.count, 0);
  const anyCritical = bays.some((b) => b.critical);
  return (
    <div className={`relative overflow-hidden rounded-xl border p-5 shadow-sm hover:shadow-lg transition-all animate-fade-in ${
      anyCritical
        ? "border-rose-500/70 bg-gradient-to-br from-rose-600/15 via-card to-card"
        : "bg-gradient-to-br from-violet-500/10 via-card to-card"
    }`}>
      <div className={`absolute -top-6 -right-6 h-24 w-24 rounded-full blur-2xl ${anyCritical ? "bg-rose-500/30 animate-pulse" : "bg-violet-500/20"}`} />
      <div className="flex items-center justify-between">
        <div className={`text-[11px] uppercase tracking-widest font-semibold flex items-center gap-1 ${anyCritical ? "text-rose-500 drop-shadow-[0_0_6px_rgba(244,63,94,0.7)]" : "text-violet-600 dark:text-violet-400"}`}>
          <Radio className="h-3 w-3" /> TV Display · Bays
        </div>
        <div className="text-xs text-muted-foreground">{total} in bays</div>
      </div>
      <div className="mt-4 grid grid-cols-3 gap-2">
        {bays.map((b) => {
          const color = BAY_ACCENT[b.bay];
          if (b.critical) {
            return (
              <div
                key={b.bay}
                className="relative rounded-lg border-2 border-rose-500 p-2.5 overflow-hidden animate-neon-pulse"
                style={{ background: "linear-gradient(135deg, rgba(244,63,94,0.35), rgba(190,18,60,0.25))" }}
              >
                <span className="absolute inset-0 rounded-lg pointer-events-none animate-pulse" style={{ boxShadow: "inset 0 0 22px rgba(244,63,94,0.9)" }} />
                <div className="relative">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-white drop-shadow-[0_0_6px_rgba(244,63,94,0.9)]">{b.bay.replace("BAY-", "Bay ")}</div>
                  <div className="text-2xl font-bold tabular-nums mt-0.5 text-white drop-shadow-[0_0_10px_rgba(244,63,94,0.9)]">
                    <AnimatedNumber value={b.count} />
                  </div>
                  <div className="flex items-center gap-1 text-[10px] font-bold text-white mt-0.5">
                    <AlertTriangle className="h-3 w-3 animate-pulse" /> CRITICAL
                  </div>
                </div>
              </div>
            );
          }
          return (
            <div
              key={b.bay}
              className="relative rounded-lg border p-2.5 overflow-hidden transition-transform hover:scale-[1.03]"
              style={{ borderColor: `${color}55`, background: `${color}12` }}
            >
              {b.active && (
                <span
                  className="absolute inset-0 rounded-lg pointer-events-none animate-pulse"
                  style={{ boxShadow: `inset 0 0 12px ${color}88` }}
                />
              )}
              <div className="text-[10px] font-medium" style={{ color }}>{b.bay.replace("BAY-", "Bay ")}</div>
              <div className="text-2xl font-bold tabular-nums mt-0.5" style={{ color }}>
                <AnimatedNumber value={b.count} />
              </div>
              <div className="flex items-center gap-1 text-[10px] text-muted-foreground mt-0.5">
                <span
                  className={`h-1.5 w-1.5 rounded-full ${b.active ? "animate-pulse" : ""}`}
                  style={{ background: b.active ? color : "#94a3b8" }}
                />
                {b.active ? "Unloading" : b.count > 0 ? "Queued" : "Idle"}
              </div>

            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ------------ Legacy stat + badges + cost analytics ------------ */

const TONE: Record<string, string> = {
  blue: "bg-blue-500/10 text-blue-600",
  indigo: "bg-indigo-500/10 text-indigo-600",
  green: "bg-emerald-500/10 text-emerald-600",
  red: "bg-red-500/10 text-red-600",
};

function StatCard({ label, value, icon: Icon, tone }: { label: string; value: number; icon: React.ComponentType<{ className?: string }>; tone: string }) {
  return (
    <div className="rounded-xl border bg-card/80 backdrop-blur p-5 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
      <div className="flex items-start justify-between">
        <div>
          <div className="text-sm text-muted-foreground">{label}</div>
          <div className="text-3xl font-bold mt-1 tabular-nums">
            <AnimatedNumber value={value} />
          </div>
        </div>
        <div className={`h-10 w-10 rounded-md grid place-items-center ${TONE[tone]}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

export function ArrivalBadge({ status }: { status: string }) {
  const c = ARRIVAL_COLORS[status] || "#64748b";
  return (
    <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: `${c}22`, color: c }}>
      {status}
    </span>
  );
}

const STATUS_COLORS: Record<string, string> = {
  Waiting: "#64748b",
  Assigned: "#6366f1",
  Unloading: "#0ea5e9",
  Hold: "#f59e0b",
  Completed: "#16a34a",
  Departed: "#9333ea",
};
export function StatusBadge({ status }: { status: string }) {
  const c = STATUS_COLORS[status] || "#64748b";
  return (
    <span className="text-xs px-2 py-0.5 rounded-full font-medium" style={{ backgroundColor: `${c}22`, color: c }}>
      {status}
    </span>
  );
}

type Bucket = "daily" | "weekly" | "monthly" | "yearly";

function CostAnalytics() {
  const { state } = useApp();
  const [bucket, setBucket] = useState<Bucket>("daily");
  const rate = state.settings.held_up_cost_rate;

  const now = new Date();

  const inRange = (iso: string, b: Bucket) => {
    const d = new Date(iso);
    if (b === "daily") return d.toDateString() === now.toDateString();
    if (b === "weekly") {
      const start = new Date(now); start.setDate(now.getDate() - 6); start.setHours(0, 0, 0, 0);
      return d >= start;
    }
    if (b === "monthly") return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
    return d.getFullYear() === now.getFullYear();
  };

  const scoped = useMemo(() => state.vehicles.filter((v) => inRange(v.in_time, bucket)), [state.vehicles, bucket, now]);

  const costFor = (v: typeof state.vehicles[number]) => heldUpCost(v, rateForVehicle(v, state.heldUpRates, rate));

  const totalCost = scoped.reduce((s, v) => s + costFor(v), 0);
  const activeHeldCost = state.vehicles.filter((v) => v.is_held_up).reduce((s, v) => s + costFor(v), 0);
  const heldVehicles = scoped.filter((v) => heldUpHours(v) > 0);

  const chartData = useMemo(() => {
    const groups = new Map<string, number>();
    scoped.forEach((v) => {
      const c = costFor(v);
      if (c <= 0) return;
      const key = v.vendor_name || "Unknown";
      groups.set(key, (groups.get(key) || 0) + c);
    });
    return Array.from(groups.entries()).map(([vendor, cost]) => ({ vendor, cost: Math.round(cost) })).sort((a, b) => b.cost - a.cost).slice(0, 8);
  }, [scoped, rate, state.heldUpRates]);

  const buckets: { key: Bucket; label: string }[] = [
    { key: "daily", label: "Daily" }, { key: "weekly", label: "Weekly" },
    { key: "monthly", label: "Monthly" }, { key: "yearly", label: "Yearly" },
  ];

  return (
    <div className="relative overflow-hidden rounded-2xl border border-amber-300/60 bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 p-5 shadow-xl shadow-orange-500/30 animate-fade-in space-y-4 text-white">
      <div className="absolute -top-16 -right-16 h-56 w-56 rounded-full bg-white/20 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-16 -left-16 h-56 w-56 rounded-full bg-rose-300/30 blur-3xl pointer-events-none" />

      <div className="relative flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-white/25 backdrop-blur text-white grid place-items-center shadow-md ring-1 ring-white/40">
            <DollarSign className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-bold text-base text-white drop-shadow">
              Held-up / Demurrage Cost Analytics
            </h3>
            <p className="text-xs text-white/85">Rate: <span className="font-semibold text-white">per-vehicle-size</span> configured in Admin Settings · beyond 24h SLA</p>
          </div>
        </div>
        <div className="flex gap-1 rounded-lg border border-white/40 bg-white/15 backdrop-blur p-0.5">
          {buckets.map((b) => (
            <button key={b.key} onClick={() => setBucket(b.key)}
              className={`h-8 px-3 text-xs font-semibold rounded-md transition-all ${bucket === b.key ? "bg-white text-rose-600 shadow" : "text-white/90 hover:bg-white/20"}`}>
              {b.label}
            </button>
          ))}
        </div>
      </div>

      <div className="relative grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="rounded-xl border border-white/30 p-4 bg-white/15 backdrop-blur shadow-sm">
          <div className="text-[11px] uppercase tracking-wider font-semibold text-white/90">Total Held-up Cost ({bucket})</div>
          <div className="text-2xl font-bold mt-1 tabular-nums text-white drop-shadow">Rs. <AnimatedNumber value={totalCost} /></div>
        </div>
        <div className="rounded-xl border border-white/40 p-4 bg-gradient-to-br from-rose-600 to-red-700 shadow-sm relative overflow-hidden">
          <div className="absolute inset-0 bg-white/10 animate-pulse pointer-events-none" />
          <div className="relative text-[11px] uppercase tracking-wider font-semibold text-white/90">Active Held-up Accrual</div>
          <div className="relative text-2xl font-bold mt-1 tabular-nums text-white drop-shadow">Rs. <AnimatedNumber value={activeHeldCost} /></div>
        </div>
        <div className="rounded-xl border border-white/30 p-4 bg-white/15 backdrop-blur shadow-sm">
          <div className="text-[11px] uppercase tracking-wider font-semibold text-white/90">Vehicles Incurring Cost</div>
          <div className="text-2xl font-bold mt-1 tabular-nums text-white drop-shadow"><AnimatedNumber value={heldVehicles.length} /></div>
        </div>
      </div>

      {chartData.length === 0 ? (
        <p className="relative text-sm text-white/90 text-center py-8">No held-up costs for this period.</p>
      ) : (
        <div className="relative rounded-xl bg-white/10 backdrop-blur border border-white/25 p-3">
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={chartData}>
              <defs>
                <linearGradient id="heldUpBar" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#fef3c7" stopOpacity={1} />
                  <stop offset="100%" stopColor="#fff" stopOpacity={0.95} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" opacity={0.25} />
              <XAxis dataKey="vendor" tick={{ fontSize: 11, fill: "#fff" }} axisLine={{ stroke: "rgba(255,255,255,0.4)" }} tickLine={{ stroke: "rgba(255,255,255,0.4)" }} />
              <YAxis tick={{ fontSize: 11, fill: "#fff" }} axisLine={{ stroke: "rgba(255,255,255,0.4)" }} tickLine={{ stroke: "rgba(255,255,255,0.4)" }} />
              <Tooltip formatter={(v: number) => `Rs. ${v.toLocaleString()}`} contentStyle={{ borderRadius: 8, border: "1px solid rgba(245,158,11,0.4)", color: "#1f2937" }} />
              <Bar dataKey="cost" fill="url(#heldUpBar)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}



/* ------------ Shift-wise picking cards ------------ */

const SHIFT_TONE: Record<string, { border: string; grad: string; text: string; ring: string; glow: string }> = {
  sky: {
    border: "border-sky-500/40",
    grad: "from-sky-500/15 via-card to-cyan-500/10",
    text: "text-sky-600 dark:text-sky-300",
    ring: "bg-sky-500/20",
    glow: "drop-shadow-[0_0_10px_rgba(14,165,233,0.45)]",
  },
  violet: {
    border: "border-violet-500/40",
    grad: "from-violet-500/15 via-card to-fuchsia-500/10",
    text: "text-violet-600 dark:text-violet-300",
    ring: "bg-violet-500/20",
    glow: "drop-shadow-[0_0_10px_rgba(139,92,246,0.45)]",
  },
};

function ShiftCard({ label, window, tone, today, yesterday }: { label: string; window: string; tone: "sky" | "violet"; today: number; yesterday: number }) {
  const t = SHIFT_TONE[tone];
  const delta = today - yesterday;
  const pct = yesterday > 0 ? Math.round(((today - yesterday) / yesterday) * 100) : today > 0 ? 100 : 0;
  const up = delta >= 0;
  const yLabel = new Date().getDay() === 1 ? "Saturday" : "Yesterday";
  return (
    <div className={`relative overflow-hidden rounded-xl border ${t.border} bg-gradient-to-br ${t.grad} p-5 shadow-sm hover:shadow-xl transition-all animate-fade-in`}>
      <div className={`absolute -top-8 -right-8 h-28 w-28 rounded-full blur-3xl ${t.ring}`} />
      <div className="relative flex items-start justify-between">
        <div>
          <div className={`text-[11px] uppercase tracking-widest font-semibold ${t.text}`}>
            Trims Picking · {label}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5 font-mono">{window}</div>
          <div className="mt-4 flex items-baseline gap-2">
            <span className={`text-5xl font-bold tabular-nums ${t.text} ${t.glow}`}>
              <AnimatedNumber value={today} />
            </span>
            <span className="text-sm text-muted-foreground font-medium">GINs today</span>
          </div>
          <div className="mt-3 flex items-center gap-2 text-xs">
            <span className="px-2 py-0.5 rounded-full bg-muted/60 text-muted-foreground font-medium tabular-nums">
              {yLabel}: <AnimatedNumber value={yesterday} />
            </span>
            <span className={`px-2 py-0.5 rounded-full font-bold tabular-nums ${
              up ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-300" : "bg-rose-500/15 text-rose-600 dark:text-rose-300"
            }`}>
              {up ? "▲" : "▼"} {Math.abs(delta)} ({up ? "+" : ""}{pct}%)
            </span>
          </div>
        </div>
        <div className="text-right">
          <div className="text-[10px] uppercase tracking-widest text-muted-foreground">vs {yLabel}</div>
          <div className={`mt-1 text-2xl font-bold tabular-nums ${up ? "text-emerald-500" : "text-rose-500"}`}>
            {up ? "+" : ""}<AnimatedNumber value={delta} />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ------------ Locked Top-Row TV Cards ------------ */

const CORE_TONE: Record<string, { bg: string; border: string; iconBg: string; ring: string }> = {
  neonBlue: {
    bg: "bg-gradient-to-br from-sky-400 via-blue-500 to-indigo-600",
    border: "border-sky-300/60",
    iconBg: "bg-white/25 text-white",
    ring: "bg-white/25",
  },
  neonAmber: {
    bg: "bg-gradient-to-br from-amber-400 via-orange-500 to-red-500",
    border: "border-amber-300/60",
    iconBg: "bg-white/25 text-white",
    ring: "bg-white/25",
  },
  emerald: {
    bg: "bg-gradient-to-br from-lime-400 via-emerald-500 to-teal-600",
    border: "border-emerald-300/60",
    iconBg: "bg-white/25 text-white",
    ring: "bg-white/25",
  },
  crimson: {
    bg: "bg-gradient-to-br from-rose-500 via-red-600 to-red-800",
    border: "border-rose-300/60",
    iconBg: "bg-white/25 text-white",
    ring: "bg-white/30",
  },
};

function CoreMetric({
  label,
  value,
  icon: Icon,
  tone,
  pulsing = false,
}: {
  label: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  tone: keyof typeof CORE_TONE;
  pulsing?: boolean;
}) {
  const t = CORE_TONE[tone];
  return (
    <div className={`relative overflow-hidden rounded-xl border ${t.border} ${t.bg} p-3 shadow-lg text-white ${pulsing ? "animate-neon-pulse" : ""}`}>
      <div className={`absolute -top-8 -right-8 h-24 w-24 rounded-full blur-2xl ${t.ring}`} />
      <div className="relative flex items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="text-[10px] uppercase tracking-widest font-bold opacity-95">{label}</div>
          <div className="mt-1 text-3xl md:text-4xl font-black tabular-nums drop-shadow">
            <AnimatedNumber value={value} />
          </div>
        </div>
        <div className={`h-10 w-10 shrink-0 rounded-md grid place-items-center ${t.iconBg} backdrop-blur`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
    </div>
  );
}

function TodayShiftSplitCard({ shift1, shift2 }: { shift1: number; shift2: number }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-indigo-300/60 bg-gradient-to-br from-sky-500 via-indigo-500 to-violet-600 shadow-lg text-white">
      <div className="absolute -top-8 -right-8 h-24 w-24 rounded-full bg-white/25 blur-2xl" />
      <div className="relative px-3 pt-2 flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-widest font-bold">
          Today · Trims GINs by Shift
        </div>
        <div className="text-[10px] font-mono tabular-nums bg-white/25 backdrop-blur px-2 py-0.5 rounded-full">
          Σ {shift1 + shift2}
        </div>
      </div>
      <div className="relative grid grid-cols-2 divide-x divide-white/25 mt-1">
        <div className="p-3">
          <div className="text-[9px] uppercase tracking-wider font-bold">Shift 1</div>
          <div className="text-[9px] font-mono opacity-90">06:00 – 14:00</div>
          <div className="mt-1 text-3xl font-black tabular-nums drop-shadow">
            <AnimatedNumber value={shift1} />
          </div>
        </div>
        <div className="p-3">
          <div className="text-[9px] uppercase tracking-wider font-bold">Shift 2</div>
          <div className="text-[9px] font-mono opacity-90">14:00 – 22:00</div>
          <div className="mt-1 text-3xl font-black tabular-nums drop-shadow">
            <AnimatedNumber value={shift2} />
          </div>
        </div>
      </div>
    </div>
  );
}

function YesterdayGinCard({ value }: { value: number }) {
  const isMon = new Date().getDay() === 1;
  return (
    <div className="relative overflow-hidden rounded-xl border border-cyan-300/60 bg-gradient-to-br from-cyan-400 via-teal-500 to-emerald-600 p-3 shadow-lg text-white">
      <div className="absolute -top-8 -right-8 h-24 w-24 rounded-full bg-white/25 blur-2xl" />
      <div className="relative">
        <div className="text-[10px] uppercase tracking-widest font-bold">
          {isMon ? "Saturday" : "Yesterday"} · Total GINs
        </div>
        <div className="mt-2 text-4xl font-black tabular-nums drop-shadow">
          <AnimatedNumber value={value} />
        </div>
        <div className="text-[10px] opacity-90 mt-1">
          {isMon ? "Sunday holiday skipped" : "prev operational day"}
        </div>
      </div>
    </div>
  );
}

function PastWeekGinCard({ value }: { value: number }) {
  return (
    <div className="relative overflow-hidden rounded-xl border border-fuchsia-300/60 bg-gradient-to-br from-fuchsia-500 via-purple-600 to-indigo-700 p-3 shadow-lg text-white">
      <div className="absolute -top-8 -right-8 h-24 w-24 rounded-full bg-white/25 blur-2xl" />
      <div className="relative">
        <div className="text-[10px] uppercase tracking-widest font-bold">
          Past Week · Consolidated
        </div>
        <div className="mt-2 text-4xl font-black tabular-nums drop-shadow">
          <AnimatedNumber value={value} />
        </div>
        <div className="text-[10px] opacity-90 mt-1">Mon – Sun aggregate</div>
      </div>
    </div>
  );
}

function HeldUpCostBigCard({ cost, count, rate }: { cost: number; count: number; rate: number }) {
  const critical = count > 0;
  return (
    <div
      className={`relative overflow-hidden rounded-xl border-2 p-3 shadow-lg text-white ${
        critical
          ? "border-rose-300/60 bg-gradient-to-br from-rose-500 via-red-600 to-red-800 animate-neon-pulse"
          : "border-emerald-300/60 bg-gradient-to-br from-emerald-400 via-green-500 to-teal-600"
      }`}
    >
      <div className="absolute -top-6 -right-6 h-24 w-24 rounded-full blur-2xl bg-white/25" />
      <div className="relative">
        <div className="text-[10px] uppercase tracking-widest font-bold flex items-center gap-1">
          <DollarSign className="h-3 w-3" /> Total Held-Up Delay Costs
        </div>
        <div className="mt-1 text-3xl md:text-4xl font-black tabular-nums drop-shadow">
          Rs. <AnimatedNumber value={cost} />
        </div>
      </div>
    </div>
  );
}

function TodayUnloadingSplitCard({
  s1, s2,
}: { s1: { box: number; roll: number }; s2: { box: number; roll: number } }) {
  const totBox = s1.box + s2.box;
  const totRoll = s1.roll + s2.roll;
  return (
    <div className="relative overflow-hidden rounded-xl border border-amber-300/60 bg-gradient-to-br from-amber-400 via-orange-500 to-rose-500 shadow-lg text-white">
      <div className="absolute -top-8 -right-8 h-28 w-28 rounded-full bg-white/25 blur-2xl" />
      <div className="relative px-3 pt-2 flex items-center justify-between">
        <div className="text-[10px] uppercase tracking-widest font-bold">
          Today's Unloading Breakdown
        </div>
        <div className="text-[10px] font-mono tabular-nums bg-white/25 backdrop-blur px-2 py-0.5 rounded-full">
          Σ {totBox} box · {totRoll} roll
        </div>
      </div>
      <div className="relative grid grid-cols-2 divide-x divide-white/25 mt-1">
        <UnloadingShiftHalf label="Shift 1" window="06:00 – 14:00" box={s1.box} roll={s1.roll} />
        <UnloadingShiftHalf label="Shift 2" window="14:00 – 22:00" box={s2.box} roll={s2.roll} />
      </div>
    </div>
  );
}

function UnloadingShiftHalf({
  label, window: win, box, roll,
}: { label: string; window: string; box: number; roll: number }) {
  return (
    <div className="p-3">
      <div className="text-[9px] uppercase tracking-wider font-bold">{label}</div>
      <div className="text-[9px] font-mono opacity-90">{win}</div>
      <div className="mt-1 flex items-baseline gap-4">
        <div>
          <div className="text-[9px] uppercase opacity-90">Box Qty</div>
          <div className="text-2xl font-black tabular-nums drop-shadow">
            <AnimatedNumber value={box} />
          </div>
        </div>
        <div>
          <div className="text-[9px] uppercase opacity-90">Roll Qty</div>
          <div className="text-2xl font-black tabular-nums drop-shadow">
            <AnimatedNumber value={roll} />
          </div>
        </div>
      </div>
    </div>
  );
}

function YesterdayUnloadingCard({ box, roll }: { box: number; roll: number }) {
  const isMon = new Date().getDay() === 1;
  return (
    <div className="relative overflow-hidden rounded-xl border border-teal-300/60 bg-gradient-to-br from-teal-400 via-emerald-500 to-green-700 p-3 shadow-lg text-white">
      <div className="absolute -top-8 -right-8 h-24 w-24 rounded-full bg-white/25 blur-2xl" />
      <div className="relative">
        <div className="text-[10px] uppercase tracking-widest font-bold">
          {isMon ? "Saturday" : "Yesterday"}'s Unloading Total
        </div>
        <div className="mt-2 grid grid-cols-2 gap-3">
          <div>
            <div className="text-[9px] uppercase opacity-90">Box Qty</div>
            <div className="text-3xl font-black tabular-nums drop-shadow">
              <AnimatedNumber value={box} />
            </div>
          </div>
          <div>
            <div className="text-[9px] uppercase opacity-90">Roll Qty</div>
            <div className="text-3xl font-black tabular-nums drop-shadow">
              <AnimatedNumber value={roll} />
            </div>
          </div>
        </div>
        <div className="text-[10px] opacity-90 mt-1">
          {isMon ? "Sunday holiday skipped" : "prev operational day"}
        </div>
      </div>
    </div>
  );
}



function CycleVarianceCard({ count }: { count: number }) {
  const alert = count > 0;
  return (
    <div className={`relative overflow-hidden rounded-2xl border p-5 shadow-lg transition-all ${alert ? "border-amber-400/60 bg-gradient-to-br from-amber-400 via-orange-500 to-rose-600 text-white" : "border-emerald-400/60 bg-gradient-to-br from-emerald-400 via-teal-500 to-cyan-600 text-white"}`}>
      <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-white/20 blur-2xl" />
      <div className="flex items-start justify-between gap-3 relative">
        <div>
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest font-bold opacity-95">
            <ClipboardList className="h-4 w-4" /> Variance Material Count
          </div>
          <div className="text-5xl font-black mt-2 drop-shadow">
            <AnimatedNumber value={count} />
          </div>
          {alert ? (
            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/25 backdrop-blur px-2.5 py-1 text-[11px] font-bold">
              <AlertTriangle className="h-3.5 w-3.5" /> Materials requiring stock adjustment
            </div>
          ) : (
            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/25 backdrop-blur px-2.5 py-1 text-[11px] font-bold">
              <CheckCircle2 className="h-3.5 w-3.5" /> All materials balanced
            </div>
          )}
        </div>
        <div className="h-11 w-11 grid place-items-center rounded-xl bg-white/25 backdrop-blur">
          <AlertTriangle className="h-6 w-6" />
        </div>
      </div>
    </div>
  );
}

function CycleHighestVarianceCard({ category, qty }: { category: string; qty: number }) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-rose-500/50 bg-gradient-to-br from-rose-600 via-red-700 to-red-900 p-5 shadow-lg text-white">
      <div className="absolute -right-8 -bottom-8 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
      <div className="flex items-start justify-between gap-3 relative">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest font-bold opacity-95">
            <TrendingDown className="h-4 w-4" /> Highest Variance Category
          </div>
          <div className="text-3xl font-black mt-2 truncate drop-shadow">{category}</div>
          <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/20 backdrop-blur px-2.5 py-1 text-[11px] font-bold">
            <AlertTriangle className="h-3.5 w-3.5" /> Total Variance: <AnimatedNumber value={qty} />
          </div>
        </div>
        <div className="h-11 w-11 grid place-items-center rounded-xl bg-white/25 backdrop-blur">
          <TrendingDown className="h-6 w-6" />
        </div>
      </div>
    </div>
  );
}

function CycleBestCategoryCard({ category, matches }: { category: string; matches: number }) {
  return (
    <div className="relative overflow-hidden rounded-2xl border border-emerald-400/60 bg-gradient-to-br from-lime-400 via-emerald-500 to-green-700 p-5 shadow-lg text-white">
      <div className="absolute -right-8 -bottom-8 h-32 w-32 rounded-full bg-white/15 blur-2xl" />
      <div className="flex items-start justify-between gap-3 relative">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-[11px] uppercase tracking-widest font-bold opacity-95">
            <ShieldCheck className="h-4 w-4" /> Best Performing Category
          </div>
          <div className="text-3xl font-black mt-2 truncate drop-shadow">{category}</div>
          <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-white/25 backdrop-blur px-2.5 py-1 text-[11px] font-bold shadow-[0_0_18px_rgba(163,255,120,0.7)]">
            <CheckCircle2 className="h-3.5 w-3.5" /> HEALTHY · <AnimatedNumber value={matches} /> perfect matches
          </div>
        </div>
        <div className="h-11 w-11 grid place-items-center rounded-xl bg-white/25 backdrop-blur">
          <ShieldCheck className="h-6 w-6" />
        </div>
      </div>
    </div>
  );
}
