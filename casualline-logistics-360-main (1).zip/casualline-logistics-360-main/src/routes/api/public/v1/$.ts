import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import {
  API_TABLES, ApiError, MAX_BODY_BYTES, SCOPES, assertTable, generateApiKey, hasScope, parseFilters,
  parseLimit, parseOffset, parseOrder, parseSelect, scopeFor, sha256Hex, tableAllowed, timingSafeEqualStr,
  validateBody, type Filter,
} from "@/lib/integration-api";

/**
 * Full-system integration API v1. Docs: /mnt/documents/Full-System-API-Guide.md
 * Auth: X-API-Key or Authorization: Bearer (never in the URL).
 * Business data uses the publishable (anon) client so row security rules apply.
 * Only key/audit/rate metadata uses the privileged client, after the key is checked.
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, PATCH, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-API-Key",
};

type Client = { id: string | null; name: string; scopes: string[]; allowed_tables: string[] | null; rate: number; master: boolean };

function json(body: unknown, status = 200, extra: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", ...CORS, ...extra } });
}

function headerKey(req: Request) {
  const x = req.headers.get("x-api-key");
  if (x) return x.trim();
  const a = req.headers.get("authorization");
  return a?.toLowerCase().startsWith("bearer ") ? a.slice(7).trim() : null;
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

function businessClient() {
  const url = process.env.SUPABASE_URL!;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY!;
  return createClient(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

async function authenticate(req: Request): Promise<Client> {
  const key = headerKey(req);
  if (!key) throw new ApiError(401, "unauthorized", "Missing API key (use X-API-Key header)");
  const master = process.env.SYSTEM_API_KEY;
  if (master && timingSafeEqualStr(key, master)) {
    return { id: null, name: "system-master", scopes: [...SCOPES], allowed_tables: null, rate: 600, master: true };
  }
  const hash = await sha256Hex(key);
  const sb = await admin();
  const { data } = await sb.from("api_clients").select("*").eq("key_hash", hash).maybeSingle();
  if (!data || !data.is_active || data.revoked_at || (data.expires_at && new Date(data.expires_at) < new Date())) {
    throw new ApiError(401, "unauthorized", "Invalid, revoked or expired API key");
  }
  void sb.from("api_clients").update({ last_used_at: new Date().toISOString() }).eq("id", data.id).then(() => {});
  return { id: data.id, name: data.name, scopes: data.scopes, allowed_tables: data.allowed_tables, rate: data.rate_limit_per_minute, master: false };
}

async function rateLimit(c: Client) {
  const sb = await admin();
  const { data, error } = await sb.rpc("api_rate_hit", { p_client_key: c.id ?? "master" });
  if (error) return; // fail open on counter errors, never block the business
  if ((data as number) > c.rate) {
    const retry = 60 - new Date().getSeconds();
    throw Object.assign(new ApiError(429, "rate_limited", `Rate limit ${c.rate}/min exceeded`), { retry });
  }
}

async function audit(entry: { client: Client | null; method: string; resource: string | null; query: string; status: number; rows: number | null; ip: string | null; ms: number }) {
  try {
    const sb = await admin();
    await sb.from("api_audit_log").insert({
      client_id: entry.client?.id ?? null, client_name: entry.client?.name ?? null, method: entry.method,
      resource: entry.resource, query: entry.query.slice(0, 1000), status: entry.status, row_count: entry.rows,
      ip: entry.ip, duration_ms: entry.ms,
    });
  } catch { /* audit must never break the request */ }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function applyFilters(q: any, filters: Filter[]) {
  for (const f of filters) {
    if (f.op === "in") q = q.in(f.col, f.value as string[]);
    else if (f.op === "is") q = q.is(f.col, f.value);
    else q = q[f.op](f.col, f.value);
  }
  return q;
}

async function readBody(req: Request) {
  const text = await req.text();
  if (text.length > MAX_BODY_BYTES) throw new ApiError(413, "body_too_large", "Body exceeds 1 MB");
  try { return JSON.parse(text); } catch { throw new ApiError(400, "bad_json", "Invalid JSON body"); }
}

async function manageKeys(req: Request, client: Client, id: string | undefined) {
  if (!client.master) throw new ApiError(403, "forbidden", "Key management requires the system master key");
  const sb = await admin();
  if (req.method === "GET") {
    const { data, error } = await sb.from("api_clients")
      .select("id,name,key_prefix,scopes,allowed_tables,rate_limit_per_minute,is_active,expires_at,last_used_at,created_at,revoked_at")
      .order("created_at", { ascending: false });
    if (error) throw new ApiError(500, "db_error", error.message);
    return { data, count: data.length };
  }
  if (req.method === "POST") {
    const b = await readBody(req);
    const name = typeof b?.name === "string" ? b.name.trim() : "";
    if (!name || name.length > 80) throw new ApiError(400, "bad_body", "name is required (max 80 chars)");
    const scopes: string[] = Array.isArray(b.scopes) && b.scopes.length ? b.scopes : ["read"];
    if (scopes.some((s) => !SCOPES.includes(s as never))) throw new ApiError(400, "bad_scope", "scopes must be read, write, delete");
    const tables: string[] | null = Array.isArray(b.allowed_tables) && b.allowed_tables.length ? b.allowed_tables : null;
    tables?.forEach(assertTable);
    const rate = b.rate_limit_per_minute == null ? 120 : Number(b.rate_limit_per_minute);
    if (!Number.isInteger(rate) || rate < 1 || rate > 6000) throw new ApiError(400, "bad_rate", "rate_limit_per_minute 1-6000");
    const expires = b.expires_at ? new Date(b.expires_at) : null;
    if (expires && isNaN(expires.getTime())) throw new ApiError(400, "bad_expiry", "expires_at must be an ISO date");
    const key = generateApiKey();
    const { data, error } = await sb.from("api_clients").insert({
      name, key_hash: await sha256Hex(key), key_prefix: key.slice(0, 12), scopes, allowed_tables: tables,
      rate_limit_per_minute: rate, expires_at: expires?.toISOString() ?? null,
    }).select("id,name,key_prefix,scopes,allowed_tables,rate_limit_per_minute,expires_at").single();
    if (error) throw new ApiError(500, "db_error", error.message);
    return { data: { ...data, api_key: key, note: "Store this key now; it is shown only once." } };
  }
  if (req.method === "DELETE") {
    if (!id) throw new ApiError(400, "missing_id", "Pass the key id: /_keys/{id}");
    const { data, error } = await sb.from("api_clients").update({ is_active: false, revoked_at: new Date().toISOString() }).eq("id", id).select("id,name");
    if (error) throw new ApiError(500, "db_error", error.message);
    return { data, count: data.length };
  }
  throw new ApiError(405, "method_not_allowed", "Use GET, POST or DELETE");
}

async function handle(req: Request, splat: string) {
  const started = Date.now();
  const url = new URL(req.url);
  const parts = splat.split("/").filter(Boolean);
  const resource = parts[0] ?? null;
  const id = parts[1] ? decodeURIComponent(parts[1]) : undefined;
  const ip = req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for");
  let client: Client | null = null;
  let status = 200; let rows: number | null = null;
  try {
    if (url.searchParams.has("api_key")) throw new ApiError(400, "key_in_url", "Send the key in the X-API-Key header, not the URL");
    client = await authenticate(req);
    await rateLimit(client);

    let body: unknown;
    if (!resource || resource === "_schema") {
      body = { data: Object.entries(API_TABLES).filter(([t]) => tableAllowed(client!.allowed_tables, t)).map(([table, v]) => ({ table, primary_key: v.pk, columns: v.columns })) };
    } else if (resource === "_keys") {
      body = await manageKeys(req, client, id);
    } else {
      const meta = assertTable(resource);
      const need = scopeFor(req.method);
      if (!hasScope(client.scopes, need)) throw new ApiError(403, "forbidden", `Key lacks "${need}" permission`);
      if (!tableAllowed(client.allowed_tables, resource)) throw new ApiError(403, "forbidden", `Key not allowed on ${resource}`);
      const sb = businessClient();
      const filters = parseFilters(resource, url.searchParams);
      const select = parseSelect(resource, url.searchParams.get("select"));
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      let q: any;
      if (req.method === "GET") {
        const limit = parseLimit(url.searchParams.get("limit"));
        const offset = parseOffset(url.searchParams.get("offset"));
        const order = parseOrder(resource, url.searchParams.get("order"));
        q = sb.from(resource).select(select, { count: "exact" });
        if (id) q = q.eq(meta.pk, id);
        q = applyFilters(q, filters);
        if (order) q = q.order(order.col, { ascending: order.ascending });
        q = q.range(offset, offset + limit - 1);
        const { data, error, count } = await q;
        if (error) throw new ApiError(400, "db_error", error.message);
        const n = data?.length ?? 0;
        body = { data, count: n, total: count, next_offset: count != null && offset + n < count ? offset + n : null };
      } else if (req.method === "POST") {
        const rowsIn = validateBody(resource, await readBody(req), true);
        const { data, error } = await sb.from(resource).insert(rowsIn).select();
        if (error) throw new ApiError(400, "db_error", error.message);
        status = 201; body = { data, count: data?.length ?? 0 };
      } else if (req.method === "PUT" || req.method === "PATCH") {
        const [patch] = validateBody(resource, await readBody(req), false);
        if (req.method === "PUT") {
          if (!id) throw new ApiError(400, "missing_id", `PUT needs /${resource}/{${meta.pk}}`);
          const { data, error } = await sb.from(resource).upsert({ ...patch, [meta.pk]: id }, { onConflict: meta.pk }).select();
          if (error) throw new ApiError(400, "db_error", error.message);
          body = { data, count: data?.length ?? 0 };
        } else {
          if (!id && filters.length === 0) throw new ApiError(400, "filter_required", "PATCH needs an id or column filters");
          q = sb.from(resource).update(patch);
          if (id) q = q.eq(meta.pk, id);
          const { data, error } = await applyFilters(q, filters).select();
          if (error) throw new ApiError(400, "db_error", error.message);
          body = { data, count: data?.length ?? 0 };
        }
      } else if (req.method === "DELETE") {
        if (!id && filters.length === 0) throw new ApiError(400, "filter_required", "DELETE needs an id or column filters");
        q = sb.from(resource).delete();
        if (id) q = q.eq(meta.pk, id);
        const { data, error } = await applyFilters(q, filters).select();
        if (error) throw new ApiError(400, "db_error", error.message);
        body = { data, count: data?.length ?? 0 };
      } else throw new ApiError(405, "method_not_allowed", "Unsupported method");
    }
    rows = (body as { count?: number })?.count ?? null;
    return json(body, status);
  } catch (e) {
    const err = e instanceof ApiError ? e : new ApiError(500, "internal_error", "Unexpected error");
    if (!(e instanceof ApiError)) console.error(e);
    status = err.status;
    const extra: Record<string, string> = status === 429 ? { "Retry-After": String((e as { retry?: number }).retry ?? 60) } : {};
    return json({ error: { code: err.code, message: err.message } }, status, extra);
  } finally {
    const safeQuery = new URLSearchParams(url.searchParams); safeQuery.delete("api_key");
    void audit({ client, method: req.method, resource, query: safeQuery.toString(), status, rows, ip, ms: Date.now() - started });
  }
}

export const Route = createFileRoute("/api/public/v1/$")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: ({ request, params }) => handle(request, params._splat ?? ""),
      POST: ({ request, params }) => handle(request, params._splat ?? ""),
      PUT: ({ request, params }) => handle(request, params._splat ?? ""),
      PATCH: ({ request, params }) => handle(request, params._splat ?? ""),
      DELETE: ({ request, params }) => handle(request, params._splat ?? ""),
    },
  },
});
