import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

/**
 * Public System API — full read/write access to all app tables.
 *
 * Auth (required on every request):
 *   Header:  X-API-Key: <SYSTEM_API_KEY>
 *   or       Authorization: Bearer <SYSTEM_API_KEY>
 *   or       ?api_key=<SYSTEM_API_KEY>
 *
 * READ:
 *   GET  /api/public/system?resource=<table>&select=*&limit=100&order=col.desc
 *        &<col>=eq.<val>&<col>=gte.<val>&<col>=in.(a,b,c)&since=ISO
 *
 *   Special:
 *     resource=all          -> snapshot of every table (last 7d where dated)
 *     resource=_tables      -> list of allowed tables
 *
 * WRITE:
 *   POST   /api/public/system?resource=<table>            body: object | object[]
 *   PATCH  /api/public/system?resource=<table>&id=<uuid>  body: object    (or use filters)
 *   DELETE /api/public/system?resource=<table>&id=<uuid>                  (or use filters)
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-API-Key",
};

// Whitelist of tables the API is allowed to touch.
const TABLES = new Set([
  "admin_settings",
  "cc_daily_actuals",
  "cc_monthly_targets",
  "cycle_count_logs",
  "fabric_downtime",
  "fabric_picker_achievements",
  "fabric_picker_targets",
  "fabric_plan",
  "green_board_concerns",
  "green_board_entries",
  "grn_pending_reasons",
  "held_up_rates",
  "invoice_daily_log",
  "picker_achievements",
  "picker_targets",
  "trims_downtime",
  "trims_plan",
  "vehicle_logs",
  "weekly_schedules",
]);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function extractKey(request: Request): string | null {
  const h = request.headers;
  const xk = h.get("x-api-key");
  if (xk) return xk.trim();
  const auth = h.get("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7).trim();
  return new URL(request.url).searchParams.get("api_key");
}

function authed(request: Request): boolean {
  const expected = process.env.SYSTEM_API_KEY;
  if (!expected) return false;
  const given = extractKey(request);
  if (!given || given.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ given.charCodeAt(i);
  return diff === 0;
}

function admin() {
  const url = process.env.SUPABASE_URL!;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

// Reserved query params that are NOT column filters.
const RESERVED = new Set(["resource", "api_key", "select", "limit", "offset", "order", "id", "since"]);

// PostgREST-style operator prefixes: eq., neq., gt., gte., lt., lte., like., ilike., is., in.(a,b)
function applyFilters(q: any, params: URLSearchParams) {
  for (const [k, raw] of params.entries()) {
    if (RESERVED.has(k)) continue;
    const v = raw;
    const m = /^(eq|neq|gt|gte|lt|lte|like|ilike|is|in)\.(.*)$/s.exec(v);
    if (!m) { q = q.eq(k, v); continue; }
    const op = m[1]; const val = m[2];
    if (op === "in") {
      const list = val.replace(/^\(|\)$/g, "").split(",").map((s) => s.trim());
      q = q.in(k, list);
    } else if (op === "is") {
      q = q.is(k, val === "null" ? null : val === "true" ? true : val === "false" ? false : val);
    } else {
      q = (q as any)[op](k, val);
    }
  }
  return q;
}

async function snapshot(sb: ReturnType<typeof admin>) {
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 86400000).toISOString();
  const weekAgoDate = weekAgo.slice(0, 10);
  const monthAgo = new Date(now.getTime() - 30 * 86400000).toISOString().slice(0, 10);

  const runs = await Promise.all([
    sb.from("vehicle_logs").select("*").gte("in_time", weekAgo).order("in_time", { ascending: false }).limit(500),
    sb.from("weekly_schedules").select("*").limit(500),
    sb.from("invoice_daily_log").select("*").gte("log_date", weekAgoDate).order("log_date", { ascending: false }),
    sb.from("trims_plan").select("*").gte("cut_date", weekAgoDate).limit(500),
    sb.from("fabric_plan").select("*").gte("cut_date", weekAgoDate).limit(500),
    sb.from("trims_downtime").select("*").gte("entry_date", weekAgoDate).order("entry_date", { ascending: false }),
    sb.from("fabric_downtime").select("*").gte("entry_date", weekAgoDate).order("entry_date", { ascending: false }),
    sb.from("picker_achievements").select("*").gte("picked_at", weekAgo).limit(1000),
    sb.from("fabric_picker_achievements").select("*").gte("picked_at", weekAgo).limit(1000),
    sb.from("picker_targets").select("*"),
    sb.from("fabric_picker_targets").select("*"),
    sb.from("green_board_entries").select("*").gte("entry_date", weekAgoDate).limit(1000),
    sb.from("green_board_concerns").select("*"),
    sb.from("cc_daily_actuals").select("*").gte("entry_date", monthAgo).limit(1000),
    sb.from("cc_monthly_targets").select("*"),
    sb.from("cycle_count_logs").select("*").gte("upload_date", weekAgo).limit(500),
    sb.from("grn_pending_reasons").select("*"),
    sb.from("held_up_rates").select("*"),
    sb.from("admin_settings").select("*"),
  ]);
  const keys = [
    "vehicle_logs","weekly_schedules","invoice_daily_log","trims_plan","fabric_plan",
    "trims_downtime","fabric_downtime","picker_achievements","fabric_picker_achievements",
    "picker_targets","fabric_picker_targets","green_board_entries","green_board_concerns",
    "cc_daily_actuals","cc_monthly_targets","cycle_count_logs","grn_pending_reasons",
    "held_up_rates","admin_settings",
  ];
  const out: Record<string, unknown> = { generated_at: now.toISOString() };
  keys.forEach((k, i) => (out[k] = runs[i].data ?? []));
  return out;
}

export const Route = createFileRoute("/api/public/system")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),

      GET: async ({ request }) => {
        if (!authed(request)) return json({ error: "Unauthorized" }, 401);
        const url = new URL(request.url);
        const resource = url.searchParams.get("resource") ?? "_tables";
        const sb = admin();

        if (resource === "_tables") return json({ tables: [...TABLES].sort() });
        if (resource === "all") return json(await snapshot(sb));
        if (!TABLES.has(resource)) return json({ error: `Unknown resource "${resource}"` }, 400);

        const select = url.searchParams.get("select") ?? "*";
        const limit = Math.min(Number(url.searchParams.get("limit")) || 500, 5000);
        const offset = Number(url.searchParams.get("offset")) || 0;
        const order = url.searchParams.get("order"); // "col" or "col.desc"
        const since = url.searchParams.get("since");

        let q: any = sb.from(resource).select(select);
        q = applyFilters(q, url.searchParams);
        if (since) {
          // Pick a sensible date column per table
          const col =
            resource === "vehicle_logs" ? "in_time" :
            resource === "invoice_daily_log" ? "log_date" :
            resource.endsWith("_downtime") ? "entry_date" :
            resource.endsWith("_achievements") ? "picked_at" :
            resource === "green_board_entries" ? "entry_date" :
            resource === "cc_daily_actuals" ? "entry_date" :
            resource.endsWith("_plan") ? "cut_date" :
            "created_at";
          q = q.gte(col, since);
        }
        if (order) {
          const [col, dir] = order.split(".");
          q = q.order(col, { ascending: (dir ?? "asc") !== "desc" });
        }
        q = q.range(offset, offset + limit - 1);

        const { data, error } = await q;
        if (error) return json({ error: error.message }, 500);
        return json({ resource, count: data?.length ?? 0, data });
      },

      POST: async ({ request }) => {
        if (!authed(request)) return json({ error: "Unauthorized" }, 401);
        const url = new URL(request.url);
        const resource = url.searchParams.get("resource");
        if (!resource || !TABLES.has(resource)) return json({ error: "Unknown or missing resource" }, 400);
        let body: unknown;
        try { body = await request.json(); } catch { return json({ error: "Invalid JSON body" }, 400); }
        if (!body || (typeof body !== "object")) return json({ error: "Body must be an object or array" }, 400);
        const sb = admin();
        const { data, error } = await sb.from(resource).insert(body as any).select();
        if (error) return json({ error: error.message }, 500);
        return json({ resource, inserted: data?.length ?? 0, data }, 201);
      },

      PATCH: async ({ request }) => {
        if (!authed(request)) return json({ error: "Unauthorized" }, 401);
        const url = new URL(request.url);
        const resource = url.searchParams.get("resource");
        if (!resource || !TABLES.has(resource)) return json({ error: "Unknown or missing resource" }, 400);
        let patch: Record<string, unknown>;
        try { patch = await request.json(); } catch { return json({ error: "Invalid JSON body" }, 400); }
        const sb = admin();
        let q: any = sb.from(resource).update(patch);
        const id = url.searchParams.get("id");
        if (id) q = q.eq("id", id);
        q = applyFilters(q, url.searchParams);
        if (!id && ![...url.searchParams.keys()].some((k) => !RESERVED.has(k))) {
          return json({ error: "Refusing to update without filters. Pass id=... or column filters." }, 400);
        }
        const { data, error } = await q.select();
        if (error) return json({ error: error.message }, 500);
        return json({ resource, updated: data?.length ?? 0, data });
      },

      DELETE: async ({ request }) => {
        if (!authed(request)) return json({ error: "Unauthorized" }, 401);
        const url = new URL(request.url);
        const resource = url.searchParams.get("resource");
        if (!resource || !TABLES.has(resource)) return json({ error: "Unknown or missing resource" }, 400);
        const sb = admin();
        let q: any = sb.from(resource).delete();
        const id = url.searchParams.get("id");
        if (id) q = q.eq("id", id);
        q = applyFilters(q, url.searchParams);
        if (!id && ![...url.searchParams.keys()].some((k) => !RESERVED.has(k))) {
          return json({ error: "Refusing to delete without filters. Pass id=... or column filters." }, 400);
        }
        const { data, error } = await q.select();
        if (error) return json({ error: error.message }, 500);
        return json({ resource, deleted: data?.length ?? 0, data });
      },
    },
  },
});
