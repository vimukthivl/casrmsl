import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";

/**
 * Public API for Picker Console data.
 *
 * Auth: pass the API key in one of:
 *   - Header:  X-API-Key: <PICKER_API_KEY>
 *   - Header:  Authorization: Bearer <PICKER_API_KEY>
 *   - Query:   ?api_key=<PICKER_API_KEY>
 *
 * Endpoints:
 *   GET  /api/public/picker?resource=pending&mode=trims|fabric|all
 *   GET  /api/public/picker?resource=achievements&mode=trims|fabric|all&since=ISO
 *   GET  /api/public/picker?resource=targets
 *
 *   POST /api/public/picker         (submit a pick)
 *     body: { epf: string, po: string, mode?: "trims"|"fabric" }
 */

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-API-Key",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", ...CORS },
  });
}

function extractKey(request: Request): string | null {
  const h = request.headers;
  const xk = h.get("x-api-key");
  if (xk) return xk.trim();
  const auth = h.get("authorization");
  if (auth?.toLowerCase().startsWith("bearer ")) return auth.slice(7).trim();
  const url = new URL(request.url);
  return url.searchParams.get("api_key");
}

function authed(request: Request): boolean {
  const expected = process.env.PICKER_API_KEY;
  if (!expected) return false;
  const given = extractKey(request);
  if (!given || given.length !== expected.length) return false;
  // constant-time compare
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected.charCodeAt(i) ^ given.charCodeAt(i);
  return diff === 0;
}

function admin() {
  const url = process.env.SUPABASE_URL!;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

export const Route = createFileRoute("/api/public/picker")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),

      GET: async ({ request }) => {
        if (!authed(request)) return json({ error: "Unauthorized" }, 401);
        const url = new URL(request.url);
        const resource = url.searchParams.get("resource") ?? "pending";
        const mode = (url.searchParams.get("mode") ?? "all") as "trims" | "fabric" | "all";
        const sb = admin();

        if (resource === "pending") {
          const cols = "id,production_order,order_description,order_qty,picker_name,picker_epf,picker_date,cut_date,start_date,work_center";
          const q = async (t: "trims_plan" | "fabric_plan") =>
            (await sb.from(t).select(cols).is("picker_name", null).order("production_order").limit(1000)).data ?? [];
          const trims = mode !== "fabric" ? await q("trims_plan") : [];
          const fabric = mode !== "trims" ? await q("fabric_plan") : [];
          return json({ trims, fabric });
        }

        if (resource === "achievements") {
          const since = url.searchParams.get("since");
          const sinceIso = since ?? new Date(new Date().setHours(0, 0, 0, 0)).toISOString();
          const q = async (t: "picker_achievements" | "fabric_picker_achievements") =>
            (await sb.from(t).select("*").gte("picked_at", sinceIso).order("picked_at", { ascending: false }).limit(2000)).data ?? [];
          const trims = mode !== "fabric" ? await q("picker_achievements") : [];
          const fabric = mode !== "trims" ? await q("fabric_picker_achievements") : [];
          return json({ since: sinceIso, trims, fabric });
        }

        if (resource === "targets") {
          const [t, f] = await Promise.all([
            sb.from("picker_targets").select("epf_number,name,gin_target_per_day,is_active"),
            sb.from("fabric_picker_targets").select("epf_number,name,gin_target_per_day,is_active"),
          ]);
          return json({ trims: t.data ?? [], fabric: f.data ?? [] });
        }

        return json({ error: "Unknown resource. Use: pending | achievements | targets" }, 400);
      },

      POST: async ({ request }) => {
        if (!authed(request)) return json({ error: "Unauthorized" }, 401);
        let body: { epf?: string; po?: string; mode?: "trims" | "fabric" };
        try { body = await request.json(); } catch { return json({ error: "Invalid JSON body" }, 400); }
        const epf = (body.epf ?? "").toString().trim();
        const po = (body.po ?? "").toString().trim();
        if (!epf) return json({ error: "epf is required" }, 400);
        if (!po) return json({ error: "po is required" }, 400);

        const sb = admin();
        let mode = body.mode ?? null;

        // Prefer a pending row (picker_name IS NULL); fall back to any row.
        // Order by picker_name nulls first, then limit(1) — safe even with duplicate POs.
        const lookup = async (t: "trims_plan" | "fabric_plan") => {
          const r = await sb
            .from(t)
            .select("id,picker_name,picker_date,production_order")
            .eq("production_order", po)
            .order("picker_name", { ascending: true, nullsFirst: true })
            .limit(1);
          if (r.error) throw new Error(`${t}: ${r.error.message}`);
          return (r.data && r.data[0]) || null;
        };

        let match: { id: string; picker_name: string | null; picker_date?: string | null } | null = null;
        try {
          if (mode) {
            match = await lookup(mode === "trims" ? "trims_plan" : "fabric_plan");
          } else {
            const [t, f] = await Promise.all([lookup("trims_plan"), lookup("fabric_plan")]);
            if (t && !t.picker_name) { mode = "trims"; match = t; }
            else if (f && !f.picker_name) { mode = "fabric"; match = f; }
            else if (t) { mode = "trims"; match = t; }
            else if (f) { mode = "fabric"; match = f; }
          }
        } catch (e) {
          return json({ error: (e as Error).message }, 500);
        }

        if (!match || !mode) return json({ error: "PO not found in active Trims or Fabric Plan" }, 404);
        if (match.picker_name) {
          return json({
            error: "Already picked",
            picked_by: match.picker_name,
            picked_at: match.picker_date ?? null,
            mode,
          }, 409);
        }

        const targetsTable = mode === "trims" ? "picker_targets" : "fabric_picker_targets";
        const { data: target } = await sb.from(targetsTable).select("name").ilike("epf_number", epf).maybeSingle();
        const displayName = target?.name ?? epf;
        const now = new Date().toISOString();
        const planTable = mode === "trims" ? "trims_plan" : "fabric_plan";
        const achTable = mode === "trims" ? "picker_achievements" : "fabric_picker_achievements";

        const [uRes, iRes] = await Promise.all([
          sb.from(planTable).update({ picker_epf: epf, picker_name: displayName, picker_date: now }).eq("id", match.id),
          sb.from(achTable).insert({ epf_number: epf, picker_name: displayName, po_number: po, plan_id: match.id, picked_at: now }),
        ]);
        if (uRes.error) return json({ error: `plan update: ${uRes.error.message}` }, 500);
        if (iRes.error) return json({ error: `achievement insert: ${iRes.error.message}` }, 500);

        return json({ ok: true, mode, po, epf, picker_name: displayName, picked_at: now, plan_id: match.id });
      },
    },
  },
});
