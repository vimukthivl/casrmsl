import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import { assistantPasswordMatches, needsAssistantPassword } from "@/lib/assistant-access";

type ChatMsg = { role: "system" | "user" | "assistant"; content: string };

async function buildLiveContext(): Promise<string> {
  try {
    const url = process.env.SUPABASE_URL;
    const anon = process.env.SUPABASE_PUBLISHABLE_KEY;
    if (!url || !anon) return "";
    const sb = createClient(url, anon, { auth: { persistSession: false } });

    const now = new Date();
    const iso = (d: Date) => d.toISOString().slice(0, 10);
    const today = iso(now);
    const yest = iso(new Date(now.getTime() - 86400000));
    const weekAgo = iso(new Date(now.getTime() - 7 * 86400000));
    const monthAgo = iso(new Date(now.getTime() - 30 * 86400000));

    const [
      vehicles,
      vehiclesRecent,
      invoiceToday,
      invoiceRecent,
      greenRecent,
      trimsDown,
      fabricDown,
      pickerAch,
      fabricPickerAch,
      pickerTargets,
      fabricPickerTargets,
      trimsPlan,
      fabricPlan,
      ccActuals,
      ccTargets,
      heldRates,
      settings,
    ] = await Promise.all([
      sb
        .from("vehicle_logs")
        .select(
          "token_no,vehicle_number,vehicle_type,driver_name,vendor_name,material_type,relevant_pcu,current_status,bay_id,in_time,unload_start_time,unload_end_time,out_time,is_held_up,roll_qty,box_qty,manually_unloaded_qty,hold_reason",
        )
        .in("current_status", ["in_bay", "unloading", "on_hold", "checked_in", "queued"])
        .limit(80),
      sb
        .from("vehicle_logs")
        .select("token_no,vehicle_number,vehicle_type,vendor_name,material_type,current_status,in_time,out_time,is_held_up,roll_qty,box_qty")
        .gte("in_time", weekAgo)
        .limit(300),
      sb.from("invoice_daily_log").select("*").eq("log_date", today).maybeSingle(),
      sb.from("invoice_daily_log").select("*").gte("log_date", weekAgo).order("log_date", { ascending: false }).limit(14),
      sb.from("green_board_entries").select("board_key,note,entry_date").gte("entry_date", weekAgo).limit(200),
      sb.from("trims_downtime").select("entry_date,concern,lost_hours,notes").gte("entry_date", weekAgo).order("entry_date", { ascending: false }).limit(100),
      sb.from("fabric_downtime").select("entry_date,concern,lost_hours,notes").gte("entry_date", weekAgo).order("entry_date", { ascending: false }).limit(100),
      sb.from("picker_achievements").select("epf_number,picker_name,po_number,picked_at").gte("picked_at", weekAgo).limit(500),
      sb.from("fabric_picker_achievements").select("epf_number,picker_name,po_number,picked_at").gte("picked_at", weekAgo).limit(500),
      sb.from("picker_targets").select("epf_number,name,gin_target_per_day,is_active").eq("is_active", true).limit(100),
      sb.from("fabric_picker_targets").select("epf_number,name,gin_target_per_day,is_active").eq("is_active", true).limit(100),
      sb.from("trims_plan").select("production_order,order_qty,picker_name,picker_date,cut_date").gte("cut_date", weekAgo).limit(200),
      sb.from("fabric_plan").select("production_order,order_qty,picker_name,picker_date,cut_date").gte("cut_date", weekAgo).limit(200),
      sb.from("cc_daily_actuals").select("warehouse,item_code,counted_qty,entry_date").gte("entry_date", monthAgo).limit(500),
      sb.from("cc_monthly_targets").select("*").limit(50),
      sb.from("held_up_rates").select("*"),
      sb.from("admin_settings").select("*").limit(1).maybeSingle(),
    ]);

    const v = vehicles.data ?? [];
    const unloading = v.filter((x) => x.current_status === "unloading");
    const inBay = v.filter((x) => x.current_status === "in_bay" || x.current_status === "unloading");
    const held = v.filter((x) => x.is_held_up);

    const vLine = (x: (typeof v)[number]) =>
      `#${x.token_no ?? "-"} ${x.vehicle_number ?? ""} (${x.vehicle_type ?? "-"}) ${x.relevant_pcu ?? x.material_type ?? ""} bay=${x.bay_id ?? "-"} status=${x.current_status}${x.is_held_up ? " HELD" : ""}${x.hold_reason ? ` reason="${x.hold_reason}"` : ""}`;

    const sumBy = <T,>(arr: T[], key: (t: T) => string, val: (t: T) => number) => {
      const m = new Map<string, number>();
      for (const it of arr) m.set(key(it), (m.get(key(it)) ?? 0) + val(it));
      return m;
    };

    const fmtMap = (m: Map<string, number>, top = 10) =>
      [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, top).map(([k, v]) => `${k}=${v}`).join(", ") || "none";

    const trimsDownByDay = sumBy(trimsDown.data ?? [], (r) => r.entry_date, (r) => Number(r.lost_hours) || 0);
    const fabricDownByDay = sumBy(fabricDown.data ?? [], (r) => r.entry_date, (r) => Number(r.lost_hours) || 0);
    const trimsDownByReason = sumBy(trimsDown.data ?? [], (r) => r.concern, (r) => Number(r.lost_hours) || 0);
    const fabricDownByReason = sumBy(fabricDown.data ?? [], (r) => r.concern, (r) => Number(r.lost_hours) || 0);

    const pickToday = (arr: { picked_at: string; picker_name: string | null; epf_number: string }[]) =>
      sumBy(arr.filter((r) => (r.picked_at ?? "").slice(0, 10) === today), (r) => `${r.picker_name ?? r.epf_number}`, () => 1);
    const pickYest = (arr: { picked_at: string; picker_name: string | null; epf_number: string }[]) =>
      sumBy(arr.filter((r) => (r.picked_at ?? "").slice(0, 10) === yest), (r) => `${r.picker_name ?? r.epf_number}`, () => 1);

    const ta = pickerAch.data ?? [];
    const fa = fabricPickerAch.data ?? [];

    const greenByDay = sumBy(greenRecent.data ?? [], (r) => r.entry_date, () => 1);
    const greenByArea = sumBy(greenRecent.data ?? [], (r) => r.board_key ?? "unknown", () => 1);

    const vRecent = vehiclesRecent.data ?? [];
    const vehiclesByDay = sumBy(vRecent, (r) => (r.in_time ?? "").slice(0, 10), () => 1);
    const rollsByDay = sumBy(vRecent, (r) => (r.in_time ?? "").slice(0, 10), (r) => Number(r.roll_qty) || 0);
    const boxesByDay = sumBy(vRecent, (r) => (r.in_time ?? "").slice(0, 10), (r) => Number(r.box_qty) || 0);

    const ccByWh = sumBy(ccActuals.data ?? [], (r) => `${r.warehouse}`, (r) => Number(r.counted_qty) || 0);

    const lines: string[] = [];
    lines.push(`LIVE_SYSTEM_CONTEXT (as of ${now.toISOString()}, today=${today}, yesterday=${yest}):`);
    lines.push(`--- VEHICLES (live) ---`);
    lines.push(`UNLOADING now (${unloading.length}): ${unloading.map(vLine).join(" | ") || "none"}`);
    lines.push(`In bays / active (${inBay.length}): ${inBay.map(vLine).join(" | ") || "none"}`);
    lines.push(`Held-up (${held.length}): ${held.map(vLine).join(" | ") || "none"}`);
    lines.push(`--- VEHICLES last 7 days ---`);
    lines.push(`Count by day: ${fmtMap(vehiclesByDay)}`);
    lines.push(`Rolls by day: ${fmtMap(rollsByDay)}`);
    lines.push(`Boxes by day: ${fmtMap(boxesByDay)}`);

    lines.push(`--- INVOICE GRN LOG ---`);
    if (invoiceToday.data) {
      lines.push(`Today: fabric ${invoiceToday.data.fabric_completed ?? 0}/${invoiceToday.data.fabric_received ?? 0}, trims ${invoiceToday.data.trims_completed ?? 0}/${invoiceToday.data.trims_received ?? 0}`);
    } else lines.push(`Today: no entry yet`);
    for (const r of invoiceRecent.data ?? []) {
      lines.push(`${r.log_date}: fabric ${r.fabric_completed ?? 0}/${r.fabric_received ?? 0}, trims ${r.trims_completed ?? 0}/${r.trims_received ?? 0}`);
    }

    lines.push(`--- DOWNTIME (last 7 days, lost hours) ---`);
    lines.push(`TRIMS by day: ${fmtMap(trimsDownByDay)}`);
    lines.push(`TRIMS by reason: ${fmtMap(trimsDownByReason)}`);
    lines.push(`FABRIC by day: ${fmtMap(fabricDownByDay)}`);
    lines.push(`FABRIC by reason: ${fmtMap(fabricDownByReason)}`);
    const trimsYestRows = (trimsDown.data ?? []).filter((r) => r.entry_date === yest);
    const fabricYestRows = (fabricDown.data ?? []).filter((r) => r.entry_date === yest);
    lines.push(`TRIMS yesterday detail: ${trimsYestRows.map((r) => `${r.concern}=${r.lost_hours}h${r.notes ? ` (${r.notes})` : ""}`).join(" | ") || "none"}`);
    lines.push(`FABRIC yesterday detail: ${fabricYestRows.map((r) => `${r.concern}=${r.lost_hours}h${r.notes ? ` (${r.notes})` : ""}`).join(" | ") || "none"}`);

    lines.push(`--- PICKER PERFORMANCE ---`);
    lines.push(`Trims picks today: ${fmtMap(pickToday(ta))}`);
    lines.push(`Trims picks yesterday: ${fmtMap(pickYest(ta))}`);
    lines.push(`Fabric picks today: ${fmtMap(pickToday(fa))}`);
    lines.push(`Fabric picks yesterday: ${fmtMap(pickYest(fa))}`);
    lines.push(`Active trims pickers: ${(pickerTargets.data ?? []).map((p) => `${p.name}(${p.epf_number},tgt${p.gin_target_per_day})`).join(", ") || "none"}`);
    lines.push(`Active fabric pickers: ${(fabricPickerTargets.data ?? []).map((p) => `${p.name}(${p.epf_number},tgt${p.gin_target_per_day})`).join(", ") || "none"}`);

    lines.push(`--- PLANS (last 7 days) ---`);
    lines.push(`Trims plan rows: ${(trimsPlan.data ?? []).length}, Fabric plan rows: ${(fabricPlan.data ?? []).length}`);

    lines.push(`--- GREEN BOARD (last 7 days) ---`);
    lines.push(`By day: ${fmtMap(greenByDay)}`);
    lines.push(`By area: ${fmtMap(greenByArea)}`);
    const gToday = (greenRecent.data ?? []).filter((g) => g.entry_date === today);
    lines.push(`Today entries (${gToday.length}): ${gToday.map((g) => `${g.board_key}:${(g.note ?? "").slice(0, 60)}`).join(" | ") || "none"}`);

    lines.push(`--- CYCLE COUNTING (last 30 days counted qty) ---`);
    lines.push(`By warehouse: ${fmtMap(ccByWh)}`);
    lines.push(`Monthly targets: ${(ccTargets.data ?? []).length} rows configured`);

    lines.push(`--- ADMIN CONFIG ---`);
    if (settings.data) {
      lines.push(`Shift ${settings.data.shift_start}-${settings.data.shift_end}, daily roll target ${settings.data.daily_roll_target}, daily box target ${settings.data.daily_box_target}`);
    }
    lines.push(`Held-up rates: ${(heldRates.data ?? []).map((r) => `${r.vehicle_size}=Rs.${r.rate_per_hour}/h`).join(", ") || "none"}`);

    return lines.join("\n");
  } catch (e) {
    return `LIVE_SYSTEM_CONTEXT unavailable: ${(e as Error).message}`;
  }
}

const READ_TABLES = [
  "vehicle_logs",
  "invoice_daily_log",
  "green_board_entries",
  "green_board_concerns",
  "trims_downtime",
  "fabric_downtime",
  "trims_plan",
  "fabric_plan",
  "picker_targets",
  "fabric_picker_targets",
  "picker_achievements",
  "fabric_picker_achievements",
  "cc_monthly_targets",
  "cc_daily_actuals",
  "admin_settings",
  "held_up_rates",
  "pending_invoices",
] as const;

const TOOLS = [
  {
    type: "function",
    function: {
      name: "read_table",
      description:
        "Read any table in the system for deeper analysis when LIVE_SYSTEM_CONTEXT is not enough. Returns rows as JSON.",
      parameters: {
        type: "object",
        properties: {
          table: { type: "string", description: `One of: ${READ_TABLES.join(", ")}` },
          date_column: { type: "string", description: "Optional date/timestamp column to filter on" },
          from_date: { type: "string", description: "YYYY-MM-DD inclusive lower bound" },
          to_date: { type: "string", description: "YYYY-MM-DD inclusive upper bound" },
          limit: { type: "number" },
        },
        required: ["table"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_invoice_log",
      description: "Create or update the Daily Invoice GRN Completion Log for a date.",
      parameters: {
        type: "object",
        properties: {
          log_date: { type: "string", description: "YYYY-MM-DD" },
          fabric_received: { type: "number" },
          fabric_completed: { type: "number" },
          trims_received: { type: "number" },
          trims_completed: { type: "number" },
        },
        required: ["log_date"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "add_green_board_entry",
      description:
        "Log a Green Board issue/note for an area, date and shift. Creates the concern if it does not exist.",
      parameters: {
        type: "object",
        properties: {
          board_key: {
            type: "string",
            description: "rm_grn | rm_kanban | rm_sau | rm_fabric_picking | rm_trims_picking",
          },
          concern: { type: "string", description: "Concern / issue label" },
          entry_date: { type: "string", description: "YYYY-MM-DD" },
          shift: { type: "string", description: "A or B" },
          note: { type: "string" },
        },
        required: ["board_key", "concern", "entry_date", "shift", "note"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "log_downtime",
      description: "Add a trims or fabric downtime record (lost hours against a concern).",
      parameters: {
        type: "object",
        properties: {
          area: { type: "string", description: "trims | fabric" },
          entry_date: { type: "string", description: "YYYY-MM-DD" },
          concern: { type: "string" },
          lost_hours: { type: "number" },
          notes: { type: "string" },
        },
        required: ["area", "entry_date", "concern", "lost_hours"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "set_vehicle_hold",
      description: "Put a vehicle on hold or release it, by token number or vehicle number.",
      parameters: {
        type: "object",
        properties: {
          token_no: { type: "string" },
          vehicle_number: { type: "string" },
          hold: { type: "boolean" },
          reason: { type: "string" },
        },
        required: ["hold"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_admin_settings",
      description: "Update shift times and daily roll/box targets in admin settings.",
      parameters: {
        type: "object",
        properties: {
          shift_start: { type: "string", description: "HH:MM" },
          shift_end: { type: "string", description: "HH:MM" },
          daily_roll_target: { type: "number" },
          daily_box_target: { type: "number" },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "update_held_up_rate",
      description: "Set the demurrage rate per hour for a vehicle size (e.g. 20Ft, 40Ft, Other).",
      parameters: {
        type: "object",
        properties: {
          vehicle_size: { type: "string" },
          rate_per_hour: { type: "number" },
        },
        required: ["vehicle_size", "rate_per_hour"],
      },
    },
  },
] as const;

type Args = Record<string, unknown>;

async function runTool(name: string, args: Args, passwordVerified: boolean): Promise<unknown> {
  if (needsAssistantPassword(name, passwordVerified)) return { error: "Change password required" };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const sb = supabaseAdmin as unknown as {
    from: (t: string) => any;
  };

  switch (name) {
    case "read_table": {
      const table = String(args.table ?? "");
      if (!(READ_TABLES as readonly string[]).includes(table)) {
        return { error: `Table not allowed. Allowed: ${READ_TABLES.join(", ")}` };
      }
      let q = sb.from(table).select("*").limit(Math.min(Number(args.limit) || 200, 500));
      const col = args.date_column ? String(args.date_column) : "";
      if (col && args.from_date) q = q.gte(col, String(args.from_date));
      if (col && args.to_date) q = q.lte(col, String(args.to_date));
      const { data, error } = await q;
      return error ? { error: error.message } : { rows: data };
    }

    case "update_invoice_log": {
      const payload: Args = { log_date: String(args.log_date) };
      for (const k of ["fabric_received", "fabric_completed", "trims_received", "trims_completed"]) {
        if (args[k] !== undefined) payload[k] = Number(args[k]);
      }
      const { data, error } = await sb
        .from("invoice_daily_log")
        .upsert(payload, { onConflict: "log_date" })
        .select()
        .maybeSingle();
      return error ? { error: error.message } : { ok: true, row: data };
    }

    case "add_green_board_entry": {
      const board_key = String(args.board_key);
      const label = String(args.concern);
      let concernId: string | null = null;
      const { data: existing } = await sb
        .from("green_board_concerns")
        .select("id,label")
        .eq("board_key", board_key)
        .ilike("label", label)
        .maybeSingle();
      if (existing?.id) concernId = existing.id;
      else {
        const { data: created, error: cErr } = await sb
          .from("green_board_concerns")
          .insert({ board_key, label, is_active: true })
          .select("id")
          .single();
        if (cErr) return { error: cErr.message };
        concernId = created.id;
      }
      const { error } = await sb.from("green_board_entries").upsert(
        {
          concern_id: concernId,
          board_key,
          entry_date: String(args.entry_date),
          shift: String(args.shift ?? "A").toUpperCase(),
          note: String(args.note ?? ""),
        },
        { onConflict: "concern_id,entry_date,board_key,shift" },
      );
      return error ? { error: error.message } : { ok: true, concern: label };
    }

    case "log_downtime": {
      const table = String(args.area).toLowerCase() === "fabric" ? "fabric_downtime" : "trims_downtime";
      const { error } = await sb.from(table).insert({
        entry_date: String(args.entry_date),
        concern: String(args.concern),
        lost_hours: Number(args.lost_hours) || 0,
        notes: args.notes ? String(args.notes) : null,
      });
      return error ? { error: error.message } : { ok: true, table };
    }

    case "set_vehicle_hold": {
      const hold = Boolean(args.hold);
      let q = sb.from("vehicle_logs").update({
        is_held_up: hold,
        hold_reason: hold ? String(args.reason ?? "Held by assistant") : null,
      });
      if (args.token_no) q = q.eq("token_no", String(args.token_no));
      else if (args.vehicle_number) q = q.ilike("vehicle_number", `%${String(args.vehicle_number)}%`);
      else return { error: "token_no or vehicle_number required" };
      const { data, error } = await q.select("token_no,vehicle_number,is_held_up");
      return error ? { error: error.message } : { ok: true, updated: data };
    }

    case "update_admin_settings": {
      const { data: row } = await sb.from("admin_settings").select("id").limit(1).maybeSingle();
      const patch: Args = {};
      for (const k of ["shift_start", "shift_end"]) if (args[k] !== undefined) patch[k] = String(args[k]);
      for (const k of ["daily_roll_target", "daily_box_target"])
        if (args[k] !== undefined) patch[k] = Number(args[k]);
      if (Object.keys(patch).length === 0) return { error: "nothing to update" };
      const { error } = row?.id
        ? await sb.from("admin_settings").update(patch).eq("id", row.id)
        : await sb.from("admin_settings").insert(patch);
      return error ? { error: error.message } : { ok: true, patch };
    }

    case "update_held_up_rate": {
      const { error } = await sb.from("held_up_rates").upsert(
        { vehicle_size: String(args.vehicle_size), rate_per_hour: Number(args.rate_per_hour) },
        { onConflict: "vehicle_size" },
      );
      return error ? { error: error.message } : { ok: true };
    }

    default:
      return { error: `Unknown tool ${name}` };
  }
}

type ToolCall = { id: string; type: "function"; function: { name: string; arguments: string } };
type AnyMsg = ChatMsg | { role: "assistant"; content: string | null; tool_calls?: ToolCall[] } | {
  role: "tool";
  tool_call_id: string;
  content: string;
};

export const Route = createFileRoute("/api/ai-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const body = (await request.json()) as { messages?: ChatMsg[]; page?: string; changePassword?: string };
        if (!Array.isArray(body.messages)) {
          return new Response("messages required", { status: 400 });
        }
        let passwordVerified = false;
        if (body.changePassword !== undefined) {
          const expected = process.env.AI_ASSISTANT_CHANGE_PASSWORD;
          if (!expected) return Response.json({ reply: "Change protection is unavailable. No changes were made." }, { status: 503 });
          passwordVerified = typeof body.changePassword === "string" && await assistantPasswordMatches(body.changePassword, expected);
          if (!passwordVerified) return Response.json({ reply: "Incorrect change password. No changes were made.", requiresPassword: true }, { status: 403, headers: { "Cache-Control": "no-store" } });
        }

        const liveCtx = await buildLiveContext();

        const system: ChatMsg = {
          role: "system",
          content:
            "You are RMWH Logistics Assistant for the MAS Casualline Logistics 360 app. " +
            "CREDIT: This chatbot and the entire Casualline Logistics 360 system were fully developed by Vimukthi Lakshan (Phone: 0763539228, Email: vimukthisen@masholdings.com / vimukthi.lakshan@hotmail.com). Whenever anyone asks who developed/built/created/made this system or chatbot (English or Sinhala, e.g. 'kaui hduwe', 'who developed this', 'developer kauda', 'මේක හැදුවේ කවුද'), reply clearly: developed by Vimukthi Lakshan and include the contact details (phone + both emails). " +
            "You have FULL READ ACCESS to every dashboard and dataset (Logistics, Trims, Fabric and Management dashboards) via LIVE_SYSTEM_CONTEXT below, plus the read_table tool for anything deeper or older. " +
            "You can make PASSWORD-PROTECTED record updates only through these supported tools: update_invoice_log, add_green_board_entry, log_downtime, set_vehicle_hold, update_admin_settings, update_held_up_rate. You cannot edit the app's source code, layouts, permissions, or deploy updates. Never claim 100% access or unsupported capabilities. Passwords must be entered only in the dedicated password field, never ask users to type them into chat. " +
            "WRITE RULES: when a user asks for a change, first confirm the exact values in one short sentence if anything is ambiguous (date, shift, area, quantity); otherwise perform the change immediately, then state exactly what was updated with the values. Never invent numbers the user did not give. Today's date is in LIVE_SYSTEM_CONTEXT — use it when the user says 'today'/'ada'. Default shift to A only if the user did not specify. " +
            "Use read_table when a question needs data beyond the summary (older dates, full row detail, per-item cycle counting, plan rows). Do the arithmetic yourself (sum hours, compute %, rank pickers). " +
            "You are BILINGUAL — detect the user's language (English or Sinhala, including romanized Singlish) and reply in the SAME language. Keep answers short, specific, friendly, with numbers." +
            (body.page ? `\n\nThe user is currently on page: ${body.page}` : "") +
            "\n\n" +
            liveCtx,
        };

        const convo: AnyMsg[] = [system, ...body.messages.filter((m) => m.role === "user" || m.role === "assistant")];

        for (let step = 0; step < 6; step++) {
          const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify({
              model: "google/gemini-2.5-flash",
              messages: convo,
              tools: TOOLS,
            }),
          });

          if (!res.ok) {
            const text = await res.text();
            return new Response(text, { status: res.status });
          }

          const data = (await res.json()) as {
            choices?: { message?: { content?: string | null; tool_calls?: ToolCall[] } }[];
          };
          const msg = data.choices?.[0]?.message;
          const calls = msg?.tool_calls ?? [];

          if (calls.length === 0) {
            return new Response(JSON.stringify({ reply: msg?.content ?? "" }), {
              headers: { "content-type": "application/json" },
            });
          }

          convo.push({ role: "assistant", content: msg?.content ?? null, tool_calls: calls });

          if (calls.some((c) => needsAssistantPassword(c.function.name, passwordVerified))) {
            return Response.json({ reply: "Enter the change password to authorize this request. No changes have been made.", requiresPassword: true }, { headers: { "Cache-Control": "no-store" } });
          }

          for (const c of calls) {
            let result: unknown;
            try {
              const parsed = c.function.arguments ? (JSON.parse(c.function.arguments) as Args) : {};
              result = await runTool(c.function.name, parsed, passwordVerified);
            } catch (e) {
              result = { error: (e as Error).message };
            }
            convo.push({
              role: "tool",
              tool_call_id: c.id,
              content: JSON.stringify(result).slice(0, 8000),
            });
          }
        }

        return new Response(
          JSON.stringify({ reply: "I couldn't finish that request — please try again with fewer steps." }),
          { headers: { "content-type": "application/json" } },
        );
      },
    },
  },
});

