import { createFileRoute } from "@tanstack/react-router";

type Role = "admin" | "pcu" | "guard" | "grn" | "tv" | "rm_gl";

const ROLE_META: Record<Role, { name: string; allowed_pages: string[] }> = {
  admin: {
    name: "System Admin",
    allowed_pages: ["dashboard", "pcu_schedule", "guard_room", "bay_management", "rm_grn_team", "green_board", "tv_display", "vehicle_update", "admin_settings"],
  },
  pcu: { name: "PCU Officer", allowed_pages: ["dashboard", "pcu_schedule", "tv_display"] },
  guard: { name: "Guard Room", allowed_pages: ["guard_room"] },
  grn: { name: "RM GRN Team", allowed_pages: ["bay_management", "rm_grn_team", "tv_display", "green_board"] },
  tv: { name: "TV Kiosk", allowed_pages: ["tv_display"] },
  rm_gl: { name: "RM GL Viewer", allowed_pages: ["green_board", "tv_display"] },
};

export const Route = createFileRoute("/api/user-session")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const roleParam = (url.searchParams.get("role") || "").toLowerCase() as Role;
        const meta = ROLE_META[roleParam];
        if (!meta) {
          return Response.json(
            { status: "error", message: "Unknown or missing role" },
            { status: 400 },
          );
        }
        return Response.json({
          status: "success",
          user: {
            name: meta.name,
            role: roleParam,
            allowed_pages: meta.allowed_pages,
          },
        });
      },
    },
  },
});
