import { createFileRoute } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { SegregationReportForm } from "@/components/SegregationArea";
import { Leaf, Send, CheckCircle2, Plus } from "lucide-react";

export const Route = createFileRoute("/report")({
  head: () => ({
    meta: [
      { title: "Green Board Issue Report Form — Casualline Logistics 360" },
      {
        name: "description",
        content:
          "Submit daily operational concerns and supplier issues for all RM Green Board areas, including Segregation Area.",
      },
      { property: "og:title", content: "Green Board Issue Report Form" },
      {
        property: "og:description",
        content: "Log operational concerns and Segregation supplier issues for Casualline RM areas — no login required.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReportPage,
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

const BOARDS = [
  { key: "grn", label: "RM GRN" },
  { key: "kanban", label: "RM Kanban Area" },
  { key: "picking", label: "RM SAU Area" },
  { key: "fabric", label: "RM Fabric Picking & Issuing" },
  { key: "trims", label: "RM Trims Picking" },
  { key: "segregation", label: "Segregation Area" },
];

interface Concern {
  id: string;
  label: string;
  sort_order: number;
  board_key: string;
}

function todayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function fmt(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function weekStartStr() {
  const d = new Date();
  const day = (d.getDay() + 6) % 7; // Monday = 0
  d.setDate(d.getDate() - day);
  return fmt(d);
}

function monthStartStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

type ShiftCounts = { day: number; week: number; month: number };
const EMPTY_COUNTS: ShiftCounts = { day: 0, week: 0, month: 0 };


function ReportPage() {
  const [boardKey, setBoardKey] = useState("grn");
  const [concerns, setConcerns] = useState<Concern[]>([]);
  const [loading, setLoading] = useState(true);
  const [concernId, setConcernId] = useState("");
  const [date, setDate] = useState(todayStr());
  const [shift, setShift] = useState<"A" | "B">("A");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [newConcern, setNewConcern] = useState("");
  const [adding, setAdding] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [statsKey, setStatsKey] = useState(0);
  const [stats, setStats] = useState<{ A: ShiftCounts; B: ShiftCounts }>({ A: EMPTY_COUNTS, B: EMPTY_COUNTS });


  const board = useMemo(() => BOARDS.find((b) => b.key === boardKey) ?? BOARDS[0], [boardKey]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    sb.from("green_board_concerns")
      .select("*")
      .eq("is_active", true)
      .eq("board_key", boardKey)
      .order("sort_order", { ascending: true })
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .then((res: any) => {
        if (cancelled) return;
        setConcerns((res.data ?? []) as Concern[]);
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [boardKey, reloadKey]);

  useEffect(() => {
    let cancelled = false;
    const mStart = monthStartStr();
    const wStart = weekStartStr();
    const today = todayStr();
    sb.from("green_board_entries")
      .select("entry_date,shift,concern_id")
      .eq("board_key", boardKey)
      .gte("entry_date", mStart)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      .then((res: any) => {
        if (cancelled) return;
        const rows = (res.data ?? []) as { entry_date: string; shift: string | null }[];
        const build = (s: "A" | "B"): ShiftCounts => {
          const mine = rows.filter((r) => (r.shift ?? "A") === s);
          return {
            day: mine.filter((r) => r.entry_date === today).length,
            week: mine.filter((r) => r.entry_date >= wStart).length,
            month: mine.length,
          };
        };
        setStats({ A: build("A"), B: build("B") });
      });
    return () => {
      cancelled = true;
    };
  }, [boardKey, reloadKey, statsKey]);

  useEffect(() => {
    setConcernId("");
  }, [boardKey]);


  const addConcern = async () => {
    const label = newConcern.trim();
    if (!label) return toast.error("Type the concern name first.");
    if (concerns.some((c) => c.label.toLowerCase() === label.toLowerCase())) {
      return toast.error("That concern already exists for this area.");
    }
    setAdding(true);
    const nextOrder = (concerns.at(-1)?.sort_order ?? 0) + 10;
    const { data, error } = await sb
      .from("green_board_concerns")
      .insert({ label, sort_order: nextOrder, board_key: boardKey })
      .select("id")
      .maybeSingle();
    setAdding(false);
    if (error) return toast.error(error.message);
    toast.success("Concern added");
    setNewConcern("");
    setShowAdd(false);
    setReloadKey((k) => k + 1);
    if (data?.id) setConcernId(data.id as string);
  };

  const submit = async () => {
    if (saving) return;
    if (!concernId) return toast.error("Please select a concern.");
    const text = note.trim();
    if (!text) return toast.error("Please describe the issue.");
    setSaving(true);

    try {
      const { error } = await sb.rpc("submit_green_board_report", {
        p_concern_id: concernId,
        p_entry_date: date,
        p_board_key: boardKey,
        p_shift: shift,
        p_note: text,
      });
      if (error) throw error;
    } catch (error) {
      toast.error(error instanceof Error ? error.message : (error as { message?: string })?.message ?? "Submission failed. Please try again.");
      return;
    } finally {
      setSaving(false);
    }
    toast.success(`Submitted — Green Board updated (Shift ${shift})`);
    setNote("");
    setDone(true);
    setStatsKey((k) => k + 1);
    setTimeout(() => setDone(false), 3500);

  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50/50 px-4 py-8">
      <div className="mx-auto w-full max-w-2xl">
        <header className="mb-6 flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-emerald-600 text-white grid place-items-center shadow-lg">
            <Leaf className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl md:text-3xl font-black uppercase tracking-tight text-slate-900 leading-none">
              Green Board Report
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              Fill the form — it syncs straight to the Green Board. No login needed.
            </p>
          </div>
        </header>

        {/* Area selector = 5 forms */}
        <div className="mb-4 grid grid-cols-1 sm:grid-cols-2 gap-2 rounded-xl border bg-white p-2 shadow-sm">
          {BOARDS.map((b) => (
            <button
              key={b.key}
              onClick={() => setBoardKey(b.key)}
              className={`px-4 py-2.5 rounded-lg text-sm font-semibold text-left transition-colors ${
                b.key === boardKey ? "bg-emerald-600 text-white shadow" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {b.label}
            </button>
          ))}
        </div>




        {boardKey === "segregation" ? <SegregationReportForm /> : (<>
        <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
          <div className="px-5 py-3 bg-slate-900 text-white text-sm font-bold uppercase tracking-wide">
            {board.label} — Issue Form
          </div>
          <div className="p-5 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold uppercase text-slate-500 mb-1.5 block">Date</label>
                <input
                  type="date"
                  value={date}
                  max={todayStr()}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="text-xs font-semibold uppercase text-slate-500 mb-1.5 block">Shift</label>
                <div className="flex gap-2">
                  {(["A", "B"] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => setShift(s)}
                      className={`flex-1 px-3 py-2 rounded-md text-sm font-bold border transition-colors ${
                        shift === s
                          ? "bg-emerald-600 border-emerald-600 text-white shadow"
                          : "bg-white border-slate-300 text-slate-600 hover:bg-slate-50"
                      }`}
                    >
                      {shift === s ? "✓ " : ""}Shift {s}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-semibold uppercase text-slate-500">Concern / Issue</label>
                <button
                  type="button"
                  onClick={() => setShowAdd((v) => !v)}
                  className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" /> {showAdd ? "Cancel" : "Add new"}
                </button>
              </div>
              <select
                value={concernId}
                onChange={(e) => setConcernId(e.target.value)}
                disabled={loading || concerns.length === 0}
                className="w-full px-3 py-2 border rounded-md text-sm bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="">
                  {loading ? "Loading…" : concerns.length ? "Select a concern…" : "No concerns set for this area"}
                </option>
                {concerns.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
              {showAdd && (
                <div className="mt-2 flex gap-2">
                  <input
                    value={newConcern}
                    onChange={(e) => setNewConcern(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") addConcern(); }}
                    placeholder={`New concern for ${board.label}`}
                    className="flex-1 px-3 py-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button
                    type="button"
                    onClick={addConcern}
                    disabled={adding}
                    className="px-4 py-2 rounded-md bg-slate-900 hover:bg-slate-800 disabled:opacity-60 text-white text-sm font-semibold"
                  >
                    {adding ? "Adding…" : "Add"}
                  </button>
                </div>
              )}
            </div>


            <div>
              <label className="text-xs font-semibold uppercase text-slate-500 mb-1.5 block">What happened?</label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={5}
                placeholder="Describe the issue…"
                className="w-full px-3 py-2 border rounded-md text-sm resize-none focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <p className="mt-1.5 text-xs text-slate-400">
                Submitting marks that day red on the Green Board. If an entry already exists, yours is appended.
              </p>
            </div>

            <button
              onClick={submit}
              disabled={saving}
              className="w-full px-4 py-3 rounded-md bg-emerald-600 hover:bg-emerald-700 disabled:opacity-60 text-white text-sm font-bold flex items-center justify-center gap-2"
            >
              {done ? <CheckCircle2 className="h-4 w-4" /> : <Send className="h-4 w-4" />}
              {saving ? "Submitting…" : done ? "Submitted!" : "Submit to Green Board"}
            </button>
          </div>
        </div>

        {/* Concern counts — Shift A (left) / Shift B (right) */}
        <div className="mt-4 grid grid-cols-2 gap-3">
          {(["A", "B"] as const).map((s) => {
            const c = stats[s];
            return (
              <div key={s} className="rounded-xl border bg-white shadow-sm overflow-hidden">
                <div
                  className={`px-4 py-2 text-xs font-bold uppercase tracking-wide text-white ${
                    s === "A" ? "bg-slate-900" : "bg-emerald-700"
                  }`}
                >
                  Shift {s} · Concerns
                </div>
                <div className="divide-y">
                  {[
                    { label: "Day", value: c.day },
                    { label: "Weekly", value: c.week },
                    { label: "Monthly", value: c.month },
                  ].map((r) => (
                    <div key={r.label} className="flex items-center justify-between px-4 py-2">
                      <span className="text-xs font-semibold uppercase text-slate-500">{r.label}</span>
                      <span className="text-xl font-black tabular-nums text-slate-900">{r.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
        </>)}

      </div>
    </div>
  );
}
