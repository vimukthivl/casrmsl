import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowDownLeft, ArrowUpRight, Clock, Package, Search, Truck, X } from "lucide-react";
import { RequireAccess } from "@/components/RequireAccess";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { VehicleUpdateCard } from "@/components/VehicleUpdateCard";
import { useApp } from "@/lib/store";
import { hasDeparted, matchesVehicleSearch } from "@/lib/vehicle-update";

export const Route = createFileRoute("/vehicle-update")({
  head: () => ({ meta: [
    { title: "Vehicle Update — Casualline Logistics 360" },
    { name: "description", content: "Live vehicle arrivals, departures and complete unloading records for Casualline PCU and RM GRN teams." },
    { property: "og:title", content: "Vehicle Update — Casualline Logistics 360" },
    { property: "og:description", content: "Vehicle movements and unloading details for PCU and RM GRN teams." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => <RequireAccess path="/vehicle-update"><VehicleUpdate /></RequireAccess>,
});

function VehicleUpdate() {
  const { state } = useApp();
  const [view, setView] = useState<"inside" | "departed" | "all">("inside");
  const [search, setSearch] = useState("");
  const [material, setMaterial] = useState("All");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [now, setNow] = useState(0);
  useEffect(() => { setNow(Date.now()); const timer = setInterval(() => setNow(Date.now()), 60000); return () => clearInterval(timer); }, []);
  const inside = state.vehicles.filter((v) => !hasDeparted(v));
  const departed = state.vehicles.length - inside.length;
  const materials = Array.from(new Set(state.vehicles.map((v) => v.material_type))).sort();
  const rows = useMemo(() => state.vehicles.filter((v) => {
    if (view === "inside" && hasDeparted(v) || view === "departed" && !hasDeparted(v)) return false;
    if (material !== "All" && v.material_type !== material) return false;
    const date = new Date(v.in_time).toLocaleDateString("en-CA");
    return (!from || date >= from) && (!to || date <= to) && matchesVehicleSearch(v, search);
  }).sort((a, b) => Date.parse(view === "departed" ? b.out_time || b.in_time : b.in_time) - Date.parse(view === "departed" ? a.out_time || a.in_time : a.in_time)), [state.vehicles, view, material, from, to, search]);

  return <div className="mx-auto max-w-7xl space-y-6 p-4 md:p-7">
    <header className="flex flex-wrap items-center justify-between gap-3">
      <div><div className="mb-1 flex items-center gap-2 text-xs font-semibold uppercase text-muted-foreground"><Truck className="h-4 w-4" />PCU · RM GRN · Admin</div><h1 className="text-2xl font-bold md:text-3xl">Vehicle Update</h1><p className="mt-1 text-sm text-muted-foreground">Vehicle arrivals and departures</p></div>
      <span className="flex items-center gap-2 text-xs text-muted-foreground"><span className="h-2 w-2 rounded-full bg-chart-2" />Live updates</span>
    </header>
    <section className="grid grid-cols-2 gap-3 lg:grid-cols-4" aria-label="Vehicle summary">
      {[{ label: "Inside premises", value: inside.length, icon: ArrowDownLeft, tone: "border-chart-3/30 bg-chart-3/10" }, { label: "Departed", value: departed, icon: ArrowUpRight, tone: "border-chart-2/30 bg-chart-2/10" }, { label: "Unloading now", value: inside.filter((v) => v.current_status === "Unloading").length, icon: Package, tone: "border-chart-4/40 bg-chart-4/10" }, { label: "On hold", value: inside.filter((v) => v.current_status === "Hold" || v.is_held_up).length, icon: Clock, tone: "border-destructive/30 bg-destructive/10" }].map((s) => <div key={s.label} className={`rounded-lg border p-4 ${s.tone}`}><s.icon className="mb-3 h-5 w-5 text-muted-foreground" /><div className="text-3xl font-bold tabular-nums">{s.value}</div><div className="mt-1 text-xs font-medium">{s.label}</div></div>)}
    </section>
    <section className="space-y-4 border-y py-4">
      <div className="flex flex-wrap gap-2" role="group" aria-label="Vehicle views">{([ ["inside", "Inside"], ["departed", "Departed"], ["all", "All vehicles"] ] as const).map(([key, label]) => <Button key={key} variant={view === key ? "default" : "outline"} aria-pressed={view === key} onClick={() => setView(key)}>{label}<span className="tabular-nums">{key === "inside" ? inside.length : key === "departed" ? departed : state.vehicles.length}</span></Button>)}</div>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1fr]">
        <div className="relative self-end"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input aria-label="Search vehicles" placeholder="Search vehicle, supplier, token, invoice…" value={search} onChange={(e) => setSearch(e.target.value)} className="h-10 pl-9 pr-10" />{search && <Button variant="ghost" size="icon" className="absolute right-0 top-0" aria-label="Clear search" onClick={() => setSearch("")}><X /></Button>}</div>
        <label className="space-y-1 text-xs text-muted-foreground">Material<select className="input-base h-10" value={material} onChange={(e) => setMaterial(e.target.value)}><option value="All">All materials</option>{materials.map((m) => <option key={m}>{m}</option>)}</select></label>
        <label className="space-y-1 text-xs text-muted-foreground">Arrived from<Input type="date" className="h-10" value={from} max={to || undefined} onChange={(e) => setFrom(e.target.value)} /></label>
        <label className="space-y-1 text-xs text-muted-foreground">Arrived until<Input type="date" className="h-10" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} /></label>
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground"><span>{rows.length} vehicle{rows.length === 1 ? "" : "s"}</span>{(search || material !== "All" || from || to) && <Button variant="ghost" size="sm" onClick={() => { setSearch(""); setMaterial("All"); setFrom(""); setTo(""); }}>Reset filters</Button>}</div>
    </section>
    {state.loading ? <div role="status" className="py-16 text-center text-muted-foreground">Loading vehicles…</div> : !rows.length ? <div className="py-16 text-center"><Truck className="mx-auto mb-3 h-9 w-9 text-muted-foreground" /><h2 className="font-semibold">No vehicles found</h2><p className="mt-1 text-sm text-muted-foreground">{search || from || to || material !== "All" ? "No matching vehicle records." : view === "inside" ? "No vehicles are currently inside." : "No vehicle records available."}</p></div> :
      <section className="grid grid-cols-1 gap-5" aria-label="Vehicle records">{rows.map((v) => <VehicleUpdateCard key={v.token_no} vehicle={v} now={now} />)}</section>}
  </div>;
}