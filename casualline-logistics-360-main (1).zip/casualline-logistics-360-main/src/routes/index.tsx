import { createFileRoute, redirect } from "@tanstack/react-router";
import { useEffect } from "react";
import { useApp, ROLE_HOMES } from "@/lib/store";
import { useNavigate } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Casualline Logistics 360 — Team Workspace" },
    { name: "description", content: "Casualline Logistics 360 warehouse and vehicle operations workspace." },
    { property: "og:title", content: "Casualline Logistics 360 — Team Workspace" },
    { property: "og:description", content: "Warehouse and vehicle operations for Casualline teams." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: Index,
});

function Index() {
  const { user } = useApp();
  const navigate = useNavigate();
  useEffect(() => {
    if (user) navigate({ to: ROLE_HOMES[user.role], replace: true });
    else navigate({ to: "/login", replace: true });
  }, [user, navigate]);
  return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
}
