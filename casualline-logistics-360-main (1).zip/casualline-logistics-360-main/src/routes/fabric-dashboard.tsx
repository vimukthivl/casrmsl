import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { AppFooter } from "@/components/AppFooter";
import { FabricSummaryPanels } from "@/components/FabricSummaryPanels";
import { FabricHealthBadge } from "@/components/FabricHealthBadge";
import { Shirt } from "lucide-react";

export const Route = createFileRoute("/fabric-dashboard")({
  head: () => ({
    meta: [
      { title: "Fabric Dashboard — Casualline Logistics 360" },
      { name: "description", content: "Fabric planning and downtime KPI overview." },
      { property: "og:title", content: "Fabric Dashboard — Casualline Logistics 360" },
      { property: "og:description", content: "Fabric planning and downtime KPI overview." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/fabric-dashboard">
      <FabricDashboardPage />
      <AppFooter />
    </RequireAccess>
  ),
});

function FabricDashboardPage() {
  return (
    <div className="p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto">
      <header className="relative overflow-hidden rounded-2xl border-2 border-fuchsia-400/30 bg-gradient-to-br from-fuchsia-500/15 via-pink-500/10 to-rose-500/10 p-5 shadow-lg shadow-fuchsia-500/10">
        <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-fuchsia-400/20 blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-3 flex-wrap">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-fuchsia-500 to-pink-600 text-white grid place-items-center shadow-md shadow-fuchsia-500/40">
            <Shirt className="h-6 w-6" />
          </div>
          <FabricHealthBadge />
          <div className="min-w-0">
            <h1 className="text-xl md:text-2xl font-extrabold truncate bg-gradient-to-r from-fuchsia-600 via-pink-600 to-rose-600 bg-clip-text text-transparent">
              Fabric Dashboard 🧵
            </h1>
            <p className="text-xs text-muted-foreground">Read-only overview · Cycle Counting, Green Board, Downtime & Picker Performance.</p>
          </div>
        </div>
      </header>

      <FabricSummaryPanels />
    </div>
  );
}
