import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
  type ErrorComponentProps,
} from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";
import { AppProvider } from "../lib/store";
import { Toaster } from "sonner";


function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: ErrorComponentProps) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "MAS Casualline Logistics 360" },
      { name: "description", content: "MAS Casualline Logistics 360 — real-time yard, bay and GRN control room with FIFO tracking, schedule compliance and held-up cost analytics." },
      { name: "author", content: "MAS Casualline Logistics 360" },
      { property: "og:title", content: "MAS Casualline Logistics 360" },
      { property: "og:description", content: "Immersive real-time control room for the MAS Casualline Logistics 360 yard and warehouse." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      {
        rel: "stylesheet",
        href: "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
      },
      { rel: "icon", href: "/favicon.ico", type: "image/x-icon" },
    ],
  }),

  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setBooting(false), 1100);
    return () => clearTimeout(t);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <AppProvider>
        <Outlet />
        <Toaster richColors position="top-right" />
        {booting && <BootSplash />}
      </AppProvider>
    </QueryClientProvider>
  );
}

function BootSplash() {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        display: "grid",
        placeItems: "center",
        background:
          "radial-gradient(1200px 800px at 20% 10%, rgba(59,130,246,0.25), transparent 60%), radial-gradient(1000px 700px at 80% 90%, rgba(139,92,246,0.25), transparent 60%), #0b1220",
        animation: "mcSplashFade 1.1s ease forwards",
      }}
    >
      <style>{`
        @keyframes mcSplashFade { 0%,70%{opacity:1} 100%{opacity:0; visibility:hidden} }
        @keyframes mcSplashPulse { 0%,100%{transform:scale(1); filter:drop-shadow(0 0 20px rgba(96,165,250,.6))} 50%{transform:scale(1.04); filter:drop-shadow(0 0 40px rgba(139,92,246,.8))} }
        @keyframes mcSplashBar { 0%{transform:translateX(-100%)} 100%{transform:translateX(200%)} }
      `}</style>
      <div style={{ textAlign: "center", animation: "mcSplashPulse 1.2s ease-in-out infinite" }}>
        <div
          style={{
            fontSize: "clamp(28px, 6vw, 56px)",
            fontWeight: 700,
            letterSpacing: "0.02em",
            background: "linear-gradient(90deg,#60a5fa,#a78bfa,#22d3ee)",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            textShadow: "0 4px 24px rgba(59,130,246,.35)",
          }}
        >
          MAS Casualline
        </div>
        <div style={{ marginTop: 8, fontSize: 12, letterSpacing: "0.3em", color: "#93c5fd", textTransform: "uppercase" }}>
          Logistics 360
        </div>
        <div
          style={{
            marginTop: 22,
            width: 220,
            height: 3,
            borderRadius: 999,
            overflow: "hidden",
            background: "rgba(148,163,184,.15)",
            marginLeft: "auto",
            marginRight: "auto",
          }}
        >
          <div
            style={{
              width: "40%",
              height: "100%",
              background: "linear-gradient(90deg, transparent, #60a5fa, #a78bfa, transparent)",
              animation: "mcSplashBar 1.1s linear infinite",
            }}
          />
        </div>
      </div>
    </div>
  );
}

