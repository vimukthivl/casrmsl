import { createFileRoute } from "@tanstack/react-router";
import { useApp, isoMondayOf, isoNextMondayOf } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { DAYS, type WeeklySchedule, type MaterialType, type VehicleType } from "@/lib/types";
import { Plus, Trash2, Upload, Download, CalendarClock, CalendarCheck2, Archive } from "lucide-react";
import { UnloadCapacityPanel } from "@/components/UnloadCapacityPanel";
import { PendingInvoices } from "@/components/PendingInvoices";
import { useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import * as XLSX from "xlsx";

export const Route = createFileRoute("/pcu")({
  head: () => ({ meta: [{ title: "PCU Weekly Schedule — Casualline Logistics 360" }, { name: "description", content: "PCU weekly deliveries and pending invoice coordination at Casualline." },
      { property: "og:title", content: "PCU Weekly Schedule — Casualline Logistics 360" },
      { property: "og:description", content: "PCU weekly deliveries and pending invoice coordination at Casualline." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: () => (
    <RequireAccess path="/pcu">
      <PCUScreen />
    </RequireAccess>
  ),
});

type WeekKind = "current" | "next";

function formatRange(startISO: string): string {
  const s = new Date(startISO);
  const e = new Date(s);
  e.setDate(s.getDate() + 5); // Mon..Sat
  const fmt = (d: Date) => d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
  return `${fmt(s)} – ${fmt(e)}, ${s.getFullYear()}`;
}

function PCUScreen() {
  const { state, user, addBlankSchedule, addSchedules, updateSchedule, updateScheduleDay, removeSchedule, clearScheduleWeek } = useApp();
  const [tab, setTab] = useState<"schedule" | "pending">("schedule");
  const currentMon = useMemo(() => isoMondayOf(), []);
  const nextMon = useMemo(() => isoNextMondayOf(), []);

  const currentRows = useMemo(() => state.schedules.filter((s) => s.week_start === currentMon), [state.schedules, currentMon]);
  const nextRows = useMemo(() => state.schedules.filter((s) => s.week_start === nextMon), [state.schedules, nextMon]);

  const pcus = useMemo(
    () => Array.from(new Set(state.schedules.map((s) => s.relevant_pcu))).filter(Boolean),
    [state.schedules],
  );

  const parseCSV = async (file: File, weekStart: string): Promise<Omit<WeeklySchedule, "id">[]> => {
    const text = await file.text();
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    if (lines.length < 2) return [];
    const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
    const rows: Omit<WeeklySchedule, "id">[] = [];
    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i].split(",").map((c) => c.trim());
      const get = (name: string) => {
        const idx = header.indexOf(name);
        return idx >= 0 ? cols[idx] : "";
      };
      rows.push({
        material_type: (get("material type") || "Fabric") as MaterialType,
        relevant_pcu: get("relevant pcu") || "",
        vehicle_type: (get("vehicle type") || get("vehicle type (ft)") || "20 FT") as VehicleType,
        vendor_name: get("vendor"),
        uom: get("uom"),
        remarks: get("remarks"),
        ih_time: get("ih time") || get("in time") || "",
        days_data: {
          Mon: Number(get("mon")) || 0, Tue: Number(get("tue")) || 0, Wed: Number(get("wed")) || 0,
          Thu: Number(get("thu")) || 0, Fri: Number(get("fri")) || 0, Sat: Number(get("sat")) || 0,
        },
        week_start: weekStart,
      });
    }
    return rows;
  };

  const normalizeVehicleType = (v: string): VehicleType => {
    const s = v.toLowerCase().replace(/\s|ft|feet/g, "").replace(",", ".");
    const map: Record<string, VehicleType> = {
      "40": "40 Ft", "20": "20 Ft",
      "16.5": "16.5 Ft", "14.5": "14.5 Ft", "12.5": "12.5 Ft",
      "10.5": "10.5 Ft", "10": "10 Ft",
      "14": "14.5 Ft",
    };
    return map[s] ?? ("20 Ft" as VehicleType);
  };

  const normalizeTime = (v: unknown): string => {
    if (v === null || v === undefined || v === "") return "";
    // Excel time serial (fraction of a day)
    if (typeof v === "number" && isFinite(v)) {
      const frac = v - Math.floor(v);
      const totalMin = Math.round(frac * 24 * 60);
      const h = Math.floor(totalMin / 60) % 24;
      const m = totalMin % 60;
      return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
    }
    const s = String(v).trim();
    if (!s) return "";
    // Match HH:MM or H:MM (optional AM/PM, optional seconds)
    const m = s.match(/^(\d{1,2}):(\d{2})(?::\d{2})?\s*(am|pm|AM|PM)?$/);
    if (m) {
      let h = parseInt(m[1], 10);
      const mm = parseInt(m[2], 10);
      const ap = m[3]?.toLowerCase();
      if (ap === "pm" && h < 12) h += 12;
      if (ap === "am" && h === 12) h = 0;
      return `${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
    }
    // "830" or "0830"
    if (/^\d{3,4}$/.test(s)) {
      const padded = s.padStart(4, "0");
      return `${padded.slice(0, 2)}:${padded.slice(2)}`;
    }
    return "";
  };

  const parseXLSX = async (file: File, weekStart: string): Promise<Omit<WeeklySchedule, "id">[]> => {
    const buf = await file.arrayBuffer();
    const wb = XLSX.read(buf);
    const ws = wb.Sheets[wb.SheetNames[0]];
    const grid = XLSX.utils.sheet_to_json<unknown[]>(ws, { header: 1, defval: "" }) as unknown[][];

    // Locate header row: contains "Material Type" and "Vendor"
    let headerRow = -1;
    for (let i = 0; i < Math.min(grid.length, 15); i++) {
      const line = grid[i].map((c) => String(c ?? "").trim().toLowerCase());
      if (line.includes("material type") && line.some((c) => c.startsWith("vendor"))) {
        headerRow = i;
        break;
      }
    }
    if (headerRow === -1) {
      // Fallback: flat sheet (old template with Mon..Sat columns)
      const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "" });
      return rows.map((r) => {
        const get = (k: string) => {
          const key = Object.keys(r).find((kk) => kk.trim().toLowerCase() === k.toLowerCase());
          return key ? String(r[key] ?? "") : "";
        };
        return {
          material_type: (() => { const m = get("Material Type").trim().toLowerCase(); if (m.startsWith("trim")) return "Trims" as MaterialType; if (m.startsWith("pack")||m.startsWith("cart")||m.startsWith("box")) return "Packaging" as MaterialType; return "Fabric" as MaterialType; })(),
          relevant_pcu: get("Relevant PCU"),
          vehicle_type: normalizeVehicleType(get("Vehicle Type (FT)") || get("Vehicle Type") || "20"),
          vendor_name: get("Vendor"),
          uom: get("UOM"),
          remarks: [get("PO #"), get("Vehicle #"), get("Remarks")].filter(Boolean).join(" | "),
          ih_time: normalizeTime((() => { const k = Object.keys(r).find((kk) => /ih\s*time|^ih$|in\s*time/i.test(kk)); return k ? r[k] : ""; })()),
          days_data: {
            Mon: Number(get("Mon")) || 0, Tue: Number(get("Tue")) || 0, Wed: Number(get("Wed")) || 0,
            Thu: Number(get("Thu")) || 0, Fri: Number(get("Fri")) || 0, Sat: Number(get("Sat")) || 0,
          },
          week_start: weekStart,
        };
      });
    }

    const header = grid[headerRow].map((c) => String(c ?? "").trim().toLowerCase());
    const col = (name: string) => header.indexOf(name);
    const cMat = col("material type");
    const cPcu = col("relevant pcu");
    const cVeh = header.findIndex((h) => h.startsWith("vehicle type"));
    const cVen = header.findIndex((h) => h.startsWith("vendor"));
    const cUom = col("uom");
    const cPo = header.findIndex((h) => h.startsWith("po"));
    const cVno = header.findIndex((h) => h.startsWith("vehicle #") || h === "vehicle no" || h === "vehicle no.");
    const cIh = header.findIndex((h) => h.includes("ih time") || h === "ih");
    const cRem = col("remarks");

    // Find day-name row within next few rows (values: monday..saturday)
    const dayNames = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const dayKeys: (keyof WeeklySchedule["days_data"])[] = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    let dayRow = -1;
    for (let i = headerRow; i < Math.min(headerRow + 4, grid.length); i++) {
      const line = grid[i].map((c) => String(c ?? "").trim().toLowerCase());
      if (dayNames.every((d) => line.includes(d))) { dayRow = i; break; }
    }
    const dayCols: Record<string, number> = {};
    if (dayRow !== -1) {
      const line = grid[dayRow].map((c) => String(c ?? "").trim().toLowerCase());
      dayNames.forEach((d, idx) => { dayCols[dayKeys[idx]] = line.indexOf(d); });
    }
    const dataStart = (dayRow !== -1 ? dayRow : headerRow) + 1;

    const normalizeMaterial = (v: string): MaterialType => {
      const s = v.trim().toLowerCase();
      if (s.startsWith("fab")) return "Fabric";
      if (s.startsWith("trim")) return "Trims";
      if (s.startsWith("pack") || s.startsWith("cart") || s.startsWith("box")) return "Packaging";
      return "Fabric";
    };

    const rows: Omit<WeeklySchedule, "id">[] = [];
    let currentMat: MaterialType = "Fabric";
    for (let i = dataStart; i < grid.length; i++) {
      const row = grid[i];
      if (!row) continue;
      const get = (idx: number) => (idx >= 0 ? String(row[idx] ?? "").trim() : "");
      const matRaw = get(cMat);
      if (matRaw && !/total/i.test(matRaw)) currentMat = normalizeMaterial(matRaw);


      const vendor = get(cVen);
      const pcu = get(cPcu);
      const veh = get(cVeh);
      if (!vendor && !pcu && !veh) continue;
      if (/total/i.test(vendor)) continue;

      const days_data = { Mon: 0, Tue: 0, Wed: 0, Thu: 0, Fri: 0, Sat: 0 };
      for (const k of dayKeys) {
        const idx = dayCols[k];
        if (idx >= 0) days_data[k] = Number(row[idx]) || 0;
      }
      const remarks = [
        get(cPo) && `PO ${get(cPo)}`,
        get(cVno) && `Veh ${get(cVno)}`,
        get(cRem),
      ].filter(Boolean).join(" | ");
      const ih_time = normalizeTime(cIh >= 0 ? row[cIh] : "");

      rows.push({
        material_type: currentMat,
        relevant_pcu: pcu,
        vehicle_type: normalizeVehicleType(veh || "20"),
        vendor_name: vendor,
        uom: get(cUom),
        remarks,
        ih_time,
        days_data,
        week_start: weekStart,
      });
    }
    return rows;
  };

  const importForWeek = async (file: File, kind: WeekKind, replace: boolean) => {
    const weekStart = kind === "current" ? currentMon : nextMon;
    try {
      const parsed = file.name.endsWith(".csv") ? await parseCSV(file, weekStart) : await parseXLSX(file, weekStart);
      if (!parsed.length) {
        toast.info("No rows found in file");
        return;
      }
      if (replace) await clearScheduleWeek(weekStart);
      await addSchedules(parsed);
      toast.success(`Imported ${parsed.length} row(s) into ${kind === "current" ? "Current" : "Next"} week`);
    } catch (err) {
      console.error(err);
      toast.error("Failed to import file");
    }
  };

  const downloadTemplate = () => {
    // "Vehicle Plan - Week" layout with dates + day names + Total Qty column.
    const mon = new Date(currentMon);
    const dates = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(mon); d.setDate(mon.getDate() + i);
      return d.toISOString().slice(0, 10);
    });
    const title = ["Vehicle Plan - Week", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
    const blank = Array(16).fill("");
    const header = ["Material Type", "Relevant PCU", "Vehicle Type (FT)", "Vendor", "UOM", "PO #", "Vehicle #", "IH TIME", "Remarks", "", "", "", "", "", "", ""];
    const dateRow = ["", "", "", "", "", "", "", "", "", ...dates, "Total Qty"];
    const dayRow  = ["", "", "", "", "", "", "", "", "", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", ""];
    const sample = [
      ["FABRIC", "Avishka",    "20ft", "ADVANTIS", "ROLL", "4502842065", "", "06:00", "", "",  250, "", "",  "",  "",  ""],
      ["",       "Dhananjali", "14ft", "BPTL",     "ROLL", "4502888093", "", "16:00", "", 140, "",  "", "",  "",  "",  ""],
      ["TRIMS",  "Upeka",      "20ft", "OCL",      "BOX",  "4502878962", "", "15:00", "", "",  "",  80, "",  "",  "",  ""],
    ];
    const aoa = [title, blank, header, dateRow, dayRow, ...sample];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    ws["!cols"] = Array(16).fill({ wch: 14 });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Weekly Plan");
    XLSX.writeFile(wb, "weekly-vehicle-plan-template.xlsx");
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-indigo-500/15 via-blue-500/10 to-cyan-500/10 p-6">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-indigo-500/25 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="relative flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-indigo-500 to-blue-600 text-white grid place-items-center shadow-lg shadow-indigo-500/30">
              <CalendarCheck2 className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-cyan-600 bg-clip-text text-transparent">PCU Weekly Delivery Schedule</h1>
              <p className="text-sm text-muted-foreground">
                Manage the live schedule and stage next week's plan. Auto-promotes every Monday.
              </p>
            </div>
          </div>
          <button
            onClick={downloadTemplate}
            className="h-10 px-4 rounded-lg bg-gradient-to-r from-indigo-500 to-blue-600 text-white shadow-md hover:shadow-lg hover:brightness-110 flex items-center gap-2 text-sm font-medium transition-all"
          >
            <Download className="h-4 w-4" /> Weekly Plan Template
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {([
          { k: "schedule", label: "Weekly Schedule" },
          { k: "pending", label: "Pending Invoices" },
        ] as const).map((t) => (
          <button
            key={t.k}
            onClick={() => setTab(t.k)}
            className={`text-sm font-semibold px-4 py-2 rounded-xl border-2 transition-all ${
              tab === t.k
                ? "bg-indigo-500 text-white border-indigo-500 shadow-md"
                : "bg-muted/40 border-transparent hover:border-indigo-400/40"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "pending" ? (
        <PendingInvoices canComplete={false} userName={user?.display_name} showAddForm={false} showSearch />
      ) : (
        <>
          <WeekPanel
            kind="current"
            weekStart={currentMon}
            rows={currentRows}
            pcus={pcus}
            onImport={importForWeek}
            onAdd={() => addBlankSchedule(currentMon).catch(() => toast.error("Failed to add row"))}
            onClear={() => clearScheduleWeek(currentMon).catch(() => toast.error("Failed to clear week"))}
            onRemove={(id) => removeSchedule(id).catch(() => toast.error("Failed to remove row"))}
            onUpdate={updateSchedule}
            onUpdateDay={updateScheduleDay}
            loading={state.loading}
          />

          <WeekPanel
            kind="next"
            weekStart={nextMon}
            rows={nextRows}
            pcus={pcus}
            onImport={importForWeek}
            onAdd={() => addBlankSchedule(nextMon).catch(() => toast.error("Failed to add row"))}
            onClear={() => clearScheduleWeek(nextMon).catch(() => toast.error("Failed to clear week"))}
            onRemove={(id) => removeSchedule(id).catch(() => toast.error("Failed to remove row"))}
            onUpdate={updateSchedule}
            onUpdateDay={updateScheduleDay}
            loading={state.loading}
          />

          <UnloadCapacityPanel />

          <div className="text-xs text-muted-foreground">
            Excel layout: title row "Vehicle Plan - Week", header (<code>Material Type, Relevant PCU, Vehicle Type (FT), Vendor, UOM, PO #, Vehicle #, IH TIME, Remarks</code>) + date row + day-name row (Monday…Saturday) + Total Qty.
          </div>
        </>
      )}
    </div>
  );
}

interface WeekPanelProps {
  kind: WeekKind;
  weekStart: string;
  rows: WeeklySchedule[];
  pcus: string[];
  onImport: (file: File, kind: WeekKind, replace: boolean) => Promise<void>;
  onAdd: () => void;
  onClear: () => void;
  onRemove: (id: string) => void;
  onUpdate: (id: string, patch: Partial<WeeklySchedule>) => Promise<void>;
  onUpdateDay: (id: string, day: (typeof DAYS)[number], val: number) => Promise<void>;
  loading: boolean;
}

function WeekPanel({ kind, weekStart, rows, pcus, onImport, onAdd, onClear, onRemove, onUpdate, onUpdateDay, loading }: WeekPanelProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [replaceMode, setReplaceMode] = useState(true);
  const isCurrent = kind === "current";

  const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    await onImport(f, kind, replaceMode);
  };

  const badgeClass = isCurrent
    ? "bg-emerald-500/15 text-emerald-700 border-emerald-500/30"
    : "bg-amber-500/15 text-amber-800 border-amber-500/30";
  const Icon = isCurrent ? CalendarCheck2 : CalendarClock;

  return (
    <section className={`rounded-2xl border-2 ${isCurrent ? "border-emerald-400/40 bg-gradient-to-br from-emerald-500/5 via-card to-card shadow-sm shadow-emerald-500/10" : "border-dashed border-amber-400/50 bg-gradient-to-br from-amber-500/5 via-card to-card"}`}>
      <header className="flex items-center justify-between flex-wrap gap-3 p-4 border-b">
        <div className="flex items-center gap-3 min-w-0">
          <div className={`h-10 w-10 rounded-lg border grid place-items-center ${badgeClass}`}>
            <Icon className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-semibold truncate">
                {isCurrent ? "Current Week Schedule" : "Next Week Schedule"}
              </h2>
              <span className={`text-[10px] font-semibold uppercase tracking-wide px-2 py-0.5 rounded-full border ${badgeClass}`}>
                {isCurrent ? "Active now" : "Staged · Activates automatically next week"}
              </span>
            </div>
            <div className="text-xs text-muted-foreground">
              Week of {formatRange(weekStart)} · {rows.length} row(s)
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <label className="flex items-center gap-1.5 text-xs text-muted-foreground select-none">
            <input
              type="checkbox"
              checked={replaceMode}
              onChange={(e) => setReplaceMode(e.target.checked)}
              className="h-3.5 w-3.5"
            />
            Replace on import
          </label>
          <input ref={inputRef} type="file" accept=".csv,.xlsx" hidden onChange={handleFile} />
          <button
            onClick={() => inputRef.current?.click()}
            className="h-9 px-3 rounded-md border bg-background hover:bg-muted flex items-center gap-2 text-sm transition-colors"
          >
            <Upload className="h-4 w-4" /> Upload {isCurrent ? "Current" : "Next"} Week
          </button>
          <button
            onClick={onAdd}
            className="h-9 px-3 rounded-md bg-primary text-primary-foreground flex items-center gap-2 text-sm hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-4 w-4" /> Add row
          </button>
          {rows.length > 0 && (
            <button
              onClick={onClear}
              className="h-9 px-3 rounded-md border border-destructive/40 text-destructive bg-background hover:bg-destructive/10 flex items-center gap-2 text-sm transition-colors"
            >
              <Archive className="h-4 w-4" /> Clear week
            </button>
          )}
        </div>
      </header>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="text-xs uppercase text-muted-foreground bg-muted/50">
            <tr>
              <th className="text-left p-3">Vendor</th>
              <th className="text-left p-3">Material</th>
              <th className="text-left p-3">PCU</th>
              <th className="text-left p-3">Vehicle</th>
              <th className="text-left p-3">UOM</th>
              <th className="text-left p-3">IH Time</th>
              {DAYS.map((d) => (
                <th key={d} className="text-left p-3">{d}</th>
              ))}
              <th className="text-left p-3">Remarks</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody>
            {rows.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="p-2">
                  <input value={s.vendor_name} onChange={(e) => onUpdate(s.id, { vendor_name: e.target.value })}
                    className="w-40 h-8 px-2 rounded border bg-background" />
                </td>
                <td className="p-2">
                  <select value={s.material_type} onChange={(e) => onUpdate(s.id, { material_type: e.target.value as MaterialType })}
                    className="h-8 px-2 rounded border bg-background">
                    <option>Fabric</option><option>Trims</option><option>Packaging</option>
                  </select>
                </td>
                <td className="p-2">
                  <input list="pcu-list" value={s.relevant_pcu} onChange={(e) => onUpdate(s.id, { relevant_pcu: e.target.value })}
                    placeholder="Type PCU"
                    className="w-28 h-8 px-2 rounded border bg-background" />
                </td>
                <td className="p-2">
                  <select value={s.vehicle_type} onChange={(e) => onUpdate(s.id, { vehicle_type: e.target.value as VehicleType })}
                    className="h-8 px-2 rounded border bg-background">
                    {["40 Ft","20 Ft","16.5 Ft","14.5 Ft","12.5 Ft","10.5 Ft","10 Ft"].map((t) => <option key={t}>{t}</option>)}
                  </select>
                </td>
                <td className="p-2">
                  <input value={s.uom} onChange={(e) => onUpdate(s.id, { uom: e.target.value })}
                    className="w-20 h-8 px-2 rounded border bg-background" />
                </td>
                <td className="p-2">
                  <input type="time" value={s.ih_time || ""} onChange={(e) => onUpdate(s.id, { ih_time: e.target.value })}
                    className="w-24 h-8 px-2 rounded border bg-background" />
                </td>
                {DAYS.map((d) => (
                  <td key={d} className="p-2">
                    <input type="number" value={s.days_data[d]} onChange={(e) => onUpdateDay(s.id, d, Number(e.target.value))}
                      className="w-16 h-8 px-2 rounded border bg-background" />
                  </td>
                ))}
                <td className="p-2">
                  <input value={s.remarks} onChange={(e) => onUpdate(s.id, { remarks: e.target.value })}
                    className="w-32 h-8 px-2 rounded border bg-background" />
                </td>
                <td className="p-2">
                  <button onClick={() => onRemove(s.id)} className="p-1.5 rounded hover:bg-destructive/10 text-destructive">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </td>
              </tr>
            ))}
            {rows.length === 0 && !loading && (
              <tr>
                <td colSpan={14} className="p-6 text-center text-sm text-muted-foreground">
                  {isCurrent
                    ? "No live schedule yet. Upload this week's plan or add a row."
                    : "Nothing staged yet. Upload next week's plan to activate it automatically on Monday."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <datalist id="pcu-list">
        {pcus.map((p) => <option key={p} value={p} />)}
      </datalist>
    </section>
  );
}
