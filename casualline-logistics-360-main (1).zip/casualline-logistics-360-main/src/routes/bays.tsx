import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { BAYS, type BayId, type VehicleLog } from "@/lib/types";
import { StatusBadge } from "./dashboard";
import { toast } from "sonner";
import { AlertTriangle, GripVertical, Inbox, Check, Package, Clock, Plus, Trash2 } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import {
  fetchUnloadEntries, addUnloadEntry, deleteUnloadEntry, subscribeUnloadEntries,
  sumByShift, shiftOf, type UnloadEntry,
} from "@/lib/unload-entries";


export const Route = createFileRoute("/bays")({
  head: () => ({ meta: [{ title: "Bay Management — Casualline Logistics 360" }, { name: "description", content: "Live bay assignments and unloading queues for Casualline warehouse teams." },
      { property: "og:title", content: "Bay Management — Casualline Logistics 360" },
      { property: "og:description", content: "Live bay assignments and unloading queues for Casualline warehouse teams." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: () => (
    <RequireAccess path="/bays">
      <Bays />
    </RequireAccess>
  ),
});

type DropTarget = BayId | "GATE_IN";

export function Bays() {
  const { state, user, assignToBay, unassignFromBay, changeBay, updateVehicle } = useApp();
  const canManage = user?.role === "grn" || user?.role === "admin";
  // Track dragged token via React state (HTML5 dataTransfer is also set for
  // browsers that require it; state is the source of truth for the UI).
  const [dragToken, setDragToken] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<DropTarget | null>(null);
  // Tap-to-move fallback (works on touch devices where HTML5 DnD does not).
  const [selectedToken, setSelectedToken] = useState<string | null>(null);
  const [entries, setEntries] = useState<UnloadEntry[]>([]);
  const [moving, setMoving] = useState(false);

  const reloadEntries = useCallback(async () => {
    try {
      setEntries(await fetchUnloadEntries());
    } catch (e) {
      console.error("load unload entries failed", e);
    }
  }, []);

  useEffect(() => {
    void reloadEntries();
    return subscribeUnloadEntries(() => { void reloadEntries(); });
  }, [reloadEntries]);

  const entriesFor = (token: string) => entries.filter((e) => e.token_no === token);

  const handleAddQty = async (v: VehicleLog, qty: number) => {
    try {
      const created = await addUnloadEntry({
        token_no: v.token_no,
        vehicle_number: v.vehicle_number,
        material_type: v.material_type,
        unit: v.material_type === "Fabric" ? "Rolls" : "Boxes",
        qty,
        entered_by: user?.display_name || user?.username || null,
      });
      setEntries((prev) => (prev.find((x) => x.id === created.id) ? prev : [...prev, created]));
      const total = [...entriesFor(v.token_no), created].reduce((s, e) => s + e.qty, 0);
      await updateVehicle(v.token_no, { manually_unloaded_qty: total });
      toast.success(`+${qty} added (Shift ${created.shift})`);
    } catch (e) {
      console.error(e);
      toast.error("Could not add qty");
    }
  };

  const handleDeleteEntry = async (v: VehicleLog, id: string) => {
    try {
      await deleteUnloadEntry(id);
      const left = entriesFor(v.token_no).filter((x) => x.id !== id);
      setEntries((prev) => prev.filter((x) => x.id !== id));
      await updateVehicle(v.token_no, {
        manually_unloaded_qty: left.length ? left.reduce((s, e) => s + e.qty, 0) : null,
      });
      toast.success("Entry removed");
    } catch (e) {
      console.error(e);
      toast.error("Could not remove entry");
    }
  };


  const gateIn = state.vehicles
    .filter((v) => !v.bay_id && v.current_status !== "Completed" && v.current_status !== "Departed")
    .sort((a, b) => new Date(a.in_time).getTime() - new Date(b.in_time).getTime());

  const bayVehicles = (bay: BayId) =>
    state.vehicles
      .filter((v) => v.bay_id === bay && v.current_status !== "Completed" && v.current_status !== "Departed")
      .sort((a, b) => {
        const pa = a.queue_position ?? 9999;
        const pb = b.queue_position ?? 9999;
        if (pa !== pb) return pa - pb;
        // Same position (or unset) → earlier check-in stays on top, newer goes below
        return new Date(a.in_time).getTime() - new Date(b.in_time).getTime();
      });


  const moveTo = async (token: string, target: DropTarget) => {
    if (!canManage || moving) return;
    const v = state.vehicles.find((x) => x.token_no === token);
    if (!v) return;
    setMoving(true);
    try {
      if (target === "GATE_IN") {
        if (v.bay_id) {
          await unassignFromBay(v.token_no);
          toast.success("Returned to Gate In");
        }
      } else if (!v.bay_id) {
        await assignToBay(v.token_no, target);
        toast.success(`Assigned to ${target}`);
      } else if (v.bay_id !== target) {
        await changeBay(v.token_no, target);
        toast.success(`Moved to ${target}`);
      }
    } catch (e) {
      console.error(e);
      toast.error(e && typeof e === "object" && "message" in e ? String(e.message) : "Could not move vehicle");
    } finally {
      setMoving(false);
    }
  };

  const handleDrop = async (e: React.DragEvent, target: DropTarget) => {
    e.preventDefault();
    const token = dragToken || e.dataTransfer.getData("text/plain");
    setDragToken(null);
    setDragOver(null);
    if (!token) return;
    await moveTo(token, target);
  };

  const handleCardTap = (token: string, currentTarget: DropTarget) => {
    if (!canManage) return;
    // If a token is selected and user taps a different card, do nothing
    // (they should tap a column). Tapping a card just selects/deselects it.
    setSelectedToken((prev) => (prev === token ? null : token));
    // Also clear when tapping a card in a different column while something selected
    void currentTarget;
  };

  const handleColumnTap = async (target: DropTarget) => {
    if (!canManage || !selectedToken) return;
    const tk = selectedToken;
    setSelectedToken(null);
    await moveTo(tk, target);
  };

  const renderColumn = ({ title, target, items, tone }: {
    title: string; target: DropTarget; items: VehicleLog[]; tone: string;
  }) => {
    const isDropHere = dragOver === target;
    const canReceiveTap = canManage && !!selectedToken;
    return (
      <div
        key={target}
        onDragOver={(e) => {
          if (!canManage) return;
          e.preventDefault();
          e.dataTransfer.dropEffect = "move";
          if (dragOver !== target) setDragOver(target);
        }}
        onDragEnter={(e) => {
          if (!canManage) return;
          e.preventDefault();
          setDragOver(target);
        }}
        onDragLeave={(e) => {
          // Only clear when leaving the column entirely
          if (e.currentTarget.contains(e.relatedTarget as Node)) return;
          setDragOver((t) => (t === target ? null : t));
        }}
        onDrop={(e) => handleDrop(e, target)}
        onClick={() => canReceiveTap && handleColumnTap(target)}
        className={`flex flex-col rounded-xl border-2 bg-card transition-colors ${
          isDropHere
            ? "border-primary bg-primary/5"
            : canReceiveTap
            ? "border-primary/40 hover:border-primary hover:bg-primary/5 cursor-pointer"
            : tone
        }`}
      >
        <div className="px-4 py-3 border-b flex items-center justify-between">
          <h3 className="font-semibold">{title}</h3>
          <span className="text-xs px-2 py-0.5 rounded-full bg-muted font-mono">{items.length}</span>
        </div>
        <div className="flex-1 p-3 min-h-[280px]">
          {items.length === 0 ? (
            <div className="h-full min-h-[240px] grid place-items-center text-sm text-muted-foreground border-2 border-dashed rounded-lg">
              <div className="text-center px-3">
                <Inbox className="h-6 w-6 mx-auto mb-1 opacity-50" />
                {canReceiveTap ? "Tap to move here" : canManage ? "Drop vehicle here" : "Empty"}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {items.map((v, idx) => (
                <div
                  key={v.token_no}
                  className="relative transition-all"
                  style={{
                    zIndex: items.length - idx,
                    marginTop: idx === 0 ? 0 : -10,
                    transform: idx === 0 ? undefined : `scale(${Math.max(0.94, 1 - idx * 0.02)})`,
                    filter: idx === 0 ? undefined : `brightness(${Math.max(0.9, 1 - idx * 0.03)})`,
                  }}
                >
                  {idx > 0 && (
                    <span className="absolute -top-1 right-2 z-10 text-[10px] px-1.5 py-0.5 rounded-full bg-slate-700 text-white font-mono shadow">
                      #{idx + 1} queued
                    </span>
                  )}
                  <VehicleCard
                    v={v}
                    draggable={canManage}
                    canEdit={canManage}
                    selected={selectedToken === v.token_no}
                    entries={entriesFor(v.token_no)}
                    onAddQty={(qty) => handleAddQty(v, qty)}
                    onDeleteEntry={(id) => handleDeleteEntry(v, id)}
                    onDragStart={(e) => {
                      setDragToken(v.token_no);
                      e.dataTransfer.effectAllowed = "move";
                      e.dataTransfer.setData("text/plain", v.token_no);
                    }}
                    onDragEnd={() => { setDragToken(null); setDragOver(null); }}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCardTap(v.token_no, target);
                    }}
                    dragging={dragToken === v.token_no}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-emerald-500/15 via-cyan-500/10 to-violet-500/10 p-5">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-cyan-500/25 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-violet-500/20 blur-3xl" />
        <div className="relative space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-emerald-500 to-cyan-600 text-white grid place-items-center shadow-lg shadow-emerald-500/30">
                <GripVertical className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-violet-600 bg-clip-text text-transparent">Bay Management</h1>
                <p className="text-sm text-muted-foreground">Assign vehicles to bays · Execution (Start / Hold / Complete) is on RM GRN</p>
              </div>
            </div>
            {!canManage && (
              <span className="text-xs px-2 py-1 rounded bg-muted text-muted-foreground">Read-only</span>
            )}
          </div>


          {/* Live bay load */}
          <div className="flex flex-wrap gap-2">
            <LoadChip label="Gate In" count={gateIn.length} tone="bg-slate-500" />
            {BAYS.map((b) => (
              <LoadChip
                key={b.id}
                label={b.label}
                count={bayVehicles(b.id).length}
                tone={b.id === "BAY-01" ? "bg-cyan-500" : b.id === "BAY-02" ? "bg-emerald-500" : "bg-violet-500"}
              />
            ))}
          </div>

          {/* Selection action bar */}
          {selectedToken && (
            <div className="flex flex-wrap items-center gap-2 rounded-xl border-2 border-primary/40 bg-primary/5 p-3">
              <span className="text-xs font-semibold">
                Selected <span className="font-mono">{selectedToken}</span> — move to:
              </span>
              {[{ id: "GATE_IN" as const, label: "Gate In" }, ...BAYS.map((b) => ({ id: b.id, label: b.label }))].map((t) => (
                <Button
                  key={t.id}
                  variant="outline"
                  disabled={moving}
                  onClick={(e) => { e.stopPropagation(); void handleColumnTap(t.id as DropTarget); }}
                  className="text-xs h-8 px-3 rounded-lg border bg-background font-medium hover:bg-primary hover:text-primary-foreground transition-colors"
                >
                  → {t.label}
                </Button>
              ))}
              <button
                onClick={() => setSelectedToken(null)}
                className="text-xs h-8 px-3 rounded-lg border text-muted-foreground hover:bg-muted ml-auto"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>


      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {renderColumn({ title: "Gate In (Awaiting)", target: "GATE_IN", items: gateIn, tone: "border-slate-300 bg-slate-50/40 dark:bg-slate-800/20" })}
        {BAYS.map((b) => {
          const themes: Record<string, string> = {
            "BAY-01": "border-cyan-400/70 bg-gradient-to-br from-cyan-500/10 via-card to-card shadow-[0_0_0_1px_rgba(6,182,212,0.25)]",
            "BAY-02": "border-emerald-400/70 bg-gradient-to-br from-emerald-500/10 via-card to-card shadow-[0_0_0_1px_rgba(34,197,94,0.25)]",
            "BAY-03": "border-violet-400/70 bg-gradient-to-br from-violet-500/10 via-card to-card shadow-[0_0_0_1px_rgba(139,92,246,0.25)]",
          };
          return (
            renderColumn({ title: b.label, target: b.id, items: bayVehicles(b.id), tone: themes[b.id] || "border-emerald-500/40" })
          );
        })}
      </div>
    </div>
  );
}

function VehicleCard({
  v, draggable, canEdit, entries, onAddQty, onDeleteEntry, onDragStart, onDragEnd, onClick, dragging, selected,
}: {
  v: VehicleLog;
  draggable: boolean;
  canEdit: boolean;
  entries: UnloadEntry[];
  onAddQty: (qty: number) => void | Promise<void>;
  onDeleteEntry: (id: string) => void | Promise<void>;
  onDragStart: (e: React.DragEvent) => void;
  onDragEnd: () => void;
  onClick: (e: React.MouseEvent) => void;
  dragging: boolean;
  selected: boolean;
}) {
  const isFabric = v.material_type === "Fabric";
  const unit = isFabric ? "Rolls" : "Boxes";
  const totalManifest = isFabric ? (v.roll_qty || 0) : (v.box_qty || 0);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [showLog, setShowLog] = useState(false);

  const unloaded = entries.reduce((s, e) => s + e.qty, 0);
  const byShift = sumByShift(entries);
  const remaining = Math.max(0, totalManifest - unloaded);
  const pct = totalManifest > 0 ? Math.min(100, Math.round((unloaded / totalManifest) * 100)) : 0;
  const parsed = Number(draft);
  const canAdd = draft.trim() !== "" && Number.isFinite(parsed) && parsed > 0 && parsed <= (remaining || parsed);
  const currentShift = shiftOf();
  const stop = (e: React.SyntheticEvent) => e.stopPropagation();

  const submit = async () => {
    if (!canAdd || saving) return;
    setSaving(true);
    try {
      await onAddQty(parsed);
      setDraft("");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div
      draggable={draggable}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onClick={onClick}
      className={`rounded-lg border bg-background p-3 shadow-sm transition-all select-none ${
        draggable ? "cursor-grab active:cursor-grabbing hover:border-primary" : ""
      } ${dragging ? "opacity-40" : ""} ${
        selected ? "ring-2 ring-primary border-primary" : ""
      } ${v.is_held_up ? "border-destructive/50 bg-destructive/5" : ""}`}
    >
      <div className="flex items-start gap-2">
        {draggable && <GripVertical className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2 mb-1">
            <span className="font-bold text-sm truncate flex items-center gap-1">
              {v.vehicle_number}
              {v.is_held_up && <AlertTriangle className="h-3.5 w-3.5 text-destructive" />}
              {selected && <Check className="h-3.5 w-3.5 text-primary" />}
            </span>
            <StatusBadge status={v.current_status} />
          </div>
          <div className="text-[11px] text-muted-foreground truncate">{v.vendor_name}</div>
          <div className="text-[11px] text-muted-foreground">
            {v.material_type} · R:<b className="text-foreground">{v.roll_qty}</b>{" "}
            B:<b className="text-foreground">{v.box_qty}</b>
          </div>
          <div className="text-[10px] font-mono text-muted-foreground mt-1">{v.token_no}</div>

          {/* Cumulative partial unloading tracker (shift-wise) */}
          <div
            onClick={stop}
            onMouseDown={stop}
            draggable={false}
            onDragStart={(e) => { e.preventDefault(); e.stopPropagation(); }}
            className="mt-2 rounded-md border border-dashed bg-muted/40 p-2 space-y-1.5"
          >
            <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-muted-foreground">
              <Package className="h-3 w-3" />
              <span>Current Unloaded</span>
              <span className="ml-auto font-mono text-foreground">Total {totalManifest} {unit}</span>
            </div>

            <div className="flex items-baseline gap-1">
              <span className="text-lg font-bold leading-none text-emerald-600">{unloaded}</span>
              <span className="text-[10px] text-muted-foreground">/ {totalManifest} {unit} ({pct}%)</span>
            </div>
            <div className="h-1.5 rounded-full bg-muted overflow-hidden">
              <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-500 transition-all" style={{ width: `${pct}%` }} />
            </div>

            <div className="grid grid-cols-2 gap-1 text-[10px]">
              <div className="rounded border bg-background px-1.5 py-1">
                <div className="text-muted-foreground flex items-center gap-1">
                  <Clock className="h-2.5 w-2.5" /> 06:00–14:00
                </div>
                <div className="font-bold text-foreground">{byShift.A} {unit}</div>
              </div>
              <div className="rounded border bg-background px-1.5 py-1">
                <div className="text-muted-foreground flex items-center gap-1">
                  <Clock className="h-2.5 w-2.5" /> 14:00–22:00
                </div>
                <div className="font-bold text-foreground">{byShift.B} {unit}</div>
              </div>
            </div>
            {byShift.OFF > 0 && (
              <div className="text-[10px] text-amber-700 dark:text-amber-400">
                Off-shift: <b>{byShift.OFF}</b> {unit}
              </div>
            )}

            {canEdit && (
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  min={1}
                  max={remaining || undefined}
                  inputMode="numeric"
                  placeholder={`Add ${unit.toLowerCase()}`}
                  value={draft}
                  onClick={stop}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") { stop(e); void submit(); } }}
                  className="w-24 h-7 px-1 rounded border bg-background text-center text-xs"
                />
                <button
                  disabled={!canAdd || saving}
                  onClick={(e) => { stop(e); void submit(); }}
                  className="h-7 px-2 rounded bg-primary text-primary-foreground text-[11px] font-medium disabled:opacity-30 inline-flex items-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Add
                </button>
                <span className="ml-auto text-[9px] uppercase tracking-wide text-muted-foreground">
                  {currentShift === "OFF" ? "Off-shift" : `Shift ${currentShift}`}
                </span>
              </div>
            )}

            <div className={`text-[11px] font-medium ${remaining === 0 && totalManifest > 0 ? "text-emerald-600" : "text-amber-700 dark:text-amber-400"}`}>
              Balance to Unload: <span className="font-bold">{remaining}</span> {unit}
            </div>

            {entries.length > 0 && (
              <div className="pt-1 border-t border-border/60">
                <button
                  onClick={(e) => { stop(e); setShowLog((s) => !s); }}
                  className="text-[10px] text-muted-foreground hover:text-foreground underline"
                >
                  {showLog ? "Hide" : `View ${entries.length} entr${entries.length === 1 ? "y" : "ies"}`}
                </button>
                {showLog && (
                  <div className="mt-1 space-y-0.5 max-h-28 overflow-auto">
                    {[...entries].reverse().map((en) => (
                      <div key={en.id} className="flex items-center gap-1 text-[10px] font-mono">
                        <span className="w-6 shrink-0 text-muted-foreground">{en.shift}</span>
                        <span className="font-bold">{en.qty}</span>
                        <span className="text-muted-foreground truncate">
                          {new Date(en.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          {en.source === "completion" ? " · balance" : ""}
                        </span>
                        {canEdit && (
                          <button
                            onClick={(e) => { stop(e); void onDeleteEntry(en.id); }}
                            className="ml-auto text-destructive/70 hover:text-destructive"
                            title="Remove entry"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}



function LoadChip({ label, count, tone }: { label: string; count: number; tone: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border bg-card/70 pl-2 pr-1 py-1 text-xs font-medium">
      <span className={`h-2 w-2 rounded-full ${tone}`} />
      {label}
      <span className="ml-0.5 min-w-5 text-center rounded-full bg-foreground/10 px-1.5 font-mono font-bold">{count}</span>
    </span>
  );
}
