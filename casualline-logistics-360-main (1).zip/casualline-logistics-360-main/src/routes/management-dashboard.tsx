import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { AppFooter } from "@/components/AppFooter";
import { Briefcase } from "lucide-react";
import { ManagementSummaryPanels } from "@/components/ManagementSummaryPanels";

export const Route = createFileRoute("/management-dashboard")({
  head: () => ({
    meta: [
      { title: "Management Dashboard — Casualline Logistics 360" },
      { name: "description", content: "High level management KPI overview across logistics, trims and fabric." },
      { property: "og:title", content: "Management Dashboard — Casualline Logistics 360" },
      { property: "og:description", content: "High level management KPI overview across logistics, trims and fabric." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/management-dashboard">
      <ManagementDashboardPage />
      <AppFooter />
    </RequireAccess>
  ),
});

function ManagementDashboardPage() {
  return (
    <div className="p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto">
      <header className="relative overflow-hidden rounded-2xl border-2 border-indigo-400/30 bg-gradient-to-br from-indigo-500/15 via-violet-500/10 to-sky-500/10 p-5 shadow-lg shadow-indigo-500/10">
        <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-indigo-400/20 blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-3 flex-wrap">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white grid place-items-center shadow-md shadow-indigo-500/40">
            <Briefcase className="h-6 w-6" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xl md:text-2xl font-extrabold truncate bg-gradient-to-r from-indigo-600 via-violet-600 to-sky-600 bg-clip-text text-transparent">
              Management Dashboard 📊
            </h1>
            <p className="text-xs text-muted-foreground">Executive KPI view across logistics, trims and fabric operations.</p>
          </div>
        </div>
      </header>

      <ManagementSummaryPanels />
    </div>
  );
}
