import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { useApp } from "@/lib/store";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useMemo, useState, useCallback } from "react";
import { toast } from "sonner";
import { Plus, Trash2, X, Save, Pencil, Leaf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SegregationBoard } from "@/components/SegregationArea";

export const Route = createFileRoute("/green-board")({
  head: () => ({
    meta: [
      { title: "RM GRN Green Board — Casualline Logistics 360" },
      { name: "description", content: "Monthly RM operational concern tracking and supplier-wise Segregation Area summaries." },
      { property: "og:title", content: "RM GRN Green Board — Casualline Logistics 360" },
      { property: "og:description", content: "Monthly RM operational concern tracking and supplier-wise Segregation Area summaries." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/green-board">
      <GreenBoardPage />
    </RequireAccess>
  ),
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

interface Concern {
  id: string;
  label: string;
  sort_order: number;
  is_active: boolean;
  board_key: string;
}

const BOARDS: { key: string; label: string }[] = [
  { key: "grn", label: "RM GRN" },
  { key: "kanban", label: "RM Kanban Area" },
  { key: "picking", label: "RM SAU Area" },
  { key: "fabric", label: "RM Fabric Picking & Issuing" },
  { key: "trims", label: "RM Trims Picking" },
  { key: "segregation", label: "Segregation Area" },
];



interface Entry {
  id: string;
  concern_id: string;
  entry_date: string; // YYYY-MM-DD
  note: string;
  shift: "A" | "B";
  submission_count: number;
}


const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function daysInMonth(year: number, month0: number) {
  return new Date(year, month0 + 1, 0).getDate();
}

function fmtDate(year: number, month0: number, day: number) {
  return `${year}-${String(month0 + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
}

function GreenBoardPage() {
  const { user } = useApp();
  const isAdmin = user?.role === "admin";

  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month0, setMonth0] = useState(now.getMonth());
  const [boardKey, setBoardKey] = useState<string>("grn");
  const currentBoard = BOARDS.find((b) => b.key === boardKey) ?? BOARDS[0];


  const [concerns, setConcerns] = useState<Concern[]>([]);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal state
  const [modal, setModal] = useState<null | {
    concern: Concern;
    date: string;
    day: number;
    shift: "A" | "B";
    existing: Entry | null;
    mode: "view" | "edit";
  }>(null);
  const [noteDraft, setNoteDraft] = useState("");

  // Admin: manage concerns
  const [newConcern, setNewConcern] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingLabel, setEditingLabel] = useState("");

  const numDays = daysInMonth(year, month0);
  // Sundays are off days — excluded from the board entirely
  const dayList = useMemo(
    () =>
      Array.from({ length: numDays }, (_, i) => i + 1).filter(
        (d) => new Date(year, month0, d).getDay() !== 0,
      ),
    [numDays, year, month0],
  );
  const workingDays = dayList.length;
  const monthStart = fmtDate(year, month0, 1);
  const monthEnd = fmtDate(year, month0, numDays);
  const todayStr = fmtDate(now.getFullYear(), now.getMonth(), now.getDate());


  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    const [cRes, eRes] = await Promise.all([
      sb.from("green_board_concerns").select("*").eq("is_active", true).eq("board_key", boardKey).order("sort_order", { ascending: true }),
      sb.from("green_board_entries").select("*").eq("board_key", boardKey).gte("entry_date", monthStart).lte("entry_date", monthEnd),
    ]);
    setConcerns((cRes.data ?? []) as Concern[]);
    setEntries((eRes.data ?? []) as Entry[]);
    setLoading(false);
  }, [monthStart, monthEnd, boardKey]);


  useEffect(() => {
    load();
    const ch = sb
      .channel("rt-green-board")
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_entries" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "green_board_concerns" }, () => load())
      .subscribe();
    const refresh = () => { if (document.visibilityState === "visible") void load(true); };
    const interval = window.setInterval(refresh, 10000);
    window.addEventListener("focus", refresh);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener("focus", refresh);
      sb.removeChannel(ch);
    };
  }, [load]);

  // Lookup map for O(1) cell access
  const entryMap = useMemo(() => {
    const m = new Map<string, Entry>();
    for (const e of entries) m.set(`${e.concern_id}|${e.entry_date}|${e.shift ?? "A"}`, e);
    return m;
  }, [entries]);

  const openCell = (concern: Concern, day: number, shift: "A" | "B") => {
    const date = fmtDate(year, month0, day);
    const existing = entryMap.get(`${concern.id}|${date}|${shift}`) ?? null;
    setModal({ concern, date, day, shift, existing, mode: existing ? "view" : "edit" });
    setNoteDraft(existing?.note ?? "");
  };

  const saveNote = async () => {
    if (!modal) return;
    const note = noteDraft.trim();
    if (!note) {
      toast.error("Please describe the issue.");
      return;
    }
    if (modal.existing) {
      const { error } = await sb
        .from("green_board_entries")
        .update({ note, updated_at: new Date().toISOString() })
        .eq("id", modal.existing.id);
      if (error) return toast.error(error.message);
    } else {
      const { error } = await sb
        .from("green_board_entries")
        .insert({ concern_id: modal.concern.id, entry_date: modal.date, note, board_key: boardKey, shift: modal.shift });
      if (error) return toast.error(error.message);


    }
    toast.success("Saved");
    setModal(null);
    load();
  };

  const clearNote = async () => {
    if (!modal?.existing) return;
    if (!confirm("Clear this entry and reset the cell to green?")) return;
    const { error } = await sb.from("green_board_entries").delete().eq("id", modal.existing.id);
    if (error) return toast.error(error.message);
    toast.success("Cell reset to green");
    setModal(null);
    load();
  };

  const addConcern = async () => {
    const label = newConcern.trim();
    if (!label) return;
    const nextOrder = (concerns.at(-1)?.sort_order ?? 0) + 10;
    const { error } = await sb.from("green_board_concerns").insert({ label, sort_order: nextOrder, board_key: boardKey });
    if (error) return toast.error(error.message);
    setNewConcern("");
    load();
  };

  const saveConcernLabel = async (id: string) => {
    const label = editingLabel.trim();
    if (!label) return;
    const { error } = await sb.from("green_board_concerns").update({ label }).eq("id", id);
    if (error) return toast.error(error.message);
    setEditingId(null);
    setEditingLabel("");
    load();
  };

  const removeConcern = async (id: string) => {
    if (!confirm("Remove this concern? All its entries will also be deleted.")) return;
    const { error } = await sb.from("green_board_concerns").delete().eq("id", id);
    if (error) return toast.error(error.message);
    load();
  };

  const clearMonthData = async () => {
    if (!isAdmin) return;
    if (!confirm(`Clear ALL logged issues for ${currentBoard.label} in ${MONTH_NAMES[month0]} ${year}? This cannot be undone.`)) return;
    const { error } = await sb
      .from("green_board_entries")
      .delete()
      .eq("board_key", boardKey)
      .gte("entry_date", monthStart)
      .lte("entry_date", monthEnd);
    if (error) return toast.error(error.message);
    toast.success("Month data cleared");
    load();
  };

  const clearAllBoardData = async () => {
    if (!isAdmin) return;
    if (!confirm(`Clear ALL data (every month) for ${currentBoard.label}? This cannot be undone.`)) return;
    if (!confirm("Are you absolutely sure? All logged issues on this board will be permanently deleted.")) return;
    const { error } = await sb.from("green_board_entries").delete().eq("board_key", boardKey);
    if (error) return toast.error(error.message);
    toast.success("All board data cleared");
    load();
  };

  const changeMonth = (delta: number) => {
    const d = new Date(year, month0 + delta, 1);
    setYear(d.getFullYear());
    setMonth0(d.getMonth());
  };

  // Stats — Sundays excluded, and Clean % only counts days elapsed so far (1st → today)
  const elapsedDays = useMemo(
    () => dayList.filter((d) => fmtDate(year, month0, d) <= todayStr),
    [dayList, year, month0, todayStr],
  );
  const elapsedSet = useMemo(
    () => new Set(elapsedDays.map((d) => fmtDate(year, month0, d))),
    [elapsedDays, year, month0],
  );
  const redCount = entries.filter((e) => elapsedSet.has(e.entry_date)).length;
  const totalCells = concerns.length * elapsedDays.length * 2;
  const cleanPct = totalCells ? Math.round(((totalCells - redCount) / totalCells) * 100) : 100;


  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-emerald-50/40 p-6">
      {/* Header */}
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-emerald-600 text-white grid place-items-center shadow-lg">
              <Leaf className="h-6 w-6" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-900 leading-none uppercase">
                {currentBoard.label}
              </h1>
              <p className="text-sm text-slate-500 mt-1">Monthly operational noise tracker — clean days stay green.</p>

            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => changeMonth(-1)}
            className="px-3 py-2 rounded-md border bg-white hover:bg-slate-50 text-sm font-medium"
          >
            ◀ Prev
          </button>
          <div className="px-4 py-2 rounded-md bg-white border shadow-sm min-w-[180px] text-center">
            <div className="text-xs uppercase tracking-wider text-slate-400">Viewing</div>
            <div className="text-lg font-bold text-slate-900">{MONTH_NAMES[month0]} {year}</div>
          </div>
          <button
            onClick={() => changeMonth(1)}
            className="px-3 py-2 rounded-md border bg-white hover:bg-slate-50 text-sm font-medium"
          >
            Next ▶
          </button>
        </div>
      </div>

      {/* Sub-board tabs */}
      <div className="mb-4 flex flex-wrap gap-2 rounded-xl border bg-white p-2 shadow-sm">
        {BOARDS.map((b) => {
          const active = b.key === boardKey;
          return (
            <button
              key={b.key}
              onClick={() => setBoardKey(b.key)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                active
                  ? "bg-emerald-600 text-white shadow"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {b.label}
            </button>
          );
        })}
      </div>



      {boardKey === "segregation" ? <SegregationBoard year={year} month0={month0} isAdmin={isAdmin} /> : (<>
      {/* Stats strip */}
      <div className="mb-4 grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Concerns Tracked" value={concerns.length} color="slate" />
        <StatCard label="Working Days (excl. Sun)" value={workingDays} color="slate" />
        <StatCard label="Red Cells (Noise)" value={redCount} color="red" />
        <StatCard label="Clean % (to date)" value={`${cleanPct}%`} color="emerald" />
      </div>

      {/* Grid */}
      <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse text-sm">
            <thead>
              <tr>
                <th
                  className="sticky left-0 z-20 bg-slate-900 text-white text-left px-4 py-3 font-semibold border-r border-slate-700"
                  style={{ minWidth: 220, maxWidth: 280 }}
                >
                  Concern / Issue
                </th>
                {dayList.map((d) => {
                  const isToday = fmtDate(year, month0, d) === todayStr;
                  return (
                    <th
                      key={d}
                      className={`px-0 py-2 text-center font-semibold border-r border-slate-700 ${
                        isToday ? "bg-amber-500 text-slate-900" : "bg-slate-900 text-white"
                      }`}
                      style={{ minWidth: 56, width: 56 }}
                    >
                      <div>{d}</div>
                      <div className="flex justify-around text-[9px] font-bold opacity-70 mt-0.5">
                        <span>A</span>
                        <span>B</span>
                      </div>
                    </th>
                  );
                })}

              </tr>
            </thead>
            <tbody>
              {loading && (
                <tr>
                  <td colSpan={workingDays + 1} className="p-12 text-center text-slate-400">Loading…</td>
                </tr>
              )}
              {!loading && concerns.length === 0 && (
                <tr>
                  <td colSpan={workingDays + 1} className="p-12 text-center text-slate-500">
                    No concerns yet. {isAdmin ? "Add one below to start tracking." : "Ask an admin to add concerns."}
                  </td>
                </tr>
              )}
              {concerns.map((c, idx) => (
                <tr key={c.id} className={idx % 2 ? "bg-slate-50/50" : ""}>
                  <td
                    className="sticky left-0 z-10 bg-white border-r border-slate-200 px-4 py-2 font-medium text-slate-800"
                    style={{ minWidth: 220, maxWidth: 280 }}
                  >
                    <div className="flex items-center justify-between gap-2">
                      {editingId === c.id ? (
                        <>
                          <input
                            value={editingLabel}
                            onChange={(e) => setEditingLabel(e.target.value)}
                            className="flex-1 min-w-0 px-2 py-1 border rounded text-sm"
                            autoFocus
                          />
                          <button onClick={() => saveConcernLabel(c.id)} className="text-emerald-600 hover:text-emerald-700">
                            <Save className="h-4 w-4" />
                          </button>
                          <button onClick={() => { setEditingId(null); setEditingLabel(""); }} className="text-slate-400 hover:text-slate-600">
                            <X className="h-4 w-4" />
                          </button>
                        </>
                      ) : (
                        <>
                          <span className="truncate">{c.label}</span>
                          {isAdmin && (
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                onClick={() => { setEditingId(c.id); setEditingLabel(c.label); }}
                                className="text-slate-400 hover:text-slate-700"
                                title="Rename"
                              >
                                <Pencil className="h-3.5 w-3.5" />
                              </button>
                              <button
                                onClick={() => removeConcern(c.id)}
                                className="text-slate-400 hover:text-red-600"
                                title="Delete"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  </td>
                  {dayList.map((d) => {
                    const date = fmtDate(year, month0, d);
                    return (
                      <td
                        key={d}
                        className="p-0 border border-white"
                        style={{ minWidth: 56, width: 56, height: 40 }}
                      >
                        <div className="flex h-full w-full">
                          {(["A", "B"] as const).map((s) => {
                            const entry = entryMap.get(`${c.id}|${date}|${s}`);
                            const isRed = !!entry;
                            const count = entry?.submission_count ?? 1;
                            return (
                              <Button
                                key={s}
                                variant="ghost"
                                type="button"
                                onClick={() => openCell(c, d, s)}
                                title={`Shift ${s} — ${isRed ? `${count} submission${count === 1 ? "" : "s"}` : "click to log an issue"}`}
                                className={`flex-1 min-w-7 h-10 rounded-none px-0.5 py-0 text-xs font-bold tabular-nums leading-none border-r border-background/70 last:border-r-0 focus-visible:ring-inset ${
                                  isRed
                                    ? "bg-destructive hover:bg-destructive/90 text-destructive-foreground hover:text-destructive-foreground"
                                    : "bg-board-clean hover:bg-board-clean/90 text-board-clean-foreground hover:text-board-clean-foreground"
                                }`}
                                aria-label={`${c.label} on day ${d} shift ${s}: ${isRed ? `${count} submission${count === 1 ? "" : "s"}` : "clean"}`}
                              >
                                {isRed ? count : s}
                              </Button>
                            );
                          })}
                        </div>
                      </td>
                    );
                  })}

                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Admin: add concern */}
      {isAdmin && (
        <div className="mt-6 rounded-xl border bg-white p-4 shadow-sm">
          <div className="text-sm font-semibold text-slate-700 mb-2">Add a new concern / issue</div>
          <div className="flex gap-2">
            <input
              value={newConcern}
              onChange={(e) => setNewConcern(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") addConcern(); }}
              placeholder="e.g. Late Invoice Submission"
              className="flex-1 px-3 py-2 border rounded-md text-sm"
            />
            <button
              onClick={addConcern}
              className="px-4 py-2 rounded-md bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium flex items-center gap-2"
            >
              <Plus className="h-4 w-4" /> Add
            </button>
          </div>

          <div className="mt-5 pt-4 border-t">
            <div className="text-sm font-semibold text-red-700 mb-1 flex items-center gap-2">
              <Trash2 className="h-4 w-4" /> Danger zone — clear logged data
            </div>
            <p className="text-xs text-slate-500 mb-3">
              These actions permanently delete red-cell entries for the current board. Concerns are kept.
            </p>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={clearMonthData}
                className="px-3 py-2 rounded-md border border-red-300 text-red-700 hover:bg-red-50 text-sm font-medium"
              >
                Clear {MONTH_NAMES[month0]} {year}
              </button>
              <button
                onClick={clearAllBoardData}
                className="px-3 py-2 rounded-md bg-red-600 hover:bg-red-700 text-white text-sm font-semibold"
              >
                Clear ALL data ({currentBoard.label})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="mt-4 flex items-center gap-4 text-xs text-slate-500">
        <div className="flex items-center gap-2"><span className="inline-block w-4 h-4 bg-emerald-500 rounded" /> Clean day</div>
        <div className="flex items-center gap-2"><span className="inline-block w-4 h-4 bg-red-500 rounded" /> Issue logged</div>
        <div className="flex items-center gap-2"><span className="inline-block w-4 h-4 bg-amber-500 rounded" /> Today</div>
      </div>

      </>)}

      {/* Modal */}
      {modal && (
        <div
          className="fixed inset-0 z-50 bg-black/50 grid place-items-center p-4"
          onClick={() => setModal(null)}
        >
          <div
            className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95"
            onClick={(e) => e.stopPropagation()}
          >
            <div className={`px-5 py-4 flex items-start justify-between ${modal.existing ? "bg-red-500" : "bg-emerald-500"} text-white`}>
              <div>
                <div className="text-xs uppercase tracking-wider opacity-80">
                  {MONTH_NAMES[month0]} {modal.day}, {year} · Shift {modal.shift}
                </div>
                <div className="text-lg font-bold">{modal.concern.label}</div>
              </div>
              <button onClick={() => setModal(null)} className="hover:bg-white/20 rounded p-1">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-5">
              {modal.mode === "view" && modal.existing ? (
                <>
                  <div className="text-xs font-semibold text-muted-foreground uppercase mb-2">Logged Issue · {modal.existing.submission_count ?? 1} submissions</div>
                  <div className="p-4 rounded-md bg-red-50 border border-red-200 text-slate-800 whitespace-pre-wrap">
                    {modal.existing.note}
                  </div>
                  <div className="mt-5 flex justify-end gap-2">
                    <button
                      onClick={clearNote}
                      className="px-3 py-2 rounded-md border border-red-300 text-red-700 hover:bg-red-50 text-sm font-medium"
                    >
                      Clear (reset to green)
                    </button>
                    <button
                      onClick={() => { setModal({ ...modal, mode: "edit" }); setNoteDraft(modal.existing?.note ?? ""); }}
                      className="px-3 py-2 rounded-md bg-slate-900 text-white text-sm font-medium hover:bg-slate-800"
                    >
                      Edit
                    </button>
                  </div>
                </>
              ) : (
                <>
                  <label className="text-xs font-semibold text-slate-500 uppercase mb-2 block">
                    Describe the issue
                  </label>
                  <textarea
                    value={noteDraft}
                    onChange={(e) => setNoteDraft(e.target.value)}
                    rows={5}
                    autoFocus
                    placeholder="What happened on this day?"
                    className="w-full px-3 py-2 border rounded-md text-sm resize-none focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <div className="mt-2 text-xs text-slate-400">
                    Saving turns this cell red. The note stays hidden until someone clicks the cell.
                  </div>
                  <div className="mt-5 flex justify-end gap-2">
                    <button
                      onClick={() => setModal(null)}
                      className="px-3 py-2 rounded-md border text-sm font-medium hover:bg-slate-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={saveNote}
                      className="px-4 py-2 rounded-md bg-red-500 hover:bg-red-600 text-white text-sm font-semibold"
                    >
                      Save & Mark Red
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string | number; color: "slate" | "red" | "emerald" }) {
  const colorMap = {
    slate: "text-slate-900",
    red: "text-red-600",
    emerald: "text-emerald-600",
  };
  return (
    <div className="rounded-lg bg-white border shadow-sm px-4 py-3">
      <div className="text-xs uppercase tracking-wider text-slate-400">{label}</div>
      <div className={`text-2xl font-bold ${colorMap[color]}`}>{value}</div>
    </div>
  );
}
