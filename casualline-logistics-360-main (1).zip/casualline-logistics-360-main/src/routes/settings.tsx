import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import type { AdminSettings, VehicleType } from "@/lib/types";
import { VEHICLE_TYPES } from "@/lib/types";
import { Save, Settings as SettingsIcon, Plus, Trash2, Check, X, Pencil, AlertTriangle, CalendarX } from "lucide-react";
import { StorageBalanceCard } from "@/components/StorageBalanceCard";
import { supabase } from "@/integrations/supabase/client";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Admin Settings — Casualline Logistics 360" }, { name: "description", content: "Configure Casualline logistics targets, shifts and operational settings." },
      { property: "og:title", content: "Admin Settings — Casualline Logistics 360" },
      { property: "og:description", content: "Configure Casualline logistics targets, shifts and operational settings." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: () => (
    <RequireAccess path="/settings">
      <SettingsPage />
    </RequireAccess>
  ),
});

function SettingsPage() {
  const { state, user, updateSettings, upsertHeldUpRate, addGrnReason, updateGrnReason, removeGrnReason } = useApp();
  const [form, setForm] = useState<AdminSettings>(state.settings);
  const [saving, setSaving] = useState(false);

  // Local rate edits (indexed by vehicle size)
  const [rateEdits, setRateEdits] = useState<Record<string, string>>({});
  useEffect(() => { setForm(state.settings); }, [state.settings]);

  // GRN reasons state
  const [newReason, setNewReason] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingLabel, setEditingLabel] = useState("");

  if (user?.role !== "admin") {
    return (
      <div className="p-8">
        <div className="rounded-lg border border-destructive/40 bg-destructive/5 p-6 text-center">
          <div className="font-semibold text-destructive">Admin access required</div>
          <p className="text-sm text-muted-foreground mt-1">Only administrators may configure operational parameters.</p>
        </div>
      </div>
    );
  }

  const save = async () => {
    setSaving(true);
    try {
      await updateSettings(form);
      toast.success("Settings saved");
    } catch { toast.error("Failed to save"); } finally { setSaving(false); }
  };

  const rateFor = (size: VehicleType): number =>
    state.heldUpRates.find((r) => r.vehicle_size === size)?.rate_per_hour ?? 0;

  const commitRate = async (size: VehicleType) => {
    const raw = rateEdits[size];
    if (raw == null) return;
    const val = Number(raw);
    if (!isFinite(val) || val < 0) { toast.error("Invalid rate"); return; }
    try {
      await upsertHeldUpRate(size, val);
      setRateEdits((prev) => { const n = { ...prev }; delete n[size]; return n; });
      toast.success(`${size} rate updated`);
    } catch { toast.error("Failed to update rate"); }
  };

  const addReason = async () => {
    const label = newReason.trim();
    if (!label) return;
    try {
      await addGrnReason(label);
      setNewReason("");
      toast.success("Reason added");
    } catch { toast.error("Failed to add"); }
  };

  const startEdit = (id: string, label: string) => { setEditingId(id); setEditingLabel(label); };
  const cancelEdit = () => { setEditingId(null); setEditingLabel(""); };
  const commitEdit = async () => {
    if (!editingId) return;
    const label = editingLabel.trim();
    if (!label) return;
    try { await updateGrnReason(editingId, { label }); cancelEdit(); toast.success("Reason updated"); }
    catch { toast.error("Failed"); }
  };

  const [clearing, setClearing] = useState<string | null>(null);
  const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
  const now = new Date();
  const yearOptions = Array.from({ length: 7 }, (_, i) => now.getFullYear() - 2 + i);

  // ---- Every operational data centre that can be month-scoped cleared ----
  type DataSource = {
    key: string;
    table: string;
    label: string;
    desc: string;
    col: string;
    kind: "ts" | "date" | "ym";
  };

  const DATA_SOURCES: DataSource[] = [
    { key: "vehicle_logs", table: "vehicle_logs", label: "Vehicle Logs", desc: "Guard / GRN / Bays vehicle records — check-ins, assignments, held-ups, departures.", col: "in_time", kind: "ts" },
    { key: "unload_entries", table: "unload_entries", label: "Partial Unload Entries", desc: "Shift-wise partial unloaded quantities recorded in Bay Management.", col: "entry_date", kind: "date" },
    { key: "weekly_schedules", table: "weekly_schedules", label: "PCU Weekly Schedules", desc: "PCU scheduled arrivals whose week falls in the selected month.", col: "week_start", kind: "date" },
    { key: "green_board_entries", table: "green_board_entries", label: "Green Board Entries", desc: "Logged issues on every board (RM GRN, Kanban, RM SAU, Fabric, Trims).", col: "entry_date", kind: "date" },
    { key: "picker_achievements", table: "picker_achievements", label: "Trims Picker Achievements", desc: "Trims picking (GIN) achievements logged by pickers.", col: "picked_at", kind: "ts" },
    { key: "fabric_picker_achievements", table: "fabric_picker_achievements", label: "Fabric Picker Achievements", desc: "Fabric picking (GIN) achievements logged by pickers.", col: "picked_at", kind: "ts" },
    { key: "trims_plan", table: "trims_plan", label: "Trims Plan Uploads", desc: "Uploaded Trims production plan rows.", col: "uploaded_at", kind: "ts" },
    { key: "fabric_plan", table: "fabric_plan", label: "Fabric Plan Uploads", desc: "Uploaded Fabric production plan rows.", col: "uploaded_at", kind: "ts" },
    { key: "trims_downtime", table: "trims_downtime", label: "Trims Downtime", desc: "Trims downtime / lost hours log entries.", col: "entry_date", kind: "date" },
    { key: "fabric_downtime", table: "fabric_downtime", label: "Fabric Downtime", desc: "Fabric downtime / lost hours log entries.", col: "entry_date", kind: "date" },
    { key: "invoice_daily_log", table: "invoice_daily_log", label: "Daily Invoice GRN Log", desc: "Fabric & Trims daily invoice received / completed counts.", col: "log_date", kind: "date" },
    { key: "cycle_count_logs", table: "cycle_count_logs", label: "Cycle Count Logs", desc: "Uploaded cycle counting variance logs.", col: "upload_date", kind: "ts" },
    { key: "cc_daily_actuals", table: "cc_daily_actuals", label: "CC Daily Actuals", desc: "Cycle counting daily counted quantities.", col: "entry_date", kind: "date" },
    { key: "cc_monthly_targets", table: "cc_monthly_targets", label: "CC Monthly Targets", desc: "Cycle counting monthly item targets for the selected month.", col: "month", kind: "ym" },
  ];

  const deleteSource = (src: DataSource, month: number, year: number) => {
    const start = new Date(year, month, 1);
    const end = new Date(year, month + 1, 1);
    const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    if (src.kind === "ym") {
      return sb.from(src.table).delete().eq(src.col, `${year}-${String(month + 1).padStart(2, "0")}`);
    }
    const from = src.kind === "ts" ? start.toISOString() : iso(start);
    const to = src.kind === "ts" ? end.toISOString() : iso(end);
    return sb.from(src.table).delete().gte(src.col, from).lt(src.col, to);
  };

  // Per-card month/year selections (default: current month for every source)
  const [srcPeriod, setSrcPeriod] = useState<Record<string, { m: number; y: number }>>(
    () => Object.fromEntries(DATA_SOURCES.map((s) => [s.key, { m: now.getMonth(), y: now.getFullYear() }])),
  );
  const periodOf = (key: string) => srcPeriod[key] ?? { m: now.getMonth(), y: now.getFullYear() };
  const setPeriod = (key: string, patch: Partial<{ m: number; y: number }>) =>
    setSrcPeriod((p) => ({ ...p, [key]: { ...periodOf(key), ...patch } }));

  const clearOne = async (src: DataSource) => {
    const { m, y } = periodOf(src.key);
    const periodLabel = `${MONTHS[m]} ${y}`;
    if (!confirm(`Clear ${src.label} for ${periodLabel}? This permanently deletes matching rows and cannot be undone.`)) return;
    const typed = prompt(`Type CLEAR to confirm deleting ${src.label} for ${periodLabel}:`);
    if (typed !== "CLEAR") { toast.error("Cancelled — confirmation text did not match"); return; }
    setClearing(src.key);
    try {
      const { error } = await deleteSource(src, m, y);
      if (error) { toast.error((error as { message?: string })?.message ?? "Failed"); return; }
      toast.success(`${src.label} cleared for ${periodLabel}`);
    } finally {
      setClearing(null);
    }
  };

  // Monthly clearance panel state
  const [mcMonth, setMcMonth] = useState<number>(now.getMonth());
  const [mcYear, setMcYear] = useState<number>(now.getFullYear());
  const [mcOpen, setMcOpen] = useState(false);
  const [mcTyped, setMcTyped] = useState("");
  const [mcBusy, setMcBusy] = useState(false);
  const [mcSelected, setMcSelected] = useState<string[]>(() => DATA_SOURCES.map((s) => s.key));

  const toggleMc = (key: string) =>
    setMcSelected((p) => (p.includes(key) ? p.filter((k) => k !== key) : [...p, key]));

  const clearMonthlyData = async () => {
    if (mcTyped !== "DELETE") return;
    setMcBusy(true);
    try {
      const targets = DATA_SOURCES.filter((s) => mcSelected.includes(s.key));
      const results = await Promise.all(targets.map((s) => deleteSource(s, mcMonth, mcYear)));
      const failed = results.find((r: { error?: unknown }) => r.error);
      if (failed?.error) throw failed.error;
      toast.success(`Cleared ${targets.length} data centre(s) for ${MONTHS[mcMonth]} ${mcYear}`);
      setMcOpen(false);
      setMcTyped("");
    } catch (e) {
      toast.error((e as { message?: string })?.message ?? "Failed to clear monthly data");
    } finally {
      setMcBusy(false);
    }
  };


  return (
    <>
    <div className="p-6 space-y-6 max-w-5xl">

      <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-violet-500/15 via-fuchsia-500/10 to-pink-500/10 p-6">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-fuchsia-500/25 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-violet-500/20 blur-3xl" />
        <div className="relative flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 text-white grid place-items-center shadow-lg shadow-fuchsia-500/30">
            <SettingsIcon className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">Admin Settings</h1>
            <p className="text-sm text-muted-foreground">Operational parameters used across the system</p>
          </div>
        </div>
      </div>

      <StorageBalanceCard />


      {/* Variable held-up rates */}
      <section className="rounded-lg border bg-card p-5 space-y-4">
        <div>
          <h3 className="font-semibold">Variable Held-up / Demurrage Cost</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Rate per hour beyond the 24h SLA, configured per vehicle size.</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {VEHICLE_TYPES.map((size) => {
            const current = rateFor(size);
            const editing = rateEdits[size];
            const dirty = editing !== undefined && Number(editing) !== current;
            return (
              <div key={size} className="rounded-md border p-3 flex items-center gap-3">
                <div className="w-16 text-sm font-semibold">{size}</div>
                <div className="flex-1 flex items-center gap-1">
                  <span className="text-xs text-muted-foreground">Rs.</span>
                  <input
                    type="number"
                    min={0}
                    value={editing !== undefined ? editing : String(current)}
                    onChange={(e) => setRateEdits((p) => ({ ...p, [size]: e.target.value }))}
                    className="w-full h-9 px-2 rounded border bg-background text-sm"
                  />
                  <span className="text-xs text-muted-foreground">/hr</span>
                </div>
                <button
                  onClick={() => commitRate(size)}
                  disabled={!dirty}
                  className="h-9 px-3 rounded-md bg-primary text-primary-foreground text-xs font-medium disabled:opacity-40"
                >
                  Save
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {/* Legacy single held-up rate (fallback) */}
      <section className="rounded-lg border bg-card p-5 space-y-4">
        <div>
          <h3 className="font-semibold">Fallback Held-up Rate</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Used when a vehicle's size is not configured above.</p>
        </div>
        <Field label="Fallback Cost Rate (Rs. per hour beyond 24h)">
          <input type="number" min={0} value={form.held_up_cost_rate}
            onChange={(e) => setForm({ ...form, held_up_cost_rate: Number(e.target.value) })}
            className="w-full h-10 px-3 rounded border bg-background" />
        </Field>
      </section>

      {/* Daily targets */}
      <section className="rounded-lg border bg-card p-5 space-y-4">
        <h3 className="font-semibold">Daily Target Capacity</h3>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Total Roll Qty / day">
            <input type="number" min={0} value={form.daily_roll_target}
              onChange={(e) => setForm({ ...form, daily_roll_target: Number(e.target.value) })}
              className="w-full h-10 px-3 rounded border bg-background" />
          </Field>
          <Field label="Total Box Qty / day">
            <input type="number" min={0} value={form.daily_box_target}
              onChange={(e) => setForm({ ...form, daily_box_target: Number(e.target.value) })}
              className="w-full h-10 px-3 rounded border bg-background" />
          </Field>
        </div>
      </section>

      {/* Shift hours */}
      <section className="rounded-lg border bg-card p-5 space-y-4">
        <h3 className="font-semibold">Shift Working Hours</h3>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Shift Start">
            <input type="time" value={form.shift_start}
              onChange={(e) => setForm({ ...form, shift_start: e.target.value })}
              className="w-full h-10 px-3 rounded border bg-background" />
          </Field>
          <Field label="Shift End">
            <input type="time" value={form.shift_end}
              onChange={(e) => setForm({ ...form, shift_end: e.target.value })}
              className="w-full h-10 px-3 rounded border bg-background" />
          </Field>
        </div>
      </section>

      <div className="flex justify-end">
        <button onClick={save} disabled={saving}
          className="h-10 px-5 rounded-md bg-primary text-primary-foreground font-medium flex items-center gap-2 disabled:opacity-60">
          <Save className="h-4 w-4" /> {saving ? "Saving…" : "Save Targets & Shift"}
        </button>
      </div>

      {/* GRN Pending Reasons */}
      <section className="rounded-lg border bg-card p-5 space-y-4">
        <div>
          <h3 className="font-semibold">GRN Pending Reasons</h3>
          <p className="text-xs text-muted-foreground mt-0.5">These appear when the GRN team places a vehicle on hold.</p>
        </div>
        <div className="flex gap-2">
          <input value={newReason} onChange={(e) => setNewReason(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addReason(); } }}
            placeholder="Add a new reason (e.g. Labor Shortage)"
            className="flex-1 h-10 px-3 rounded border bg-background" />
          <button onClick={addReason}
            className="h-10 px-4 rounded-md bg-primary text-primary-foreground text-sm font-medium flex items-center gap-1">
            <Plus className="h-4 w-4" /> Add
          </button>
        </div>
        <ul className="divide-y rounded-md border">
          {state.grnReasons.length === 0 && (
            <li className="p-4 text-sm text-muted-foreground text-center">No reasons yet.</li>
          )}
          {state.grnReasons.map((r) => (
            <li key={r.id} className="flex items-center gap-2 p-2.5">
              <label className="flex items-center gap-2 text-xs text-muted-foreground shrink-0 pl-1">
                <input
                  type="checkbox"
                  checked={r.is_active}
                  onChange={(e) => updateGrnReason(r.id, { is_active: e.target.checked })}
                />
                Active
              </label>
              <div className="flex-1">
                {editingId === r.id ? (
                  <input
                    autoFocus
                    value={editingLabel}
                    onChange={(e) => setEditingLabel(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") commitEdit(); if (e.key === "Escape") cancelEdit(); }}
                    className="w-full h-8 px-2 rounded border bg-background text-sm"
                  />
                ) : (
                  <span className={`text-sm ${r.is_active ? "" : "line-through text-muted-foreground"}`}>{r.label}</span>
                )}
              </div>
              {editingId === r.id ? (
                <>
                  <button onClick={commitEdit} className="h-8 w-8 rounded hover:bg-muted grid place-items-center" title="Save">
                    <Check className="h-4 w-4 text-emerald-600" />
                  </button>
                  <button onClick={cancelEdit} className="h-8 w-8 rounded hover:bg-muted grid place-items-center" title="Cancel">
                    <X className="h-4 w-4" />
                  </button>
                </>
              ) : (
                <>
                  <button onClick={() => startEdit(r.id, r.label)} className="h-8 w-8 rounded hover:bg-muted grid place-items-center" title="Edit">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => { if (confirm(`Delete "${r.label}"?`)) removeGrnReason(r.id); }}
                    className="h-8 w-8 rounded hover:bg-destructive/10 grid place-items-center"
                    title="Delete"
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      </section>

      {/* Danger Zone — admin-only data clearing */}
      <section className="rounded-lg border-2 border-red-300 bg-red-50/40 p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-red-600 text-white grid place-items-center">
            <AlertTriangle className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold text-red-900">Danger Zone — Clear Data ({DATA_SOURCES.length} data centres)</h3>
            <p className="text-xs text-red-700/80 mt-0.5">
              Permanently delete operational records, per data centre and per month. Configuration (settings, rates, reasons, concerns, picker targets) is preserved.
              Each button requires typing <code className="font-mono bg-white px-1 rounded">CLEAR</code> to confirm.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {DATA_SOURCES.map((src) => (
            <DangerCard
              key={src.key}
              title={src.label}
              desc={src.desc}
              busy={clearing === src.key}
              onClick={() => clearOne(src)}
              month={periodOf(src.key).m}
              year={periodOf(src.key).y}
              onMonthChange={(m) => setPeriod(src.key, { m })}
              onYearChange={(y) => setPeriod(src.key, { y })}
              months={MONTHS} years={yearOptions}
            />
          ))}
        </div>
      </section>

      {/* Monthly Data Clearance Panel */}
      <section className="rounded-lg border-2 border-red-300 bg-red-50/40 p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-md bg-red-600 text-white grid place-items-center">
            <CalendarX className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold text-red-900">Monthly Data Clearance</h3>
            <p className="text-xs text-red-700/80 mt-0.5">
              Purge every selected data centre for one month in a single action. Configuration (settings, rates, reasons, concerns, picker targets) is preserved.
            </p>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-3 items-end">
          <label className="block">
            <span className="text-xs font-medium text-red-900">Select Month</span>
            <select value={mcMonth} onChange={(e) => setMcMonth(Number(e.target.value))}
              className="mt-1 w-full h-10 px-3 rounded border bg-white">
              {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="text-xs font-medium text-red-900">Select Year</span>
            <select value={mcYear} onChange={(e) => setMcYear(Number(e.target.value))}
              className="mt-1 w-full h-10 px-3 rounded border bg-white">
              {yearOptions.map((y) => <option key={y} value={y}>{y}</option>)}
            </select>
          </label>
          <button
            disabled={mcSelected.length === 0}
            onClick={() => { setMcTyped(""); setMcOpen(true); }}
            className="h-10 px-4 rounded-md bg-red-600 hover:bg-red-700 text-white text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-40"
          >
            <Trash2 className="h-4 w-4" /> Clear Selected Month Data
          </button>
        </div>

        <div className="rounded-md border border-red-200 bg-white p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-red-900">
              Data centres included ({mcSelected.length}/{DATA_SOURCES.length})
            </span>
            <div className="flex gap-2">
              <button onClick={() => setMcSelected(DATA_SOURCES.map((s) => s.key))}
                className="text-[11px] px-2 py-1 rounded border hover:bg-red-50">Select all</button>
              <button onClick={() => setMcSelected([])}
                className="text-[11px] px-2 py-1 rounded border hover:bg-red-50">Clear selection</button>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5">
            {DATA_SOURCES.map((s) => (
              <label key={s.key} className="flex items-center gap-2 text-xs text-slate-700">
                <input type="checkbox" checked={mcSelected.includes(s.key)} onChange={() => toggleMc(s.key)} />
                <span className="truncate">{s.label}</span>
              </label>
            ))}
          </div>
        </div>
      </section>

    </div>

    {mcOpen && (
      <div className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4" onClick={() => !mcBusy && setMcOpen(false)}>
        <div className="w-full max-w-md rounded-lg bg-white shadow-2xl border-2 border-red-400" onClick={(e) => e.stopPropagation()}>
          <div className="p-5 border-b border-red-200 flex items-start gap-3">
            <div className="h-10 w-10 rounded-md bg-red-600 text-white grid place-items-center shrink-0">
              <AlertTriangle className="h-5 w-5" />
            </div>
            <div>
              <h4 className="font-bold text-red-900">Warning — Permanent Deletion</h4>
              <p className="text-sm text-slate-700 mt-1 leading-relaxed">
                This will permanently delete <strong>{mcSelected.length}</strong> selected data centre(s)
                ({DATA_SOURCES.filter((s) => mcSelected.includes(s.key)).map((s) => s.label).join(", ")})
                for <strong>{MONTHS[mcMonth]} {mcYear}</strong>. This cannot be undone.
              </p>

            </div>
          </div>
          <div className="p-5 space-y-3">
            <label className="block">
              <span className="text-xs font-medium text-slate-700">
                Type <code className="font-mono bg-red-100 text-red-800 px-1.5 py-0.5 rounded">DELETE</code> to confirm:
              </span>
              <input
                autoFocus
                value={mcTyped}
                onChange={(e) => setMcTyped(e.target.value)}
                placeholder="DELETE"
                className="mt-1 w-full h-10 px-3 rounded border bg-white font-mono"
              />
            </label>
          </div>
          <div className="p-4 bg-slate-50 border-t flex justify-end gap-2 rounded-b-lg">
            <button
              onClick={() => setMcOpen(false)}
              disabled={mcBusy}
              className="h-10 px-4 rounded-md border bg-white text-sm font-medium hover:bg-slate-100 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              onClick={clearMonthlyData}
              disabled={mcTyped !== "DELETE" || mcBusy}
              className="h-10 px-4 rounded-md bg-red-600 hover:bg-red-700 text-white text-sm font-semibold flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Trash2 className="h-4 w-4" /> {mcBusy ? "Clearing…" : "Confirm Delete"}
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
}


function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-medium text-muted-foreground">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}

function DangerCard({ title, desc, busy, onClick, month, year, onMonthChange, onYearChange, months, years }: {
  title: string; desc: string; busy: boolean; onClick: () => void;
  month: number; year: number;
  onMonthChange: (v: number) => void; onYearChange: (v: number) => void;
  months: string[]; years: number[];
}) {
  return (
    <div className="rounded-md border border-red-200 bg-white p-4 flex flex-col gap-3">
      <div>
        <div className="font-semibold text-slate-900 text-sm">{title}</div>
        <p className="text-xs text-slate-500 mt-1 leading-relaxed">{desc}</p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        <select value={month} onChange={(e) => onMonthChange(Number(e.target.value))}
          className="h-9 px-2 rounded border bg-white text-xs">
          {months.map((m, i) => <option key={m} value={i}>{m}</option>)}
        </select>
        <select value={year} onChange={(e) => onYearChange(Number(e.target.value))}
          className="h-9 px-2 rounded border bg-white text-xs">
          {years.map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>
      <button
        onClick={onClick}
        disabled={busy}
        className="mt-auto h-9 px-3 rounded-md bg-red-600 hover:bg-red-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 disabled:opacity-50"
      >
        <Trash2 className="h-3.5 w-3.5" /> {busy ? "Clearing…" : `Clear ${months[month]} ${year}`}
      </button>
    </div>
  );
}
