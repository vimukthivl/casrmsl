import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/view")({
  head: () => ({
    meta: [
      { title: "Visitor View — Casualline Logistics 360" },
      { name: "description", content: "Read-only visitor access to Casualline Logistics 360 dashboards and boards." },
      { property: "og:title", content: "Visitor View — Casualline Logistics 360" },
      { property: "og:description", content: "Read-only visitor access to Casualline Logistics 360 dashboards and boards." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ViewerEntry,
});

function ViewerEntry() {
  const { login } = useApp();
  const navigate = useNavigate();

  useEffect(() => {
    login("viewer", "view123");
    navigate({ to: "/dashboard", replace: true });
  }, [login, navigate]);

  return (
    <div className="min-h-screen grid place-items-center text-muted-foreground">
      Opening read-only visitor view…
    </div>
  );
}
