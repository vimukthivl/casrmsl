import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { supabase } from "@/integrations/supabase/client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { HandMetal, AlertTriangle, CheckCircle2, User as UserIcon, Loader2, Delete, CornerDownLeft } from "lucide-react";

export const Route = createFileRoute("/picker")({
  head: () => ({
    meta: [
      { title: "Picker — MAS Casualline Logistics 360" },
      { name: "description", content: "Floor picker submission: EPF + PO validation against active Trims Plan." },
      { property: "og:title", content: "Picker — MAS Casualline Logistics 360" },
      { property: "og:description", content: "Floor picker submission: EPF + PO validation against active Trims Plan." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/picker">
      <PickerPage />
    </RequireAccess>
  ),
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

interface PlanPO {
  id: string;
  production_order: string;
  order_description: string | null;
  order_qty: number | null;
  picker_name: string | null;
  picker_epf: string | null;
}

interface PickerTarget {
  epf_number: string;
  name: string;
  gin_target_per_day: number;
}

function todayIsoStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

type PickMode = "trims" | "fabric";
type PendingPO = PlanPO & { _mode: PickMode };

function PickerPage() {
  const [epf, setEpf] = useState("");
  const [po, setPo] = useState("");
  const [pendingTrims, setPendingTrims] = useState<PendingPO[]>([]);
  const [pendingFabric, setPendingFabric] = useState<PendingPO[]>([]);
  const [targets, setTargets] = useState<PickerTarget[]>([]);
  const [trimsCounts, setTrimsCounts] = useState<Record<string, number>>({});
  const [fabricCounts, setFabricCounts] = useState<Record<string, number>>({});
  const [wrong, setWrong] = useState(false);
  const [busy, setBusy] = useState(false);
  const [showSuggest, setShowSuggest] = useState(false);
  const suggestRef = useRef<HTMLDivElement>(null);
  const [activeField, setActiveField] = useState<"epf" | "po" | null>(null);
  const epfRef = useRef<HTMLInputElement>(null);
  const poRef = useRef<HTMLInputElement>(null);


  const load = useCallback(async () => {
    const [pRes, fRes, tRes, ftRes, aRes, faRes] = await Promise.all([
      sb.from("trims_plan").select("id,production_order,order_description,order_qty,picker_name,picker_epf").is("picker_name", null).order("production_order", { ascending: true }).limit(500),
      sb.from("fabric_plan").select("id,production_order,order_description,order_qty,picker_name,picker_epf").is("picker_name", null).order("production_order", { ascending: true }).limit(500),
      sb.from("picker_targets").select("epf_number,name,gin_target_per_day").eq("is_active", true),
      sb.from("fabric_picker_targets").select("epf_number,name,gin_target_per_day").eq("is_active", true),
      sb.from("picker_achievements").select("epf_number").gte("picked_at", todayIsoStart()),
      sb.from("fabric_picker_achievements").select("epf_number").gte("picked_at", todayIsoStart()),
    ]);
    setPendingTrims(((pRes.data ?? []) as PlanPO[]).map((r) => ({ ...r, _mode: "trims" as const })));
    setPendingFabric(((fRes.data ?? []) as PlanPO[]).map((r) => ({ ...r, _mode: "fabric" as const })));
    // merge both roster tables, dedupe by EPF (case-insensitive)
    const merged = new Map<string, PickerTarget>();
    ([...((tRes.data ?? []) as PickerTarget[]), ...((ftRes.data ?? []) as PickerTarget[])]).forEach((t) => {
      const key = t.epf_number.toLowerCase();
      if (!merged.has(key)) merged.set(key, t);
    });
    setTargets(Array.from(merged.values()));
    const tc: Record<string, number> = {};
    ((aRes.data ?? []) as { epf_number: string }[]).forEach((r) => {
      tc[r.epf_number] = (tc[r.epf_number] ?? 0) + 1;
    });
    setTrimsCounts(tc);
    const fc: Record<string, number> = {};
    ((faRes.data ?? []) as { epf_number: string }[]).forEach((r) => {
      fc[r.epf_number] = (fc[r.epf_number] ?? 0) + 1;
    });
    setFabricCounts(fc);
  }, []);


  useEffect(() => {
    load();
    const ch = sb.channel("rt-picker-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "trims_plan" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_plan" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "picker_achievements" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_picker_achievements" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "picker_targets" }, () => load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_picker_targets" }, () => load())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load]);

  // merged suggestions across both plans — PO auto-routes to correct table
  const pending = useMemo<PendingPO[]>(() => [...pendingTrims, ...pendingFabric], [pendingTrims, pendingFabric]);
  const suggestions = useMemo(() => {
    const q = po.trim().toLowerCase();
    if (!q) return [];
    return pending.filter((p) => p.production_order.toLowerCase().includes(q)).slice(0, 10);
  }, [po, pending]);

  useEffect(() => { setWrong(false); }, [po]);

  const currentTarget = useMemo(() => targets.find((t) => t.epf_number.toLowerCase() === epf.trim().toLowerCase()), [targets, epf]);
  const currentAchieved = currentTarget
    ? (trimsCounts[currentTarget.epf_number] ?? 0) + (fabricCounts[currentTarget.epf_number] ?? 0)
    : 0;
  const currentPct = currentTarget && currentTarget.gin_target_per_day > 0
    ? Math.min(100, Math.round((currentAchieved / currentTarget.gin_target_per_day) * 100))
    : 0;

  const submit = async (overridePo?: string, overrideMode?: PickMode) => {
    const poVal = (overridePo ?? po).trim();
    const epfVal = epf.trim();
    if (!epfVal) { toast.error("EPF number required"); return; }
    if (!poVal) { toast.error("PO number required"); return; }

    setBusy(true);
    try {
      // Auto-detect mode: check trims first, then fabric
      let resolvedMode: PickMode | null = overrideMode ?? null;
      let match: { id: string; picker_name: string | null; picker_date?: string | null } | null = null;

      if (resolvedMode) {
        const table = resolvedMode === "trims" ? "trims_plan" : "fabric_plan";
        const r = await sb.from(table).select("*").eq("production_order", poVal).maybeSingle();
        if (r.error) throw r.error;
        match = r.data;
      } else {
        const [tR, fR] = await Promise.all([
          sb.from("trims_plan").select("*").eq("production_order", poVal).maybeSingle(),
          sb.from("fabric_plan").select("*").eq("production_order", poVal).maybeSingle(),
        ]);
        if (tR.error) throw tR.error;
        if (fR.error) throw fR.error;
        // Prefer unpicked one; if both unpicked, trims wins
        if (tR.data && !tR.data.picker_name) { resolvedMode = "trims"; match = tR.data; }
        else if (fR.data && !fR.data.picker_name) { resolvedMode = "fabric"; match = fR.data; }
        else if (tR.data) { resolvedMode = "trims"; match = tR.data; }
        else if (fR.data) { resolvedMode = "fabric"; match = fR.data; }
      }

      if (!match || !resolvedMode) {
        setWrong(true);
        toast.error("Wrong PO — not in active Trims or Fabric Plan");
        return;
      }

      if (match.picker_name) {
        setWrong(true);
        toast.error(`Already picked by ${match.picker_name}${match.picker_date ? " at " + new Date(match.picker_date).toLocaleString() : ""}`);
        return;
      }

      const planTable = resolvedMode === "trims" ? "trims_plan" : "fabric_plan";
      const achTable = resolvedMode === "trims" ? "picker_achievements" : "fabric_picker_achievements";
      const target = targets.find((t) => t.epf_number.toLowerCase() === epfVal.toLowerCase());
      const displayName = target?.name ?? epfVal;
      const now = new Date().toISOString();

      await Promise.all([
        sb.from(planTable).update({ picker_epf: epfVal, picker_name: displayName, picker_date: now }).eq("id", match.id),
        sb.from(achTable).insert({ epf_number: epfVal, picker_name: displayName, po_number: poVal, plan_id: match.id, picked_at: now }),
      ]);

      toast.success(`PO ${poVal} picked (${resolvedMode === "trims" ? "Trims" : "Fabric"}) · GIN +1`);
      setPo("");
      setShowSuggest(false);
      await load();
    } catch (e) {
      toast.error("Submit failed: " + (e instanceof Error ? e.message : "unknown"));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-4">
      {/* Colorful gradient header */}
      <header className="relative overflow-hidden rounded-2xl border-2 border-fuchsia-400/30 bg-gradient-to-br from-fuchsia-500/15 via-orange-500/10 to-amber-500/15 p-5 shadow-lg shadow-fuchsia-500/10">
        <div className="absolute -top-10 -right-10 h-32 w-32 rounded-full bg-fuchsia-400/20 blur-3xl" />
        <div className="absolute -bottom-10 -left-10 h-32 w-32 rounded-full bg-amber-400/20 blur-3xl" />
        <div className="relative flex items-center gap-3">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-fuchsia-500 to-orange-500 text-white grid place-items-center shrink-0 shadow-md shadow-fuchsia-500/40">
            <HandMetal className="h-6 w-6" />
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="text-xl md:text-2xl font-black truncate bg-gradient-to-r from-fuchsia-600 via-rose-500 to-orange-500 bg-clip-text text-transparent">
              Picker Console 🎯
            </h1>
            <p className="text-xs text-muted-foreground">Tap your EPF, tap the PO — auto-routes to Trims or Fabric ✨</p>
          </div>
        </div>
      </header>

      {/* Wrong PO banner */}
      {wrong && (
        <div className="rounded-xl border-2 border-red-500 bg-gradient-to-r from-red-500/20 to-rose-500/20 text-red-700 dark:text-red-200 px-4 py-3 flex items-center gap-2 animate-pulse shadow-md shadow-red-500/20">
          <AlertTriangle className="h-5 w-5 shrink-0" />
          <div className="font-bold">Wrong PO</div>
          <div className="text-xs opacity-80">— not in active Trims or Fabric Plan, or already picked.</div>
        </div>
      )}


      <section className="rounded-2xl border-2 border-sky-400/30 bg-gradient-to-br from-sky-500/10 via-background to-violet-500/10 p-4 md:p-6 space-y-4 shadow-lg shadow-sky-500/10">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400 flex items-center gap-1">
              <UserIcon className="h-3 w-3" /> EPF Number
            </label>
            <input
              ref={epfRef}
              value={epf}
              onChange={(e) => setEpf(e.target.value)}
              onFocus={(e) => { setActiveField("epf"); e.currentTarget.blur(); }}
              onClick={() => setActiveField("epf")}
              readOnly
              autoFocus
              className={`w-full px-4 py-3 text-lg rounded-xl border-2 bg-background font-mono cursor-pointer transition-all ${activeField === "epf" ? "border-sky-500 ring-4 ring-sky-500/30 shadow-md shadow-sky-500/20" : "border-sky-300/50 hover:border-sky-400"}`}
              placeholder="EPF001"
              inputMode="none"
            />

            {currentTarget ? (
              <div className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1 bg-emerald-500/10 rounded-md px-2 py-1 w-fit">
                <UserIcon className="h-3 w-3" /> {currentTarget.name} ✓
              </div>
            ) : epf.trim() ? (
              <div className="text-xs text-amber-600 dark:text-amber-400">EPF not in roster — submissions will still record under this EPF.</div>
            ) : null}
          </div>

          <div className="space-y-1.5 relative" ref={suggestRef}>
            <label className="text-xs font-bold uppercase tracking-wider text-violet-600 dark:text-violet-400 flex items-center gap-1">
              <CheckCircle2 className="h-3 w-3" /> PO Number
            </label>
            <input
              ref={poRef}
              value={po}
              onChange={(e) => { setPo(e.target.value); setShowSuggest(true); }}
              onFocus={(e) => { setActiveField("po"); setShowSuggest(true); e.currentTarget.blur(); }}
              onClick={() => { setActiveField("po"); setShowSuggest(true); }}
              readOnly
              className={`w-full px-4 py-3 text-lg rounded-xl border-2 bg-background font-mono cursor-pointer transition-all ${wrong ? "border-red-500 ring-4 ring-red-500/30" : activeField === "po" ? "border-violet-500 ring-4 ring-violet-500/30 shadow-md shadow-violet-500/20" : "border-violet-300/50 hover:border-violet-400"}`}
              placeholder="Tap to enter PO…"
              inputMode="none"
            />

            {showSuggest && suggestions.length > 0 && (
              <div className="absolute z-20 top-full left-0 right-0 mt-1 rounded-xl border-2 border-violet-400/40 bg-popover shadow-xl shadow-violet-500/20 max-h-64 overflow-auto">
                {suggestions.map((s) => (
                  <button
                    key={`${s._mode}-${s.id}`}
                    type="button"
                    onClick={() => { setPo(s.production_order); setShowSuggest(false); submit(s.production_order, s._mode); }}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-gradient-to-r hover:from-violet-500/10 hover:to-fuchsia-500/10 flex items-center justify-between gap-2 border-b last:border-b-0"
                  >
                    <span className="flex items-center gap-2 min-w-0">
                      <span className={`text-[10px] font-black px-1.5 py-0.5 rounded ${s._mode === "trims" ? "bg-fuchsia-500/20 text-fuchsia-700 dark:text-fuchsia-300" : "bg-sky-500/20 text-sky-700 dark:text-sky-300"}`}>{s._mode === "trims" ? "🧵 T" : "🧶 F"}</span>
                      <span className="font-mono font-bold text-violet-700 dark:text-violet-300">{s.production_order}</span>
                    </span>
                    <span className="text-xs text-muted-foreground truncate max-w-[50%]">{s.order_description ?? ""}</span>
                  </button>
                ))}
              </div>
            )}
            {showSuggest && po.trim() && suggestions.length === 0 && (
              <div className="absolute z-20 top-full left-0 right-0 mt-1 rounded-xl border-2 border-red-500 bg-red-500/10 px-3 py-2 text-sm text-red-700 dark:text-red-300 font-semibold">
                Wrong PO — no match in active Trims or Fabric Plan
              </div>
            )}

          </div>
        </div>

        <button
          onClick={() => submit()}
          disabled={busy || !epf.trim() || !po.trim()}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 text-white font-bold text-lg hover:brightness-110 disabled:opacity-40 disabled:cursor-not-allowed inline-flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/40 active:scale-[0.98] transition-all"
        >
          {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <CheckCircle2 className="h-5 w-5" />}
          Submit Pick 🚀
        </button>

        {/* Custom on-screen NumPad — tablet-optimised, replaces native keyboard */}
        {activeField && (
          <NumPad
            fieldLabel={activeField === "epf" ? "EPF Number" : "PO Number"}
            value={activeField === "epf" ? epf : po}
            onKey={(k) => {
              const setV = activeField === "epf" ? setEpf : setPo;
              const cur = activeField === "epf" ? epf : po;
              if (k === "back") setV(cur.slice(0, -1));
              else if (k === "clear") setV("");
              else {
                setV(cur + k);
                if (activeField === "po") setShowSuggest(true);
              }
            }}
            onEnter={() => {
              if (activeField === "epf") {
                if (!epf.trim()) { toast.error("EPF number required"); return; }
                setActiveField("po");
                setShowSuggest(true);
              } else {
                submit();
              }
            }}
            onClose={() => setActiveField(null)}
          />
        )}
      </section>


      {/* Progress wheel for the entered EPF */}
      {currentTarget && (
        <section className="rounded-2xl border-2 border-emerald-400/30 bg-gradient-to-br from-emerald-500/15 via-teal-500/10 to-cyan-500/15 p-5 flex items-center gap-4 shadow-lg shadow-emerald-500/10">
          <ProgressWheel pct={currentPct} />
          <div className="min-w-0">
            <div className="text-xs font-bold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">Today's GIN progress 🌟</div>
            <div className="text-xl font-black truncate bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">{currentTarget.name}</div>
            <div className="text-sm mt-0.5">
              <span className="font-black text-2xl text-emerald-600 dark:text-emerald-400 tabular-nums">{currentAchieved}</span>
              <span className="text-muted-foreground"> / {currentTarget.gin_target_per_day} target</span>
            </div>
          </div>
        </section>
      )}

    </div>
  );
}


function ProgressWheel({ pct }: { pct: number }) {
  const r = 32;
  const c = 2 * Math.PI * r;
  const offset = c - (pct / 100) * c;
  const color = pct >= 100 ? "text-emerald-500" : pct >= 50 ? "text-blue-500" : "text-amber-500";
  return (
    <div className="relative h-20 w-20 shrink-0">
      <svg className="h-full w-full -rotate-90" viewBox="0 0 80 80">
        <circle cx="40" cy="40" r={r} strokeWidth="7" className="stroke-muted fill-none" />
        <circle
          cx="40" cy="40" r={r} strokeWidth="7"
          className={`fill-none ${color} transition-all duration-700`}
          stroke="currentColor" strokeDasharray={c} strokeDashoffset={offset} strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-sm font-bold tabular-nums">{pct}%</div>
    </div>
  );
}

type NumKey = "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "back" | "clear";

function NumPad({ fieldLabel, value, onKey, onEnter, onClose }: {
  fieldLabel: string;
  value: string;
  onKey: (k: NumKey) => void;
  onEnter: () => void;
  onClose: () => void;
}) {
  const digits: NumKey[] = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
  const btn = "h-16 md:h-20 rounded-xl text-3xl font-bold tabular-nums select-none active:scale-95 transition-all shadow-md border";
  return (
    <div className="mt-2 rounded-2xl border-2 border-primary/40 bg-gradient-to-b from-slate-900 to-slate-800 dark:from-slate-950 dark:to-slate-900 p-4 shadow-2xl animate-fade-in">
      <div className="flex items-center justify-between mb-3">
        <div className="text-xs uppercase tracking-wider text-slate-300 font-semibold">
          Entering: <span className="text-white">{fieldLabel}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="px-3 py-1 rounded-md bg-slate-950 text-emerald-400 font-mono text-lg min-w-[6rem] text-right tabular-nums">
            {value || "—"}
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-xs px-2 py-1 rounded-md bg-slate-700 text-slate-100 hover:bg-slate-600"
          >
            Close
          </button>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-2">
        {digits.map((d) => (
          <button key={d} type="button" onClick={() => onKey(d)}
            className={`${btn} bg-slate-100 hover:bg-white text-slate-900 border-slate-300`}>
            {d}
          </button>
        ))}
        <button type="button" onClick={() => onKey("clear")}
          className={`${btn} bg-amber-500 hover:bg-amber-400 text-white border-amber-600`}>
          CLR
        </button>
        <button type="button" onClick={() => onKey("0")}
          className={`${btn} bg-slate-100 hover:bg-white text-slate-900 border-slate-300`}>
          0
        </button>
        <button type="button" onClick={() => onKey("back")}
          className={`${btn} bg-slate-600 hover:bg-slate-500 text-white border-slate-700 inline-flex items-center justify-center gap-2`}>
          <Delete className="h-6 w-6" />
        </button>
      </div>
      <button
        type="button"
        onClick={onEnter}
        className="mt-2 w-full h-16 md:h-20 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-2xl font-bold shadow-lg active:scale-[0.98] transition-all inline-flex items-center justify-center gap-3 border border-emerald-700"
      >
        <CornerDownLeft className="h-7 w-7" /> ENTER
      </button>
    </div>
  );
}
