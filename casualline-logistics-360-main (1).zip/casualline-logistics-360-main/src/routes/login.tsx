import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { useApp, ROLE_HOMES } from "@/lib/store";
import { Truck } from "lucide-react";



export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in — Casualline Logistics 360" }, { name: "description", content: "Sign in to the Casualline Logistics 360 team workspace." },
      { property: "og:title", content: "Sign in — Casualline Logistics 360" },
      { property: "og:description", content: "Sign in to the Casualline Logistics 360 team workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: Login,
});

function Login() {
  const { user, login } = useApp();
  const navigate = useNavigate();
  const [username, setU] = useState("");
  const [password, setP] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => {
    if (user) navigate({ to: ROLE_HOMES[user.role], replace: true });
  }, [user, navigate]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    const r = login(username, password);
    if (!r.ok) setErr(r.error || "Login failed");
  };


  return (
    <div className="min-h-screen grid md:grid-cols-2 bg-background">
      <div className="hidden md:flex flex-col justify-between p-12 bg-primary text-primary-foreground">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 rounded-xl bg-primary-foreground/10 grid place-items-center">
            <Truck className="h-6 w-6" />
          </div>
          <div>
            <div className="font-bold text-lg">MAS Casualline</div>
            <div className="text-sm opacity-80">Logistics 360</div>
          </div>
        </div>
        <div>
          <h1 className="text-4xl font-bold leading-tight">MAS Casualline Logistics 360</h1>
          <p className="mt-4 text-sm font-light tracking-wide opacity-70 max-w-md">
            Real-time FIFO queue tracking, automated schedule compliance, green board management, and 24-hour hold-up
            detection across every gate, dock, and material line.
          </p>

          <div className="mt-6 pt-5 border-t border-primary-foreground/15 max-w-md space-y-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="opacity-70">&copy; 2026 <span className="font-semibold">MAS Casualline</span>. All Rights Reserved.</span>
              <span className="uppercase tracking-wider text-[10px] font-semibold text-[#ff9aa8] bg-[#f64e60]/20 px-2 py-0.5 rounded">
                MAS Internal Use Only
              </span>
            </div>

            <div className="flex items-center gap-3 flex-wrap">
              <span className="uppercase text-[10px] opacity-60">Built with:</span>
              <i className="fab fa-react text-base transition-transform hover:scale-125" style={{ color: "#61DAFB" }} title="React" />
              <i className="fab fa-python text-base transition-transform hover:scale-125" style={{ color: "#3776AB" }} title="Python" />
              <i className="fas fa-database text-base transition-transform hover:scale-125" style={{ color: "#00758F" }} title="MySQL" />
              <i className="fas fa-bolt text-base transition-transform hover:scale-125" style={{ color: "#3ECF8E" }} title="Supabase" />
              <i className="fab fa-github text-base transition-transform hover:scale-125" style={{ color: "#ffffff" }} title="GitHub" />
              <a href="https://lovable.dev" target="_blank" rel="noopener noreferrer" title="Lovable" className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-white/10 border border-white/15 hover:bg-white/20 transition">
                <span style={{ color: "#ff4d8f" }}>❤</span>
                <span className="text-[10px] font-semibold">Lovable</span>
              </a>
              <i className="fas fa-comment-dots text-base transition-transform hover:scale-125" style={{ color: "#10a37f" }} title="ChatGPT" />
              <i className="fas fa-gem text-base transition-transform hover:scale-125" style={{ color: "#4285F4" }} title="Gemini" />
            </div>

            <div className="opacity-70">
              Developed by:{" "}
              <a href="mailto:vimukthisen@masholdings.com" className="font-medium underline underline-offset-2 hover:opacity-100">
                Vimukthi Lakshan
              </a>{" "}
              <span className="opacity-60">· vimukthisen@masholdings.com</span>
            </div>
          </div>
        </div>
        <div className="text-xs opacity-70">© 2026 MAS Casualline Logistics 360</div>

      </div>
      <div className="flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <h2 className="text-2xl font-semibold">Sign in</h2>
          <p className="text-sm text-muted-foreground mt-1">Access your role-based workflow</p>
          <form onSubmit={submit} className="mt-6 space-y-4">
            <div>
              <label className="text-sm font-medium">Username</label>
              <input
                className="mt-1 w-full h-10 px-3 rounded-md border bg-background"
                value={username}
                onChange={(e) => setU(e.target.value)}
                autoComplete="username"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Password</label>
              <input
                type="password"
                className="mt-1 w-full h-10 px-3 rounded-md border bg-background"
                value={password}
                onChange={(e) => setP(e.target.value)}
                autoComplete="current-password"
              />
            </div>
            {err && <div className="text-sm text-destructive">{err}</div>}
            <button className="w-full h-10 rounded-md bg-primary text-primary-foreground font-medium">
              Sign in
            </button>
          </form>
          <p className="mt-6 text-xs text-muted-foreground text-center">
            Authorised personnel only. Contact your administrator for access.
          </p>

        </div>
      </div>
    </div>
  );
}
