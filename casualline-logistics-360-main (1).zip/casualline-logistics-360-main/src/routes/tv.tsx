import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { BAYS, type BayId, type VehicleLog } from "@/lib/types";
import { useEffect, useRef, useState } from "react";
import { Package, Boxes, AlertTriangle, PauseCircle, Activity, CheckCircle2, Play, Moon } from "lucide-react";
import { APP_TIMEZONE, operatingDate, operatingDayStart, timelineCards } from "@/lib/bay-timeline";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { VehicleArrivalToast } from "@/components/VehicleArrivalToast";
import { VehicleUpdateCard } from "@/components/VehicleUpdateCard";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";


export const Route = createFileRoute("/tv")({
  head: () => ({ meta: [
    { title: "TV Display — Bay Timeline · Casualline Logistics 360" },
    { name: "description", content: "Live saved unloading reservations across Casualline warehouse bays." },
    { property: "og:title", content: "Bay Timeline — Casualline Logistics 360" },
    { property: "og:description", content: "Live bay reservations, unloading progress and completion times." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }),
  component: () => (
    <RequireAccess path="/tv">
      <TVDisplay />
    </RequireAccess>
  ),
});

const PAUSE_MARKER = "SHIFT_PAUSE:";
const SHIFT_START_H = 6;
const SHIFT_END_H = 22;

function parseHM(s: string): number {
  const [h, m] = s.split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}
function toMinutes(d: Date): number { return d.getHours() * 60 + d.getMinutes(); }
function isSunday(d = new Date()): boolean { return d.getDay() === 0; }
function readPauseElapsedMs(hold_notes?: string): number {
  if (!hold_notes) return 0;
  const line = hold_notes.split("\n").find((l) => l.startsWith(PAUSE_MARKER));
  if (!line) return 0;
  return Number(line.slice(PAUSE_MARKER.length)) || 0;
}
// Elapsed ms counting ONLY working minutes (Mon–Sat, 06:00–22:00).
function workingElapsedMs(startMs: number, endMs: number, shiftStartMinutes = SHIFT_START_H * 60, shiftEndMinutes = SHIFT_END_H * 60): number {
  if (endMs <= startMs) return 0;
  let total = 0;
  let cursor = new Date(new Date(startMs).toLocaleString("en-US", { timeZone: APP_TIMEZONE }));
  const end = new Date(new Date(endMs).toLocaleString("en-US", { timeZone: APP_TIMEZONE }));
  // Safety cap: at most 60 day-iterations
  for (let i = 0; i < 60 && cursor < end; i++) {
    const dayEnd = new Date(cursor); dayEnd.setHours(24, 0, 0, 0);
    const chunkEnd = dayEnd < end ? dayEnd : end;
    if (cursor.getDay() !== 0) {
      const shiftStart = new Date(cursor); shiftStart.setHours(Math.floor(shiftStartMinutes / 60), shiftStartMinutes % 60, 0, 0);
      const shiftEnd = new Date(cursor); shiftEnd.setHours(Math.floor(shiftEndMinutes / 60), shiftEndMinutes % 60, 0, 0);
      const a = cursor > shiftStart ? cursor : shiftStart;
      const b = chunkEnd < shiftEnd ? chunkEnd : shiftEnd;
      if (b > a) total += b.getTime() - a.getTime();
    }
    cursor = dayEnd;
  }
  return total;
}
// Most recent working-shift start (06:00) at or before `d`. Skips Sundays.
function currentShiftStartMs(d = new Date()): number {
  const probe = new Date(d);
  probe.setSeconds(0, 0);
  // If we're before today's 06:00, step back a day
  if (probe.getHours() < SHIFT_START_H) probe.setDate(probe.getDate() - 1);
  probe.setHours(SHIFT_START_H, 0, 0, 0);
  // Skip Sundays
  for (let i = 0; i < 8 && probe.getDay() === 0; i++) probe.setDate(probe.getDate() - 1);
  return probe.getTime();
}
function effectiveElapsedMs(v: VehicleLog, now: number, shiftStart?: number, shiftEnd?: number): number {
  const paused = readPauseElapsedMs(v.hold_notes);
  if (v.current_status === "Completed" && v.unload_start_time && v.unload_end_time) {
    return paused + workingElapsedMs(new Date(v.unload_start_time).getTime(), new Date(v.unload_end_time).getTime(), shiftStart, shiftEnd);
  }
  if (v.current_status === "Hold" || v.current_status === "Assigned" || !v.unload_start_time) return paused;
  const start = new Date(v.unload_start_time).getTime();
  return paused + workingElapsedMs(start, now, shiftStart, shiftEnd);
}
function targetMinutesFor(v: VehicleLog, unitsPerHour: number): number {
  const totalUnits = (v.roll_qty || 0) + (v.box_qty || 0);
  if (totalUnits <= 0) return 30;
  return Math.max(15, Math.round((totalUnits / Math.max(1, unitsPerHour)) * 60));
}
function fmtMS(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}h ${m}m` : `${m}:${String(sec).padStart(2, "0")}`;
}

const ACK_STORAGE_KEY = "tv_shift_ack_v1";
function loadAckMap(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(ACK_STORAGE_KEY) || "{}"); } catch { return {}; }
}
function saveAckMap(m: Record<string, number>) {
  try { localStorage.setItem(ACK_STORAGE_KEY, JSON.stringify(m)); } catch { /* noop */ }
}

function TVDisplay() {
  const { state } = useApp();
  const [selectedToken, setSelectedToken] = useState<string | null>(null);
  const [showOtherReservations, setShowOtherReservations] = useState(false);
  const selectedVehicle = state.vehicles.find((v) => v.token_no === selectedToken);
  const [nowTick, setNowTick] = useState<number>(Date.now());
  const [ackMap, setAckMap] = useState<Record<string, number>>(() =>
    typeof window === "undefined" ? {} : loadAckMap()
  );

  // --- Animated arrival notifications (guard check-in) ---------------------
  const shownRef = useRef<Set<string>>(new Set());
  const bootRef = useRef<number>(Date.now());
  const [arrivals, setArrivals] = useState<VehicleLog[]>([]);

  const announce = useRef((list: VehicleLog[]) => {
    const fresh = list.filter((v) => {
      if (!v?.token_no || shownRef.current.has(v.token_no)) return false;
      const t = new Date(v.in_time).getTime();
      if (!Number.isFinite(t)) return false;
      // Show check-ins from the last 5 minutes, or anything that arrived after
      // this screen was opened.
      return Date.now() - t < 5 * 60 * 1000 || t >= bootRef.current;
    });
    if (!fresh.length) return;
    fresh.forEach((v) => shownRef.current.add(v.token_no));
    setArrivals((prev) => [...prev, ...fresh].slice(-3));
    fresh.forEach((v) => {
      setTimeout(() => {
        setArrivals((prev) => prev.filter((a) => a.token_no !== v.token_no));
      }, 8000);
    });
  }).current;

  // React to store updates (realtime channel)
  useEffect(() => {
    announce(state.vehicles);
  }, [state.vehicles, announce]);

  // Polling fallback — keeps notifications alive if the realtime channel drops
  useEffect(() => {
    let stop = false;
    const poll = async () => {
      try {
        const { supabase } = await import("@/integrations/supabase/client");
        const since = new Date(Date.now() - 5 * 60 * 1000).toISOString();
        const { data } = await supabase
          .from("vehicle_logs")
          .select("*")
          .gte("in_time", since)
          .order("in_time", { ascending: true });
        if (!stop && data) announce(data as unknown as VehicleLog[]);
      } catch {
        /* ignore transient network errors */
      }
    };
    void poll();
    const id = setInterval(poll, 10000);
    return () => { stop = true; clearInterval(id); };
  }, [announce]);



  useEffect(() => {
    const t = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);


  const settings = state.settings;
  const [selectedDate, setSelectedDate] = useState("");
  const displayDate = selectedDate || operatingDate(nowTick);
  const todayStart = operatingDayStart(displayDate);
  const dayEnd = todayStart + 24 * 60 * 60_000;
  const trackStart = todayStart + parseHM(settings.shift_start) * 60_000;
  const trackEnd = todayStart + parseHM(settings.shift_end) * 60_000;
  const timelineLength = (trackEnd - trackStart) / 60_000;
  const markers = Array.from({ length: Math.ceil(timelineLength / 120) + 1 }, (_, i) => Math.min(parseHM(settings.shift_start) + i * 120, parseHM(settings.shift_end)));
  const nowDate = new Date(new Date(nowTick).toLocaleString("en-US", { timeZone: APP_TIMEZONE }));
  const inShift = !isSunday(nowDate) && toMinutes(nowDate) >= parseHM(settings.shift_start) && toMinutes(nowDate) < parseHM(settings.shift_end);
  const sunday = isSunday(nowDate);
  const shiftStartMs = currentShiftStartMs(nowDate);

  const ackStart = (token: string) => {
    setAckMap((prev) => {
      const next = { ...prev, [token]: shiftStartMs };
      saveAckMap(next);
      return next;
    });
  };

  // Live time cursor position on the fixed 06:00–22:00 track (percent)
  const cursorPct = Math.max(0, Math.min(100, ((nowTick - trackStart) / (trackEnd - trackStart)) * 100));

  const shiftLen = Math.max(1, parseHM(settings.shift_end) - parseHM(settings.shift_start));
  const unitsPerHour = Math.max(
    1,
    (settings.daily_roll_target + settings.daily_box_target) / (shiftLen / 60)
  );

  const bayView = (bay: BayId) => {
    const list = state.vehicles
      .filter((v) => {
        if (v.bay_id !== bay) return false;
        const start = Date.parse(v.scheduled_start_time || v.unload_start_time || "");
        const end = Date.parse(v.scheduled_end_time || v.unload_end_time || "");
        return Number.isFinite(start) && Number.isFinite(end) && start < dayEnd && end > todayStart;
      });
    const active = list.find((v) => v.current_status === "Unloading");
    const completedToday = list.filter((v) => (v.current_status === "Completed" || v.current_status === "Departed") && Date.parse(v.unload_end_time || "") >= todayStart && Date.parse(v.unload_end_time || "") < dayEnd);
    const rolls = completedToday.reduce((s, v) => s + (v.roll_qty || 0), 0);
    const boxes = completedToday.reduce((s, v) => s + (v.box_qty || 0), 0);
    return { list, active, rolls, boxes };
  };

  const bayData = BAYS.map((b) => ({ bay: b, ...bayView(b.id) }));
  const otherReservations = state.vehicles.filter(v => v.bay_id && !["Completed", "Departed"].includes(v.current_status) && !timelineCards([v], trackStart, trackEnd).length);
  const totalRolls = bayData.reduce((s, b) => s + b.rolls, 0);
  const totalBoxes = bayData.reduce((s, b) => s + b.boxes, 0);
  const activeCount = bayData.filter((b) => b.active).length;
  const frozen = !inShift || displayDate !== operatingDate(nowTick);

  return (
    <div
      style={{ width: "100vw", height: "100vh", overflow: "hidden" }}
      className="fixed inset-0 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-slate-100 flex flex-col p-[1vh] gap-[1vh]"
    >
      {/* Animated arrival notifications — lorry drives into the yard */}
      {arrivals.length > 0 && (
        <div className="pointer-events-none absolute bottom-[2vh] left-[1.5vw] z-50 flex flex-col-reverse gap-[0.8vh]">
          {arrivals.map((v) => (
            <VehicleArrivalToast key={v.token_no} v={v} />

          ))}
        </div>
      )}

      {/* Header */}

      <header className="flex flex-wrap items-center justify-between shrink-0 px-[1vw] gap-2 py-2">
        <div className="flex items-center gap-3 min-w-0">
          <div className="h-[7vh] w-[7vh] rounded-2xl bg-gradient-to-br from-sky-500 to-cyan-500 grid place-items-center shadow-lg shadow-sky-500/30 shrink-0">
            <Activity style={{ height: "4vh", width: "4vh" }} className="text-white" />
          </div>
          <div className="min-w-0">
            <h1 className="font-black tracking-tight leading-none truncate" style={{ fontSize: "clamp(18px, 2.6vw, 44px)" }}>
              BAY TIMELINE · LIVE
            </h1>
            <p className="text-slate-400 mt-1 font-mono truncate" style={{ fontSize: "clamp(10px, 1vw, 15px)" }}>
              Timeline {settings.shift_start}–{settings.shift_end}{" · "}
              {frozen ? (
                <span className="text-yellow-400 font-bold">{sunday ? "SUNDAY OFF" : "OUTSIDE SHIFT — PAUSED"}</span>
              ) : (
                <span className="text-emerald-400 font-bold">LIVE {cursorPct.toFixed(0)}%</span>
              )}
            </p>
          </div>
        </div>

        <div className="shrink-0 rounded-2xl bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-sky-500/40 px-[1.2vw] py-[0.6vh] shadow-xl shadow-sky-500/20 text-center">
          <div className="font-black tabular-nums leading-none text-white tracking-tight"
               style={{ fontSize: "clamp(28px, 4.2vw, 72px)", fontVariantNumeric: "tabular-nums" }}>
            {nowDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false })}
          </div>
          <div className="uppercase tracking-widest text-sky-300 font-bold mt-[0.3vh]"
               style={{ fontSize: "clamp(9px, 0.85vw, 13px)" }}>
            {nowDate.toLocaleDateString([], { weekday: "long", day: "2-digit", month: "short", year: "numeric" })}
          </div>
        </div>

        <Input aria-label="Operating date" type="date" value={displayDate} onChange={e => setSelectedDate(e.target.value)} className="w-36 shrink-0" />
        {otherReservations.length > 0 && <Button variant="secondary" onClick={() => setShowOtherReservations(true)}>Other reservations ({otherReservations.length})</Button>}
        <div className="flex gap-[0.6vw] shrink-0">
          <BigMetric label="ACTIVE" value={activeCount} accent="from-indigo-500 to-purple-500" icon={Activity} />
          <BigMetric label="ROLLS" value={totalRolls} accent="from-sky-500 to-cyan-500" icon={Package} />
          <BigMetric label="BOXES" value={totalBoxes} accent="from-emerald-500 to-teal-500" icon={Boxes} />
        </div>
      </header>

      {/* 3 bays stacked vertically */}
      <div className="flex-1 min-h-0 grid grid-rows-3 gap-[1vh]">
        {bayData.map(({ bay, list, active, rolls, boxes }) => (
          <BayTrack
            key={bay.id}
            bayId={bay.id}
            label={bay.label}
            list={list}
            active={active}
            rolls={rolls}
            boxes={boxes}
            unitsPerHour={unitsPerHour}
            nowMs={nowTick}
            cursorPct={cursorPct}
            frozen={frozen}
            sunday={sunday}
            todayStart={todayStart}
            trackStart={trackStart}
            trackEnd={trackEnd}
            markers={markers}
            shiftStartMs={shiftStartMs}
            ackMap={ackMap}
            onAckStart={ackStart}
            onVehicleSelect={setSelectedToken}
          />
        ))}
      </div>
      <Dialog open={Boolean(selectedVehicle)} onOpenChange={(open) => { if (!open) setSelectedToken(null); }}>
        <DialogContent className="max-h-[90dvh] w-[calc(100%-2rem)] max-w-5xl overflow-y-auto rounded-lg">
          <DialogHeader><DialogTitle className="pr-6 break-words">Vehicle details · {selectedVehicle?.vehicle_number || selectedVehicle?.token_no}</DialogTitle><DialogDescription>Complete vehicle record · Colombo time</DialogDescription></DialogHeader>
          {selectedVehicle && <>{selectedVehicle.current_status === "Hold" && <p className="flex items-start gap-2 rounded-md border border-chart-5/40 bg-chart-5/10 p-3 text-sm font-semibold"><PauseCircle className="mt-0.5 h-4 w-4 shrink-0" />On hold — {selectedVehicle.hold_reason || "Reason not entered"}</p>}<VehicleUpdateCard vehicle={selectedVehicle} now={nowTick} /></>}
        </DialogContent>
      </Dialog>
      <Dialog open={showOtherReservations} onOpenChange={setShowOtherReservations}>
        <DialogContent className="max-h-[85dvh] overflow-y-auto">
          <DialogHeader><DialogTitle>Other bay reservations</DialogTitle><DialogDescription>Outside the selected operating date or shift</DialogDescription></DialogHeader>
          <div className="divide-y divide-border">{otherReservations.map(v => <div key={v.token_no} className="py-3 space-y-2">
            <p className="font-semibold break-words">{v.vehicle_number} · {v.bay_id}</p>
            <p className="text-sm text-muted-foreground">{v.current_status}{v.current_status === "Hold" ? ` — ${v.hold_reason || "Reason not entered"}` : ""}</p>
            <p className="text-sm">{v.scheduled_start_time ? new Date(v.scheduled_start_time).toLocaleString("en-GB", { timeZone: APP_TIMEZONE }) : "Reservation not saved"}</p>
            <div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => { setShowOtherReservations(false); setSelectedToken(v.token_no); }}>Vehicle details</Button>{v.scheduled_start_time && <Button onClick={() => { setSelectedDate(operatingDate(Date.parse(v.scheduled_start_time || ""))); setShowOtherReservations(false); }}>View scheduled date</Button>}</div>
          </div>)}</div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function BigMetric({
  label, value, icon: Icon, accent,
}: { label: string; value: number; icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>; accent: string }) {
  return (
    <div className={`rounded-2xl bg-gradient-to-br ${accent} px-[1vw] py-[0.6vh] shadow-xl flex flex-col justify-center`}>
      <div className="flex items-center gap-1 text-white/90 uppercase font-bold tracking-widest" style={{ fontSize: "clamp(8px, 0.75vw, 12px)" }}>
        <Icon style={{ height: "1.5vh", width: "1.5vh" }} /> {label}
      </div>
      <div className="font-black text-white leading-none mt-0.5 tabular-nums" style={{ fontSize: "clamp(18px, 2.6vw, 44px)" }}>{value}</div>
    </div>
  );
}

const BAY_THEMES: Record<BayId, {
  border: string; ring: string; accentText: string; accentDot: string; readyPill: string; idleBorder: string;
}> = {
  "BAY-01": {
    border: "border-cyan-400/70",
    ring: "shadow-[0_0_40px_-6px_rgba(6,182,212,0.55)]",
    accentText: "text-cyan-200",
    accentDot: "bg-cyan-400",
    readyPill: "bg-cyan-500/25 text-cyan-100",
    idleBorder: "border-cyan-500/30",
  },
  "BAY-02": {
    border: "border-emerald-400/70",
    ring: "shadow-[0_0_40px_-6px_rgba(52,211,153,0.55)]",
    accentText: "text-emerald-200",
    accentDot: "bg-emerald-400",
    readyPill: "bg-emerald-500/25 text-emerald-100",
    idleBorder: "border-emerald-500/30",
  },
  "BAY-03": {
    border: "border-violet-400/70",
    ring: "shadow-[0_0_40px_-6px_rgba(139,92,246,0.55)]",
    accentText: "text-violet-200",
    accentDot: "bg-violet-400",
    readyPill: "bg-violet-500/25 text-violet-100",
    idleBorder: "border-violet-500/30",
  },
};

function BayTrack({
  bayId, label, list, active, rolls, boxes, unitsPerHour, nowMs, cursorPct, frozen, sunday, todayStart,
  shiftStartMs, ackMap, onAckStart, trackStart, trackEnd, markers, onVehicleSelect,
}: {
  bayId: BayId;
  label: string;
  list: VehicleLog[];
  active: VehicleLog | undefined;
  rolls: number;
  boxes: number;
  unitsPerHour: number;
  nowMs: number;
  cursorPct: number;
  frozen: boolean;
  sunday: boolean;
  todayStart: number;
  trackStart: number;
  trackEnd: number;
  markers: number[];
  shiftStartMs: number;
  ackMap: Record<string, number>;
  onAckStart: (token: string) => void;
  onVehicleSelect: (token: string) => void;
}) {
  const theme = BAY_THEMES[bayId];
  const hasDelay = list.some((v) => {
    if (v.current_status !== "Unloading") return false;
    const target = targetMinutesFor(v, unitsPerHour) * 60_000;
    return effectiveElapsedMs(v, nowMs, (trackStart-todayStart)/60_000, (trackEnd-todayStart)/60_000) > target;
  });

  // Compute readable, time-relative cards and queue collisions horizontally.
  const positioned = timelineCards(list, trackStart, trackEnd);

  return (
    <section
      className={`relative rounded-2xl border-2 bg-slate-900/70 backdrop-blur px-[1vw] py-[0.8vh] flex flex-col min-h-0 overflow-hidden transition-colors ${
        hasDelay ? "border-red-500 shadow-[0_0_40px_-8px_rgba(239,68,68,0.7)] animate-pulse"
        : frozen ? "border-yellow-500/60"
        : active ? `${theme.border} ${theme.ring}`
        : theme.idleBorder
      }`}
    >
      {/* Bay header */}
      <div className="flex items-center justify-between mb-[0.6vh] shrink-0">
        <div className="flex items-center gap-[0.8vw] min-w-0">
          <div className={`h-[1.5vh] w-[1.5vh] rounded-full shrink-0 ${
            hasDelay ? "bg-red-500 animate-pulse" :
            frozen ? "bg-yellow-400" :
            active ? `${theme.accentDot} animate-pulse` : theme.accentDot
          }`} />
          <h3 className={`font-black tracking-tight truncate ${theme.accentText}`} style={{ fontSize: "clamp(16px, 2vw, 32px)" }}>{label}</h3>
          <span className={`font-bold px-2 py-0.5 rounded uppercase tracking-widest shrink-0 ${
            hasDelay ? "bg-red-500/20 text-red-300" :
            frozen ? "bg-yellow-500/20 text-yellow-300" :
            active ? theme.readyPill : theme.readyPill
          }`} style={{ fontSize: "clamp(9px, 0.85vw, 13px)" }}>
            {hasDelay ? "⚠ DELAY" : frozen ? (sunday ? "SUNDAY OFF" : "SHIFT PAUSED") : active ? "UNLOADING" : list.length ? "READY" : "IDLE"}
          </span>
        </div>
        <div className="flex gap-[0.4vw] font-bold shrink-0" style={{ fontSize: "clamp(10px, 1vw, 15px)" }}>
          <span className="px-[0.7vw] py-[0.3vh] rounded-lg bg-sky-500/15 text-sky-200 border border-sky-500/30">
            R <span className="tabular-nums">{rolls}</span>
          </span>
          <span className="px-[0.7vw] py-[0.3vh] rounded-lg bg-emerald-500/15 text-emerald-200 border border-emerald-500/30">
            B <span className="tabular-nums">{boxes}</span>
          </span>
          <span className="px-[0.7vw] py-[0.3vh] rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
            Q <span className="tabular-nums">{list.length}</span>
          </span>
        </div>
      </div>

      {/* Timeline canvas: cards absolutely placed by time */}
      <div className="flex-1 min-h-0 relative rounded-xl border border-slate-800 bg-slate-950/40 overflow-hidden">
        {/* vertical hour grid lines */}
        {markers.map((h) => {
          const pct = ((h - (trackStart - todayStart) / 60_000) / ((trackEnd - trackStart) / 60_000)) * 100;
          return (
            <div
              key={h}
              className="absolute top-0 bottom-0 border-l border-slate-700/50"
              style={{ left: `${pct}%` }}
            />
          );
        })}

        {/* live NOW cursor */}
        {!frozen && (
          <div
            className="absolute top-0 bottom-0 w-[2px] bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.9)] z-20"
            style={{ left: `${cursorPct}%` }}
          />
        )}

        {positioned.length === 0 ? (
          <div className="absolute inset-0 grid place-items-center text-slate-500 font-bold"
               style={{ fontSize: "clamp(14px, 1.5vw, 22px)" }}>
            BAY EMPTY
          </div>
        ) : (
          positioned.map(({ v, targetMin, leftPct, widthPct, lane, laneCount }) => {
            const startedMs = v.unload_start_time ? new Date(v.unload_start_time).getTime() : 0;
            const needsManualStart =
              v.current_status === "Unloading" &&
              startedMs > 0 &&
              startedMs < shiftStartMs &&
              (ackMap[v.token_no] || 0) < shiftStartMs;
            return (
              <VehicleCard
                key={v.token_no}
                v={v}
                targetMin={targetMin}
                leftPct={leftPct}
                widthPct={widthPct}
                lane={lane}
                laneCount={laneCount}

                shiftStartMinutes={(trackStart-todayStart)/60_000}
                shiftEndMinutes={(trackEnd-todayStart)/60_000}
                nowMs={nowMs}
                frozen={frozen}
                needsManualStart={needsManualStart && !frozen}
                onStart={() => onAckStart(v.token_no)}
                onSelect={() => onVehicleSelect(v.token_no)}
              />
            );
          })
        )}
      </div>

      {/* 2-hour interval time axis */}
      <div className="mt-[0.6vh] shrink-0 relative h-[2.2vh]">
        <div className="absolute inset-x-0 top-1/2 h-[2px] bg-slate-700 -translate-y-1/2" />
        {markers.map((h) => {
          const pct = ((h - (trackStart - todayStart) / 60_000) / ((trackEnd - trackStart) / 60_000)) * 100;
          return (
            <div
              key={h}
              className="absolute top-0 bottom-0 flex flex-col items-center"
              style={{ left: `${pct}%`, transform: "translateX(-50%)" }}
            >
              <div className="w-[2px] h-[0.8vh] bg-slate-500" />
              <div className="font-mono font-bold text-slate-300 tabular-nums leading-none mt-[0.2vh]"
                   style={{ fontSize: "clamp(9px, 0.9vw, 14px)" }}>
                {String(Math.floor(h / 60)).padStart(2, "0")}:{String(h % 60).padStart(2, "0")}
              </div>
            </div>
          );
        })}
        {!frozen && (
          <div
            className="absolute top-0 bottom-0 w-[2px] bg-emerald-400"
            style={{ left: `${cursorPct}%` }}
          />
        )}
      </div>
    </section>
  );
}

function VehicleCard({
  v, targetMin, leftPct, widthPct, lane, laneCount, nowMs, frozen, needsManualStart, onStart, shiftStartMinutes, shiftEndMinutes, onSelect,
}: { shiftStartMinutes: number; shiftEndMinutes: number; v: VehicleLog; targetMin: number; leftPct: number; widthPct: number; lane: number; laneCount: number; nowMs: number; frozen: boolean; needsManualStart: boolean; onStart: () => void; onSelect: () => void }) {
  const targetMs = targetMin * 60_000;
  const elapsedMs = effectiveElapsedMs(v, nowMs, shiftStartMinutes, shiftEndMinutes);
  const remainMs = Math.max(0, targetMs - elapsedMs);
  const isCompleted = v.current_status === "Completed" || v.current_status === "Departed";
  const isUnloading = v.current_status === "Unloading" && !isCompleted;
  const isHold = v.current_status === "Hold";
  const isAssigned = v.current_status === "Assigned";
  const isDelayed = isUnloading && !frozen && elapsedMs > targetMs;

  const pct = isCompleted ? 100 : Math.min(100, (elapsedMs / Math.max(1, targetMs)) * 100);

  const bgClass =
    isCompleted ? "bg-timeline-completed border-timeline-completed-border" :
    isDelayed ? "bg-red-600 border-red-300" :
    isHold ? "bg-orange-500 border-orange-200" :
    isUnloading ? "bg-yellow-400 border-yellow-200" :
    "bg-blue-600 border-blue-300";


  const textPrimary = isCompleted ? "text-timeline-completed-foreground" : isUnloading ? "text-slate-900" : "text-white";
  const textMuted = isCompleted ? "text-timeline-completed-foreground/80" : isUnloading ? "text-slate-700" : "text-white/75";

  const statusLabel =
    isCompleted ? "COMPLETED" :
    isHold ? `ON HOLD — ${v.hold_reason || "Reason not entered"}` :
    isDelayed ? "DELAYED" :
    isUnloading ? "UNLOADING" :
    isAssigned ? "IN BAY" :
    "QUEUED";

  const StatusIcon =
    isCompleted ? CheckCircle2 :
    isHold || isDelayed ? (isDelayed ? AlertTriangle : PauseCircle) :
    null;
  const compact = widthPct < 13 || laneCount > 2;
  const laneH = 100 / laneCount;

  return (
    <div
      data-vehicle-token={v.token_no}
      data-vehicle-status={v.current_status}
      title={`Gate in: ${new Date(v.in_time).toLocaleString("en-GB", { timeZone: APP_TIMEZONE })} · Assigned: ${v.bay_assigned_at ? new Date(v.bay_assigned_at).toLocaleString("en-GB", { timeZone: APP_TIMEZONE }) : "—"} · Scheduled: ${v.scheduled_start_time ? new Date(v.scheduled_start_time).toLocaleString("en-GB", { timeZone: APP_TIMEZONE }) : "—"} → ${v.scheduled_end_time ? new Date(v.scheduled_end_time).toLocaleString("en-GB", { timeZone: APP_TIMEZONE }) : "—"}`}
      style={{
        position: "absolute",
        left: `${leftPct}%`,
        width: `${widthPct}%`,
        minWidth: 0,
        maxWidth: "100%",
        boxSizing: "border-box",
        top: `calc(${lane * laneH}% + 4px)`,
        height: `calc(${laneH}% - 8px)`,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        alignItems: "stretch",
        padding: widthPct < 5 ? "0" : compact ? "6px" : "8px",
        writingMode: "horizontal-tb",
        textOrientation: "mixed",
      }}

      className={`relative rounded-lg border ${bgClass} overflow-hidden shadow-lg z-10 ${
        isDelayed ? "animate-pulse" : ""
      } ${v.is_held_up ? "ring-4 ring-red-300/70" : ""}`}
    >
      <Button type="button" variant="ghost" onClick={onSelect} aria-label={`View vehicle details for ${v.vehicle_number || v.token_no}`} className="absolute inset-0 z-30 h-full w-full cursor-pointer rounded-lg p-0 hover:bg-transparent focus-visible:ring-inset"><span className="sr-only">View vehicle details</span></Button>
      {/* Live progress overlay: fills across the full target-duration width based on elapsed time */}
      {!isCompleted && (isUnloading || isAssigned || isHold) && (
        <div
          aria-hidden
          className={`pointer-events-none absolute inset-y-0 left-0 transition-[width] duration-1000 ${
            isDelayed ? "bg-red-900/45" : isHold ? "bg-black/30" : isUnloading ? "bg-yellow-600/35" : "bg-white/20"
          }`}
          style={{ width: `${pct}%` }}
        />
      )}
      <div className={`relative font-black leading-none text-center ${textPrimary}`}
           style={{ fontSize: compact ? "clamp(14px, 2.3vh, 24px)" : "clamp(18px, 3.2vh, 38px)", letterSpacing: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", wordBreak: "keep-all", overflowWrap: "normal", writingMode: "horizontal-tb" }}>
        {v.vehicle_number || "—"}
      </div>

      <div className={`font-extrabold text-center ${textPrimary} mt-[0.3vh]`}
           style={{ fontSize: compact ? "clamp(10px, 1.7vh, 14px)" : "clamp(12px, 2vh, 17px)", lineHeight: 1.1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", wordBreak: "keep-all", overflowWrap: "normal", writingMode: "horizontal-tb" }}>
        {v.vendor_name}
      </div>

      <div className="flex items-center justify-center gap-1 min-w-0">
        {StatusIcon ? <StatusIcon style={{ height: compact ? "1.5vh" : "1.8vh", width: compact ? "1.5vh" : "1.8vh", flexShrink: 0 }} className={textPrimary} /> : null}
        <span title={statusLabel} className={`font-black uppercase ${textPrimary}`}
              style={{ fontSize: compact ? "clamp(8px, 1.3vh, 11px)" : "clamp(9px, 1.5vh, 13px)", letterSpacing: 0, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", wordBreak: "keep-all" }}>
          {statusLabel}
        </span>
      </div>

      {needsManualStart ? (
        <Button
          type="button"
          onClick={(e) => { e.stopPropagation(); onStart(); }}
          className="relative z-40 mt-1 flex items-center justify-center gap-1 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-white font-black uppercase tracking-wider shadow-lg ring-2 ring-emerald-300/70 animate-pulse py-1.5"
          style={{ fontSize: compact ? "clamp(9px, 1.4vh, 12px)" : "clamp(11px, 1.8vh, 15px)" }}
        >
          <Play style={{ height: compact ? "1.6vh" : "2vh", width: compact ? "1.6vh" : "2vh" }} />
          Start Shift
        </Button>
      ) : frozen && (isUnloading || isAssigned || isHold) ? (
        <div className="mt-1 flex items-center justify-center gap-1 rounded-lg bg-slate-900/70 border border-yellow-400/60 text-yellow-200 font-black uppercase tracking-wider py-1.5"
             style={{ fontSize: compact ? "clamp(9px, 1.4vh, 12px)" : "clamp(11px, 1.8vh, 15px)" }}>
          <Moon style={{ height: compact ? "1.6vh" : "2vh", width: compact ? "1.6vh" : "2vh" }} />
          Shift Paused
        </div>
      ) : (
        <div>
          <div className="flex items-baseline justify-between gap-2 min-w-0">
            <div className={`uppercase font-black shrink-0 ${textMuted}`}
                 style={{ fontSize: compact ? "clamp(8px, 1.25vh, 10px)" : "clamp(9px, 1.45vh, 12px)", letterSpacing: 0, whiteSpace: "nowrap" }}>
              {isCompleted ? "Total" : isUnloading ? "Left" : "Target"}
            </div>
            <div className={`font-black tabular-nums leading-none ${textPrimary}`}
                 style={{ fontSize: compact ? "clamp(10px, 1.7vh, 14px)" : "clamp(13px, 2.2vh, 24px)", whiteSpace: "nowrap" }}>
              {isCompleted ? fmtMS(elapsedMs) : isUnloading ? fmtMS(remainMs) : `${targetMin}m`}
            </div>
          </div>
          <div className="mt-[0.4vh] h-[0.8vh] rounded-full bg-black/30 overflow-hidden">
            <div
              className={`h-full transition-[width] duration-1000 ${
                isCompleted ? "bg-timeline-completed-foreground/80" :
                isDelayed || isHold ? "bg-white/85" :
                isUnloading ? "bg-slate-900" :
                "bg-white/85"
              }`}
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>
      )}
    </div>

  );
}
