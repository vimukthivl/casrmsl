import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { supabase } from "@/integrations/supabase/client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import * as XLSX from "xlsx";
import { ClipboardList, Upload, Trash2, Users, Target, Plus, RefreshCw, CheckCircle2, Gauge, Zap, Download, AlertTriangle, Clock } from "lucide-react";
import { AnimatedNumber } from "@/components/AnimatedNumber";

export const Route = createFileRoute("/fabric-plan")({
  head: () => ({
    meta: [
      { title: "Fabric Plan — MAS Casualline Logistics 360" },
      { name: "description", content: "Weekly Fabric roadmap upload and picker achievement tracking." },
      { property: "og:title", content: "Fabric Plan — MAS Casualline Logistics 360" },
      { property: "og:description", content: "Weekly Fabric roadmap upload and picker achievement tracking." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/fabric-plan">
      <FabricPlanPage />
    </RequireAccess>
  ),
});

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const sb = supabase as any;

interface FabricRow {
  id: string;
  work_center: string | null;
  production_order: string;
  order_description: string | null;
  order_qty: number | null;
  so_no: string | null;
  so_li: string | null;
  cut_date: string | null;
  start_date: string | null;
  picker_name: string | null;
  picker_epf: string | null;
  picker_date: string | null;
  uploaded_at: string;
}

interface PickerTarget {
  id: string;
  epf_number: string;
  name: string;
  gin_target_per_day: number;
  is_active: boolean;
}

const HEADER_MAP: Record<string, keyof Omit<FabricRow, "id" | "picker_name" | "picker_epf" | "picker_date" | "uploaded_at">> = {
  "work center": "work_center",
  "workcenter": "work_center",
  "production order": "production_order",
  "po": "production_order",
  "po number": "production_order",
  "order description": "order_description",
  "description": "order_description",
  "order qty": "order_qty",
  "qty": "order_qty",
  "so": "so_no",
  "so no": "so_no",
  "so li": "so_li",
  "so line": "so_li",
  "cut date": "cut_date",
  "start date": "start_date",
};

function normHeader(h: string) {
  return h.toLowerCase().trim().replace(/[_\-.]+/g, " ").replace(/\s+/g, " ");
}

function parseDate(v: unknown): string | null {
  if (v == null || v === "") return null;
  if (typeof v === "number") {
    // Excel serial date
    const d = XLSX.SSF.parse_date_code(v);
    if (d) return `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}`;
  }
  const d = new Date(String(v));
  if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  return null;
}

function FabricPlanPage() {
  const [rows, setRows] = useState<FabricRow[]>([]);
  const [targets, setTargets] = useState<PickerTarget[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [filter, setFilter] = useState("");
  const [tab, setTab] = useState<"plan" | "analytics" | "downtime">("plan");
  const fileRef = useRef<HTMLInputElement>(null);

  // picker target form
  const [tEpf, setTEpf] = useState("");
  const [tName, setTName] = useState("");
  const [tTarget, setTTarget] = useState(10);

  const load = useCallback(async () => {
    const [r, t] = await Promise.all([
      sb.from("fabric_plan").select("*").order("uploaded_at", { ascending: false }).order("production_order", { ascending: true }),
      sb.from("fabric_picker_targets").select("*").order("name", { ascending: true }),
    ]);
    setRows((r.data ?? []) as FabricRow[]);
    setTargets((t.data ?? []) as PickerTarget[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const ch = sb.channel("rt-fabric").on("postgres_changes", { event: "*", schema: "public", table: "fabric_plan" }, () => load()).subscribe();
    const ch2 = sb.channel("rt-fabric-picker-targets").on("postgres_changes", { event: "*", schema: "public", table: "fabric_picker_targets" }, () => load()).subscribe();
    return () => { sb.removeChannel(ch); sb.removeChannel(ch2); };
  }, [load]);

  const handleUpload = async (file: File) => {
    setBusy(true);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array", cellDates: false });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
      if (!raw.length) { toast.error("Empty sheet"); return; }

      const parsed = raw.map((r) => {
        const out: Record<string, unknown> = {};
        for (const [k, v] of Object.entries(r)) {
          const key = HEADER_MAP[normHeader(k)];
          if (!key) continue;
          if (key === "order_qty") out[key] = Number(v) || 0;
          else if (key === "cut_date" || key === "start_date") out[key] = parseDate(v);
          else out[key] = v === "" ? null : String(v).trim();
        }
        return out;
      }).filter((r) => r.production_order);

      if (!parsed.length) {
        toast.error("No valid rows found. Expected a 'Production Order' (PO) column.");
        return;
      }

      // Merge logic: fetch existing picker fields for these POs so re-upload preserves achievements.
      const pos = parsed.map((r) => r.production_order as string);
      const { data: existing } = await sb.from("fabric_plan").select("production_order,picker_name,picker_epf,picker_date").in("production_order", pos);
      const existingMap = new Map<string, { picker_name: string | null; picker_epf: string | null; picker_date: string | null }>();
      (existing ?? []).forEach((e: { production_order: string; picker_name: string | null; picker_epf: string | null; picker_date: string | null }) => {
        existingMap.set(e.production_order, { picker_name: e.picker_name, picker_epf: e.picker_epf, picker_date: e.picker_date });
      });

      const payload = parsed.map((r) => {
        const prev = existingMap.get(r.production_order as string);
        return {
          ...r,
          picker_name: prev?.picker_name ?? null,
          picker_epf: prev?.picker_epf ?? null,
          picker_date: prev?.picker_date ?? null,
          uploaded_at: new Date().toISOString(),
        };
      });

      // Upsert on production_order
      const { error } = await sb.from("fabric_plan").upsert(payload, { onConflict: "production_order" });
      if (error) throw error;
      toast.success(`Uploaded ${payload.length} PO rows (picker achievements preserved).`);
      await load();
    } catch (e) {
      console.error(e);
      toast.error("Upload failed: " + (e instanceof Error ? e.message : "unknown"));
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const clearAll = async () => {
    if (!confirm("Delete ALL fabric plan rows? Picker achievements will be lost.")) return;
    setBusy(true);
    const { error } = await sb.from("fabric_plan").delete().neq("id", "00000000-0000-0000-0000-000000000000");
    setBusy(false);
    if (error) toast.error(error.message); else { toast.success("Cleared"); await load(); }
  };

  const addTarget = async () => {
    if (!tEpf.trim() || !tName.trim()) { toast.error("EPF and Name required"); return; }
    const { error } = await sb.from("fabric_picker_targets").upsert(
      { epf_number: tEpf.trim(), name: tName.trim(), gin_target_per_day: tTarget, is_active: true },
      { onConflict: "epf_number" },
    );
    if (error) toast.error(error.message);
    else { toast.success("Picker saved"); setTEpf(""); setTName(""); setTTarget(10); }
  };

  const removeTarget = async (id: string) => {
    const { error } = await sb.from("fabric_picker_targets").delete().eq("id", id);
    if (error) toast.error(error.message);
  };

  const downloadTemplate = () => {
    const headers = [
      "Work Center", "Production Order", "Order Description", "Order Qty",
      "SO No", "SO Li", "Cut Date", "Start Date",
    ];
    const sample = [
      ["WC-01", "PO-100234", "Ladies Casual Tee - M", 1500, "SO-8891", "10", "2026-07-20", "2026-07-22"],
      ["WC-02", "PO-100235", "Mens Polo - L", 2200, "SO-8892", "20", "2026-07-21", "2026-07-23"],
    ];
    const ws = XLSX.utils.aoa_to_sheet([headers, ...sample]);
    ws["!cols"] = [{ wch: 12 }, { wch: 18 }, { wch: 28 }, { wch: 10 }, { wch: 12 }, { wch: 8 }, { wch: 12 }, { wch: 12 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Fabric Plan");
    XLSX.writeFile(wb, "fabric-plan-template.xlsx");
  };

  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter((r) =>
      r.production_order.toLowerCase().includes(q) ||
      (r.order_description ?? "").toLowerCase().includes(q) ||
      (r.work_center ?? "").toLowerCase().includes(q) ||
      (r.picker_name ?? "").toLowerCase().includes(q),
    );
  }, [rows, filter]);

  const stats = useMemo(() => {
    const total = rows.length;
    const picked = rows.filter((r) => r.picker_name).length;
    return { total, picked, pending: total - picked, pct: total ? Math.round((picked / total) * 100) : 0 };
  }, [rows]);

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-[1600px] mx-auto">
      <header className="relative overflow-hidden rounded-2xl border-2 border-teal-400/30 bg-gradient-to-br from-teal-500/15 via-emerald-500/10 to-lime-500/10 p-4 md:p-5 shadow-lg shadow-emerald-500/10">
        <div className="absolute -top-16 -right-16 h-48 w-48 rounded-full bg-teal-400/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-10 h-48 w-48 rounded-full bg-lime-400/20 blur-3xl pointer-events-none" />
        <div className="relative flex items-center gap-3 flex-wrap">
          <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-teal-500 to-emerald-600 text-white grid place-items-center shrink-0 shadow-md shadow-emerald-500/40">
            <ClipboardList className="h-6 w-6" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xl md:text-2xl font-extrabold truncate bg-gradient-to-r from-teal-600 via-emerald-600 to-lime-600 bg-clip-text text-transparent">
              Fabric Plan 🧵
            </h1>
            <p className="text-xs text-muted-foreground">Weekly Fabric roadmap · PO-keyed merge preserves picker achievements 🎯</p>
          </div>
          {tab === "plan" && (
            <div className="ml-auto flex items-center gap-2">
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
              />
              <button
                onClick={downloadTemplate}
                className="inline-flex items-center gap-2 px-3 py-2 text-sm font-semibold rounded-xl bg-gradient-to-r from-sky-500 to-indigo-500 text-white shadow-md shadow-sky-500/30 hover:shadow-lg hover:brightness-110 transition-all"
              >
                <Download className="h-4 w-4" /> Template
              </button>
              <button
                onClick={() => fileRef.current?.click()}
                disabled={busy}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 text-white shadow-md shadow-emerald-500/30 hover:shadow-lg hover:shadow-emerald-500/50 active:scale-[0.98] transition-all disabled:opacity-50"
              >
                {busy ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                Upload Excel
              </button>
              <button
                onClick={clearAll}
                disabled={busy || !rows.length}
                className="inline-flex items-center gap-2 px-3 py-2 text-sm rounded-xl border-2 border-rose-400/40 text-rose-600 dark:text-rose-300 hover:bg-rose-500/10 disabled:opacity-40 transition-colors"
              >
                <Trash2 className="h-4 w-4" /> Clear All
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Tab switcher */}
      <div className="flex items-center gap-1 p-1.5 rounded-2xl bg-gradient-to-r from-teal-500/10 via-emerald-500/10 to-lime-500/10 border border-emerald-400/20 w-fit shadow-sm">
        <button
          onClick={() => setTab("plan")}
          className={`px-4 py-2 text-sm rounded-xl transition-all ${tab === "plan" ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-md shadow-emerald-500/30 font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-background/60"}`}
        >
          <ClipboardList className="h-4 w-4 inline mr-1.5 -mt-0.5" />
          Trims Plan
        </button>
        <button
          onClick={() => setTab("analytics")}
          className={`px-4 py-2 text-sm rounded-xl transition-all ${tab === "analytics" ? "bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-md shadow-fuchsia-500/30 font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-background/60"}`}
        >
          <Gauge className="h-4 w-4 inline mr-1.5 -mt-0.5" />
          Picker Analytics
        </button>
        <button
          onClick={() => setTab("downtime")}
          className={`px-4 py-2 text-sm rounded-xl transition-all ${tab === "downtime" ? "bg-gradient-to-r from-rose-500 to-orange-500 text-white shadow-md shadow-rose-500/30 font-semibold" : "text-muted-foreground hover:text-foreground hover:bg-background/60"}`}
        >
          <AlertTriangle className="h-4 w-4 inline mr-1.5 -mt-0.5" />
          Fabric Downtime
        </button>
      </div>

      {tab === "plan" && (<>


      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Total POs" value={stats.total} tone="slate" />
        <StatCard label="Picked" value={stats.picked} tone="emerald" />
        <StatCard label="Pending" value={stats.pending} tone="amber" />
        <StatCard label="Completion" value={`${stats.pct}%`} tone="blue" />
      </div>

      {/* Picker targets */}
      <section className="rounded-2xl border-2 border-violet-400/30 bg-gradient-to-br from-violet-500/10 via-fuchsia-500/5 to-pink-500/10 p-4 space-y-3 shadow-sm shadow-violet-500/10">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-500 text-white grid place-items-center shadow-md shadow-violet-500/30">
            <Target className="h-4 w-4" />
          </div>
          <h2 className="font-bold bg-gradient-to-r from-violet-600 to-fuchsia-600 bg-clip-text text-transparent">Picker GIN Targets</h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-violet-500/15 text-violet-700 dark:text-violet-300 font-semibold">{targets.length}</span>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-muted-foreground font-medium">EPF Number</label>
            <input value={tEpf} onChange={(e) => setTEpf(e.target.value)} className="w-32 px-2.5 py-2 text-sm rounded-lg border-2 border-violet-300/40 bg-background focus:border-violet-500 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all" placeholder="EPF001" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-muted-foreground font-medium">Name</label>
            <input value={tName} onChange={(e) => setTName(e.target.value)} className="w-40 px-2.5 py-2 text-sm rounded-lg border-2 border-fuchsia-300/40 bg-background focus:border-fuchsia-500 focus:ring-2 focus:ring-fuchsia-500/20 outline-none transition-all" placeholder="Picker name" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-muted-foreground font-medium">Daily GIN target</label>
            <input type="number" min={1} value={tTarget} onChange={(e) => setTTarget(Number(e.target.value) || 1)} className="w-24 px-2.5 py-2 text-sm rounded-lg border-2 border-pink-300/40 bg-background focus:border-pink-500 focus:ring-2 focus:ring-pink-500/20 outline-none transition-all tabular-nums" />
          </div>
          <button onClick={addTarget} className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-lg bg-gradient-to-r from-violet-500 via-fuchsia-500 to-pink-500 text-white shadow-md shadow-fuchsia-500/30 hover:shadow-lg active:scale-[0.98] transition-all">
            <Plus className="h-4 w-4" /> Save
          </button>
        </div>
        {targets.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-1">
            {targets.map((t, i) => {
              const palette = [
                "from-sky-500/15 to-cyan-500/10 border-sky-400/40 text-sky-700 dark:text-sky-300",
                "from-violet-500/15 to-fuchsia-500/10 border-violet-400/40 text-violet-700 dark:text-violet-300",
                "from-rose-500/15 to-pink-500/10 border-rose-400/40 text-rose-700 dark:text-rose-300",
                "from-amber-500/15 to-orange-500/10 border-amber-400/40 text-amber-700 dark:text-amber-300",
                "from-emerald-500/15 to-teal-500/10 border-emerald-400/40 text-emerald-700 dark:text-emerald-300",
                "from-lime-500/15 to-green-500/10 border-lime-400/40 text-lime-700 dark:text-lime-300",
              ][i % 6];
              return (
                <div key={t.id} className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r ${palette} border-2 text-sm shadow-sm`}>
                  <Users className="h-3.5 w-3.5" />
                  <span className="font-semibold text-foreground">{t.name}</span>
                  <span className="text-xs opacity-80">{t.epf_number} · {t.gin_target_per_day}/day</span>
                  <button onClick={() => removeTarget(t.id)} className="text-rose-500/80 hover:text-rose-600 hover:scale-110 transition-transform">
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Plan table */}
      <section className="rounded-2xl border-2 border-sky-400/30 bg-gradient-to-br from-sky-500/5 via-cyan-500/5 to-blue-500/5 shadow-sm shadow-sky-500/10 overflow-hidden">
        <div className="p-3 flex items-center gap-2 border-b border-sky-400/20 bg-gradient-to-r from-sky-500/10 to-cyan-500/10">
          <input
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="flex-1 px-3 py-2 text-sm rounded-lg border-2 border-sky-300/40 bg-background focus:border-sky-500 focus:ring-2 focus:ring-sky-500/20 outline-none transition-all"
            placeholder="🔍 Search PO / description / work center / picker…"
          />
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-sky-500/15 text-sky-700 dark:text-sky-300 whitespace-nowrap">{filtered.length} rows</span>
        </div>
        <div className="overflow-auto max-h-[60vh]">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-gradient-to-r from-sky-500/20 via-cyan-500/20 to-blue-500/20 backdrop-blur z-10">
              <tr className="text-left">
                {["Work Center","PO","Description","Qty","SO","SO LI","Cut Date","Start Date","Picker","Picker Date"].map((h) => (
                  <th key={h} className="px-3 py-2.5 font-bold whitespace-nowrap text-sky-900 dark:text-sky-100">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan={10} className="p-6 text-center text-muted-foreground">Loading…</td></tr>}
              {!loading && filtered.length === 0 && (
                <tr><td colSpan={10} className="p-6 text-center text-muted-foreground">No rows. Upload an Excel plan to begin.</td></tr>
              )}
              {filtered.map((r) => {
                const picked = !!r.picker_name;
                return (
                  <tr key={r.id} className={`border-t transition-colors ${picked ? "bg-emerald-500/15 hover:bg-emerald-500/25" : "hover:bg-muted/40"}`}>
                    <td className="px-3 py-2 whitespace-nowrap">{r.work_center ?? "—"}</td>
                    <td className="px-3 py-2 font-mono font-semibold whitespace-nowrap">{r.production_order}</td>
                    <td className="px-3 py-2 max-w-[280px] truncate" title={r.order_description ?? ""}>{r.order_description ?? "—"}</td>
                    <td className="px-3 py-2 text-right tabular-nums">{r.order_qty ?? "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{r.so_no ?? "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{r.so_li ?? "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{r.cut_date ?? "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">{r.start_date ?? "—"}</td>
                    <td className="px-3 py-2 whitespace-nowrap">
                      {picked ? (
                        <span className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-300">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          {r.picker_name} <span className="text-muted-foreground">({r.picker_epf})</span>
                        </span>
                      ) : <span className="text-muted-foreground">—</span>}
                    </td>
                    <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">
                      {r.picker_date ? new Date(r.picker_date).toLocaleString() : "—"}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      </>)}

      {tab === "analytics" && <PickerPerformanceAnalytics targets={targets} />}
      {tab === "downtime" && <FabricDowntimePanel />}
    </div>
  );
}

type ViewType = "daily" | "weekly" | "monthly";

interface AchievementRow {
  id: string;
  epf_number: string;
  picker_name: string | null;
  picked_at: string;
}

function isoDate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

// Monday of the week containing d
function startOfWeekMon(d: Date) {
  const nd = new Date(d);
  const day = nd.getDay(); // 0=Sun..6=Sat
  const diff = (day + 6) % 7; // days since Monday
  nd.setDate(nd.getDate() - diff);
  nd.setHours(0, 0, 0, 0);
  return nd;
}

// Count Mon–Sat working days between two dates (inclusive)
function workingDaysBetween(start: Date, end: Date) {
  let n = 0;
  const cur = new Date(start);
  cur.setHours(0, 0, 0, 0);
  const stop = new Date(end);
  stop.setHours(0, 0, 0, 0);
  while (cur <= stop) {
    const dow = cur.getDay();
    if (dow !== 0) n++; // exclude Sundays
    cur.setDate(cur.getDate() + 1);
  }
  return n;
}

function PickerPerformanceAnalytics({ targets }: { targets: PickerTarget[] }) {
  const [viewType, setViewType] = useState<ViewType>("daily");
  const [selectedDate, setSelectedDate] = useState<string>(isoDate(new Date()));
  const [rows, setRows] = useState<AchievementRow[]>([]);
  const [loading, setLoading] = useState(false);

  const range = useMemo(() => {
    const d = new Date(selectedDate + "T00:00:00");
    let start: Date, end: Date, workingDays: number, label: string;
    if (viewType === "daily") {
      start = new Date(d); end = new Date(d);
      workingDays = d.getDay() === 0 ? 0 : 1;
      label = d.toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "short", day: "numeric" });
    } else if (viewType === "weekly") {
      start = startOfWeekMon(d);
      end = new Date(start); end.setDate(start.getDate() + 5); // Mon..Sat
      workingDays = 6;
      label = `Week of ${start.toLocaleDateString(undefined, { month: "short", day: "numeric" })} – ${end.toLocaleDateString(undefined, { month: "short", day: "numeric" })}`;
    } else {
      start = new Date(d.getFullYear(), d.getMonth(), 1);
      end = new Date(d.getFullYear(), d.getMonth() + 1, 0);
      workingDays = workingDaysBetween(start, end);
      label = d.toLocaleDateString(undefined, { month: "long", year: "numeric" });
    }
    start.setHours(0, 0, 0, 0);
    const endEx = new Date(end); endEx.setHours(23, 59, 59, 999);
    return { start, end: endEx, workingDays, label };
  }, [viewType, selectedDate]);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await sb
      .from("fabric_picker_achievements")
      .select("id,epf_number,picker_name,picked_at")
      .gte("picked_at", range.start.toISOString())
      .lte("picked_at", range.end.toISOString());
    if (error) toast.error(error.message);
    setRows((data ?? []) as AchievementRow[]);
    setLoading(false);
  }, [range]);

  useEffect(() => {
    load();
    const ch = sb
      .channel("rt-fabric-picker-achievements-analytics")
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_picker_achievements" }, () => load())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load]);

  const perPicker = useMemo(() => {
    const active = targets.filter((t) => t.is_active);
    const counts = new Map<string, number>();
    for (const r of rows) counts.set(r.epf_number, (counts.get(r.epf_number) ?? 0) + 1);
    // include any epf that has achievements but no target row
    const seen = new Set(active.map((t) => t.epf_number));
    const extras: PickerTarget[] = [];
    counts.forEach((_v, epf) => {
      if (!seen.has(epf)) {
        const nm = rows.find((r) => r.epf_number === epf)?.picker_name ?? "Unknown";
        extras.push({ id: `x-${epf}`, epf_number: epf, name: nm, gin_target_per_day: 0, is_active: true });
      }
    });
    return [...active, ...extras].map((t) => {
      const achieved = counts.get(t.epf_number) ?? 0;
      const target = (t.gin_target_per_day || 0) * range.workingDays;
      const efficiency = target > 0 ? Math.round((achieved / target) * 1000) / 10 : 0;
      const hours = 7.33 * range.workingDays;
      const ginPerHour = hours > 0 ? Math.round((achieved / hours) * 100) / 100 : 0;
      return { ...t, achieved, target, efficiency, ginPerHour, hours };
    }).sort((a, b) => b.efficiency - a.efficiency);
  }, [rows, targets, range.workingDays]);

  return (
    <section className="rounded-2xl border bg-gradient-to-br from-slate-900 via-slate-950 to-black text-white p-4 md:p-5 space-y-4 shadow-2xl">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="h-10 w-10 rounded-xl bg-fuchsia-500/20 text-fuchsia-300 grid place-items-center shrink-0 shadow-[0_0_20px_rgba(217,70,239,0.4)]">
          <Gauge className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <h2 className="text-lg md:text-xl font-bold tracking-tight">Picker Performance Analytics</h2>
          <p className="text-[11px] text-slate-400">Shift baseline · <span className="text-amber-300 font-semibold">7.33 hrs</span> · {range.label} · {range.workingDays} working day{range.workingDays === 1 ? "" : "s"}</p>
        </div>
        <div className="ml-auto flex items-center gap-2 flex-wrap">
          <div className="inline-flex rounded-lg overflow-hidden border border-white/15 bg-white/5">
            {(["daily", "weekly", "monthly"] as ViewType[]).map((v) => (
              <button
                key={v}
                onClick={() => setViewType(v)}
                className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-colors ${viewType === v ? "bg-fuchsia-500 text-white shadow-[0_0_16px_rgba(217,70,239,0.6)]" : "text-slate-300 hover:bg-white/10"}`}
              >
                {v}
              </button>
            ))}
          </div>
          <input
            type={viewType === "monthly" ? "month" : viewType === "weekly" ? "week" : "date"}
            value={
              viewType === "monthly"
                ? selectedDate.slice(0, 7)
                : viewType === "weekly"
                  ? (() => {
                      const d = new Date(selectedDate + "T00:00:00");
                      const mon = startOfWeekMon(d);
                      // ISO week
                      const target = new Date(mon);
                      target.setDate(target.getDate() + 3);
                      const firstThu = new Date(target.getFullYear(), 0, 4);
                      const week = 1 + Math.round(((target.getTime() - firstThu.getTime()) / 86400000 - 3 + ((firstThu.getDay() + 6) % 7)) / 7);
                      return `${target.getFullYear()}-W${String(week).padStart(2, "0")}`;
                    })()
                  : selectedDate
            }
            onChange={(e) => {
              const v = e.target.value;
              if (viewType === "monthly") setSelectedDate(v + "-01");
              else if (viewType === "weekly") {
                const [y, w] = v.split("-W").map(Number);
                const simple = new Date(y, 0, 1 + (w - 1) * 7);
                const dow = simple.getDay();
                const mon = new Date(simple);
                mon.setDate(simple.getDate() - ((dow + 6) % 7));
                setSelectedDate(isoDate(mon));
              } else setSelectedDate(v);
            }}
            className="px-3 py-1.5 text-xs rounded-lg bg-white/5 border border-white/15 text-white [color-scheme:dark]"
          />
        </div>
      </div>

      {loading && <div className="text-center text-slate-400 text-sm py-6">Loading…</div>}
      {!loading && perPicker.length === 0 && (
        <div className="text-center text-slate-400 text-sm py-6">No active pickers or achievements for this period.</div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
        {perPicker.map((p) => (
          <PickerEfficiencyCard key={p.id} p={p} />
        ))}
      </div>
    </section>
  );
}

function PickerEfficiencyCard({
  p,
}: {
  p: {
    id: string;
    epf_number: string;
    name: string;
    achieved: number;
    target: number;
    efficiency: number;
    ginPerHour: number;
    hours: number;
  };
}) {
  const eff = p.efficiency;
  let theme: { grad: string; ring: string; glow: string; text: string; pulse?: string };
  if (eff >= 85) {
    theme = {
      grad: "from-emerald-500/30 via-emerald-500/10 to-emerald-900/40",
      ring: "border-emerald-400/50",
      glow: "shadow-[0_0_30px_rgba(16,185,129,0.45)]",
      text: "text-emerald-300",
    };
  } else if (eff >= 50) {
    theme = {
      grad: "from-amber-500/30 via-amber-500/10 to-amber-900/40",
      ring: "border-amber-400/50",
      glow: "shadow-[0_0_30px_rgba(245,158,11,0.5)]",
      text: "text-amber-300",
    };
  } else {
    theme = {
      grad: "from-rose-600/40 via-rose-600/10 to-rose-900/40",
      ring: "border-rose-400/60",
      glow: "shadow-[0_0_30px_rgba(244,63,94,0.55)]",
      text: "text-rose-300",
      pulse: "animate-pulse",
    };
  }
  return (
    <div className={`relative rounded-2xl border ${theme.ring} bg-gradient-to-br ${theme.grad} ${theme.glow} ${theme.pulse ?? ""} p-4 backdrop-blur overflow-hidden`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="text-sm font-bold truncate">{p.name}</div>
          <div className="text-[10px] uppercase tracking-widest text-white/60">EPF {p.epf_number}</div>
        </div>
        <div className={`text-[10px] font-bold px-2 py-0.5 rounded-full bg-black/30 ${theme.text}`}>
          {eff >= 85 ? "HIGH" : eff >= 50 ? "MID" : "LOW"}
        </div>
      </div>
      <div className={`mt-2 font-black leading-none ${theme.text} drop-shadow-[0_0_12px_currentColor]`} style={{ fontSize: "3.25rem" }}>
        <AnimatedNumber value={eff} format={(n) => `${n.toFixed(1)}%`} />
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
        <div className="rounded-lg bg-black/25 px-2 py-1.5">
          <div className="text-[9px] uppercase tracking-wider text-white/60">Achieved</div>
          <div className="font-bold tabular-nums text-white text-base"><AnimatedNumber value={p.achieved} /></div>
        </div>
        <div className="rounded-lg bg-black/25 px-2 py-1.5">
          <div className="text-[9px] uppercase tracking-wider text-white/60">Target</div>
          <div className="font-bold tabular-nums text-white/90 text-base"><AnimatedNumber value={p.target} /></div>
        </div>
      </div>
      <div className="mt-2 flex items-center gap-1.5 text-[11px] text-white/80">
        <Zap className="h-3.5 w-3.5 text-yellow-300" />
        <span className="font-semibold tabular-nums">{p.ginPerHour}</span>
        <span className="text-white/60">GIN/hr · {p.hours.toFixed(2)}h shift base</span>
      </div>
    </div>
  );
}


function StatCard({ label, value, tone }: { label: string; value: number | string; tone: "slate" | "emerald" | "amber" | "blue" }) {
  const toneClass = {
    slate: "from-slate-500/20 via-slate-500/10 to-slate-500/5 border-slate-400/40 text-slate-700 dark:text-slate-200 shadow-slate-500/20",
    emerald: "from-emerald-500/25 via-emerald-500/15 to-teal-500/10 border-emerald-400/50 text-emerald-700 dark:text-emerald-200 shadow-emerald-500/25",
    amber: "from-amber-500/25 via-orange-500/15 to-yellow-500/10 border-amber-400/50 text-amber-700 dark:text-amber-200 shadow-amber-500/25",
    blue: "from-sky-500/25 via-blue-500/15 to-cyan-500/10 border-sky-400/50 text-sky-700 dark:text-sky-200 shadow-sky-500/25",
  }[tone];
  return (
    <div className={`relative overflow-hidden rounded-2xl border-2 p-3.5 bg-gradient-to-br ${toneClass} shadow-md hover:shadow-lg hover:scale-[1.02] transition-all`}>
      <div className="absolute -top-6 -right-6 h-20 w-20 rounded-full bg-current opacity-10 blur-2xl" />
      <div className="relative text-[11px] uppercase tracking-wider font-bold opacity-80">{label}</div>
      <div className="relative text-3xl font-extrabold tabular-nums mt-1">{value}</div>
    </div>
  );
}

interface FabricDowntimeRow {
  id: string;
  entry_date: string;
  concern: string;
  lost_hours: number;
  notes: string | null;
  created_at: string;
}

function FabricDowntimePanel() {
  const [rows, setRows] = useState<FabricDowntimeRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [newConcern, setNewConcern] = useState("");
  const [rangeEnd, setRangeEnd] = useState<string>(isoDate(new Date()));
  const [days, setDays] = useState<number>(7);

  const load = useCallback(async () => {
    const { data, error } = await sb
      .from("fabric_downtime")
      .select("*")
      .order("created_at", { ascending: true });
    if (error) toast.error(error.message);
    setRows((data ?? []) as FabricDowntimeRow[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
    const ch = sb
      .channel("rt-fabric-downtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "fabric_downtime" }, () => load())
      .subscribe();
    return () => { sb.removeChannel(ch); };
  }, [load]);

  const concerns = useMemo(() => {
    const seen = new Map<string, string>();
    for (const r of rows) {
      const key = r.concern.trim();
      if (!key) continue;
      if (!seen.has(key.toLowerCase())) seen.set(key.toLowerCase(), key);
    }
    return Array.from(seen.values());
  }, [rows]);

  const dateCols = useMemo(() => {
    const end = new Date(rangeEnd + "T00:00:00");
    const list: string[] = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date(end);
      d.setDate(end.getDate() - i);
      list.push(isoDate(d));
    }
    return list;
  }, [rangeEnd, days]);

  const cellMap = useMemo(() => {
    const m = new Map<string, FabricDowntimeRow>();
    for (const r of rows) {
      m.set(`${r.concern.trim().toLowerCase()}|${r.entry_date}`, r);
    }
    return m;
  }, [rows]);

  const addConcern = async () => {
    const name = newConcern.trim();
    if (!name) { toast.error("Enter concern name"); return; }
    if (concerns.some((c) => c.toLowerCase() === name.toLowerCase())) {
      toast.error("Concern already exists");
      return;
    }
    setBusy(true);
    const { error } = await sb.from("fabric_downtime").insert({
      entry_date: isoDate(new Date()),
      concern: name,
      lost_hours: 0,
      notes: null,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    setNewConcern("");
    toast.success("Concern added");
  };

  const setCell = async (concern: string, date: string, value: number) => {
    const key = `${concern.trim().toLowerCase()}|${date}`;
    const existing = cellMap.get(key);
    if (existing) {
      if (value === 0) {
        const anyOther = rows.some(
          (r) => r.concern.trim().toLowerCase() === concern.toLowerCase() && r.id !== existing.id,
        );
        if (anyOther) {
          const { error } = await sb.from("fabric_downtime").delete().eq("id", existing.id);
          if (error) toast.error(error.message);
          return;
        }
      }
      const { error } = await sb.from("fabric_downtime").update({ lost_hours: value }).eq("id", existing.id);
      if (error) toast.error(error.message);
    } else {
      if (value === 0) return;
      const { error } = await sb.from("fabric_downtime").insert({
        entry_date: date,
        concern: concern.trim(),
        lost_hours: value,
        notes: null,
      });
      if (error) toast.error(error.message);
    }
  };

  const renameConcern = async (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed || trimmed === oldName) return;
    if (concerns.some((c) => c.toLowerCase() === trimmed.toLowerCase())) {
      toast.error("A concern with that name already exists");
      return;
    }
    const ids = rows.filter((r) => r.concern.trim().toLowerCase() === oldName.toLowerCase()).map((r) => r.id);
    if (!ids.length) return;
    const { error } = await sb.from("fabric_downtime").update({ concern: trimmed }).in("id", ids);
    if (error) toast.error(error.message);
  };

  const removeConcern = async (name: string) => {
    if (!confirm(`Delete concern "${name}" and all its downtime entries?`)) return;
    const ids = rows.filter((r) => r.concern.trim().toLowerCase() === name.toLowerCase()).map((r) => r.id);
    if (!ids.length) return;
    const { error } = await sb.from("fabric_downtime").delete().in("id", ids);
    if (error) toast.error(error.message);
  };

  const rowTotal = (concern: string) =>
    dateCols.reduce((s, d) => s + Number(cellMap.get(`${concern.toLowerCase()}|${d}`)?.lost_hours ?? 0), 0);

  const colTotal = (date: string) =>
    concerns.reduce((s, c) => s + Number(cellMap.get(`${c.toLowerCase()}|${date}`)?.lost_hours ?? 0), 0);

  const grandTotal = useMemo(
    () => rows.reduce((s, r) => s + Number(r.lost_hours || 0), 0),
    [rows],
  );
  const todayIso = isoDate(new Date());
  const todayTotal = useMemo(
    () => rows.filter((r) => r.entry_date === todayIso).reduce((s, r) => s + Number(r.lost_hours || 0), 0),
    [rows, todayIso],
  );

  const shiftRange = (deltaDays: number) => {
    const d = new Date(rangeEnd + "T00:00:00");
    d.setDate(d.getDate() + deltaDays);
    setRangeEnd(isoDate(d));
  };

  return (
    <div className="space-y-4">
      <section className="rounded-2xl border-2 border-rose-400/30 bg-gradient-to-br from-rose-500/10 via-orange-500/5 to-amber-500/10 p-4 space-y-3 shadow-sm shadow-rose-500/10">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-rose-500 to-orange-500 text-white grid place-items-center shadow-md shadow-rose-500/30">
            <AlertTriangle className="h-4 w-4" />
          </div>
          <h2 className="font-bold bg-gradient-to-r from-rose-600 to-orange-600 bg-clip-text text-transparent">Log Fabric Downtime Concern</h2>
          <div className="ml-auto flex items-center gap-2 text-xs">
            <span className="px-2.5 py-1 rounded-full bg-rose-500/15 text-rose-700 dark:text-rose-300 font-semibold inline-flex items-center gap-1">
              <Clock className="h-3 w-3" /> Today: {todayTotal.toFixed(2)} h
            </span>
            <span className="px-2.5 py-1 rounded-full bg-amber-500/15 text-amber-700 dark:text-amber-300 font-semibold">
              Total: {grandTotal.toFixed(2)} h · {concerns.length} concerns
            </span>
          </div>
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex flex-col gap-1 flex-1 min-w-[220px]">
            <label className="text-[11px] text-muted-foreground font-medium">New concern (added as a new row)</label>
            <input
              value={newConcern}
              onChange={(e) => setNewConcern(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") addConcern(); }}
              className="px-2.5 py-2 text-sm rounded-lg border-2 border-orange-300/40 bg-background focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none transition-all"
              placeholder="e.g. No fabric, Wrong roll issued, Shade issue…"
            />
          </div>
          <button onClick={addConcern} disabled={busy} className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold rounded-lg bg-gradient-to-r from-rose-500 via-orange-500 to-amber-500 text-white shadow-md shadow-orange-500/30 hover:shadow-lg active:scale-[0.98] transition-all disabled:opacity-50">
            <Plus className="h-4 w-4" /> Add concern
          </button>
        </div>
        <div className="flex flex-wrap items-end gap-2 pt-1 border-t border-rose-400/20">
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-muted-foreground font-medium">Range end date</label>
            <input type="date" value={rangeEnd} onChange={(e) => setRangeEnd(e.target.value)} className="px-2.5 py-2 text-sm rounded-lg border-2 border-rose-300/40 bg-background focus:border-rose-500 focus:ring-2 focus:ring-rose-500/20 outline-none transition-all" />
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-muted-foreground font-medium">Days shown</label>
            <select value={days} onChange={(e) => setDays(Number(e.target.value))} className="px-2.5 py-2 text-sm rounded-lg border-2 border-amber-300/40 bg-background focus:border-amber-500 outline-none">
              {[3, 5, 7, 10, 14, 21, 30].map((n) => <option key={n} value={n}>{n} days</option>)}
            </select>
          </div>
          <div className="flex gap-1">
            <button onClick={() => shiftRange(-days)} className="px-3 py-2 text-xs font-semibold rounded-lg border-2 border-rose-300/40 hover:bg-rose-500/10 transition-all">◀ Prev</button>
            <button onClick={() => setRangeEnd(isoDate(new Date()))} className="px-3 py-2 text-xs font-semibold rounded-lg border-2 border-orange-300/40 hover:bg-orange-500/10 transition-all">Today</button>
            <button onClick={() => shiftRange(days)} className="px-3 py-2 text-xs font-semibold rounded-lg border-2 border-rose-300/40 hover:bg-rose-500/10 transition-all">Next ▶</button>
          </div>
        </div>
      </section>

      <section className="rounded-2xl border-2 border-rose-400/30 bg-gradient-to-br from-rose-500/5 via-orange-500/5 to-amber-500/5 shadow-sm shadow-rose-500/10 overflow-hidden">
        <div className="overflow-auto max-h-[65vh]">
          <table className="w-full text-xs border-collapse">
            <thead className="sticky top-0 bg-gradient-to-r from-rose-500/20 via-orange-500/20 to-amber-500/20 backdrop-blur z-10">
              <tr className="text-left">
                <th className="px-3 py-2.5 font-bold whitespace-nowrap text-rose-900 dark:text-rose-100 sticky left-0 bg-rose-500/25 backdrop-blur z-20 min-w-[220px]">Concern ▼</th>
                {dateCols.map((d) => {
                  const dt = new Date(d + "T00:00:00");
                  const isToday = d === todayIso;
                  return (
                    <th key={d} className={`px-2 py-2.5 font-bold whitespace-nowrap text-center ${isToday ? "text-orange-900 dark:text-orange-100 bg-orange-500/20" : "text-rose-900 dark:text-rose-100"}`}>
                      <div className="text-[10px] uppercase opacity-70">{dt.toLocaleDateString(undefined, { weekday: "short" })}</div>
                      <div className="tabular-nums">{dt.toLocaleDateString(undefined, { month: "short", day: "2-digit" })}</div>
                    </th>
                  );
                })}
                <th className="px-3 py-2.5 font-bold whitespace-nowrap text-center text-amber-900 dark:text-amber-100 bg-amber-500/20">Total</th>
                <th className="px-2 py-2.5"></th>
              </tr>
            </thead>
            <tbody>
              {loading && <tr><td colSpan={dateCols.length + 3} className="p-6 text-center text-muted-foreground">Loading…</td></tr>}
              {!loading && concerns.length === 0 && (
                <tr><td colSpan={dateCols.length + 3} className="p-6 text-center text-muted-foreground">No concerns yet. Add one above.</td></tr>
              )}
              {concerns.map((c) => (
                <tr key={c} className="border-t hover:bg-muted/30 transition-colors">
                  <td className="px-2 py-1.5 sticky left-0 bg-background/95 backdrop-blur z-10 border-r border-rose-400/20">
                    <input
                      defaultValue={c}
                      onBlur={(e) => renameConcern(c, e.target.value)}
                      className="w-full px-2 py-1 rounded border border-transparent hover:border-orange-300/40 focus:border-orange-500 bg-transparent outline-none font-medium"
                    />
                  </td>
                  {dateCols.map((d) => {
                    const cell = cellMap.get(`${c.toLowerCase()}|${d}`);
                    const val = cell ? Number(cell.lost_hours) : 0;
                    return (
                      <td key={d} className="px-1 py-1 text-center">
                        <input
                          type="number"
                          step="0.25"
                          min={0}
                          defaultValue={val || ""}
                          key={`${c}-${d}-${cell?.id ?? "empty"}-${val}`}
                          onBlur={(e) => {
                            const v = Number(e.target.value || 0);
                            if (!isFinite(v) || v < 0) return;
                            if (v === val) return;
                            setCell(c, d, v);
                          }}
                          className="w-16 px-1.5 py-1 rounded border border-transparent hover:border-amber-300/40 focus:border-amber-500 bg-transparent outline-none text-center tabular-nums"
                          placeholder="—"
                        />
                      </td>
                    );
                  })}
                  <td className="px-3 py-1.5 text-center tabular-nums font-bold text-rose-700 dark:text-rose-300 bg-amber-500/10">
                    {rowTotal(c).toFixed(2)}
                  </td>
                  <td className="px-2 py-1.5 text-right">
                    <button onClick={() => removeConcern(c)} className="text-rose-500/80 hover:text-rose-600 hover:scale-110 transition-transform" title="Delete concern">
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
              {concerns.length > 0 && (
                <tr className="border-t-2 border-rose-400/40 bg-gradient-to-r from-rose-500/10 via-orange-500/10 to-amber-500/10 font-bold">
                  <td className="px-3 py-2 sticky left-0 bg-rose-500/15 backdrop-blur z-10 text-rose-900 dark:text-rose-100">Daily total</td>
                  {dateCols.map((d) => (
                    <td key={d} className="px-1 py-2 text-center tabular-nums text-rose-800 dark:text-rose-200">
                      {colTotal(d).toFixed(2)}
                    </td>
                  ))}
                  <td className="px-3 py-2 text-center tabular-nums text-amber-800 dark:text-amber-200 bg-amber-500/20">
                    {dateCols.reduce((s, d) => s + colTotal(d), 0).toFixed(2)}
                  </td>
                  <td></td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
