import { createFileRoute } from "@tanstack/react-router";
import { useApp } from "@/lib/store";
import { RequireAccess } from "@/components/RequireAccess";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ArrivalBadge, StatusBadge } from "./dashboard";
import { GatePass } from "@/components/GatePass";
import { BAYS, type BayId, type HoldReason, type VehicleLog } from "@/lib/types";
import { Play, Pause, CheckCircle2, X, AlertTriangle, ArrowUp, ArrowDown, ArrowRightLeft, Save, Pencil, Undo2, Warehouse, FileSpreadsheet, Clock } from "lucide-react";
import { Bays } from "./bays";
import { InvoiceLog } from "./invoice-log";
import { UnloadCapacityPanel } from "@/components/UnloadCapacityPanel";
import { PendingInvoices } from "@/components/PendingInvoices";

export const Route = createFileRoute("/grn")({
  head: () => ({ meta: [{ title: "RM GRN — Priority & Bay Control · Casualline Logistics 360" }, { name: "description", content: "RM GRN bay execution, invoice tracking and operational priorities." },
      { property: "og:title", content: "RM GRN — Priority & Bay Control · Casualline Logistics 360" },
      { property: "og:description", content: "RM GRN bay execution, invoice tracking and operational priorities." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ] }),
  component: () => (
    <RequireAccess path="/grn">
      <GRN />
    </RequireAccess>
  ),
});

function GRN() {
  const {
    state, user, updateVehicle, completeUnloading,
    assignToBay, changeBay, startUnloading, unassignFromBay, revertGateIn,
  } = useApp();
  const [selected, setSelected] = useState<string | null>(null);
  const [tab, setTab] = useState<"grn" | "bays" | "invoice" | "pending">("grn");
  const [holdModal, setHoldModal] = useState<{ token: string } | null>(null);
  const [holdReason, setHoldReason] = useState<HoldReason>("Portal Pending");
  const [holdNotes, setHoldNotes] = useState("");
  const [passVehicle, setPassVehicle] = useState<VehicleLog | null>(null);
  const [qtyDraft, setQtyDraft] = useState<Record<string, { roll: number; box: number }>>({});
  const [returnModal, setReturnModal] = useState<VehicleLog | null>(null);
  const [revertModal, setRevertModal] = useState<VehicleLog | null>(null);
  const [editModal, setEditModal] = useState<VehicleLog | null>(null);
  const [editDraft, setEditDraft] = useState<{ vehicle_number: string; roll_qty: number; box_qty: number }>({ vehicle_number: "", roll_qty: 0, box_qty: 0 });

  const isGrnTeam = user?.role === "grn" || user?.role === "admin" || user?.role === "menu";
  const canEditOrRevert = (v: VehicleLog) => isGrnTeam && v.current_status !== "Completed" && v.current_status !== "Departed";

  const openEdit = (v: VehicleLog) => {
    setEditDraft({ vehicle_number: v.vehicle_number, roll_qty: v.roll_qty, box_qty: v.box_qty });
    setEditModal(v);
  };

  const saveEdit = async () => {
    if (!editModal) return;
    const vn = editDraft.vehicle_number.trim();
    if (!vn) { toast.error("Vehicle number required"); return; }
    if (editDraft.roll_qty < 0 || editDraft.box_qty < 0) { toast.error("Quantities must be ≥ 0"); return; }
    try {
      await updateVehicle(editModal.token_no, {
        vehicle_number: vn,
        roll_qty: editDraft.roll_qty,
        box_qty: editDraft.box_qty,
      });
      toast.success("Vehicle details updated — dashboard & TV refreshed");
      setEditModal(null);
    } catch (e) {
      console.error(e);
      toast.error("Update failed");
    }
  };

  const confirmRevert = async () => {
    if (!revertModal) return;
    const v = revertModal;
    setRevertModal(null);
    try {
      await revertGateIn(v.token_no, "GRN revert — invalid gate-in");
      toast.success(`Vehicle ${v.vehicle_number} reverted & removed from dashboard/TV`);
    } catch {
      toast.error("Revert failed");
    }
  };


  // Waiting = no bay yet, sorted by manual priority (queue_position) then FIFO
  const waiting = useMemo(
    () => state.vehicles
      .filter((v) => !v.bay_id && (v.current_status === "Waiting" || v.current_status === "Assigned"))
      .sort((a, b) => {
        const ap = a.queue_position ?? 9999;
        const bp = b.queue_position ?? 9999;
        if (ap !== bp) return ap - bp;
        return new Date(a.in_time).getTime() - new Date(b.in_time).getTime();
      }),
    [state.vehicles]
  );

  // Everything in a bay (active + queued)
  const inBays = useMemo(
    () => state.vehicles
      .filter((v) => v.bay_id && v.current_status !== "Completed" && v.current_status !== "Departed")
      .sort((a, b) => (a.bay_id || "").localeCompare(b.bay_id || "") || (a.queue_position ?? 0) - (b.queue_position ?? 0)),
    [state.vehicles]
  );

  const counts = useMemo(() => {
    const active = state.vehicles.filter((v) => v.current_status !== "Completed" && v.current_status !== "Departed");
    return {
      unloading: active.filter((v) => v.current_status === "Unloading").length,
      hold: active.filter((v) => v.current_status === "Hold").length,
      heldUp: active.filter((v) => v.is_held_up).length,
    };
  }, [state.vehicles]);

  const current = state.vehicles.find((v) => v.token_no === selected) || null;

  const wrap = async (fn: () => Promise<void>, ok: string) => {
    try { await fn(); toast.success(ok); } catch (e) { console.error(e); toast.error(e && typeof e === "object" && "message" in e ? String(e.message) : "Action failed"); }
  };

  const setWaitingPriority = async (token: string, dir: "up" | "down") => {
    const list = [...waiting];
    const idx = list.findIndex((v) => v.token_no === token);
    const swap = dir === "up" ? idx - 1 : idx + 1;
    if (swap < 0 || swap >= list.length) return;
    [list[idx], list[swap]] = [list[swap], list[idx]];
    // persist queue_position 0..n
    for (let i = 0; i < list.length; i++) {
      await updateVehicle(list[i].token_no, { queue_position: i });
    }
    toast.success(`Priority updated`);
  };

  const openHold = (token: string) => {
    setHoldReason((state.grnReasons[0]?.label as HoldReason) || "Portal Pending");
    setHoldNotes("");
    setHoldModal({ token });
  };

  const confirmHold = async () => {
    if (!holdModal) return;
    if (holdReason === "Other" && !holdNotes.trim()) { toast.error("Please provide a reason"); return; }
    try {
    await updateVehicle(holdModal.token, {
      current_status: "Hold",
      hold_reason: holdReason,
      hold_notes: holdReason === "Other" ? holdNotes.trim() : undefined,
    });
    toast.warning("Vehicle placed on hold");
    setHoldModal(null);
    } catch (e) { toast.error(e && typeof e === "object" && "message" in e ? String(e.message) : "Could not place vehicle on Hold"); }
  };

  const complete = async (token: string) => {
    try {
      const v = await completeUnloading(token, user?.display_name || user?.username);
      toast.success("Complete — Gate Pass ready");
      if (v) setPassVehicle(v);
    } catch { toast.error("Complete failed"); }
  };

  const saveQty = async (token: string) => {
    const d = qtyDraft[token];
    if (!d) return;
    await updateVehicle(token, { roll_qty: d.roll, box_qty: d.box });
    toast.success("Actual quantities updated");
    setQtyDraft((prev) => { const n = { ...prev }; delete n[token]; return n; });
  };

  const priorityLabel = (i: number) => {
    const ords = ["1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", "10th"];
    return `${ords[i] || `#${i + 1}`} Unloading`;
  };

  return (
    <div className="p-6 space-y-6 animate-fade-in">
      <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-rose-500/15 via-orange-500/10 to-amber-500/10 p-6">
        <div className="absolute -top-20 -right-20 w-72 h-72 rounded-full bg-rose-500/25 blur-3xl" />
        <div className="absolute -bottom-20 -left-20 w-72 h-72 rounded-full bg-amber-400/20 blur-3xl" />
        <div className="relative flex items-center gap-3">
          <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-rose-500 to-orange-500 text-white grid place-items-center shadow-lg shadow-rose-500/30">
            <ArrowRightLeft className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-rose-600 to-amber-600 bg-clip-text text-transparent">RM GRN — Priority &amp; Bay Control</h1>
            <p className="text-sm text-muted-foreground">Set priority, assign / switch bays, manage status, record quantities</p>
          </div>
        </div>
      </div>

      {/* Live status strip */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <StatTile label="Waiting" value={waiting.length} tone="amber" hint="No bay yet" />
        <StatTile label="In Bay" value={inBays.length} tone="sky" hint="Assigned / active" />
        <StatTile label="Unloading" value={counts.unloading} tone="emerald" hint="In progress" />
        <StatTile label="On Hold" value={counts.hold} tone="orange" hint="Blocked" />
        <StatTile label="Held-up >24h" value={counts.heldUp} tone="rose" hint="Demurrage risk" />
      </div>

      {/* Section switcher — card style tabs */}
      <div className="grid gap-3 md:grid-cols-4">
        <SectionTab
          active={tab === "grn"} onClick={() => setTab("grn")} icon={ArrowRightLeft}
          tone="rose" step="1" title="Priority & Bay Control"
          desc="Waiting pool priority, bay assign, start / hold / complete"
          badge={waiting.length + inBays.length}
        />
        <SectionTab
          active={tab === "bays"} onClick={() => setTab("bays")} icon={Warehouse}
          tone="emerald" step="2" title="Bay Management"
          desc="Drag & drop bay board, partial unload qty tracker"
          badge={inBays.length}
        />
        <SectionTab
          active={tab === "invoice"} onClick={() => setTab("invoice")} icon={FileSpreadsheet}
          tone="sky" step="3" title="Daily Invoice GRN Log"
          desc="Fabric & Trims invoice received vs completed"
        />
        <SectionTab
          active={tab === "pending"} onClick={() => setTab("pending")} icon={Clock}
          tone="amber" step="4" title="Pending Invoices"
          desc="Received date, reason, PCU member, auto pending days"
        />
      </div>


      {tab === "pending" ? (
        <PendingInvoices canComplete={isGrnTeam} userName={user?.display_name ?? user?.username} />
      ) : tab === "invoice" ? (
        <div className="-mx-6 -mb-6"><InvoiceLog /></div>
      ) : tab === "bays" ? (
        <div className="-mx-6 -mb-6"><Bays /></div>
      ) : (
        <>
      {/* Waiting Pool — priority + assign */}
      <section className="rounded-2xl border-2 border-amber-400/40 bg-gradient-to-br from-amber-500/5 via-card to-card p-5 shadow-sm shadow-amber-500/10">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
          <h3 className="font-semibold flex items-center gap-2">
            <span className="h-6 w-6 grid place-items-center rounded-md bg-amber-500 text-white text-xs font-bold">1</span>
            Gate-In Waiting Pool
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-600">{waiting.length}</span>
          </h3>
          <span className="text-xs text-muted-foreground">Reorder priority (↑ ↓) · then assign to a Bay</span>
        </div>
        

        {waiting.length === 0 ? (
          <p className="text-sm text-muted-foreground">No vehicles waiting for bay assignment.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-muted-foreground border-b">
                <tr>
                  <th className="text-left py-2 w-28">Priority</th>
                  <th className="text-left py-2">Vehicle / Token</th>
                  <th className="text-left py-2">Vendor / Material</th>
                  <th className="text-left py-2">Arrival</th>
                  <th className="text-left py-2">In Time</th>
                  <th className="text-right py-2 w-56">Assign to Bay</th>
                </tr>
              </thead>
              <tbody>
                {waiting.map((v, i) => (
                  <tr key={v.token_no} className={`border-b last:border-0 ${v.is_held_up ? "bg-destructive/5" : ""}`}>
                    <td className="py-2">
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-bold text-primary w-20">{priorityLabel(i)}</span>
                        <button onClick={() => setWaitingPriority(v.token_no, "up")} disabled={i === 0}
                          className="h-6 w-6 grid place-items-center rounded border hover:bg-muted disabled:opacity-30">
                          <ArrowUp className="h-3 w-3" />
                        </button>
                        <button onClick={() => setWaitingPriority(v.token_no, "down")} disabled={i === waiting.length - 1}
                          className="h-6 w-6 grid place-items-center rounded border hover:bg-muted disabled:opacity-30">
                          <ArrowDown className="h-3 w-3" />
                        </button>
                      </div>
                    </td>
                    <td className="py-2">
                      <div className="font-medium flex items-center gap-1">
                        {v.vehicle_number}
                        {v.is_held_up && <AlertTriangle className="h-3.5 w-3.5 text-destructive" />}
                      </div>
                      <div className="text-[11px] font-mono text-muted-foreground">{v.token_no}</div>
                    </td>
                    <td className="py-2">
                      <div>{v.vendor_name}</div>
                      <div className="text-xs text-muted-foreground">{v.material_type} · {v.relevant_pcu}</div>
                    </td>
                    <td className="py-2"><ArrivalBadge status={v.arrival_status} /></td>
                    <td className="py-2 text-xs text-muted-foreground">{new Date(v.in_time).toLocaleTimeString()}</td>
                    <td className="py-2">
                      <div className="flex gap-1 justify-end">
                        {BAYS.map((b) => (
                          <button key={b.id}
                            onClick={() => wrap(() => assignToBay(v.token_no, b.id), `Assigned → ${b.label}`)}
                            className="text-xs h-8 px-2 rounded border hover:bg-primary hover:text-primary-foreground transition-colors">
                            → {b.label.replace("Bay ", "B")}
                          </button>
                        ))}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* In-Bay Control */}
      <section className="rounded-2xl border-2 border-sky-400/40 bg-gradient-to-br from-sky-500/5 via-card to-card p-5 shadow-sm shadow-sky-500/10">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
          <h3 className="font-semibold flex items-center gap-2">
            <span className="h-6 w-6 grid place-items-center rounded-md bg-sky-500 text-white text-xs font-bold">2</span>
            In-Bay Vehicles
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-sky-500/15 text-sky-600">{inBays.length}</span>
          </h3>
          <span className="text-xs text-muted-foreground">Start / Hold / Complete · Switch bay · Record actual Roll &amp; Box qty</span>
        </div>
        <p className="text-xs text-muted-foreground mb-3">Step 2 — Manage vehicles inside the bay: start unloading, place on hold, save actual qty.</p>

        {inBays.length === 0 ? (
          <p className="text-sm text-muted-foreground">No vehicles currently in any bay.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-xs uppercase text-muted-foreground border-b">
                <tr>
                  <th className="text-left py-2">Bay</th>
                  <th className="text-left py-2">Vehicle</th>
                  <th className="text-left py-2">Vendor</th>
                  <th className="text-left py-2">Status</th>
                  <th className="text-left py-2">Actual Qty (Roll / Box)</th>
                  <th className="text-left py-2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {inBays.map((v) => {
                  const draft = qtyDraft[v.token_no] || { roll: v.roll_qty, box: v.box_qty };
                  const dirty = draft.roll !== v.roll_qty || draft.box !== v.box_qty;
                  return (
                    <tr key={v.token_no} className={`border-b last:border-0 ${v.is_held_up ? "bg-destructive/5" : ""}`}>
                      <td className="py-2">
                        <span className="text-xs font-bold px-2 py-0.5 rounded bg-primary/10 text-primary">{v.bay_id}</span>
                      </td>
                      <td className="py-2">
                        <div className="font-medium">{v.vehicle_number}</div>
                        <div className="text-[11px] font-mono text-muted-foreground">{v.token_no}</div>
                      </td>
                      <td className="py-2">
                        <div>{v.vendor_name}</div>
                        <div className="text-xs text-muted-foreground">{v.material_type}</div>
                      </td>
                      <td className="py-2"><StatusBadge status={v.current_status} /></td>
                      <td className="py-2">
                        <div className="flex items-center gap-1">
                          <input type="number" min={0} value={draft.roll}
                            onChange={(e) => setQtyDraft((p) => ({ ...p, [v.token_no]: { ...draft, roll: Number(e.target.value) } }))}
                            className="w-16 h-8 px-1 rounded border bg-background text-center" />
                          <span className="text-muted-foreground">/</span>
                          <input type="number" min={0} value={draft.box}
                            onChange={(e) => setQtyDraft((p) => ({ ...p, [v.token_no]: { ...draft, box: Number(e.target.value) } }))}
                            className="w-16 h-8 px-1 rounded border bg-background text-center" />
                          <button disabled={!dirty} onClick={() => saveQty(v.token_no)}
                            className="h-8 px-2 rounded bg-primary text-primary-foreground text-xs font-medium disabled:opacity-30 flex items-center gap-1">
                            <Save className="h-3 w-3" /> Save
                          </button>
                        </div>
                      </td>
                      <td className="py-2">
                        <div className="flex gap-1 flex-wrap">
                          {(v.current_status === "Waiting" || v.current_status === "Assigned") && (
                            <MiniBtn onClick={() => wrap(() => startUnloading(v.token_no), "Unloading started")} icon={Play} label="Start" tone="blue" />
                          )}
                          {v.current_status === "Unloading" && (
                            <>
                              <MiniBtn onClick={() => openHold(v.token_no)} icon={Pause} label="Hold" tone="amber" />
                              <MiniBtn onClick={() => complete(v.token_no)} icon={CheckCircle2} label="Complete" tone="green" />
                            </>
                          )}
                          {v.current_status === "Hold" && (
                            <>
                              <MiniBtn onClick={() => wrap(() => startUnloading(v.token_no), "Unloading resumed")} icon={Play} label="Resume" tone="blue" />
                              <MiniBtn onClick={() => complete(v.token_no)} icon={CheckCircle2} label="Complete" tone="green" />
                            </>
                          )}
                          <BaySwitcher current={v.bay_id as BayId} onPick={(b) => wrap(() => changeBay(v.token_no, b), "Bay switched")} />
                          <MiniBtn onClick={() => setReturnModal(v)} icon={X} label="Return" tone="gray" />
                          {canEditOrRevert(v) && (
                            <>
                              <MiniBtn onClick={() => openEdit(v)} icon={Pencil} label="Edit" tone="blue" />
                              <MiniBtn onClick={() => setRevertModal(v)} icon={Undo2} label="Revert" tone="red" />
                            </>
                          )}
                          <button onClick={() => setSelected(v.token_no)}
                            className="h-8 px-2 rounded border text-xs hover:bg-muted">Details</button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Details drawer for selected */}
      {current && (
        <section className="rounded-lg border bg-card p-5">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold">Vehicle Details — {current.vehicle_number}</h3>
            <button onClick={() => setSelected(null)} className="p-1 hover:bg-muted rounded"><X className="h-4 w-4" /></button>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <Cell label="Token" value={current.token_no} />
            <Cell label="Vendor" value={current.vendor_name} />
            <Cell label="Material" value={current.material_type} />
            <Cell label="PCU" value={current.relevant_pcu} />
            <Cell label="Invoice" value={current.invoice_no || "—"} />
            <Cell label="Vehicle Type" value={current.vehicle_type} />
            <Cell label="Driver" value={current.driver_name || "—"} />
            <Cell label="Phone" value={current.driver_phone || "—"} />
            <Cell label="In Time" value={new Date(current.in_time).toLocaleString()} />
            <Cell label="Unload Start" value={current.unload_start_time ? new Date(current.unload_start_time).toLocaleTimeString() : "—"} />
            <Cell label="Bay" value={current.bay_id || "—"} />
            <Cell label="Held-up" value={current.is_held_up ? "YES" : "No"} />
          </div>
          {current.hold_reason && (
            <div className="mt-3 p-2 rounded bg-amber-500/10 text-amber-800 dark:text-amber-300 text-xs">
              <div className="font-semibold">Hold: {current.hold_reason}</div>
              {current.hold_notes && <div className="italic">"{current.hold_notes}"</div>}
            </div>
          )}
          {canEditOrRevert(current) && (
            <div className="mt-4 pt-3 border-t flex flex-wrap gap-2">
              <span className="text-xs uppercase text-muted-foreground self-center mr-2">RM GRN Actions</span>
              <button onClick={() => openEdit(current)}
                className="h-9 px-3 rounded-md bg-sky-600 hover:bg-sky-700 text-white text-sm font-medium flex items-center gap-1.5">
                <Pencil className="h-3.5 w-3.5" /> Edit Vehicle Details
              </button>
              <button onClick={() => setRevertModal(current)}
                className="h-9 px-3 rounded-md bg-rose-600 hover:bg-rose-700 text-white text-sm font-medium flex items-center gap-1.5">
                <Undo2 className="h-3.5 w-3.5" /> Revert Vehicle
              </button>
            </div>
          )}
          {current.current_status === "Completed" && (
            <div className="mt-3 text-xs text-muted-foreground italic">
              Vehicle is Completed — Edit &amp; Revert actions are locked.
            </div>
          )}
        </section>
      )}

      {holdModal && (
        <div className="fixed inset-0 bg-black/50 grid place-items-center z-50 p-4">
          <div className="w-full max-w-md bg-card rounded-lg border p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Place vehicle on hold</h3>
              <button onClick={() => setHoldModal(null)} className="p-1 hover:bg-muted rounded"><X className="h-4 w-4" /></button>
            </div>
            <div>
              <label className="text-sm font-medium">Reason</label>
              <select value={holdReason} onChange={(e) => setHoldReason(e.target.value as HoldReason)}
                className="mt-1 w-full h-10 px-2 rounded border bg-background">
                {state.grnReasons.filter((r) => r.is_active).map((r) => (
                  <option key={r.id} value={r.label}>{r.label}</option>
                ))}
                <option value="Portal Pending">Portal Pending</option>
                <option value="Other">Other</option>
              </select>
            </div>
            {holdReason === "Other" && (
              <div>
                <label className="text-sm font-medium">Details</label>
                <textarea value={holdNotes} onChange={(e) => setHoldNotes(e.target.value)}
                  rows={3} className="mt-1 w-full p-2 rounded border bg-background" placeholder="Describe the hold reason…" />
              </div>
            )}
            <div className="flex justify-end gap-2">
              <button onClick={() => setHoldModal(null)} className="h-9 px-3 rounded-md border">Cancel</button>
              <button onClick={confirmHold} className="h-9 px-3 rounded-md bg-amber-600 text-white font-medium">Confirm Hold</button>
            </div>
          </div>
        </div>
      )}

      {passVehicle && (
        <GatePass vehicle={passVehicle} costRate={state.settings.held_up_cost_rate} onClose={() => setPassVehicle(null)} />
      )}

      {returnModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm grid place-items-center z-50 p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-card rounded-xl border shadow-2xl p-6 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3">
              <div className="h-11 w-11 grid place-items-center rounded-full bg-amber-500/15 text-amber-600">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Return vehicle?</h3>
                <p className="text-xs text-muted-foreground">This will remove the vehicle from its bay.</p>
              </div>
            </div>
            <div className="rounded-lg border bg-muted/40 p-3 text-sm">
              <div className="font-medium">Are you sure to return vehicle <span className="text-primary">{returnModal.vehicle_number}</span>?</div>
              <div className="text-xs text-muted-foreground mt-1">
                Token {returnModal.token_no} · Bay {returnModal.bay_id} · {returnModal.vendor_name}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button onClick={() => setReturnModal(null)} className="h-9 px-4 rounded-md border hover:bg-muted transition-colors">
                Cancel
              </button>
              <button
                onClick={async () => {
                  const token = returnModal.token_no;
                  setReturnModal(null);
                  await wrap(() => unassignFromBay(token), "Vehicle returned");
                }}
                className="h-9 px-4 rounded-md bg-amber-600 hover:bg-amber-700 text-white font-medium transition-colors"
              >
                Yes, return vehicle
              </button>
            </div>
          </div>
        </div>
      )}

      {editModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm grid place-items-center z-50 p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-card rounded-xl border shadow-2xl p-6 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="h-11 w-11 grid place-items-center rounded-full bg-sky-500/15 text-sky-600">
                  <Pencil className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Edit Vehicle Details</h3>
                  <p className="text-xs text-muted-foreground">Token {editModal.token_no} · RM GRN override</p>
                </div>
              </div>
              <button onClick={() => setEditModal(null)} className="p-1 hover:bg-muted rounded"><X className="h-4 w-4" /></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium">Vehicle Registration Number</label>
                <input value={editDraft.vehicle_number}
                  onChange={(e) => setEditDraft((d) => ({ ...d, vehicle_number: e.target.value.toUpperCase() }))}
                  className="mt-1 w-full h-10 px-3 rounded border bg-background" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-sm font-medium">Roll Qty</label>
                  <input type="number" min={0} value={editDraft.roll_qty}
                    onChange={(e) => setEditDraft((d) => ({ ...d, roll_qty: Number(e.target.value) }))}
                    className="mt-1 w-full h-10 px-3 rounded border bg-background" />
                </div>
                <div>
                  <label className="text-sm font-medium">Box Qty</label>
                  <input type="number" min={0} value={editDraft.box_qty}
                    onChange={(e) => setEditDraft((d) => ({ ...d, box_qty: Number(e.target.value) }))}
                    className="mt-1 w-full h-10 px-3 rounded border bg-background" />
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground">
                Save instantly recalculates dashboard totals and pushes to the TV display via realtime.
              </p>
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setEditModal(null)} className="h-9 px-3 rounded-md border hover:bg-muted">Cancel</button>
              <button onClick={saveEdit} className="h-9 px-4 rounded-md bg-sky-600 hover:bg-sky-700 text-white font-medium flex items-center gap-1.5">
                <Save className="h-4 w-4" /> Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {revertModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm grid place-items-center z-50 p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-card rounded-xl border shadow-2xl p-6 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3">
              <div className="h-11 w-11 grid place-items-center rounded-full bg-rose-500/15 text-rose-600">
                <Undo2 className="h-6 w-6" />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Revert vehicle check-in?</h3>
                <p className="text-xs text-muted-foreground">Removes from bays, dashboard counters &amp; TV display.</p>
              </div>
            </div>
            <div className="rounded-lg border bg-rose-500/5 p-3 text-sm">
              <div className="font-medium">Cancel gate-in for <span className="text-rose-600">{revertModal.vehicle_number}</span>?</div>
              <div className="text-xs text-muted-foreground mt-1">
                Token {revertModal.token_no} · {revertModal.vendor_name} · {revertModal.material_type}
              </div>
              <div className="text-xs text-rose-700 dark:text-rose-400 mt-2 font-medium">
                This action cannot be undone.
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-1">
              <button onClick={() => setRevertModal(null)} className="h-9 px-4 rounded-md border hover:bg-muted">Cancel</button>
              <button onClick={confirmRevert}
                className="h-9 px-4 rounded-md bg-rose-600 hover:bg-rose-700 text-white font-medium">
                Yes, revert vehicle
              </button>
            </div>
          </div>
        </div>
      )}
      </>
      )}

      <UnloadCapacityPanel />
    </div>
  );
}

const TONE: Record<string, string> = {
  blue: "bg-sky-600 hover:bg-sky-700 text-white",
  amber: "bg-amber-600 hover:bg-amber-700 text-white",
  green: "bg-emerald-600 hover:bg-emerald-700 text-white",
  red: "bg-rose-600 hover:bg-rose-700 text-white",
  gray: "border hover:bg-muted",
};
function MiniBtn({ onClick, icon: Icon, label, tone }: { onClick: () => void; icon: React.ComponentType<{ className?: string }>; label: string; tone: string }) {
  return (
    <button onClick={onClick} className={`h-8 px-2 rounded text-xs font-medium flex items-center gap-1 ${TONE[tone]}`}>
      <Icon className="h-3 w-3" /> {label}
    </button>
  );
}

function BaySwitcher({ current, onPick }: { current: BayId; onPick: (b: BayId) => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setOpen((o) => !o)}
        className="h-8 px-2 rounded border text-xs hover:bg-muted flex items-center gap-1">
        <ArrowRightLeft className="h-3 w-3" /> Switch
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-1 z-20 bg-card border rounded-md shadow-lg p-1 flex gap-1">
          {BAYS.filter((b) => b.id !== current).map((b) => (
            <button key={b.id} onClick={() => { onPick(b.id); setOpen(false); }}
              className="text-xs h-7 px-2 rounded hover:bg-primary hover:text-primary-foreground whitespace-nowrap">
              → {b.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[10px] uppercase text-muted-foreground">{label}</div>
      <div className="font-medium">{value}</div>
    </div>
  );
}

const TILE_TONES: Record<string, string> = {
  amber: "border-amber-400/40 bg-amber-500/5 text-amber-600",
  sky: "border-sky-400/40 bg-sky-500/5 text-sky-600",
  emerald: "border-emerald-400/40 bg-emerald-500/5 text-emerald-600",
  orange: "border-orange-400/40 bg-orange-500/5 text-orange-600",
  rose: "border-rose-400/40 bg-rose-500/5 text-rose-600",
};

function StatTile({ label, value, tone, hint }: { label: string; value: number; tone: string; hint?: string }) {
  return (
    <div className={`rounded-xl border-2 p-3 ${TILE_TONES[tone] || TILE_TONES.sky}`}>
      <div className="text-[11px] uppercase tracking-wide font-semibold opacity-80">{label}</div>
      <div className="text-2xl font-bold leading-tight text-foreground">{value}</div>
      {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
    </div>
  );
}

const TAB_TONES: Record<string, { active: string; icon: string }> = {
  rose: { active: "border-rose-500 ring-2 ring-rose-500/30 bg-rose-500/5", icon: "from-rose-500 to-orange-500" },
  emerald: { active: "border-emerald-500 ring-2 ring-emerald-500/30 bg-emerald-500/5", icon: "from-emerald-500 to-teal-500" },
  sky: { active: "border-sky-500 ring-2 ring-sky-500/30 bg-sky-500/5", icon: "from-sky-500 to-indigo-500" },
};

function SectionTab({
  active, onClick, icon: Icon, tone, step, title, desc, badge,
}: {
  active: boolean; onClick: () => void; icon: React.ComponentType<{ className?: string }>;
  tone: string; step: string; title: string; desc: string; badge?: number;
}) {
  const t = TAB_TONES[tone] || TAB_TONES.sky;
  return (
    <button
      onClick={onClick}
      className={`text-left rounded-2xl border-2 p-4 transition-all hover:shadow-md ${
        active ? t.active : "border-border bg-card hover:border-muted-foreground/30"
      }`}
    >
      <div className="flex items-start gap-3">
        <div className={`h-10 w-10 shrink-0 rounded-xl bg-gradient-to-br ${t.icon} text-white grid place-items-center shadow`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase text-muted-foreground">Step {step}</span>
            {badge !== undefined && badge > 0 && (
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-foreground/10">{badge}</span>
            )}
          </div>
          <div className="font-semibold text-sm truncate">{title}</div>
          <div className="text-[11px] text-muted-foreground leading-snug">{desc}</div>
        </div>
      </div>
    </button>
  );
}
