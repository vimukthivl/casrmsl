import { createFileRoute } from "@tanstack/react-router";
import { RequireAccess } from "@/components/RequireAccess";
import { useState } from "react";
import { ClipboardCheck, ShieldAlert, Scissors, Shirt } from "lucide-react";
import { CycleCountTracker } from "@/components/CycleCountTracker";

export const Route = createFileRoute("/cycle-counting")({
  head: () => ({
    meta: [
      { title: "Cycle Counting — MAS Casualline Logistics 360" },
      { name: "description", content: "Monthly SAP target vs daily actual cycle counting for Trims and Fabric warehouses." },
      { property: "og:title", content: "Cycle Counting — MAS Casualline Logistics 360" },
      { property: "og:description", content: "Monthly SAP target vs daily actual cycle counting for Trims and Fabric warehouses." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: () => (
    <RequireAccess path="/cycle-counting">
      <CycleCountingPage />
    </RequireAccess>
  ),
});

function CycleCountingPage() {
  const [trackerTab, setTrackerTab] = useState<"trims" | "fabric">("trims");

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-[1400px] mx-auto">
      {/* Colorful Header banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 p-6 shadow-lg shadow-teal-500/20">
        <div className="absolute -right-8 -top-8 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <div className="absolute -left-4 -bottom-10 h-32 w-32 rounded-full bg-white/10 blur-2xl" />
        <div className="relative flex items-start justify-between gap-4 flex-wrap">
          <div className="flex items-start gap-3">
            <div className="h-12 w-12 rounded-xl bg-white/25 backdrop-blur grid place-items-center ring-1 ring-white/40 shadow">
              <ClipboardCheck className="h-6 w-6 text-white" />
            </div>
            <div className="text-white">
              <h1 className="text-2xl font-bold leading-tight">Cycle Counting</h1>
              <p className="text-sm text-white/90 mt-1 max-w-xl">
                Set monthly SAP material targets and log daily counted quantities for each warehouse.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs bg-white/20 backdrop-blur border border-white/30 text-white rounded-lg px-3 py-2 shadow-sm">
            <ShieldAlert className="h-4 w-4" />
            <span className="font-medium">Live Progress Tracking</span>
          </div>
        </div>
      </div>

      {/* Monthly Target vs Daily Actual Tracker — Trims / Fabric */}
      <div className="rounded-2xl border-2 border-indigo-300/40 bg-gradient-to-br from-indigo-500/5 via-violet-500/5 to-fuchsia-500/5 p-3 md:p-4 space-y-3">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <h2 className="text-base md:text-lg font-bold">Monthly SAP Target vs Daily Actual</h2>
            <p className="text-xs text-muted-foreground">Set monthly item targets and log daily counted quantities per SAP code.</p>
          </div>
          <div className="inline-flex rounded-xl border bg-background p-1 shadow-sm">
            <button
              onClick={() => setTrackerTab("trims")}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                trackerTab === "trims"
                  ? "bg-gradient-to-r from-teal-500 to-emerald-500 text-white shadow"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              <Scissors className="h-3.5 w-3.5" /> Trims WH
            </button>
            <button
              onClick={() => setTrackerTab("fabric")}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                trackerTab === "fabric"
                  ? "bg-gradient-to-r from-fuchsia-500 to-pink-500 text-white shadow"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              <Shirt className="h-3.5 w-3.5" /> Fabric WH
            </button>
          </div>
        </div>
        {trackerTab === "trims" ? (
          <CycleCountTracker warehouse="trims" accent="teal" />
        ) : (
          <CycleCountTracker warehouse="fabric" accent="fuchsia" />
        )}
      </div>
    </div>
  );
}
