# Improve Pending Invoice Views

## User-facing changes
- Keep invoice entry only in the RM GRN Team page; remove the Add Pending Invoice form from the PCU page.
- Replace “Pending by PCU Member” with a supplier-wise pending summary and visually highlight the supplier with the highest pending count.
- Add a clear search bar to the PCU Pending Invoices tab that searches supplier, P/O, invoice number, reason, PCU member, merchant, and comments.
- Improve the PCU pending list layout and empty-state feedback while keeping comments available and completion restricted to the RM GRN Team.
- Add a live supplier-wise pending-invoice panel to the Logistics Dashboard, with the highest supplier clearly highlighted.

## Technical details
- Extend the shared pending-invoice component with page-specific options for showing the entry form and search.
- Load pending invoice supplier totals on the Logistics Dashboard and refresh them through the existing live database channel pattern.
- Preserve received-date sorting and current permission rules.
- Validate the updated pages and metadata after implementation.
