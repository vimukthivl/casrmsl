# Full-System Integration API — Review and Plan

## 1. What exists today
- One external data feed (`/api/public/system`) that already supports read, create, update and delete.
- It is protected by one shared system key, kept as a secret on the server.
- It covers **19 of the 22** business tables. Three are missing: **Pending Invoices, Sample Handovers, Unload Entries**.
- It also offers an "all" snapshot of the last 7 days and a list of tables.
- The Picker feed (`/api/public/picker`) and the assistant chat are separate. They stay as they are.

## 2. What is missing
- The three tables above.
- **PUT** (full replace). Only PATCH works today.
- **Per-integration keys with permissions.** Right now one key gives full write access, so Power BI holds a key that can delete data.
- **Audit log.** Nothing records who called the feed, what they did, or when.
- **Rate limiting.** There is none.
- **Request checks.** Column names, filters, body size and row limits are not checked.
- **Key in the web address.** `?api_key=` is still accepted, so the key can end up in logs and browser history.
- **Security level.** The feed uses the master database key, which skips row security rules. You asked us not to do that.

## 3. Can Lovable Cloud do this?
Yes. It can all be built as server routes, a few protected tables and server-side secrets. One limit: Power BI can't connect to the database directly, because Lovable Cloud doesn't give out the database password. Power BI connects through this web feed instead, which is the supported way.

## 4. How the keys will be secured
- Each integration (for example "Power BI", "ERP") gets its own key. The full key is shown **once** when it is created.
- The database stores only a SHA-256 fingerprint of each key, never the key itself.
- Each key has a scope: `read`, `write` or `delete`. It can also be limited to certain tables, and it can be revoked or set to expire.
- Keys are accepted only in the `X-API-Key` header or `Authorization: Bearer` header. The `?api_key=` option is removed for new keys. Power BI can send headers.
- The existing system key keeps working, so nothing breaks.
- Keys never reach the browser, and responses never include them.

## 5. Implementation plan
1. **Database (new tables only, existing data unchanged)**
   - `api_clients`: name, key fingerprint, scopes, allowed tables, rate limit, active flag, expiry date, last used time.
   - `api_audit_log`: time, client, method, table, filters, status, row count, IP, how long it took. Request bodies and secrets are never stored.
   - `api_rate_counters`: counts requests per minute.
   - All three are locked by row security. Only the server can reach them.
2. **Database access with row security still applied**
   - The feed checks the key itself, then reads and writes using the normal app access level, so the existing security rules still apply. Every business table already allows this access, so nothing gets blocked.
   - If you later tighten a table's security rules, the feed follows them automatically.
3. **API v1** (`/api/public/v1/{table}`, plus `/v1/{table}/{id}`)
   - GET, POST, PUT, PATCH, DELETE on all 22 tables. The current endpoint keeps working too.
   - Request checks:
     - Table names and column names come from an approved list.
     - Filter operators come from an approved list.
     - Limit is at most 5000, body size at most 1 MB, and at most 1000 rows per insert.
     - Update and delete need an id or a filter.
   - Every response has the same shape: `{ data, count, next_offset }`, or `{ error: { code, message } }`.
   - Paging uses `limit` and `offset`. A `/v1/_schema` endpoint lists the tables and their columns.
   - Sensitive columns are never exposed. User session and password data are not part of any business table.
4. **Rate limit:** 120 requests per minute per key by default, changeable per key. Going over returns 429 with a `Retry-After` header.
5. **Admin key management:** two admin-only server actions to create and revoke keys, plus a small "Integration keys" box in Settings. This is the only change to the screens. Say so if you'd rather manage keys some other way.
6. **Documentation:** `/mnt/documents/Full-System-API-Guide.md`, covering endpoints, methods, parameters, response examples, error codes, and step-by-step Power BI setup (Get Data, Web, Advanced, header `X-API-Key`, paging, scheduled refresh). I'll also include a ready-made Power BI paging query.
7. **Tests:**
   - A read-only key can't write.
   - A revoked key gets 401.
   - Going over the rate limit gets 429.
   - An unknown table or column gets 400.
   - Delete without a filter is refused.

## 6. What will not change
Existing screens, sign-in, roles, records and the current endpoints stay as they are. No records are deleted.
