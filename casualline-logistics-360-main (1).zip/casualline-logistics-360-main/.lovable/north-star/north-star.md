<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# මඟ පෙන්වන තරුව

නිෂ්පාදන පේළිවලට අවශ්‍ය අමුද්‍රව්‍ය නියමිත වේලාවට ලැබී සූදානම්ව තිබීම

## මිනුම

සම්පූර්ණයෙන් unload කර Complete ලෙස සලකුණු කළ වාහන, දිනපතා
