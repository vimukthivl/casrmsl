<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Vehicle Update reuses the shared live vehicle store and centralized route access rules; its read-only record card component renders saved vehicle fields without maintaining a second data source or recalculating reservations.
- Green Board Report uses an atomic database upsert to append notes and increment per-cell submission counts; direct note edits preserve counts to avoid lost concurrent reports or inflated totals.
- Segregation forms and board share the existing segregation entries; supplier summaries aggregate saved submissions without rewriting historical records or duplicating storage.
- Bay reservations are calculated by database triggers under a transaction advisory lock, so all writers share one deterministic schedule; timeline rendering only clips saved timestamps and never invents gate-based starts.
- The bay active-slot constraint applies only to Unloading; held vehicles preserve accumulated working time and move behind the current unloader through the same transactional schedule recalculation, never browser-side queue writes.
- Bay board columns must keep stable React identity during drag and selection; the shared vehicle store refreshes complete saved schedules after realtime reconnects and periodically to recover missed updates.
- Pending invoice uniqueness is enforced by a normalized partial database index, with matching client validation for immediate feedback; blank invoice numbers remain compatible with P/O-only records.
- Assistant mutations require per-request server verification of the change-password secret before any tool write; credentials stay outside model messages and are never persisted in browser storage. The assistant cannot edit or deploy application code.
