
-- fabric_plan
CREATE TABLE public.fabric_plan (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_center text,
  production_order text NOT NULL UNIQUE,
  order_description text,
  order_qty numeric,
  so_no text,
  so_li text,
  cut_date date,
  start_date date,
  picker_name text,
  picker_epf text,
  picker_date timestamptz,
  uploaded_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.fabric_plan TO anon, authenticated;
GRANT ALL ON public.fabric_plan TO service_role;
ALTER TABLE public.fabric_plan ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw fabric_plan" ON public.fabric_plan FOR ALL TO public USING (true) WITH CHECK (true);
CREATE TRIGGER fabric_plan_touch BEFORE UPDATE ON public.fabric_plan FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

-- fabric_picker_targets
CREATE TABLE public.fabric_picker_targets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  epf_number text NOT NULL UNIQUE,
  name text NOT NULL,
  gin_target_per_day integer NOT NULL DEFAULT 10,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.fabric_picker_targets TO anon, authenticated;
GRANT ALL ON public.fabric_picker_targets TO service_role;
ALTER TABLE public.fabric_picker_targets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw fabric_picker_targets" ON public.fabric_picker_targets FOR ALL TO public USING (true) WITH CHECK (true);
CREATE TRIGGER fabric_picker_targets_touch BEFORE UPDATE ON public.fabric_picker_targets FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

-- fabric_picker_achievements
CREATE TABLE public.fabric_picker_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  epf_number text NOT NULL,
  picker_name text,
  po_number text NOT NULL,
  plan_id uuid,
  picked_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.fabric_picker_achievements TO anon, authenticated;
GRANT ALL ON public.fabric_picker_achievements TO service_role;
ALTER TABLE public.fabric_picker_achievements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw fabric_picker_achievements" ON public.fabric_picker_achievements FOR ALL TO public USING (true) WITH CHECK (true);
