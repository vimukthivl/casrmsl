CREATE TABLE public.weekly_schedules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor_name text NOT NULL DEFAULT '',
  material_type text NOT NULL DEFAULT 'Fabric',
  relevant_pcu text NOT NULL DEFAULT '',
  vehicle_type text NOT NULL DEFAULT '20 FT',
  uom text NOT NULL DEFAULT '',
  remarks text NOT NULL DEFAULT '',
  days_data jsonb NOT NULL DEFAULT '{"Mon":0,"Tue":0,"Wed":0,"Thu":0,"Fri":0,"Sat":0}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.weekly_schedules TO anon, authenticated;
GRANT ALL ON public.weekly_schedules TO service_role;
ALTER TABLE public.weekly_schedules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw weekly_schedules" ON public.weekly_schedules FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.vehicle_logs (
  token_no text PRIMARY KEY,
  vehicle_number text NOT NULL DEFAULT '',
  vehicle_type text NOT NULL DEFAULT '20 FT',
  driver_name text NOT NULL DEFAULT '',
  driver_phone text NOT NULL DEFAULT '',
  invoice_no text NOT NULL DEFAULT '',
  quantity_brought numeric NOT NULL DEFAULT 0,
  vendor_name text NOT NULL DEFAULT '',
  material_type text NOT NULL DEFAULT 'Fabric',
  relevant_pcu text NOT NULL DEFAULT '',
  arrival_status text NOT NULL DEFAULT 'Unscheduled',
  current_status text NOT NULL DEFAULT 'Waiting',
  hold_reason text,
  hold_notes text,
  in_time timestamptz NOT NULL DEFAULT now(),
  unload_start_time timestamptz,
  unload_end_time timestamptz,
  out_time timestamptz,
  is_held_up boolean NOT NULL DEFAULT false
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_logs TO anon, authenticated;
GRANT ALL ON public.vehicle_logs TO service_role;
ALTER TABLE public.vehicle_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw vehicle_logs" ON public.vehicle_logs FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.weekly_schedules;
ALTER PUBLICATION supabase_realtime ADD TABLE public.vehicle_logs;