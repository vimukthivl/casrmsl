
CREATE TABLE public.cc_monthly_targets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse text NOT NULL CHECK (warehouse IN ('fabric','trims')),
  month text NOT NULL,
  item_code text NOT NULL,
  target_qty numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (warehouse, month, item_code)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cc_monthly_targets TO authenticated, anon;
GRANT ALL ON public.cc_monthly_targets TO service_role;
ALTER TABLE public.cc_monthly_targets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw cc_monthly_targets" ON public.cc_monthly_targets FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER cc_monthly_targets_touch BEFORE UPDATE ON public.cc_monthly_targets FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

CREATE TABLE public.cc_daily_actuals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  warehouse text NOT NULL CHECK (warehouse IN ('fabric','trims')),
  entry_date date NOT NULL,
  item_code text NOT NULL,
  counted_qty numeric NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (warehouse, entry_date, item_code)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cc_daily_actuals TO authenticated, anon;
GRANT ALL ON public.cc_daily_actuals TO service_role;
ALTER TABLE public.cc_daily_actuals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw cc_daily_actuals" ON public.cc_daily_actuals FOR ALL USING (true) WITH CHECK (true);
CREATE TRIGGER cc_daily_actuals_touch BEFORE UPDATE ON public.cc_daily_actuals FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.cc_monthly_targets;
ALTER PUBLICATION supabase_realtime ADD TABLE public.cc_daily_actuals;
