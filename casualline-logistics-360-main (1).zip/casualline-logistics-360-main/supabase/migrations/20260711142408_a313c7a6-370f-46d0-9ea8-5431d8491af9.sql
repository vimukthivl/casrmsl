
CREATE TABLE public.green_board_concerns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.green_board_concerns TO anon, authenticated;
GRANT ALL ON public.green_board_concerns TO service_role;
ALTER TABLE public.green_board_concerns ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw green_board_concerns" ON public.green_board_concerns FOR ALL USING (true) WITH CHECK (true);

CREATE TABLE public.green_board_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  concern_id uuid NOT NULL REFERENCES public.green_board_concerns(id) ON DELETE CASCADE,
  entry_date date NOT NULL,
  note text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (concern_id, entry_date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.green_board_entries TO anon, authenticated;
GRANT ALL ON public.green_board_entries TO service_role;
ALTER TABLE public.green_board_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw green_board_entries" ON public.green_board_entries FOR ALL USING (true) WITH CHECK (true);

INSERT INTO public.green_board_concerns (label, sort_order) VALUES
  ('Vehicle Delays', 10),
  ('Missing Documents', 20),
  ('Quality Issues', 30),
  ('Bay Congestion', 40),
  ('Communication Gap', 50);
