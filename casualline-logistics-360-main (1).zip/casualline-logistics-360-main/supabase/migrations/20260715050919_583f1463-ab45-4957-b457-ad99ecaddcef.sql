CREATE TABLE public.fabric_downtime (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  entry_date DATE NOT NULL,
  concern TEXT NOT NULL,
  lost_hours NUMERIC NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.fabric_downtime TO anon, authenticated;
GRANT ALL ON public.fabric_downtime TO service_role;

ALTER TABLE public.fabric_downtime ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public rw fabric_downtime" ON public.fabric_downtime
  FOR ALL TO public USING (true) WITH CHECK (true);

CREATE TRIGGER fabric_downtime_touch_updated_at
  BEFORE UPDATE ON public.fabric_downtime
  FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

ALTER PUBLICATION supabase_realtime ADD TABLE public.fabric_downtime;