
ALTER TABLE public.weekly_schedules
  ADD COLUMN IF NOT EXISTS claimed_date DATE,
  ADD COLUMN IF NOT EXISTS claimed_token TEXT;

ALTER TABLE public.vehicle_logs
  ADD COLUMN IF NOT EXISTS completed_by TEXT,
  ADD COLUMN IF NOT EXISTS schedule_id UUID;

CREATE TABLE IF NOT EXISTS public.admin_settings (
  id TEXT PRIMARY KEY DEFAULT 'singleton',
  held_up_cost_rate NUMERIC NOT NULL DEFAULT 500,
  daily_roll_target NUMERIC NOT NULL DEFAULT 1000,
  daily_box_target NUMERIC NOT NULL DEFAULT 500,
  shift_start TEXT NOT NULL DEFAULT '06:00',
  shift_end TEXT NOT NULL DEFAULT '22:00',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.admin_settings TO anon, authenticated;
GRANT ALL ON public.admin_settings TO service_role;

ALTER TABLE public.admin_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public rw admin_settings" ON public.admin_settings;
CREATE POLICY "public rw admin_settings" ON public.admin_settings
  FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

INSERT INTO public.admin_settings (id) VALUES ('singleton')
  ON CONFLICT (id) DO NOTHING;

ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_settings;
