DROP POLICY IF EXISTS "Authenticated can read invoice_daily_log" ON public.invoice_daily_log;
DROP POLICY IF EXISTS "Authenticated can write invoice_daily_log" ON public.invoice_daily_log;
DROP POLICY IF EXISTS "Authenticated can update invoice_daily_log" ON public.invoice_daily_log;
DROP POLICY IF EXISTS "Authenticated can delete invoice_daily_log" ON public.invoice_daily_log;
CREATE POLICY "public rw invoice_daily_log" ON public.invoice_daily_log FOR ALL TO public USING (true) WITH CHECK (true);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.invoice_daily_log TO anon, authenticated;