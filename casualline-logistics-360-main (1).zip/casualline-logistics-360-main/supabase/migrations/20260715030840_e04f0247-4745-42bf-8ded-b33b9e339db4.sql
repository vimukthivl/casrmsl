CREATE TABLE public.invoice_daily_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  log_date DATE NOT NULL UNIQUE,
  fabric_received INTEGER NOT NULL DEFAULT 0,
  fabric_completed INTEGER NOT NULL DEFAULT 0,
  trims_received INTEGER NOT NULL DEFAULT 0,
  trims_completed INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.invoice_daily_log TO authenticated;
GRANT ALL ON public.invoice_daily_log TO service_role;

ALTER TABLE public.invoice_daily_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can read invoice_daily_log"
  ON public.invoice_daily_log FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated can write invoice_daily_log"
  ON public.invoice_daily_log FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated can update invoice_daily_log"
  ON public.invoice_daily_log FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "Authenticated can delete invoice_daily_log"
  ON public.invoice_daily_log FOR DELETE TO authenticated USING (true);

CREATE TRIGGER trg_invoice_daily_log_updated
  BEFORE UPDATE ON public.invoice_daily_log
  FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();