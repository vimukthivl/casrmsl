
-- Held-up rates per vehicle size
CREATE TABLE public.held_up_rates (
  vehicle_size text PRIMARY KEY,
  rate_per_hour numeric NOT NULL DEFAULT 500,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.held_up_rates TO anon, authenticated;
GRANT ALL ON public.held_up_rates TO service_role;
ALTER TABLE public.held_up_rates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw held_up_rates" ON public.held_up_rates FOR ALL USING (true) WITH CHECK (true);

INSERT INTO public.held_up_rates (vehicle_size, rate_per_hour) VALUES
  ('40 Ft', 1200),
  ('20 Ft', 800),
  ('16.5 Ft', 700),
  ('14.5 Ft', 600),
  ('12.5 Ft', 550),
  ('10.5 Ft', 500),
  ('10 Ft', 450)
ON CONFLICT (vehicle_size) DO NOTHING;

-- GRN pending reasons (CRUD by admin)
CREATE TABLE public.grn_pending_reasons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.grn_pending_reasons TO anon, authenticated;
GRANT ALL ON public.grn_pending_reasons TO service_role;
ALTER TABLE public.grn_pending_reasons ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw grn_pending_reasons" ON public.grn_pending_reasons FOR ALL USING (true) WITH CHECK (true);

INSERT INTO public.grn_pending_reasons (label, sort_order) VALUES
  ('Portal Pending', 1),
  ('Labor Shortage', 2),
  ('Quality Check Delay', 3),
  ('Documentation Issue', 4),
  ('Other', 99);

-- Migrate legacy vehicle_type values to new "Ft" casing
UPDATE public.vehicle_logs SET vehicle_type = '10 Ft' WHERE vehicle_type = '10 FT';
UPDATE public.vehicle_logs SET vehicle_type = '20 Ft' WHERE vehicle_type = '20 FT';
UPDATE public.vehicle_logs SET vehicle_type = '40 Ft' WHERE vehicle_type = '40 FT';
UPDATE public.weekly_schedules SET vehicle_type = '10 Ft' WHERE vehicle_type = '10 FT';
UPDATE public.weekly_schedules SET vehicle_type = '20 Ft' WHERE vehicle_type = '20 FT';
UPDATE public.weekly_schedules SET vehicle_type = '40 Ft' WHERE vehicle_type = '40 FT';

-- Enable realtime for new tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.held_up_rates;
ALTER PUBLICATION supabase_realtime ADD TABLE public.grn_pending_reasons;
