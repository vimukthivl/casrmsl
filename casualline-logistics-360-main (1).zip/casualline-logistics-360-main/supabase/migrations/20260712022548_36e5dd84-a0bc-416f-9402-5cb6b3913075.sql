
-- ================= TRIMS PLAN =================
CREATE TABLE public.trims_plan (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  work_center TEXT,
  production_order TEXT NOT NULL UNIQUE,
  order_description TEXT,
  order_qty NUMERIC,
  so_no TEXT,
  so_li TEXT,
  cut_date DATE,
  start_date DATE,
  picker_name TEXT,
  picker_epf TEXT,
  picker_date TIMESTAMPTZ,
  uploaded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.trims_plan TO anon, authenticated;
GRANT ALL ON public.trims_plan TO service_role;

ALTER TABLE public.trims_plan ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw trims_plan" ON public.trims_plan FOR ALL USING (true) WITH CHECK (true);

CREATE INDEX trims_plan_po_idx ON public.trims_plan (production_order);
CREATE INDEX trims_plan_picker_date_idx ON public.trims_plan (picker_epf, picker_date);

-- ================= PICKER TARGETS =================
CREATE TABLE public.picker_targets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  epf_number TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  gin_target_per_day INTEGER NOT NULL DEFAULT 10,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.picker_targets TO anon, authenticated;
GRANT ALL ON public.picker_targets TO service_role;

ALTER TABLE public.picker_targets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw picker_targets" ON public.picker_targets FOR ALL USING (true) WITH CHECK (true);

-- ================= PICKER ACHIEVEMENTS (audit log) =================
CREATE TABLE public.picker_achievements (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  epf_number TEXT NOT NULL,
  picker_name TEXT,
  po_number TEXT NOT NULL,
  plan_id UUID REFERENCES public.trims_plan(id) ON DELETE SET NULL,
  picked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.picker_achievements TO anon, authenticated;
GRANT ALL ON public.picker_achievements TO service_role;

ALTER TABLE public.picker_achievements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw picker_achievements" ON public.picker_achievements FOR ALL USING (true) WITH CHECK (true);

CREATE INDEX picker_achievements_epf_date_idx ON public.picker_achievements (epf_number, picked_at);

-- ================= Trigger to bump updated_at =================
CREATE OR REPLACE FUNCTION public.tp_touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER trims_plan_touch BEFORE UPDATE ON public.trims_plan
FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

CREATE TRIGGER picker_targets_touch BEFORE UPDATE ON public.picker_targets
FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

-- Seed a couple of pickers from the user's example
INSERT INTO public.picker_targets (epf_number, name, gin_target_per_day)
VALUES ('SEW001', 'Sewwandi', 10), ('KAS001', 'Kasun', 16)
ON CONFLICT (epf_number) DO NOTHING;
