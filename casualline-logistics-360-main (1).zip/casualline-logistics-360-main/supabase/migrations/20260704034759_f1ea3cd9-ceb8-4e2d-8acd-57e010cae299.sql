ALTER TABLE public.vehicle_logs
  ADD COLUMN IF NOT EXISTS bay_id text,
  ADD COLUMN IF NOT EXISTS queue_position integer,
  ADD COLUMN IF NOT EXISTS roll_qty numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS box_qty numeric NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_vehicle_logs_bay_queue
  ON public.vehicle_logs (bay_id, queue_position);