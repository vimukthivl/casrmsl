CREATE TABLE public.trims_downtime (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  entry_date DATE NOT NULL DEFAULT CURRENT_DATE,
  concern TEXT NOT NULL,
  lost_hours NUMERIC(6,2) NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.trims_downtime TO authenticated;
GRANT ALL ON public.trims_downtime TO service_role;
ALTER TABLE public.trims_downtime ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated can manage trims downtime" ON public.trims_downtime FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER trims_downtime_touch_updated_at BEFORE UPDATE ON public.trims_downtime FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();
ALTER PUBLICATION supabase_realtime ADD TABLE public.trims_downtime;