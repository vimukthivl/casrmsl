ALTER TABLE public.green_board_concerns ADD COLUMN IF NOT EXISTS board_key TEXT NOT NULL DEFAULT 'grn';
ALTER TABLE public.green_board_entries ADD COLUMN IF NOT EXISTS board_key TEXT NOT NULL DEFAULT 'grn';
CREATE INDEX IF NOT EXISTS idx_gbc_board ON public.green_board_concerns(board_key);
CREATE INDEX IF NOT EXISTS idx_gbe_board_date ON public.green_board_entries(board_key, entry_date);