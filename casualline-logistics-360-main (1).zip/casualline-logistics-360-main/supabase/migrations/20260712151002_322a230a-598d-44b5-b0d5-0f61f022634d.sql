
CREATE TABLE public.cycle_count_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  category TEXT NOT NULL,
  material_code TEXT NOT NULL,
  material_description TEXT NOT NULL DEFAULT '',
  grand_qty NUMERIC(14,2) NOT NULL DEFAULT 0,
  available_qty NUMERIC(14,2) NOT NULL DEFAULT 0,
  upload_date TIMESTAMPTZ NOT NULL DEFAULT now(),
  count_by TEXT NOT NULL,
  batch_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_cycle_count_logs_upload_date ON public.cycle_count_logs(upload_date DESC);
CREATE INDEX idx_cycle_count_logs_material_code ON public.cycle_count_logs(material_code);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.cycle_count_logs TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.cycle_count_logs TO authenticated;
GRANT ALL ON public.cycle_count_logs TO service_role;

ALTER TABLE public.cycle_count_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Cycle count logs are readable and writable by all"
  ON public.cycle_count_logs
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE TRIGGER trg_cycle_count_logs_updated_at
  BEFORE UPDATE ON public.cycle_count_logs
  FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();
