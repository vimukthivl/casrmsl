ALTER TABLE public.vehicle_logs
  ADD COLUMN IF NOT EXISTS manually_unloaded_qty numeric NULL;