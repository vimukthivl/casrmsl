DROP POLICY IF EXISTS "Authenticated can manage trims downtime" ON public.trims_downtime;
CREATE POLICY "public rw trims_downtime" ON public.trims_downtime FOR ALL TO public USING (true) WITH CHECK (true);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.trims_downtime TO anon, authenticated;