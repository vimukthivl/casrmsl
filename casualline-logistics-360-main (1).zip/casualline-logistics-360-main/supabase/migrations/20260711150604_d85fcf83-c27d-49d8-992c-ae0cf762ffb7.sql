
ALTER TABLE public.weekly_schedules
  ADD COLUMN IF NOT EXISTS week_start DATE NOT NULL DEFAULT (date_trunc('week', now())::date);

CREATE INDEX IF NOT EXISTS weekly_schedules_week_start_idx ON public.weekly_schedules(week_start);

-- Ensure existing rows without an explicit week are tagged to the current ISO week (Monday)
UPDATE public.weekly_schedules
SET week_start = date_trunc('week', now())::date
WHERE week_start IS NULL;
