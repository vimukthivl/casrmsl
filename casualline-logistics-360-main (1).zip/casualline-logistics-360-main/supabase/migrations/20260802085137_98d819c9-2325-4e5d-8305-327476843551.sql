CREATE TABLE public.unload_entries (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token_no text NOT NULL,
  vehicle_number text NOT NULL DEFAULT '',
  material_type text NOT NULL DEFAULT 'Fabric',
  unit text NOT NULL DEFAULT 'Rolls',
  qty numeric NOT NULL DEFAULT 0,
  shift text NOT NULL DEFAULT 'A',
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  entered_by text,
  source text NOT NULL DEFAULT 'manual',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);
CREATE INDEX unload_entries_token_idx ON public.unload_entries (token_no);
CREATE INDEX unload_entries_date_idx ON public.unload_entries (entry_date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.unload_entries TO anon, authenticated;
GRANT ALL ON public.unload_entries TO service_role;
ALTER TABLE public.unload_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw unload_entries" ON public.unload_entries FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.unload_entries;