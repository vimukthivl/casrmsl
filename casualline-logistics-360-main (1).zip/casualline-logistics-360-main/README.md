# Casualline Flow

Build a complete Enterprise Warehouse Logistics and Yard Management System called "Casualline Logistics 360" for the RMWH Casualline Division. The system must include Role-Based Access Control (RBAC), automatic scheduling comparison against a weekly delivery plan, live FIFO queue tracking, automatic 24-hour held-up detection, and detailed real-time dashboards.

Use Tailwind CSS for a modern, clean, UI/UX dashboard design with distinct interactive status indicators.

=========================================

1. AUTHENTICATION & ROLE-BASED ACCESS (RBAC)

=========================================

Implement a secure login screen with 4 distinct user roles. Each role redirects to its specific workflow dashboard with strict permissions:

- Admin: Full access to all screens, dashboards, configuration, and ability to manually override statuses.

- PCU (Production Control Unit): Can upload/edit the Weekly Schedule and view the Main Dashboard.

- Guard Room: Access only to Gate Operations (Vehicle In/Out Entry Form and active yard list).

- RM GRN Team: Access only to the Vehicle Status Manager (FIFO Queue, Unloading Actions, and Hold Reasons).

=========================================

2. DATABASE SCHEMA & STRUCTURE

=========================================

Create the following database tables (or mock state if purely frontend) to handle the core logistics flow:

A. weekly_schedules:

   - id, vendor_name, material_type (Fabric, Trims, Packaging), relevant_pcu (PCU-1, PCU-2, PCU-3), vehicle_type (10 FT, 20 FT, 40 FT), uom, remarks, days_data (JSON storing planned quantities for Monday to Saturday).

B. vehicle_logs:

   - token_no (Auto-generated unique ID, format: TKN-YYYY-XXXX for FIFO ranking)

   - vehicle_number (Primary search key, e.g., WP LK-5566)

   - vehicle_type, driver_name, driver_phone, invoice_no, quantity_brought

   - vendor_name, material_type, relevant_pcu

   - arrival_status (Auto-calculated: 'On-Time', 'Early', 'Delayed', 'Unscheduled')

   - current_status ('Waiting', 'Unloading', 'Hold', 'Completed', 'Departed')

   - hold_reason ('Portal Pending' or 'Other')

   - hold_notes (Custom text input for manual 'Other' reasons)

   - in_time (Timestamp when Guard checks vehicle IN)

   - unload_start_time, unload_end_time, out_time (Timestamps)

   - is_held_up (Boolean - true if in_time older than 24 hours and current_status is not Completed/Departed)

=========================================

3. WORKFLOW LOGIC & AUTOMATIONS

=========================================

- Schedule Matching (Guard Room In): When a vehicle is checked IN on the current day, the system checks the 'weekly_schedules' for that Vendor and Material Type:

  * If scheduled for Today -> arrival_status = 'On-Time'

  * If scheduled for a future day this week -> arrival_status = 'Early'

  * If scheduled for a past day this week -> arrival_status = 'Delayed'

  * If not anywhere in the weekly plan -> arrival_status = 'Unscheduled'

- FIFO Queue: The RM GRN Team dashboard must sort active vehicles strictly by `in_time` (First In, First Out) for vehicles with 'Waiting' or 'Unloading' status.

- 24-Hour Held-Up Timer: A background interval checks if an active vehicle's `in_time` exceeds 24 hours. If it does, automatically flip `is_held_up` to TRUE and trigger a critical red alert banner on the main dashboard.

=========================================

4. USER INTERFACE & SCREENS BY ROLE

=========================================

A. PCU SCREEN:

   - A file upload interface to parse/import the "weekly-delivery-plan-mock-filled.xlsx" format containing columns: Material Type, Relevant PCU, Vehicle Type (FT), Vendor, UOM, Remarks, and Mon-Sat quantity columns.

   - A data table grid to review and manually tweak planned numbers.

B. GUARD ROOM SCREEN:

   - "Vehicle IN" Form: Dropdowns for Vendor Name, Material Type, Relevant PCU (populated from schedule) + Text fields for Vehicle Number, Vehicle Type, Driver Info, Invoice No, and Quantity Brought. Clicking "Submit" generates a Token, logs `in_time`, calculates arrival_status, and pushes it to the FIFO queue.

   - "Vehicle OUT" List: Displays only vehicles marked as 'Completed' by the RM Team. Guard clicks "Confirm Departure" to log `out_time` and set status to 'Departed'.

C. RM GRN TEAM SCREEN (Vehicle Status Manager):

   - Displays the Live FIFO Queue. Selecting a vehicle reveals an action panel with 3 primary buttons:

     1. [Start Unloading] -> Sets status to 'Unloading' and logs `unload_start_time`.

     2. [Hold / Pending] -> Sets status to 'Hold'. Opens a modal requiring a Reason dropdown: Choice of "Portal Pending" or "Other". Selecting "Other" displays a text input box for manual notes. Includes a [Resume Unloading] button to flip it back to 'Unloading'.

     3. [Complete] -> Sets status to 'Completed', logs `unload_end_time`, and triggers an alert notification to the Guard Room for vehicle release.

D. MAIN MASTER DASHBOARD (Home Screen - Visible to Admin, PCU, and Management):

   - Top Summary Cards: Displays real-time metrics for: Today's Total Scheduled, Total Vehicles Checked IN Today, Total Completed/Departed Today, and Active Held-Up Vehicles (>24 Hours).

   - Arrival Status Widget: Visual breakdown (charts or colored badges) of On-Time vs Early vs Delayed vs Unscheduled arrivals.

   - Live Yard FIFO Grid: Real-time table tracking what is currently Waiting or Unloading.

   - GRN Pending & Bottlenecks Widget: Dedicated section displaying vehicles on 'Hold'. Explicitly grouping and showing "Portal Pending" cases and displaying the custom "Other" manual reasons text, along with the Vendor Name and responsible PCU Department.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://casualline-logistics-360.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/d95caec0-23c4-449e-949a-b27eb8a0c25d).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
