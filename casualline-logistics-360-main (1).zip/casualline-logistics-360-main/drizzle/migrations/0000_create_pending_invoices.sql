CREATE TABLE public.pending_invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  received_date date NOT NULL DEFAULT CURRENT_DATE,
  supplier text NOT NULL DEFAULT '',
  po_number text NOT NULL DEFAULT '',
  invoice_no text NOT NULL DEFAULT '',
  reason text NOT NULL DEFAULT '',
  pcu_member text NOT NULL DEFAULT '',
  merchant text NOT NULL DEFAULT '',
  pcu_comment text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'Pending',
  completed_at timestamptz,
  completed_by text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.pending_invoices TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.pending_invoices TO authenticated;
GRANT ALL ON public.pending_invoices TO service_role;

ALTER TABLE public.pending_invoices ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public rw pending_invoices" ON public.pending_invoices
  FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TRIGGER pending_invoices_touch BEFORE UPDATE ON public.pending_invoices
  FOR EACH ROW EXECUTE FUNCTION public.tp_touch_updated_at();

CREATE INDEX pending_invoices_received_date_idx ON public.pending_invoices (received_date);