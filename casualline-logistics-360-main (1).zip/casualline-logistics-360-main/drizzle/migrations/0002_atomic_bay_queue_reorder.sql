CREATE OR REPLACE FUNCTION public.reorder_bay_queue(p_tokens text[])
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE bay text; old_flag text;
BEGIN
 PERFORM pg_advisory_xact_lock(360,1);
 SELECT bay_id INTO bay FROM public.vehicle_logs WHERE token_no=p_tokens[1];
 IF bay IS NULL OR EXISTS(SELECT 1 FROM public.vehicle_logs WHERE token_no=ANY(p_tokens) AND (bay_id IS DISTINCT FROM bay OR current_status IN ('Completed','Departed'))) OR (SELECT COUNT(*) FROM public.vehicle_logs WHERE token_no=ANY(p_tokens))<>cardinality(p_tokens) THEN RAISE EXCEPTION 'Invalid bay queue'; END IF;
 old_flag:=current_setting('app.bay_recalculating',true);
 PERFORM set_config('app.bay_recalculating','on',true);
 UPDATE public.vehicle_logs v SET queue_position=q.ordinality-1 FROM unnest(p_tokens) WITH ORDINALITY q(token,ordinality) WHERE v.token_no=q.token;
 PERFORM set_config('app.bay_recalculating',COALESCE(old_flag,'off'),true);
 PERFORM public.recalculate_bay_schedules();
END $$;
REVOKE ALL ON FUNCTION public.reorder_bay_queue(text[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.reorder_bay_queue(text[]) TO anon,authenticated,service_role;