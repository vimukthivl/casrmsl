ALTER TABLE public.vehicle_logs ADD COLUMN IF NOT EXISTS bay_assigned_at timestamptz;
ALTER TABLE public.vehicle_logs ADD COLUMN IF NOT EXISTS requested_start_time timestamptz;
ALTER TABLE public.vehicle_logs ADD COLUMN IF NOT EXISTS scheduled_start_time timestamptz;
ALTER TABLE public.vehicle_logs ADD COLUMN IF NOT EXISTS scheduled_end_time timestamptz;
COMMENT ON COLUMN public.vehicle_logs.in_time IS 'Actual gate arrival; never used as a bay scheduling anchor.';
COMMENT ON COLUMN public.vehicle_logs.bay_assigned_at IS 'Actual latest bay assignment. Legacy queued rows without an assignment record use migration time, not an invented past assignment.';
COMMENT ON COLUMN public.vehicle_logs.requested_start_time IS 'Optional explicit requested reservation start, separate from calculated schedule and actual unloading.';
COMMENT ON COLUMN public.vehicle_logs.scheduled_start_time IS 'Calculated planned bay reservation start.';
COMMENT ON COLUMN public.vehicle_logs.scheduled_end_time IS 'Calculated planned bay reservation end.';
UPDATE public.vehicle_logs SET bay_assigned_at = COALESCE(unload_start_time, now()), scheduled_start_time = unload_start_time, scheduled_end_time = unload_end_time WHERE bay_id IS NOT NULL;
CREATE OR REPLACE FUNCTION public.bay_work_start(p_at timestamptz, p_start time, p_end time)
RETURNS timestamptz LANGUAGE plpgsql STABLE SET search_path = public AS $$
DECLARE local_at timestamp := p_at AT TIME ZONE 'Asia/Colombo';
BEGIN
  IF local_at::time >= p_end THEN local_at := (local_at::date + 1) + p_start;
  ELSIF local_at::time < p_start THEN local_at := local_at::date + p_start; END IF;
  IF EXTRACT(dow FROM local_at) = 0 THEN local_at := (local_at::date + 1) + p_start; END IF;
  RETURN local_at AT TIME ZONE 'Asia/Colombo';
END $$;
CREATE OR REPLACE FUNCTION public.bay_work_end(p_at timestamptz, p_minutes numeric, p_start time, p_end time)
RETURNS timestamptz LANGUAGE plpgsql STABLE SET search_path = public AS $$
DECLARE cursor_at timestamptz := p_at; remaining numeric := p_minutes; available numeric; shift_end_at timestamptz;
BEGIN
  WHILE remaining > 0 LOOP
    cursor_at := public.bay_work_start(cursor_at, p_start, p_end);
    shift_end_at := (((cursor_at AT TIME ZONE 'Asia/Colombo')::date + p_end) AT TIME ZONE 'Asia/Colombo');
    available := EXTRACT(epoch FROM shift_end_at - cursor_at) / 60;
    IF remaining <= available THEN RETURN cursor_at + remaining * interval '1 minute'; END IF;
    remaining := remaining - available;
    cursor_at := public.bay_work_start(shift_end_at, p_start, p_end);
  END LOOP;
  RETURN cursor_at;
END $$;
CREATE OR REPLACE FUNCTION public.recalculate_bay_schedules()
RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path = public AS $$
DECLARE cfg public.admin_settings%ROWTYPE; v public.vehicle_logs%ROWTYPE; bay text; previous_end timestamptz; start_at timestamptz; end_at timestamptz; conflict_end timestamptz; minutes numeric; rate numeric; pos integer; has_active boolean; previous_flag text;
BEGIN
  PERFORM pg_advisory_xact_lock(360, 1);
  previous_flag := current_setting('app.bay_recalculating',true);
  PERFORM set_config('app.bay_recalculating','on',true);
  SELECT * INTO cfg FROM public.admin_settings WHERE id = 'singleton';
  IF NOT FOUND OR cfg.shift_end::time <= cfg.shift_start::time THEN RAISE EXCEPTION 'Invalid working shift settings'; END IF;
  rate := GREATEST(1, (cfg.daily_roll_target + cfg.daily_box_target) / (EXTRACT(epoch FROM cfg.shift_end::time - cfg.shift_start::time) / 3600));
  FOREACH bay IN ARRAY ARRAY['BAY-01','BAY-02','BAY-03'] LOOP
    previous_end := NULL; pos := 0;
    SELECT EXISTS(SELECT 1 FROM public.vehicle_logs WHERE bay_id=bay AND current_status IN ('Unloading','Hold')) INTO has_active;
    FOR v IN SELECT * FROM public.vehicle_logs WHERE bay_id=bay AND current_status NOT IN ('Completed','Departed')
      ORDER BY CASE WHEN current_status IN ('Unloading','Hold') THEN 0 ELSE 1 END,
      (COALESCE(requested_start_time,bay_assigned_at) AT TIME ZONE 'Asia/Colombo')::date,
      queue_position NULLS LAST, COALESCE(requested_start_time,bay_assigned_at), token_no
    LOOP
      start_at := GREATEST(COALESCE(v.requested_start_time,v.bay_assigned_at), v.bay_assigned_at);
      IF v.current_status IN ('Unloading','Hold') AND v.unload_start_time IS NOT NULL THEN start_at := v.unload_start_time; END IF;
      start_at := GREATEST(start_at,previous_end);
      IF start_at IS NULL THEN RAISE EXCEPTION 'Missing bay assignment timestamp for %',v.token_no; END IF;
      start_at := public.bay_work_start(start_at,cfg.shift_start::time,cfg.shift_end::time);
      minutes := CASE WHEN COALESCE(v.roll_qty,0)+COALESCE(v.box_qty,0)<=0 THEN 30 ELSE GREATEST(15,ROUND((COALESCE(v.roll_qty,0)+COALESCE(v.box_qty,0))/rate*60)) END;
      end_at := public.bay_work_end(start_at,minutes,cfg.shift_start::time,cfg.shift_end::time);
      LOOP
        SELECT MAX(COALESCE(unload_end_time,scheduled_end_time)) INTO conflict_end FROM public.vehicle_logs
          WHERE bay_id=bay AND token_no<>v.token_no AND current_status IN ('Completed','Departed')
          AND COALESCE(unload_start_time,scheduled_start_time)<end_at AND COALESCE(unload_end_time,scheduled_end_time)>start_at;
        EXIT WHEN conflict_end IS NULL;
        start_at := public.bay_work_start(conflict_end,cfg.shift_start::time,cfg.shift_end::time);
        end_at := public.bay_work_end(start_at,minutes,cfg.shift_start::time,cfg.shift_end::time);
      END LOOP;
      UPDATE public.vehicle_logs SET scheduled_start_time=start_at,scheduled_end_time=end_at,queue_position=pos,
        current_status=CASE WHEN current_status IN ('Waiting','Assigned') THEN CASE WHEN pos=0 AND NOT has_active THEN 'Assigned' ELSE 'Waiting' END ELSE current_status END
        WHERE token_no=v.token_no AND (scheduled_start_time IS DISTINCT FROM start_at OR scheduled_end_time IS DISTINCT FROM end_at OR queue_position IS DISTINCT FROM pos OR (current_status IN ('Waiting','Assigned') AND current_status IS DISTINCT FROM CASE WHEN pos=0 AND NOT has_active THEN 'Assigned' ELSE 'Waiting' END));
      previous_end := end_at; pos := pos+1;
    END LOOP;
  END LOOP;
  PERFORM set_config('app.bay_recalculating',COALESCE(previous_flag,'off'),true);
END $$;
CREATE OR REPLACE FUNCTION public.lock_bay_schedule_write()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  PERFORM pg_advisory_xact_lock(360,1);
  RETURN NULL;
END $$;
CREATE OR REPLACE FUNCTION public.prepare_bay_vehicle()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE is_assignment boolean;
BEGIN
  IF pg_trigger_depth()>1 OR current_setting('app.bay_recalculating',true)='on' THEN RETURN NEW; END IF;
  is_assignment := NEW.bay_id IS NOT NULL AND (TG_OP='INSERT' OR NEW.bay_id IS DISTINCT FROM OLD.bay_id);
  IF is_assignment THEN
    NEW.bay_assigned_at := clock_timestamp();
    SELECT COALESCE(MAX(queue_position),-1)+1 INTO NEW.queue_position FROM public.vehicle_logs WHERE bay_id=NEW.bay_id AND current_status NOT IN ('Completed','Departed') AND token_no<>NEW.token_no;
    IF NEW.current_status NOT IN ('Unloading','Hold','Completed','Departed') THEN NEW.current_status := 'Waiting'; END IF;
  ELSIF NEW.bay_id IS NULL THEN
    NEW.bay_assigned_at := NULL; NEW.scheduled_start_time := NULL; NEW.scheduled_end_time := NULL;
  END IF;
  IF TG_OP='UPDATE' AND NEW.scheduled_start_time IS DISTINCT FROM OLD.scheduled_start_time THEN
    NEW.requested_start_time := NEW.scheduled_start_time;
  END IF;
  IF NEW.current_status='Unloading' AND (TG_OP='INSERT' OR OLD.current_status IS DISTINCT FROM 'Unloading') THEN
    IF NEW.bay_id IS NULL THEN RAISE EXCEPTION 'Assign the vehicle to a bay before starting unloading'; END IF;
    IF EXISTS(SELECT 1 FROM public.vehicle_logs WHERE bay_id=NEW.bay_id AND token_no<>NEW.token_no AND current_status IN ('Unloading','Hold')) THEN
      RAISE EXCEPTION 'This bay is occupied. Complete or move the current vehicle before starting another.';
    END IF;
    IF EXISTS(SELECT 1 FROM public.vehicle_logs WHERE bay_id=NEW.bay_id AND token_no<>NEW.token_no AND current_status NOT IN ('Completed','Departed') AND queue_position<NEW.queue_position) THEN
      RAISE EXCEPTION 'Start the first vehicle in the bay queue before this vehicle.';
    END IF;
    IF OLD.current_status IS DISTINCT FROM 'Hold' THEN NEW.unload_start_time := clock_timestamp(); END IF;
  END IF;
  IF TG_OP='UPDATE' AND NEW.current_status IN ('Completed','Departed') AND OLD.current_status NOT IN ('Completed','Departed') THEN
    NEW.scheduled_end_time := COALESCE(NEW.unload_end_time,NEW.scheduled_end_time);
  END IF;
  RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.refresh_bay_schedule_write()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF pg_trigger_depth()>1 OR current_setting('app.bay_recalculating',true)='on' THEN RETURN NULL; END IF;
  PERFORM public.recalculate_bay_schedules();
  RETURN NULL;
END $$;
REVOKE ALL ON FUNCTION public.recalculate_bay_schedules() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.recalculate_bay_schedules() TO anon,authenticated,service_role;
CREATE TRIGGER bay_schedule_write_lock BEFORE INSERT OR UPDATE OR DELETE ON public.vehicle_logs FOR EACH STATEMENT EXECUTE FUNCTION public.lock_bay_schedule_write();
CREATE TRIGGER bay_schedule_prepare BEFORE INSERT OR UPDATE ON public.vehicle_logs FOR EACH ROW EXECUTE FUNCTION public.prepare_bay_vehicle();
CREATE TRIGGER bay_schedule_refresh AFTER INSERT OR UPDATE OR DELETE ON public.vehicle_logs FOR EACH STATEMENT EXECUTE FUNCTION public.refresh_bay_schedule_write();
CREATE TRIGGER bay_settings_write_lock BEFORE UPDATE ON public.admin_settings FOR EACH STATEMENT EXECUTE FUNCTION public.lock_bay_schedule_write();
CREATE TRIGGER bay_settings_refresh AFTER UPDATE ON public.admin_settings FOR EACH STATEMENT EXECUTE FUNCTION public.refresh_bay_schedule_write();
SELECT public.recalculate_bay_schedules();