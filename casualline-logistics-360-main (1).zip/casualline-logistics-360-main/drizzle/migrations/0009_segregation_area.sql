CREATE TABLE public.segregation_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL CHECK (kind IN ('supplier','packaging','supplier_concern','packaging_concern')),
  label text NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX segregation_options_kind_label ON public.segregation_options (kind, lower(btrim(label)));
GRANT SELECT, INSERT, UPDATE, DELETE ON public.segregation_options TO anon, authenticated;
GRANT ALL ON public.segregation_options TO service_role;
ALTER TABLE public.segregation_options ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw segregation_options" ON public.segregation_options FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.segregation_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entry_date date NOT NULL DEFAULT CURRENT_DATE,
  supplier text NOT NULL DEFAULT '',
  supplier_concern text NOT NULL DEFAULT '',
  packaging text NOT NULL DEFAULT '',
  packaging_concern text NOT NULL DEFAULT '',
  note text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX segregation_entries_date ON public.segregation_entries (entry_date);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.segregation_entries TO anon, authenticated;
GRANT ALL ON public.segregation_entries TO service_role;
ALTER TABLE public.segregation_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public rw segregation_entries" ON public.segregation_entries FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);