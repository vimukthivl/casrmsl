CREATE TABLE public.api_clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  key_hash text NOT NULL UNIQUE,
  key_prefix text NOT NULL,
  scopes text[] NOT NULL DEFAULT ARRAY['read']::text[],
  allowed_tables text[],
  rate_limit_per_minute integer NOT NULL DEFAULT 120,
  is_active boolean NOT NULL DEFAULT true,
  expires_at timestamptz,
  last_used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz
);
GRANT ALL ON public.api_clients TO service_role;
ALTER TABLE public.api_clients ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.api_audit_log (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT now(),
  client_id uuid,
  client_name text,
  method text NOT NULL,
  resource text,
  query text,
  status integer NOT NULL,
  row_count integer,
  ip text,
  duration_ms integer
);
CREATE INDEX api_audit_log_created_idx ON public.api_audit_log (created_at DESC);
GRANT ALL ON public.api_audit_log TO service_role;
ALTER TABLE public.api_audit_log ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.api_rate_counters (
  client_key text NOT NULL,
  window_start timestamptz NOT NULL,
  count integer NOT NULL DEFAULT 0,
  PRIMARY KEY (client_key, window_start)
);
GRANT ALL ON public.api_rate_counters TO service_role;
ALTER TABLE public.api_rate_counters ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.api_rate_hit(p_client_key text)
RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE w timestamptz := date_trunc('minute', now()); c integer;
BEGIN
  INSERT INTO api_rate_counters(client_key, window_start, count) VALUES (p_client_key, w, 1)
  ON CONFLICT (client_key, window_start) DO UPDATE SET count = api_rate_counters.count + 1
  RETURNING count INTO c;
  DELETE FROM api_rate_counters WHERE window_start < now() - interval '10 minutes';
  RETURN c;
END $$;
REVOKE ALL ON FUNCTION public.api_rate_hit(text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.api_rate_hit(text) TO service_role;