ALTER TABLE public.vehicle_logs ADD COLUMN hold_started_at timestamptz;
CREATE OR REPLACE FUNCTION public.prepare_bay_vehicle() RETURNS trigger LANGUAGE plpgsql SET search_path=public AS $$
DECLARE is_assignment boolean; cfg public.admin_settings%ROWTYPE; paused numeric:=0; marker text;
BEGIN
 IF pg_trigger_depth()>1 OR current_setting('app.bay_recalculating',true)='on' THEN RETURN NEW; END IF;
 is_assignment:=NEW.bay_id IS NOT NULL AND (TG_OP='INSERT' OR NEW.bay_id IS DISTINCT FROM OLD.bay_id);
 IF is_assignment THEN
  NEW.bay_assigned_at:=clock_timestamp();
  SELECT COALESCE(MAX(queue_position),-1)+1 INTO NEW.queue_position FROM public.vehicle_logs WHERE bay_id=NEW.bay_id AND current_status NOT IN ('Completed','Departed') AND token_no<>NEW.token_no;
  IF NEW.current_status NOT IN ('Unloading','Hold','Completed','Departed') THEN NEW.current_status:='Waiting'; END IF;
 ELSIF NEW.bay_id IS NULL THEN
  NEW.bay_assigned_at:=NULL; NEW.scheduled_start_time:=NULL; NEW.scheduled_end_time:=NULL; NEW.requested_start_time:=NULL; NEW.hold_started_at:=NULL;
 END IF;
 IF TG_OP='UPDATE' AND NEW.bay_id IS NOT NULL AND NEW.scheduled_start_time IS DISTINCT FROM OLD.scheduled_start_time THEN NEW.requested_start_time:=NEW.scheduled_start_time; END IF;
 IF TG_OP='UPDATE' AND OLD.current_status='Unloading' AND (NEW.current_status='Hold' OR (NEW.current_status='Unloading' AND NEW.bay_id IS DISTINCT FROM OLD.bay_id)) THEN
  IF NEW.current_status='Hold' THEN NEW.hold_started_at:=clock_timestamp(); END IF;
  SELECT * INTO cfg FROM public.admin_settings WHERE id='singleton';
  marker:=substring(COALESCE(OLD.hold_notes,'') FROM 'SHIFT_PAUSE:([0-9.]+)');
  paused:=COALESCE(marker::numeric,0)+public.bay_elapsed_minutes(OLD.unload_start_time,clock_timestamp(),cfg.shift_start::time,cfg.shift_end::time)*60000;
  NEW.hold_notes:=concat_ws(E'\n',NULLIF(regexp_replace(COALESCE(NEW.hold_notes,''),'SHIFT_PAUSE:[0-9.]+','','g'),''),'SHIFT_PAUSE:'||paused::text);
 END IF;
 IF NEW.current_status='Unloading' AND (TG_OP='INSERT' OR OLD.current_status IS DISTINCT FROM 'Unloading' OR NEW.bay_id IS DISTINCT FROM OLD.bay_id) THEN
  IF NEW.bay_id IS NULL THEN RAISE EXCEPTION 'Assign the vehicle to a bay before starting unloading'; END IF;
  IF EXISTS(SELECT 1 FROM public.vehicle_logs WHERE bay_id=NEW.bay_id AND token_no<>NEW.token_no AND current_status='Unloading') THEN RAISE EXCEPTION 'This bay is unloading another vehicle. Place it on Hold before starting this vehicle.'; END IF;
  IF OLD.current_status NOT IN ('Hold','Unloading') AND EXISTS(SELECT 1 FROM public.vehicle_logs WHERE bay_id=NEW.bay_id AND token_no<>NEW.token_no AND current_status NOT IN ('Completed','Departed','Hold') AND queue_position<NEW.queue_position) THEN RAISE EXCEPTION 'Start the first vehicle in the bay queue before this vehicle.'; END IF;
  IF TG_OP='UPDATE' AND OLD.current_status='Hold' THEN NEW.hold_notes:=OLD.hold_notes; END IF;
  NEW.unload_start_time:=clock_timestamp();
 END IF;
 IF TG_OP='UPDATE' AND NEW.current_status IN ('Completed','Departed') AND OLD.current_status NOT IN ('Completed','Departed') THEN NEW.scheduled_end_time:=COALESCE(NEW.unload_end_time,NEW.scheduled_end_time); END IF;
 RETURN NEW;
END $$;
CREATE OR REPLACE FUNCTION public.recalculate_bay_schedules() RETURNS void LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE cfg public.admin_settings%ROWTYPE; v public.vehicle_logs%ROWTYPE; bay text; previous_end timestamptz; start_at timestamptz; end_at timestamptz; conflict_end timestamptz; minutes numeric; rate numeric; pos integer; has_active boolean; previous_flag text; paused numeric;
BEGIN
 PERFORM pg_advisory_xact_lock(360,1);
 previous_flag:=current_setting('app.bay_recalculating',true); PERFORM set_config('app.bay_recalculating','on',true);
 SELECT * INTO cfg FROM public.admin_settings WHERE id='singleton';
 IF NOT FOUND OR cfg.shift_end::time<=cfg.shift_start::time THEN RAISE EXCEPTION 'Invalid working shift settings'; END IF;
 rate:=GREATEST(1,(cfg.daily_roll_target+cfg.daily_box_target)/(EXTRACT(epoch FROM cfg.shift_end::time-cfg.shift_start::time)/3600));
 FOREACH bay IN ARRAY ARRAY['BAY-01','BAY-02','BAY-03'] LOOP
  previous_end:=NULL; pos:=0;
  SELECT EXISTS(SELECT 1 FROM public.vehicle_logs WHERE bay_id=bay AND current_status='Unloading') INTO has_active;
  FOR v IN SELECT * FROM public.vehicle_logs WHERE bay_id=bay AND current_status NOT IN ('Completed','Departed') ORDER BY CASE WHEN current_status='Unloading' THEN 0 WHEN current_status='Hold' THEN 1 ELSE 2 END,(COALESCE(requested_start_time,bay_assigned_at) AT TIME ZONE 'Asia/Colombo')::date,queue_position NULLS LAST,COALESCE(requested_start_time,bay_assigned_at),token_no LOOP
   start_at:=GREATEST(COALESCE(v.requested_start_time,v.bay_assigned_at),v.bay_assigned_at);
   IF v.current_status='Hold' THEN start_at:=GREATEST(start_at,v.hold_started_at); END IF;
   IF v.current_status='Unloading' AND v.unload_start_time IS NOT NULL THEN start_at:=v.unload_start_time; END IF;
   start_at:=GREATEST(start_at,previous_end);
   IF start_at IS NULL THEN RAISE EXCEPTION 'Missing bay assignment timestamp for %',v.token_no; END IF;
   IF v.current_status<>'Unloading' THEN start_at:=public.bay_work_start(start_at,cfg.shift_start::time,cfg.shift_end::time); END IF;
   paused:=COALESCE(substring(COALESCE(v.hold_notes,'') FROM 'SHIFT_PAUSE:([0-9.]+)')::numeric,0)/60000;
   minutes:=GREATEST(1,(CASE WHEN COALESCE(v.roll_qty,0)+COALESCE(v.box_qty,0)<=0 THEN 30 ELSE GREATEST(15,ROUND((COALESCE(v.roll_qty,0)+COALESCE(v.box_qty,0))/rate*60)) END)-paused);
   end_at:=public.bay_work_end(start_at,minutes,cfg.shift_start::time,cfg.shift_end::time);
   LOOP
    SELECT MAX(COALESCE(unload_end_time,scheduled_end_time)) INTO conflict_end FROM public.vehicle_logs WHERE bay_id=bay AND token_no<>v.token_no AND current_status IN ('Completed','Departed') AND COALESCE(unload_start_time,scheduled_start_time)<end_at AND COALESCE(unload_end_time,scheduled_end_time)>start_at;
    EXIT WHEN conflict_end IS NULL;
    start_at:=public.bay_work_start(conflict_end,cfg.shift_start::time,cfg.shift_end::time); end_at:=public.bay_work_end(start_at,minutes,cfg.shift_start::time,cfg.shift_end::time);
   END LOOP;
   UPDATE public.vehicle_logs SET scheduled_start_time=start_at,scheduled_end_time=end_at,queue_position=pos,current_status=CASE WHEN current_status IN ('Waiting','Assigned') THEN CASE WHEN NOT has_active AND NOT EXISTS(SELECT 1 FROM public.vehicle_logs ahead WHERE ahead.bay_id=bay AND ahead.token_no<>v.token_no AND ahead.current_status IN ('Waiting','Assigned') AND ahead.queue_position<pos) THEN 'Assigned' ELSE 'Waiting' END ELSE current_status END WHERE token_no=v.token_no AND (scheduled_start_time IS DISTINCT FROM start_at OR scheduled_end_time IS DISTINCT FROM end_at OR queue_position IS DISTINCT FROM pos OR current_status IN ('Waiting','Assigned'));
   previous_end:=end_at; pos:=pos+1;
  END LOOP;
 END LOOP;
 PERFORM set_config('app.bay_recalculating',COALESCE(previous_flag,'off'),true);
END $$;