ALTER TABLE public.segregation_entries ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT '';
ALTER TABLE public.segregation_options DROP CONSTRAINT IF EXISTS segregation_options_kind_check;
ALTER TABLE public.segregation_options ADD CONSTRAINT segregation_options_kind_check CHECK (kind IN ('supplier', 'supplier_concern', 'category', 'packaging_concern'));
COMMENT ON COLUMN public.segregation_entries.category IS 'Issue category selected in the Segregation Area report form.';
COMMENT ON COLUMN public.segregation_entries.note IS 'Optional free-text note attached to a Segregation Area report.';