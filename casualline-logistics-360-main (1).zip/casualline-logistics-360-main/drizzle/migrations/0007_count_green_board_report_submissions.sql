ALTER TABLE public.green_board_entries ADD COLUMN submission_count integer NOT NULL DEFAULT 1 CHECK (submission_count >= 1);
UPDATE public.green_board_entries SET submission_count = 1 + (length(note) - length(replace(note, E'\n— ', ''))) / length(E'\n— ');
COMMENT ON COLUMN public.green_board_entries.submission_count IS 'Report submissions per concern/date/shift; legacy counts inferred from appended-note separators. Note edits do not increment.';
CREATE OR REPLACE FUNCTION public.submit_green_board_report(p_concern_id uuid, p_entry_date date, p_board_key text, p_shift text, p_note text)
RETURNS public.green_board_entries
LANGUAGE plpgsql SECURITY INVOKER SET search_path = public
AS $$
DECLARE saved public.green_board_entries;
BEGIN
 IF p_shift IS NULL OR p_shift NOT IN ('A','B') OR p_note IS NULL OR btrim(p_note) = '' THEN RAISE EXCEPTION 'Select a shift and describe the issue.'; END IF;
 IF NOT EXISTS (SELECT 1 FROM public.green_board_concerns WHERE id = p_concern_id AND board_key = p_board_key AND is_active) THEN RAISE EXCEPTION 'Select an active concern for this area.'; END IF;
 INSERT INTO public.green_board_entries AS e (concern_id, entry_date, board_key, shift, note, submission_count)
 VALUES (p_concern_id, p_entry_date, p_board_key, p_shift, btrim(p_note), 1)
 ON CONFLICT (concern_id, entry_date, board_key, shift) DO UPDATE
 SET note = e.note || E'\n— ' || EXCLUDED.note, submission_count = e.submission_count + 1, updated_at = clock_timestamp()
 RETURNING * INTO saved;
 RETURN saved;
END;
$$;
REVOKE ALL ON FUNCTION public.submit_green_board_report(uuid,date,text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.submit_green_board_report(uuid,date,text,text,text) TO anon, authenticated, service_role;